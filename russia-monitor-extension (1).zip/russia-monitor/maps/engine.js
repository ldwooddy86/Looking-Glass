/* ============================================================================
   LOOKING GLASS · maps/model.js — operating-area likelihood engine (domain-agnostic)
   Pure computation, no DOM. Expects globals GRID (from maps_prep_geo.py) and CFG (theatre config).
   Output: a STRUCTURAL PRIOR over where a DEPLOYED unit of a class would be — never a
   detection, track, patrol box or position. Every factor is declared in the config and
   carries the reference IDs it was built from.
   ---------------------------------------------------------------------------
   Domains (GRID.domain / CFG.grid.domain):
     sea   raster classes = bathymetry bands, 255 = land (impassable). The COUNTDOWN engine.
     land  raster classes = terrain/movement classes (road corridor, cover, open, urban …),
           255 = water or outside the confined territory (impassable). Road-mobile launchers.
     air   raster classes = airspace classes (own, allied, neutral, adversary), nothing
           impassable; movement cost per class stands in for airspace avoidance.
   The engine does not care which: "impassable" and "class" are all it reads. The names
   `land` and `depth` are kept for the sea heritage (and for app.js) — read them as
   `impassable` and `cellClass`.
   ---------------------------------------------------------------------------
   Factor types (config.factors[].type):
     depth | terrain  suitability per raster class (config.depth_suitability[cls] or
                      config.terrain_suitability[cls] — eight multipliers)
     zones          polygon multipliers: zones:[{polygon, mult:{cls:param}}]
     hubs           1 + Σ amp·exp(-d/scale): sets:[{set, scale_nm, amp:{cls:param}}]
     points         Π (1 + amp·exp(-(d/r)^2)): points:[{point, radius_nm, amp:{cls:param}}]
     line_exposure  inside/beyond a polygon + near-line penalty + beyond decay
     pressure       exp(-k·P), P = Σ w·exp(-d/scale) over a weighted point set; optional shield polygon
     proximity      1 + amp·exp(-(dmin/r)^2) over a point set (negative amp = avoidance)
     envelope       soft wall on routed distance from own base: 0.05 + 0.95/(1+exp((d-wall)/60))
   Per-class params: number | {mod, base, gain} (posture) | {default, scenario, value}
   Per-class movement cost: classes[c].shallow_cost (sea heritage: shelf-to-shelf edges ×cost)
   or classes[c].cell_cost (eight multipliers by raster class, averaged over an edge).
   Deployed counts: classes[c].deployed[posture] (alias: at_sea).
   ============================================================================ */
(function (root) {
  'use strict';
  const G = root.GRID, CFG = root.CFG;
  const NC = G.nc, NR = G.nr, STEP = G.step, LON0 = G.lon0, LAT0 = G.lat0;
  const N = NC * NR, NM_PER_DEG = 60.0, R_NM = 3440.065;
  const CELL_NM = STEP * NM_PER_DEG;                   // cell height in nm
  const nmToCells = nm => Math.max(0.35, nm / CELL_NM);
  const DOMAIN = (G.domain || (CFG.grid && CFG.grid.domain) || 'sea');

  // ---- raster ------------------------------------------------------------------
  const ras = new Uint8Array(N); { let p = 0; for (const [v, n] of G.rle) { ras.fill(v, p, p + n); p += n; } }
  const land = new Uint8Array(N), depth = new Uint8Array(N);   // land = impassable, depth = raster class
  for (let i = 0; i < N; i++) { if (ras[i] === 255) { land[i] = 1; } else depth[i] = ras[i]; }
  const lat = new Float64Array(N), lon = new Float64Array(N), cellW = new Float64Array(N), area = new Float64Array(N);
  for (let i = 0; i < N; i++) { const r = (i / NC) | 0, c = i - r * NC; lat[i] = LAT0 + (r + 0.5) * STEP; lon[i] = LON0 + (c + 0.5) * STEP; cellW[i] = CELL_NM * Math.cos(lat[i] * Math.PI / 180); area[i] = cellW[i] * CELL_NM; }
  let seaCount = 0; for (let i = 0; i < N; i++) if (!land[i]) seaCount++;

  // ---- geometry helpers --------------------------------------------------------------
  function hav(lon1, lat1, lon2, lat2) { const la1 = lat1 * Math.PI / 180, la2 = lat2 * Math.PI / 180, dlon = (lon2 - lon1) * Math.PI / 180, dlat = la2 - la1; const a = Math.sin(dlat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dlon / 2) ** 2; return 2 * R_NM * Math.asin(Math.sqrt(Math.min(1, Math.max(0, a)))); }
  const distField = (plon, plat) => { const o = new Float64Array(N); for (let i = 0; i < N; i++) o[i] = hav(lon[i], lat[i], plon, plat); return o; };
  const minField = fields => { const o = new Float64Array(N).fill(Infinity); for (const f of fields) for (let i = 0; i < N; i++) if (f[i] < o[i]) o[i] = f[i]; return o; };
  function pointInPoly(px, py, poly) { let inside = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) { const xi = poly[i][0], yi = poly[i][1], xj = poly[j][0], yj = poly[j][1]; if (((yi > py) !== (yj > py)) && (px < (xj - xi) * (py - yi) / ((yj - yi) || 1e-12) + xi)) inside = !inside; } return inside; }
  const polyMask = poly => { const m = new Uint8Array(N); for (let i = 0; i < N; i++) if (pointInPoly(lon[i], lat[i], poly)) m[i] = 1; return m; };
  function polylineDist(pts) { const out = new Float64Array(N).fill(Infinity); for (let s = 0; s < pts.length - 1; s++) { const x1 = pts[s][0], y1 = pts[s][1], x2 = pts[s + 1][0], y2 = pts[s + 1][1]; const cl = Math.cos(((y1 + y2) / 2) * Math.PI / 180); const bx = (x2 - x1) * cl, by = y2 - y1, bb = bx * bx + by * by || 1e-12; for (let i = 0; i < N; i++) { const ax = (lon[i] - x1) * cl, ay = lat[i] - y1; let t = (ax * bx + ay * by) / bb; t = t < 0 ? 0 : t > 1 ? 1 : t; const dx = ax - t * bx, dy = ay - t * by; const d = Math.sqrt(dx * dx + dy * dy) * NM_PER_DEG; if (d < out[i]) out[i] = d; } } return out; }

  // ---- static layers from config -----------------------------------------------------------
  const POLY = {}; for (const k in (CFG.polygons || {})) POLY[k] = polyMask(CFG.polygons[k].pts);
  const LINE = {}; for (const k in (CFG.lines || {})) LINE[k] = polylineDist(CFG.lines[k].pts);
  const PT = {}; for (const k in (CFG.points || {})) PT[k] = distField(CFG.points[k].lon, CFG.points[k].lat);
  const SET = {}; for (const k in (CFG.point_sets || {})) { const s = CFG.point_sets[k]; SET[k] = { min: minField(s.pts.map(p => distField(p.lon ?? p[0], p.lat ?? p[1]))), pts: s.pts }; }
  const REGION = (CFG.regions || []).map(r => ({ id: r.id, name: r.name, mask: polyMask(r.pts) }));
  const regionOf = new Int16Array(N).fill(-1); REGION.forEach((rg, ri) => { for (let i = 0; i < N; i++) if (regionOf[i] < 0 && rg.mask[i]) regionOf[i] = ri; });
  const pressureCache = {};
  function pressureField(setKey, scale) { const key = setKey + '|' + scale; if (pressureCache[key]) return pressureCache[key]; const P = new Float64Array(N); for (const p of CFG.point_sets[setKey].pts) { const f = distField(p.lon, p.lat); const w = p.w == null ? 1 : p.w; for (let i = 0; i < N; i++) P[i] += w * Math.exp(-f[i] / scale); } pressureCache[key] = P; return P; }

  // ---- movement cost -----------------------------------------------------------------------
  // Sea heritage: shallow_cost multiplies shelf-to-shelf edges (class 0 → class 0).
  // General form: cell_cost[8] multiplies every edge by the mean cost of its two cells.
  function costSpec(cls) { const c = CFG.classes[cls] || {}; const tab = Array.isArray(c.cell_cost) && c.cell_cost.length === 8 ? c.cell_cost.map(Number) : null; return { shallow: c.shallow_cost || 1, tab }; }
  const costKey = spec => (spec.tab ? 'T' + spec.tab.join(',') : 'S' + spec.shallow);

  // ---- 16-neighbour Dijkstra ----------------------------------------------------------------
  const MOVES = []; for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) { if (!dr && !dc) continue; if (Math.abs(dr) === 2 && Math.abs(dc) === 2) continue; if ((Math.abs(dr) === 2 && dc === 0) || (Math.abs(dc) === 2 && dr === 0)) continue; MOVES.push([dr, dc]); }
  function passable(r, c, dr, dc) { const rr = r + dr, cc = c + dc; if (rr < 0 || rr >= NR || cc < 0 || cc >= NC) return false; if (land[rr * NC + cc]) return false; if (Math.abs(dr) === 1 && Math.abs(dc) === 1) { if (land[r * NC + cc] && land[rr * NC + c]) return false; } else if (Math.abs(dr) === 2 || Math.abs(dc) === 2) { const m1r = r + (Math.abs(dr) === 2 ? dr / 2 : dr), m1c = c + (Math.abs(dc) === 2 ? dc / 2 : 0); const m2r = r + (Math.abs(dr) === 2 ? dr / 2 : 0), m2c = c + (Math.abs(dc) === 2 ? dc / 2 : dc); if (land[m1r * NC + m1c] || land[m2r * NC + m2c]) return false; } return true; }
  function nearestSea(plon, plat) { const c0 = Math.floor((plon - LON0) / STEP), r0 = Math.floor((plat - LAT0) / STEP); let best = -1, bd = Infinity; for (let dr = -8; dr <= 8; dr++) for (let dc = -8; dc <= 8; dc++) { const r = r0 + dr, c = c0 + dc; if (r < 0 || r >= NR || c < 0 || c >= NC) continue; const i = r * NC + c; if (land[i]) continue; const d = dr * dr + dc * dc; if (d < bd) { bd = d; best = i; } } return best; }
  class Heap { constructor() { this.k = []; this.v = []; } push(key, val) { const k = this.k, v = this.v; k.push(key); v.push(val); let i = k.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (k[p] <= k[i]) break; [k[p], k[i]] = [k[i], k[p]]; [v[p], v[i]] = [v[i], v[p]]; i = p; } } pop() { const k = this.k, v = this.v; const top = [k[0], v[0]]; const lk = k.pop(), lv = v.pop(); if (k.length) { k[0] = lk; v[0] = lv; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < k.length && k[l] < k[m]) m = l; if (r < k.length && k[r] < k[m]) m = r; if (m === i) break; [k[m], k[i]] = [k[i], k[m]]; [v[m], v[i]] = [v[i], v[m]]; i = m; } } return top; } get size() { return this.k.length; } }
  function dijkstra(src, spec) {
    const dist = new Float64Array(N).fill(Infinity); dist[src] = 0; const h = new Heap(); h.push(0, src);
    const shallowCost = spec.shallow, tab = spec.tab;
    while (h.size) { const [d, u] = h.pop(); if (d > dist[u]) continue; const r = (u / NC) | 0, c = u - r * NC;
      for (const [dr, dc] of MOVES) { if (!passable(r, c, dr, dc)) continue; const v = (r + dr) * NC + (c + dc); let w = Math.hypot(dc * cellW[u], dr * CELL_NM);
        if (tab) w *= 0.5 * (tab[depth[u]] + tab[depth[v]]);
        else if (shallowCost > 1 && depth[v] === 0 && depth[u] === 0) w *= shallowCost;
        const nd = d + w; if (nd < dist[v]) { dist[v] = nd; h.push(nd, v); } } }
    const idx = []; for (let i = 0; i < N; i++) if (isFinite(dist[i])) idx.push(i); idx.sort((a, b) => dist[b] - dist[a]);
    return { dist, order: Uint32Array.from(idx) };
  }
  const SRC = {};   // key: base|cost
  function srcFor(baseKey, shallowOrSpec) { const spec = (shallowOrSpec && typeof shallowOrSpec === 'object') ? shallowOrSpec : { shallow: shallowOrSpec || 1, tab: null }; const k = baseKey + '|' + costKey(spec); if (!SRC[k]) { const b = CFG.bases[baseKey]; if (!b) throw new Error('unknown base ' + baseKey); const cell = nearestSea(b.lon, b.lat); if (cell < 0) throw new Error('no passable cell near base ' + baseKey); SRC[k] = dijkstra(cell, spec); SRC[k].cell = cell; } return SRC[k]; }
  const srcForClass = (baseKey, cls) => srcFor(baseKey, costSpec(cls));

  // ---- multiple-flow-direction accumulation --------------------------------------------------
  const MFD_P = 4;
  function flow(p, src) { const { dist, order } = src; const F = Float64Array.from(p); const nb = new Array(16), nw = new Float64Array(16);
    for (let oi = 0; oi < order.length; oi++) { const u = order[oi]; if (F[u] === 0) continue; const r = (u / NC) | 0, c = u - r * NC, du = dist[u]; let k = 0, wsum = 0;
      for (const [dr, dc] of MOVES) { if (!passable(r, c, dr, dc)) continue; const v = (r + dr) * NC + (c + dc), dv = dist[v]; if (dv < du - 1e-6) { const len = Math.hypot(dc * cellW[u], dr * CELL_NM); const w = Math.pow((du - dv) / len, MFD_P); nb[k] = v; nw[k] = w; wsum += w; k++; } }
      if (!wsum) continue; const fu = F[u]; for (let j = 0; j < k; j++) F[nb[j]] += fu * nw[j] / wsum; }
    return F; }
  function blurSea(x, sigmaCells) { const sigma = Math.max(0.3, sigmaCells); const rad = Math.ceil(sigma * 3); const ker = []; let ks = 0; for (let k = -rad; k <= rad; k++) { const w = Math.exp(-(k * k) / (2 * sigma * sigma)); ker.push(w); ks += w; } for (let k = 0; k < ker.length; k++) ker[k] /= ks;
    const tmp = new Float64Array(N), tmpm = new Float64Array(N), out = new Float64Array(N); let tot = 0; for (let i = 0; i < N; i++) tot += x[i];
    for (let r = 0; r < NR; r++) for (let c = 0; c < NC; c++) { let s = 0, sm = 0; for (let k = -rad; k <= rad; k++) { const cc = c + k; if (cc < 0 || cc >= NC) continue; const j = r * NC + cc; if (land[j]) continue; const w = ker[k + rad]; s += x[j] * w; sm += w; } tmp[r * NC + c] = s; tmpm[r * NC + c] = sm; }
    for (let r = 0; r < NR; r++) for (let c = 0; c < NC; c++) { const i = r * NC + c; if (land[i]) continue; let s = 0, sm = 0; for (let k = -rad; k <= rad; k++) { const rr = r + k; if (rr < 0 || rr >= NR) continue; const j = rr * NC + c; if (land[j]) continue; const w = ker[k + rad]; s += tmp[j] * w; sm += tmpm[j] * w; } out[i] = sm > 0 ? s / sm : 0; }
    let ot = 0; for (let i = 0; i < N; i++) ot += out[i]; if (ot > 0) { const f = tot / ot; for (let i = 0; i < N; i++) out[i] *= f; } return out; }

  // ---- parameter resolution ---------------------------------------------------------------------
  function withCtx(ctx) { if (!ctx.pm) ctx.pm = (CFG.postures && CFG.postures.modifiers && CFG.postures.modifiers[ctx.posture]) || {}; if (!ctx.enabled) ctx.enabled = {}; if (!ctx.scenarios) ctx.scenarios = {}; return ctx; }
  function resolve(v, ctx, dflt) { if (v == null) return dflt == null ? 1 : dflt; if (typeof v === 'number') return v; if (typeof v === 'object') { if (v.scenario && ctx.scenarios[v.scenario]) return v.value; if (v.mod != null) { const m = ctx.pm[v.mod]; const mv = m == null ? 1 : m; return (v.base == null ? 0 : v.base) + (v.gain == null ? 1 : v.gain) * mv; } if (v.default != null) return v.default; } return dflt == null ? 1 : dflt; }
  const P = (obj, cls, ctx, dflt) => resolve(obj ? obj[cls] : undefined, ctx, dflt);
  const suitTable = cls => (CFG.terrain_suitability && CFG.terrain_suitability[cls]) || (CFG.depth_suitability && CFG.depth_suitability[cls]) || [1, 1, 1, 1, 1, 1, 1, 1];
  const deployedOf = cls => (CFG.classes[cls].deployed || CFG.classes[cls].at_sea || {});
  // Source shares may switch under a scenario: classes[c].sources_scenarios = { <scenarioId>: { base: share } }.
  function srcShares(cls, ctx) { withCtx(ctx); const c = CFG.classes[cls]; const alt = c.sources_scenarios || {}; for (const id in alt) if (ctx.scenarios[id]) return alt[id]; return c.sources; }

  // ---- factor evaluators --------------------------------------------------------------------------
  const bump = (d, r, a) => 1 + a * Math.exp(-((d / r) * (d / r)));
  const EVAL = {
    depth: (F, cls, ctx) => { const t = suitTable(cls); return i => t[depth[i]]; },
    zones: (F, cls, ctx) => { const zs = F.zones.map(z => ({ m: POLY[z.polygon], v: P(z.mult, cls, ctx, 1) })).filter(z => z.m); return i => { let v = 1; for (const z of zs) if (z.m[i]) v *= z.v; return v; }; },
    hubs: (F, cls, ctx) => { const ss = F.sets.map(s => ({ d: SET[s.set].min, sc: s.scale_nm, a: P(s.amp, cls, ctx, 0) })); return i => { let v = 1; for (const s of ss) v += s.a * Math.exp(-s.d[i] / s.sc); return v; }; },
    points: (F, cls, ctx) => { const ps = F.points.map(p => ({ d: PT[p.point], r: p.radius_nm || (CFG.points[p.point] && CFG.points[p.point].radius_nm) || 60, a: P(p.amp, cls, ctx, 0) })).filter(p => p.d); return i => { let v = 1; for (const p of ps) v *= bump(p.d[i], p.r, p.a); return v; }; },
    line_exposure: (F, cls, ctx) => { const inside = F.inside_polygon ? POLY[F.inside_polygon] : null; const dl = F.line ? LINE[F.line] : null; const near = P(F.near_penalty, cls, ctx, 0), width = F.width_nm || 70; const beyond = P(F.beyond_mult, cls, ctx, 1); const bd = F.beyond_decay_nm ? P(F.beyond_decay_nm, cls, ctx, 0) : 0;
      return i => { let v = 1; const isIn = inside ? !!inside[i] : true; if (!isIn) { v *= beyond; if (bd > 0 && dl) v *= Math.exp(-dl[i] / bd); } if (dl && near > 0) v *= 1 - near * Math.exp(-((dl[i] / width) ** 2)); return v; }; },
    pressure: (F, cls, ctx) => { const Pf = pressureField(F.set, F.scale_nm || 280); const k = P(F.k, cls, ctx, 0); const shield = F.shield && POLY[F.shield.polygon] ? { m: POLY[F.shield.polygon], s: P(F.shield.scale, cls, ctx, F.shield.scale) } : null; return i => { let p = Pf[i]; if (shield && shield.m[i]) p *= (typeof shield.s === 'number' ? shield.s : 1); return Math.exp(-k * p); }; },
    proximity: (F, cls, ctx) => { const d = SET[F.set].min; const r = P(F.radius_nm, cls, ctx, 45), a = P(F.amp, cls, ctx, 0); return i => 1 + a * Math.exp(-((d[i] / r) ** 2)); },
    envelope: () => () => 1   // handled per source in sourceTerms (needs own-base distance)
  };
  EVAL.terrain = EVAL.depth;
  function factorFns(cls, ctx) { withCtx(ctx); const out = []; for (const F of CFG.factors) { if (ctx.enabled[F.id] === false) continue; const mk = EVAL[F.type]; if (!mk) continue; if (F.classes && !F.classes.includes(cls)) continue; out.push({ id: F.id, fn: mk(F, cls, ctx) }); } return out; }
  function prior(cls, ctx) { const fns = factorFns(cls, ctx); const f = new Float64Array(N); for (let i = 0; i < N; i++) { if (land[i]) continue; let v = 1; for (const F of fns) v *= F.fn(i); f[i] = v; } return f; }
  function factorBreakdown(cls, i, ctx) { withCtx(ctx); return CFG.factors.filter(F => !F.classes || F.classes.includes(cls)).map(F => { const on = ctx.enabled[F.id] !== false; let mult = 1; if (F.type === 'envelope') { const cfg = CFG.classes[cls]; const wall = P(F.wall_nm, cls, ctx, 0); if (wall > 0) { let best = Infinity; for (const sk in srcShares(cls, ctx)) { const d = srcForClass(sk, cls).dist[i]; if (d < best) best = d; } mult = isFinite(best) ? 0.05 + 0.95 / (1 + Math.exp((best - wall) / 60)) : 1; } } else { const mk = EVAL[F.type]; mult = mk ? mk(F, cls, ctx)(i) : 1; } return { id: F.id, label: F.label, on, mult }; }); }

  // ---- surfaces -------------------------------------------------------------------------------------
  function sourceTerms(cls, key, basePrior, ctx) {
    const cfg = CFG.classes[cls]; const src = srcForClass(key, cls);
    const lam = (cfg.source_decay && cfg.source_decay[key]) || cfg.decay_nm || 600;
    const envF = CFG.factors.find(F => F.type === 'envelope' && ctx.enabled[F.id] !== false && (!F.classes || F.classes.includes(cls))); const wall = envF ? P(envF.wall_nm, cls, ctx, 0) : 0;
    const p = new Float64Array(N); let tot = 0;
    for (let i = 0; i < N; i++) { const d = src.dist[i]; if (!isFinite(d) || land[i]) continue; let v = basePrior[i] * Math.exp(-d / lam); if (wall > 0) v *= 0.05 + 0.95 / (1 + Math.exp((d - wall) / 60)); p[i] = v; tot += v; }
    if (tot > 0) for (let i = 0; i < N; i++) p[i] /= tot;
    return { p, F: flow(p, src), dist: src.dist };
  }
  const BL = Object.assign({ transit_blur_nm: 36, ring_blur_nm: 24, ring_width_nm: 9, speed_mix: [[0.75, 0.25], [1.0, 0.5], [1.25, 0.25]] }, CFG.routing || {});
  const STEP_NM = CELL_NM * 1.15;
  function timeSurface(terms, v, hours, patrolDays) { const { p, F, dist } = terms; const out = new Float64Array(N);
    if (hours == null) { const vT = v * patrolDays * 24; const tr = new Float64Array(N); for (let i = 0; i < N; i++) { if (!isFinite(dist[i])) continue; out[i] = p[i] * Math.max(0, 1 - 2 * dist[i] / vT); tr[i] = Math.max(0, F[i] - p[i]) * (2 * STEP_NM / vT); } const trb = blurSea(tr, nmToCells(BL.transit_blur_nm)); for (let i = 0; i < N; i++) out[i] += trb[i]; }
    else { for (const [vf, vw] of BL.speed_mix) { const R = v * vf * hours; const ring = new Float64Array(N), onst = new Float64Array(N); let mOn = 0, rs = 0; for (let i = 0; i < N; i++) { const d = dist[i]; if (!isFinite(d)) continue; if (d <= R) { onst[i] = p[i]; mOn += p[i]; } const k = Math.exp(-(((d - R) / BL.ring_width_nm) ** 2)); const t = Math.max(0, F[i] - p[i]) * k; ring[i] = t; rs += t; } const mTr = Math.max(0, 1 - mOn); if (rs > 0) { const f = mTr / rs; for (let i = 0; i < N; i++) ring[i] *= f; } const rb = blurSea(ring, nmToCells(BL.ring_blur_nm)); for (let i = 0; i < N; i++) out[i] += vw * (onst[i] + rb[i]); } }
    let s = 0; for (let i = 0; i < N; i++) s += out[i]; if (s > 0) for (let i = 0; i < N; i++) out[i] /= s; return out; }
  const MAINT = {};
  function maintenanceRoute(cls) { if (MAINT[cls]) return MAINT[cls]; const mt = CFG.classes[cls].maintenance_transit; const src = mt.plain_routing ? srcFor(mt.from, 1) : srcForClass(mt.from, cls); const target = nearestSea(CFG.bases[mt.to].lon, CFG.bases[mt.to].lat); const p = new Float64Array(N); p[target] = 1; const F = flow(p, src); const out = new Float64Array(N); let s = 0; for (let i = 0; i < N; i++) { if (!isFinite(src.dist[i])) continue; out[i] = Math.max(0, F[i] - p[i]); s += out[i]; } if (s > 0) for (let i = 0; i < N; i++) out[i] /= s; MAINT[cls] = blurSea(out, nmToCells(mt.blur_nm || 26)); return MAINT[cls]; }
  const CACHE = {};
  function classSurface(cls, ctx) { withCtx(ctx); const cfg = CFG.classes[cls]; const key = JSON.stringify([cls, ctx.posture, ctx.scenarios, ctx.enabled]); let terms = CACHE[key];
    const shares = srcShares(cls, ctx);
    if (!terms) { const bp = prior(cls, ctx); terms = {}; for (const sk in shares) terms[sk] = sourceTerms(cls, sk, bp, ctx); for (const k in CACHE) delete CACHE[k]; CACHE[key] = terms; }
    const out = new Float64Array(N); let wsum = 0; for (const sk in shares) { const w = shares[sk]; wsum += w; const s = timeSurface(terms[sk], cfg.speed_kts, ctx.hours, cfg.patrol_days || 30); for (let i = 0; i < N; i++) out[i] += w * s[i]; } for (let i = 0; i < N; i++) out[i] /= wsum;
    const mt = cfg.maintenance_transit; if (mt && (!mt.factor || ctx.enabled[mt.factor] !== false)) { const M = maintenanceRoute(cls); const wm = mt.weight || 0.03; for (let i = 0; i < N; i++) out[i] = (1 - wm) * out[i] + wm * M[i]; }
    return out; }
  function combinedSurface(ctx) { withCtx(ctx); const out = new Float64Array(N); let tot = 0; for (const cls in CFG.classes) { const n = deployedOf(cls)[ctx.posture] || 0; if (!n) continue; const s = classSurface(cls, ctx); for (let i = 0; i < N; i++) out[i] += n * s[i]; tot += n; } if (tot > 0) for (let i = 0; i < N; i++) out[i] /= tot; return out; }

  // ---- analytics ---------------------------------------------------------------------------------------
  function hdr(pdf) { const dens = new Float64Array(N); const idx = []; for (let i = 0; i < N; i++) { if (land[i] || pdf[i] <= 0) continue; dens[i] = pdf[i] / area[i]; idx.push(i); } idx.sort((a, b) => dens[b] - dens[a]); const coord = new Float64Array(N); let cum = 0, ar = 0; const levels = { 0.5: null, 0.8: null, 0.95: null }, areas = { 0.5: 0, 0.8: 0, 0.95: 0 }; for (const i of idx) { cum += pdf[i]; ar += area[i]; coord[i] = cum; for (const q of [0.5, 0.8, 0.95]) if (levels[q] === null && cum >= q) { levels[q] = dens[i]; areas[q] = ar; } } return { dens, coord, levels, areas, ranked: idx }; }
  function regionMass(pdf) { const m = new Float64Array(REGION.length); let other = 0; for (let i = 0; i < N; i++) { if (!pdf[i]) continue; const r = regionOf[i]; if (r >= 0) m[r] += pdf[i]; else other += pdf[i]; } const rows = REGION.map((rg, k) => ({ id: rg.id, name: rg.name, mass: m[k] })); rows.push({ id: 'other', name: 'Elsewhere in frame', mass: other }); rows.sort((a, b) => b.mass - a.mass); return rows; }
  function transitSplit(cls, ctx) { withCtx(ctx); const cfg = CFG.classes[cls]; const key = JSON.stringify([cls, ctx.posture, ctx.scenarios, ctx.enabled]); const terms = CACHE[key]; if (!terms) return null; const shares = srcShares(cls, ctx); let on = 0, wsum = 0; for (const sk in shares) { const w = shares[sk]; wsum += w; const { p, dist } = terms[sk]; let s = 0; if (ctx.hours == null) { const vT = cfg.speed_kts * (cfg.patrol_days || 30) * 24; for (let i = 0; i < N; i++) if (isFinite(dist[i])) s += p[i] * Math.max(0, 1 - 2 * dist[i] / vT); } else { const R = cfg.speed_kts * ctx.hours; for (let i = 0; i < N; i++) if (isFinite(dist[i]) && dist[i] <= R) s += p[i]; } on += w * s; } return on / wsum; }
  function contours(dens, level) { const segs = []; const val = (r, c) => { const i = r * NC + c; return land[i] ? 0 : dens[i]; }; const lerp = (a, b) => { const d = b - a; return Math.abs(d) < 1e-30 ? 0.5 : Math.min(1, Math.max(0, (level - a) / d)); };
    for (let r = 0; r < NR - 1; r++) for (let c = 0; c < NC - 1; c++) { const v0 = val(r, c), v1 = val(r, c + 1), v2 = val(r + 1, c + 1), v3 = val(r + 1, c); const code = (v0 >= level ? 1 : 0) | ((v1 >= level ? 1 : 0) << 1) | ((v2 >= level ? 1 : 0) << 2) | ((v3 >= level ? 1 : 0) << 3); if (code === 0 || code === 15) continue; const top = [c + lerp(v0, v1), r], right = [c + 1, r + lerp(v1, v2)], bottom = [c + lerp(v3, v2), r + 1], left = [c, r + lerp(v0, v3)]; const add = (a, b) => segs.push([a, b]);
      switch (code) { case 1: case 14: add(left, top); break; case 2: case 13: add(top, right); break; case 3: case 12: add(left, right); break; case 4: case 11: add(right, bottom); break; case 5: add(left, top); add(right, bottom); break; case 6: case 9: add(top, bottom); break; case 7: case 8: add(left, bottom); break; case 10: add(top, right); add(left, bottom); break; } }
    return segs; }

  root.MODEL = { N, NC, NR, STEP, LON0, LAT0, DOMAIN, land, depth, lat, lon, area, seaCount, regionOf, REGION, POLY, LINE, SET, PT, srcFor, srcForClass, costSpec, deployedOf, srcShares, prior, classSurface, combinedSurface, hdr, regionMass, transitSplit, contours, factorBreakdown, hav, pressureField,
    cellIndex: (plon, plat) => { const c = Math.floor((plon - LON0) / STEP), r = Math.floor((plat - LAT0) / STEP); if (c < 0 || c >= NC || r < 0 || r >= NR) return -1; return r * NC + c; } };
})(typeof window !== 'undefined' ? window : globalThis);

/* LOOKING GLASS · maps/app.js — rendering, interaction and readouts (config-driven, domain-agnostic)
   Sea (COUNTDOWN heritage), land (road-mobile launcher dispersal) and air (strike / support aircraft
   sortie areas) theatres share this file. Vocabulary, base-map layers, marker glyphs and the optional
   live overlay are all driven by the theatre config and the geodata that maps_prep_geo.py produced. */
(function () {
  'use strict';
  const M = window.MODEL, CFG = window.CFG, G = window.GRID, GEO = window.GEO;
  const PR = GEO.proj, W = GEO.W, H = GEO.H;
  const DOMAIN = M.DOMAIN || 'sea';
  const $ = s => document.querySelector(s);
  const fmt = (n, d = 0) => (isFinite(n) ? n : 0).toLocaleString('en-US', { maximumFractionDigits: d, minimumFractionDigits: d });
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const D2R = Math.PI / 180;

  // ---- vocabulary (per domain, overridable per theatre via CFG.vocab) --------------------------------
  const VOCAB = {
    sea: { unit: 'boat', units: 'boats', deployed: 'at sea', home: 'port', areas: 'named sea areas', cell: 'sea cell', cells: 'sea cells', distance: 'Sea distance', sortie: 'sortie', onstation: 'On station', onstation_l: 'on station', transit: 'in transit', patrol: 'patrol', water: 'water' },
    land: { unit: 'launcher', units: 'launchers', deployed: 'in the field', home: 'garrison', areas: 'named dispersal areas', cell: 'passable cell', cells: 'passable cells', distance: 'Road distance', sortie: 'leaving garrison', onstation: 'In field positions', onstation_l: 'in field positions', transit: 'on the move', patrol: 'field deployment', water: 'ground' },
    air: { unit: 'aircraft', units: 'aircraft', deployed: 'airborne', home: 'air base', areas: 'named airspace areas', cell: 'airspace cell', cells: 'airspace cells', distance: 'Routed distance', sortie: 'take-off', onstation: 'On station / orbit', onstation_l: 'on station', transit: 'in transit', patrol: 'sortie', water: 'airspace' }
  };
  const V = Object.assign({}, VOCAB[DOMAIN] || VOCAB.sea, CFG.vocab || {});
  const cap = s => s.charAt(0).toUpperCase() + s.slice(1);

  // ---- projection (same maths as maps_prep_geo.py) --------------------------------------------------
  const merc = lat => Math.log(Math.tan(Math.PI / 4 + lat * D2R / 2));
  function rawProj(lon, lat) {
    if (PR.type === 'lcc') { const phi = Math.max(-89, Math.min(89, lat)) * D2R; const rho = PR.F / Math.pow(Math.tan(Math.PI / 4 + phi / 2), PR.n); const th = PR.n * (lon - PR.lon0) * D2R; return [rho * Math.sin(th), PR.rho0 - rho * Math.cos(th)]; }
    return [lon, merc(Math.max(-85, Math.min(85, lat))) / D2R];
  }
  function proj(lon, lat) { const [X, Y] = rawProj(lon, lat); return [(X - PR.minX) * PR.S, (PR.maxY - Y) * PR.S]; }
  function unproj(x, y) { const X = x / PR.S + PR.minX, Y = PR.maxY - y / PR.S;
    if (PR.type === 'lcc') { const dy = PR.rho0 - Y; const rho = Math.sign(PR.n) * Math.sqrt(X * X + dy * dy); const th = Math.atan2(PR.n >= 0 ? X : -X, PR.n >= 0 ? dy : -dy); const phi = 2 * Math.atan(Math.pow(PR.F / rho, 1 / PR.n)) - Math.PI / 2; return [PR.lon0 + th / PR.n / D2R, phi / D2R]; }
    return [X, (2 * Math.atan(Math.exp(Y * D2R)) - Math.PI / 2) / D2R]; }
  const path = (pts, close) => pts.map((p, i) => (i ? 'L' : 'M') + proj(p[0], p[1]).map(v => v.toFixed(1)).join(',')).join('') + (close ? 'Z' : '');
  const geodesicPath = (pts, close) => { const out = []; for (let s = 0; s < pts.length - (close ? 0 : 1); s++) { const a = pts[s], b = pts[(s + 1) % pts.length]; const n = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / 1.0)); for (let k = 0; k < n; k++) out.push([a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n]); } if (!close) out.push(pts[pts.length - 1]); return path(out, close); };
  const nmToPx = (nm, lat) => { const [x1, y1] = proj(0 + CFG.grid.lon0 + 1, lat), [x2, y2] = proj(CFG.grid.lon0 + 1, lat + 1); return nm / 60 * Math.hypot(x2 - x1, y2 - y1); };

  // ---- state -----------------------------------------------------------------------------------------------
  const CLASSES = Object.keys(CFG.classes);
  const SERIES = {}; CLASSES.forEach(c => SERIES[c] = CFG.classes[c].colour || '#C97F1E'); SERIES.all = '#C9D3E3';
  const CLABEL = {}; CLASSES.forEach(c => CLABEL[c] = CFG.classes[c].label); CLABEL.all = `All classes (${V.unit}-weighted)`;
  const TIME_STEPS = (CFG.ui && CFG.ui.time_steps) || [6, 12, 24, 48, 72, 120, 168, 240, 336, null];
  const timeLabel = h => h == null ? `${cap(V.patrol)} average` : h < 48 ? `T + ${h} h after ${V.sortie}` : `T + ${h / 24} days after ${V.sortie}`;
  const LEVELS = (CFG.postures && CFG.postures.levels) || ['guarded', 'elevated', 'high', 'severe'];
  const LEVEL_LABEL = (CFG.postures && CFG.postures.labels) || {};
  const state = { cls: (CFG.ui && CFG.ui.default_class) || CLASSES[0], tIdx: TIME_STEPS.length - 1, posture: CFG.meta.posture_default || LEVELS[1] || LEVELS[0], scenarios: {}, enabled: {},
    layers: Object.assign({ contours: true, bases: true, chokes: true, lines: true, hubs: true, asw: true, events: true, zones: false, labels: true, graticule: true, live: true }, (CFG.ui && CFG.ui.layers) || {}) };
  let cur = { surface: null, hdr: null, ctx: null };

  // ---- SVG scaffolding -----------------------------------------------------------------------------------------
  const NS = 'http://www.w3.org/2000/svg';
  const el = (tag, attrs, parent) => { const e = document.createElementNS(NS, tag); for (const k in attrs) if (attrs[k] != null) e.setAttribute(k, attrs[k]); if (parent) parent.appendChild(e); return e; };
  const svg = $('#overlay'), base = $('#base');
  const layers = { sheet: el('g', { id: 'L-sheet' }, base), bathy: el('g', { id: 'L-bathy' }, base) };
  for (const id of ['land', 'graticule', 'zones', 'lines', 'hubs', 'asw', 'chokes', 'events', 'contours', 'live', 'bases', 'labels']) layers[id] = el('g', { id: 'L-' + id }, svg);
  const markers = [];
  function mk(parent, x, y, draw) { const g = el('g', { class: 'mk', transform: `translate(${x},${y})` }, parent); g.__xy = [x, y]; draw(g); markers.push(g); return g; }
  function txt(g, s, dx, dy, o = {}) { const t = el('text', { x: dx, y: dy, fill: o.fill || 'var(--dim)', 'font-size': o.size || 10, 'font-family': 'var(--mono)', 'text-anchor': o.anchor || 'start', 'letter-spacing': o.ls || '.06em', 'paint-order': 'stroke', stroke: 'rgba(10,17,30,.85)', 'stroke-width': 3, 'stroke-linejoin': 'round', 'font-weight': o.weight || 500 }, g); t.textContent = s; return t; }
  const lab = (arr, dflt) => Array.isArray(arr) && arr.length >= 3 ? arr : dflt;

  // map sheet: the lat/lon bbox as drawn by the projection (a trapezoid under LCC)
  { const g = CFG.grid, e = []; const n = 120;
    for (let i = 0; i <= n; i++) e.push([g.lon0 + (g.lon1 - g.lon0) * i / n, g.lat1]);
    for (let i = 0; i <= n; i++) e.push([g.lon1, g.lat1 - (g.lat1 - g.lat0) * i / n]);
    for (let i = 0; i <= n; i++) e.push([g.lon1 - (g.lon1 - g.lon0) * i / n, g.lat0]);
    for (let i = 0; i <= n; i++) e.push([g.lon0, g.lat0 + (g.lat1 - g.lat0) * i / n]);
    el('path', { d: path(e, true), fill: DOMAIN === 'sea' ? 'var(--sea)' : 'var(--sheet)', stroke: 'var(--line)', 'stroke-width': 1, 'vector-effect': 'non-scaling-stroke' }, layers.sheet); }

  // base map — generic layer list from prep_geo (sea heritage keys still honoured)
  if (Array.isArray(GEO.layers) && GEO.layers.length) {
    for (const L of GEO.layers) { if (!L.d) continue; const parent = L.group === 'land' ? layers.land : layers.bathy;
      el('path', { d: L.d, fill: L.fill || 'none', stroke: L.stroke || null, 'stroke-width': L.width || null, 'stroke-dasharray': L.dash || null, opacity: L.opacity == null ? null : L.opacity, 'fill-rule': L.fill && L.fill !== 'none' ? 'evenodd' : null, 'vector-effect': 'non-scaling-stroke', 'data-layer': L.id }, parent); }
  } else {
    el('path', { d: GEO.shelf, fill: 'var(--shelf)' }, layers.bathy); el('path', { d: GEO.deep, fill: 'var(--deep)' }, layers.bathy); el('path', { d: GEO.abyss, fill: 'var(--abyss)' }, layers.bathy);
    el('path', { d: GEO.shelf, fill: 'none', stroke: '#1E3354', 'stroke-width': .6, 'vector-effect': 'non-scaling-stroke' }, layers.bathy); el('path', { d: GEO.deep, fill: 'none', stroke: '#152744', 'stroke-width': .6, 'vector-effect': 'non-scaling-stroke' }, layers.bathy);
    if (GEO.ice) el('path', { d: GEO.ice, fill: 'rgba(200,220,240,.07)', stroke: '#6E88AA', 'stroke-width': .7, 'stroke-dasharray': '3 3', 'vector-effect': 'non-scaling-stroke' }, layers.bathy);
    el('path', { d: GEO.land, fill: 'var(--landfill)', stroke: 'var(--coast)', 'stroke-width': .7, 'vector-effect': 'non-scaling-stroke' }, layers.land);
  }
  // graticule
  { const gs = CFG.grid.graticule || 5; const lon0 = Math.ceil(CFG.grid.lon0 / gs) * gs, lat0 = Math.ceil(CFG.grid.lat0 / gs) * gs;
    for (let lo = lon0; lo <= CFG.grid.lon1; lo += gs) { const pts = []; for (let la = CFG.grid.lat0; la <= CFG.grid.lat1 + 1e-9; la += 0.5) pts.push([lo, Math.min(la, CFG.grid.lat1)]); el('path', { d: path(pts), fill: 'none', stroke: '#1C2C48', 'stroke-width': .5, 'vector-effect': 'non-scaling-stroke' }, layers.graticule); }
    for (let la = lat0; la <= CFG.grid.lat1; la += gs) { const pts = []; for (let lo = CFG.grid.lon0; lo <= CFG.grid.lon1 + 1e-9; lo += 0.5) pts.push([Math.min(lo, CFG.grid.lon1), la]); el('path', { d: path(pts), fill: 'none', stroke: '#1C2C48', 'stroke-width': .5, 'vector-effect': 'non-scaling-stroke' }, layers.graticule); }
    for (let lo = lon0; lo <= CFG.grid.lon1; lo += gs * 2) { const [x, y] = proj(lo, CFG.grid.lat0 + 0.6); mk(layers.graticule, x, y, g => txt(g, `${Math.abs(lo)}°${lo < 0 ? 'W' : 'E'}`, 0, 0, { fill: '#3E5375', size: 9, anchor: 'middle' })); }
    for (let la = lat0; la <= CFG.grid.lat1; la += gs * 2) { const [x, y] = proj(CFG.grid.lon0 + 0.4, la); mk(layers.graticule, x, y, g => txt(g, `${Math.abs(la)}°${la < 0 ? 'S' : 'N'}`, 0, -3, { fill: '#3E5375', size: 9 })); } }
  // zones (polygons)
  for (const k in (CFG.polygons || {})) { const Pg = CFG.polygons[k]; const st = Pg.style || {}; if (st.show === false) continue; const col = st.colour || '#C97F1E';
    el('path', { d: geodesicPath(Pg.pts, true), fill: col, 'fill-opacity': st.fill == null ? .05 : st.fill, stroke: col, 'stroke-width': st.width || .8, 'stroke-dasharray': st.dash || '4 3', 'vector-effect': 'non-scaling-stroke', opacity: .9 }, layers.zones);
    if (st.label !== false) { const c = Pg.pts.reduce((a, p) => [a[0] + p[0] / Pg.pts.length, a[1] + p[1] / Pg.pts.length], [0, 0]); const [x, y] = proj(c[0], c[1]); mk(layers.zones, x, y, g => txt(g, (Pg.label || k).toUpperCase(), 0, 0, { fill: col, size: 8.5, anchor: 'middle', ls: '.12em' })); } }
  // lines
  for (const k in (CFG.lines || {})) { const L = CFG.lines[k]; const st = L.style || {}; const col = st.colour || '#9B8CFF';
    el('path', { d: geodesicPath(L.pts, false), fill: 'none', stroke: col, 'stroke-width': st.width || 1.3, 'stroke-dasharray': st.dash || '6 4', 'vector-effect': 'non-scaling-stroke', opacity: .75 }, layers.lines);
    for (const n of (L.nodes || [])) { const [x, y] = proj(n.lon, n.lat); const lp = lab(n.label_pos, [7, 22, 'start']); mk(layers.lines, x, y, g => { el('circle', { r: 4.5, fill: 'none', stroke: col, 'stroke-width': 1.2 }, g); el('circle', { r: 1.4, fill: col }, g); txt(g, n.name.toUpperCase(), lp[0], lp[1], { fill: col, size: 8.5, ls: '.1em', anchor: lp[2] }); }); }
    if (L.label_at) { const [x, y] = proj(L.label_at[0], L.label_at[1]); mk(layers.lines, x, y, g => txt(g, (L.label_short || L.label).toUpperCase(), 6, 0, { fill: col, size: 8.5, ls: '.1em' })); } }
  // point sets
  for (const k in (CFG.point_sets || {})) { const S = CFG.point_sets[k]; const style = S.style || 'generic'; const parent = style === 'hub' ? layers.hubs : style === 'asw' ? layers.asw : style === 'choke' ? layers.chokes : layers.events; const col = S.colour || (style === 'hub' ? '#FFB454' : style === 'asw' ? '#7CC5A0' : '#C9D3E3');
    S.pts.forEach((p, idx) => { const plon = p.lon ?? p[0], plat = p.lat ?? p[1]; const [x, y] = proj(plon, plat); const name = p.name || ''; const lp = p.label === false ? null : lab(p.label, null);
      mk(parent, x, y, g => { if (style === 'hub') el('path', { d: S.outline ? 'M0,-3.5L3.5,0L0,3.5L-3.5,0Z' : 'M0,-4.5L4.5,0L0,4.5L-4.5,0Z', fill: S.outline ? 'none' : col, stroke: col, 'stroke-width': 1.1, opacity: .9 }, g);
        else if (style === 'asw') el('path', { d: 'M0,-5L5,4L-5,4Z', fill: '#0A111E', stroke: col, 'stroke-width': 1.3 }, g);
        else if (style === 'choke') { el('circle', { r: 3.2, fill: 'none', stroke: col, 'stroke-width': 1.1 }, g); el('line', { x1: -5.5, y1: 0, x2: 5.5, y2: 0, stroke: col, 'stroke-width': .8 }, g); }
        else el('circle', { r: 2.5, fill: col }, g);
        if (lp && name) txt(g, name.toUpperCase(), lp[0], lp[1], { fill: col, size: 8, ls: '.08em', anchor: lp[2] }); }); });
    if (S.label_at) { const [x, y] = proj(S.label_at[0], S.label_at[1]); mk(parent, x, y, g => txt(g, (S.label_short || S.label).toUpperCase(), 6, 3, { fill: col, size: 8, ls: '.1em' })); } }
  // circles
  for (const c of (CFG.circles || [])) { const [x, y] = proj(c.lon, c.lat); const r = nmToPx(c.radius_nm, c.lat); const col = c.colour || '#7CC5A0'; const parent = layers[c.layer] || layers.asw; el('circle', { cx: x, cy: y, r, fill: c.fill ? col : 'none', 'fill-opacity': c.fill || 0, stroke: col, 'stroke-width': .7, 'stroke-dasharray': c.dash || '3 6', 'vector-effect': 'non-scaling-stroke', opacity: .55 }, parent); if (c.label) { const [lx, ly] = proj(c.label_at ? c.label_at[0] : c.lon, c.label_at ? c.label_at[1] : c.lat + c.radius_nm / 60 * 1.05); mk(parent, lx, ly, g => txt(g, c.label.toUpperCase(), 0, 0, { fill: col, size: 8, anchor: 'middle', ls: '.1em' })); } }
  // events / points — kinds: launch · detection · survey · visit · sighting · exercise · closure · other
  for (const k in (CFG.points || {})) { const p = CFG.points[k]; const [x, y] = proj(p.lon, p.lat); const kind = p.kind || 'other'; const lp = lab(p.label_pos, [8, 3, 'start']); const short = p.label_short || p.label || k;
    if ((kind === 'launch' || kind === 'closure' || kind === 'exercise') && p.radius_nm) { const r = nmToPx(p.radius_nm, p.lat); const col = kind === 'launch' ? '#FF5B47' : kind === 'closure' ? '#9B8CFF' : '#FFB454'; el('circle', { cx: x, cy: y, r, fill: col, 'fill-opacity': .06, stroke: col, 'stroke-width': 1, 'stroke-dasharray': '5 4', 'vector-effect': 'non-scaling-stroke', opacity: .8 }, layers.events); }
    mk(layers.events, x, y, g => { if (kind === 'launch') { el('path', { d: 'M0,-6L1.8,-1.8L6,0L1.8,1.8L0,6L-1.8,1.8L-6,0L-1.8,-1.8Z', fill: '#FF5B47' }, g); txt(g, short.toUpperCase(), lp[0], lp[1], { fill: '#FF5B47', size: 8.5, ls: '.08em', anchor: lp[2] }); }
      else if (kind === 'detection') { el('path', { d: 'M0,-5L5,0L0,5L-5,0Z', fill: '#0A111E', stroke: '#FF5B47', 'stroke-width': 1.4 }, g); txt(g, short.toUpperCase(), lp[0], lp[1], { fill: '#FF9A8C', size: 8, ls: '.06em', anchor: lp[2] }); }
      else if (kind === 'survey') { el('path', { d: 'M-4.5,0H4.5M0,-4.5V4.5', stroke: '#9B8CFF', 'stroke-width': 1.4 }, g); txt(g, short.toUpperCase(), lp[0], lp[1], { fill: '#B8ADFF', size: 7.8, ls: '.06em', anchor: lp[2] }); }
      else if (kind === 'visit') { el('circle', { r: 3.5, fill: '#0A111E', stroke: '#FFB454', 'stroke-width': 1.3 }, g); el('circle', { r: 1.2, fill: '#FFB454' }, g); txt(g, short.toUpperCase(), lp[0], lp[1], { fill: '#FFD9A6', size: 7.8, ls: '.06em', anchor: lp[2] }); }
      else if (kind === 'sighting') { el('path', { d: 'M0,-7C-3.5,-7 -5,-4.5 -5,-2.5C-5,1 0,6 0,6C0,6 5,1 5,-2.5C5,-4.5 3.5,-7 0,-7Z', fill: '#0A111E', stroke: '#FFD166', 'stroke-width': 1.3 }, g); el('circle', { r: 1.4, cy: -2.5, fill: '#FFD166' }, g); txt(g, short.toUpperCase(), lp[0], lp[1], { fill: '#FFE7A8', size: 7.8, ls: '.06em', anchor: lp[2] }); }
      else if (kind === 'exercise') { el('path', { d: 'M0,-5.5L4.8,-2.75L4.8,2.75L0,5.5L-4.8,2.75L-4.8,-2.75Z', fill: '#0A111E', stroke: '#FFB454', 'stroke-width': 1.3 }, g); txt(g, short.toUpperCase(), lp[0], lp[1], { fill: '#FFD9A6', size: 7.8, ls: '.06em', anchor: lp[2] }); }
      else if (kind === 'closure') { el('circle', { r: 3.6, fill: 'none', stroke: '#9B8CFF', 'stroke-width': 1.3, 'stroke-dasharray': '2 2' }, g); txt(g, short.toUpperCase(), lp[0], lp[1], { fill: '#B8ADFF', size: 7.8, ls: '.06em', anchor: lp[2] }); }
      else { el('circle', { r: 3, fill: '#C9D3E3' }, g); txt(g, short.toUpperCase(), lp[0], lp[1], { fill: '#C9D3E3', size: 7.8, ls: '.06em', anchor: lp[2] }); } }); }
  // bases — kinds: port · yard · garrison · airbase · depot · site
  for (const k in CFG.bases) { const b = CFG.bases[k]; const [x, y] = proj(b.lon, b.lat); const kind = b.kind || (DOMAIN === 'land' ? 'garrison' : DOMAIN === 'air' ? 'airbase' : 'port'); const left = b.label_side === 'left'; const dy = b.label_dy == null ? 4 : b.label_dy;
    mk(layers.bases, x, y, g => {
      if (kind === 'yard') el('rect', { x: -5, y: -5, width: 10, height: 10, fill: '#0A111E', stroke: '#FFB454', 'stroke-width': 1.3, transform: 'rotate(45)' }, g);
      else if (kind === 'garrison') { el('rect', { x: -5, y: -5, width: 10, height: 10, fill: '#FFB454', stroke: '#FFB454', 'stroke-width': 1.3 }, g); el('rect', { x: -2, y: -2, width: 4, height: 4, fill: '#0A111E' }, g); }
      else if (kind === 'airbase') { el('circle', { r: 5.2, fill: '#FFB454', stroke: '#FFB454', 'stroke-width': 1.2 }, g); el('path', { d: 'M-3.2,0H3.2M0,-3.2V3.2', stroke: '#0A111E', 'stroke-width': 1.6 }, g); }
      else if (kind === 'depot') el('path', { d: 'M0,-6L6,4.5L-6,4.5Z', fill: '#0A111E', stroke: '#FFB454', 'stroke-width': 1.4 }, g);
      else if (kind === 'site') { el('circle', { r: 4.5, fill: '#0A111E', stroke: '#FFB454', 'stroke-width': 1.3 }, g); el('circle', { r: 1.5, fill: '#FFB454' }, g); }
      else el('rect', { x: -5, y: -5, width: 10, height: 10, fill: '#FFB454', stroke: '#FFB454', 'stroke-width': 1.3 }, g);
      const nm = (b.short || b.name.split(' (')[0].split(' — ')[0]).toUpperCase(); txt(g, nm, left ? -8 : 8, dy, { fill: '#FFD9A6', size: 9, weight: 600, ls: '.08em', anchor: left ? 'end' : 'start' }); if (b.ref) txt(g, b.ref, left ? -8 : 8, dy + 11, { fill: '#8DA0BC', size: 7.5, ls: '.1em', anchor: left ? 'end' : 'start' }); }); }
  // labels
  for (const s of ((CFG.labels && CFG.labels.seas) || [])) { const [x, y] = proj(s.lon, s.lat); mk(layers.labels, x, y, g => txt(g, s.name.toUpperCase(), 0, 0, { fill: '#4A6188', size: s.name.length > 12 ? 9.5 : 10.5, anchor: 'middle', ls: '.28em' })); }
  for (const s of ((CFG.labels && CFG.labels.places) || [])) { const [x, y] = proj(s.lon, s.lat); mk(layers.labels, x, y, g => txt(g, s.name.toUpperCase(), 0, 0, { fill: '#5C7396', size: s.name.length > 6 ? 8.5 : 9.5, anchor: 'middle', ls: '.22em', weight: 600 })); }

  // ---- live overlay (air theatres only): coarse public ADS-B broadcasts posted by the parent dashboard ----
  // The parent (LOOKING GLASS dashboard, extension mode) posts {type:'lg-live', ac:[{cls,t,r,flight,lat,lon,alt,airborne}]}.
  // Positions are already rounded to 0.1° by the worker; this layer draws what public receivers heard, nothing more.
  const LIVE_OK = DOMAIN === 'air' && !(CFG.ui && CFG.ui.live_overlay === false);
  const liveMarkers = [];
  function renderLive(ac) {
    for (const g of liveMarkers) { const i = markers.indexOf(g); if (i >= 0) markers.splice(i, 1); g.remove(); } liveMarkers.length = 0;
    layers.live.innerHTML = '';
    if (!LIVE_OK || !Array.isArray(ac)) return;
    let n = 0;
    for (const a of ac.slice(0, 60)) { if (typeof a.lat !== 'number' || typeof a.lon !== 'number') continue; if (a.lon < CFG.grid.lon0 || a.lon > CFG.grid.lon1 || a.lat < CFG.grid.lat0 || a.lat > CFG.grid.lat1) continue; const [x, y] = proj(a.lon, a.lat); const col = a.airborne ? '#7CC5A0' : '#6B7A94'; const label = String(a.t || a.cls || '').toUpperCase().slice(0, 8) + (a.r ? ' ' + String(a.r).slice(0, 8) : '');
      const g = mk(layers.live, x, y, g => { el('path', { d: 'M0,-6L5,5L0,2.5L-5,5Z', fill: a.airborne ? col : '#0A111E', stroke: col, 'stroke-width': 1.3 }, g); txt(g, label, 8, 3, { fill: col, size: 8, ls: '.06em' }); }); liveMarkers.push(g); n++; }
    const lg = $('#legend-live'); if (lg) { lg.hidden = false; lg.textContent = `${n} public ADS-B broadcast${n === 1 ? '' : 's'} in frame · coarse 0.1° · as heard by community receivers · not a track`; }
    applyView();
  }
  window.addEventListener('message', ev => { if (!LIVE_OK) return; if (ev.source !== window.parent) return; const d = ev.data; if (!d || d.type !== 'lg-live') return; renderLive(d.ac || []); });
  if (LIVE_OK && Array.isArray(window.LG_LIVE)) setTimeout(() => renderLive(window.LG_LIVE), 0);

  // ---- pan / zoom ------------------------------------------------------------------------------------------------
  const viewport = $('#viewport'), world = $('#world'); const view = { k: 1, tx: 0, ty: 0 };
  function applyView() { if (!(view.k > 0 && isFinite(view.k))) view.k = 1; world.style.transform = `translate(${view.tx}px,${view.ty}px) scale(${view.k})`; const inv = 1 / view.k; for (const g of markers) g.setAttribute('transform', `translate(${g.__xy[0]},${g.__xy[1]}) scale(${inv})`); }
  let needsFit = null;
  function fitTo(lon0, lat0, lon1, lat1) { const corners = [proj(lon0, lat0), proj(lon0, lat1), proj(lon1, lat0), proj(lon1, lat1), proj((lon0 + lon1) / 2, lat1), proj((lon0 + lon1) / 2, lat0)]; const x0 = Math.min(...corners.map(c => c[0])), x1 = Math.max(...corners.map(c => c[0])), y0 = Math.min(...corners.map(c => c[1])), y1 = Math.max(...corners.map(c => c[1])); const vw = viewport.clientWidth, vh = viewport.clientHeight;
    if (!(vw > 0 && vh > 0)) { needsFit = [lon0, lat0, lon1, lat1]; view.k = 1; view.tx = 0; view.ty = 0; applyView(); return; }   // hidden (e.g. an inactive tab's iframe): fit once it has a size
    needsFit = null; view.k = Math.min(vw / (x1 - x0), vh / (y1 - y0)); view.tx = (vw - (x1 - x0) * view.k) / 2 - x0 * view.k; view.ty = (vh - (y1 - y0) * view.k) / 2 - y0 * view.k; applyView(); }
  if (typeof ResizeObserver !== 'undefined') new ResizeObserver(() => { if (needsFit && viewport.clientWidth > 0 && viewport.clientHeight > 0) fitTo(...needsFit); }).observe(viewport);
  const HOME = CFG.grid.home_view || [CFG.grid.lon0, CFG.grid.lat0, CFG.grid.lon1, CFG.grid.lat1];
  function zoomAt(f, cx, cy) { const k2 = Math.min(Math.max(view.k * f, 0.2), 12); const s = k2 / view.k; view.tx = cx - (cx - view.tx) * s; view.ty = cy - (cy - view.ty) * s; view.k = k2; applyView(); }
  viewport.addEventListener('wheel', e => { e.preventDefault(); const r = viewport.getBoundingClientRect(); zoomAt(Math.exp(-e.deltaY * 0.0016), e.clientX - r.left, e.clientY - r.top); }, { passive: false });
  let drag = null; viewport.addEventListener('pointerdown', e => { drag = { x: e.clientX, y: e.clientY, tx: view.tx, ty: view.ty }; viewport.classList.add('dragging'); viewport.setPointerCapture(e.pointerId); });
  viewport.addEventListener('pointermove', e => { if (drag) { view.tx = drag.tx + e.clientX - drag.x; view.ty = drag.ty + e.clientY - drag.y; applyView(); hideTip(); return; } hover(e); });
  const endDrag = () => { drag = null; viewport.classList.remove('dragging'); }; viewport.addEventListener('pointerup', endDrag); viewport.addEventListener('pointercancel', endDrag); viewport.addEventListener('pointerleave', () => { endDrag(); hideTip(); });
  $('#zin').addEventListener('click', () => zoomAt(1.5, viewport.clientWidth / 2, viewport.clientHeight / 2)); $('#zout').addEventListener('click', () => zoomAt(1 / 1.5, viewport.clientWidth / 2, viewport.clientHeight / 2)); $('#zhome').addEventListener('click', () => fitTo(...HOME));
  if (CFG.grid.focus_view) { $('#zfocus').title = 'Zoom to ' + (CFG.grid.focus_label || 'focus'); $('#zfocus').addEventListener('click', () => fitTo(...CFG.grid.focus_view)); } else $('#zfocus').hidden = true;
  window.addEventListener('resize', () => fitTo(...HOME));

  // ---- heat canvas ------------------------------------------------------------------------------------------------
  const canvas = $('#heat'); const CW = 1400, CH = Math.round(CW * H / W); canvas.width = CW; canvas.height = CH; canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
  for (const sv of [svg, base]) { sv.setAttribute('viewBox', `0 0 ${W} ${H}`); sv.setAttribute('width', W); sv.setAttribute('height', H); } world.style.width = W + 'px'; world.style.height = H + 'px';
  const ctx2d = canvas.getContext('2d');
  const pxLL = new Float32Array(CW * CH * 2); for (let py = 0; py < CH; py++) for (let px = 0; px < CW; px++) { const [lo, la] = unproj((px + 0.5) * W / CW, (py + 0.5) * H / CH); const o = (py * CW + px) * 2; pxLL[o] = lo; pxLL[o + 1] = la; }
  const LUT = new Uint8ClampedArray(256 * 4); { const stops = [[0.0, 0x3A, 0x22, 0x08, 0.0], [0.05, 0x5A, 0x34, 0x0C, 0.28], [0.25, 0x7A, 0x4A, 0x10, 0.55], [0.5, 0xC9, 0x7F, 0x1E, 0.80], [0.75, 0xFF, 0xB4, 0x54, 0.92], [1.0, 0xFF, 0xE2, 0xB8, 1.0]]; for (let i = 0; i < 256; i++) { const c = i / 255; let a = stops[0], b = stops[stops.length - 1]; for (let s = 0; s < stops.length - 1; s++) if (c >= stops[s][0] && c <= stops[s + 1][0]) { a = stops[s]; b = stops[s + 1]; break; } const t = (c - a[0]) / ((b[0] - a[0]) || 1); for (let ch = 0; ch < 3; ch++) LUT[i * 4 + ch] = a[1 + ch] + (b[1 + ch] - a[1 + ch]) * t; LUT[i * 4 + 3] = 255 * (a[4] + (b[4] - a[4]) * t); } }
  function renderHeat(coord) { const img = ctx2d.createImageData(CW, CH), d = img.data; const NC = M.NC, NR = M.NR, land = M.land; const cval = new Float32Array(M.N); for (let i = 0; i < M.N; i++) cval[i] = (land[i] || coord[i] === 0) ? 0 : Math.max(0, 1 - coord[i]);
    for (let py = 0; py < CH; py++) for (let px = 0; px < CW; px++) { const o2 = (py * CW + px) * 2; const fr = (pxLL[o2 + 1] - G.lat0) / G.step - 0.5, fc = (pxLL[o2] - G.lon0) / G.step - 0.5; const r0 = Math.floor(fr), c0 = Math.floor(fc); if (r0 < -1 || r0 >= NR || c0 < -1 || c0 >= NC) continue; const tr = fr - r0, tc = fc - c0; let v = 0, wsum = 0;
      for (let dr = 0; dr <= 1; dr++) { const r = r0 + dr; if (r < 0 || r >= NR) continue; const wr = dr ? tr : 1 - tr; for (let dc = 0; dc <= 1; dc++) { const c = c0 + dc; if (c < 0 || c >= NC) continue; const i = r * NC + c; if (land[i]) continue; const w = wr * (dc ? tc : 1 - tc); v += cval[i] * w; wsum += w; } }
      if (wsum <= 0) continue; v /= wsum; if (v < 0.04) continue; const li = Math.min(255, Math.round(v * 255)) * 4, o = (py * CW + px) * 4; d[o] = LUT[li]; d[o + 1] = LUT[li + 1]; d[o + 2] = LUT[li + 2]; d[o + 3] = LUT[li + 3]; }
    ctx2d.putImageData(img, 0, 0); }
  function renderContours(h, colour) { layers.contours.innerHTML = ''; for (const [q, w, op] of [[0.95, 0.9, .55], [0.8, 1.3, .8], [0.5, 2.0, 1]]) { const lv = h.levels[q]; if (lv == null) continue; const segs = M.contours(h.dens, lv); let d = ''; for (const [a, b] of segs) { const p1 = proj(G.lon0 + (a[0] + 0.5) * G.step, G.lat0 + (a[1] + 0.5) * G.step), p2 = proj(G.lon0 + (b[0] + 0.5) * G.step, G.lat0 + (b[1] + 0.5) * G.step); d += `M${p1[0].toFixed(1)},${p1[1].toFixed(1)}L${p2[0].toFixed(1)},${p2[1].toFixed(1)}`; } el('path', { d, fill: 'none', stroke: colour, 'stroke-width': w, 'stroke-linecap': 'round', 'vector-effect': 'non-scaling-stroke', opacity: op }, layers.contours); } }

  // ---- model glue --------------------------------------------------------------------------------------------------
  const ctxNow = () => ({ posture: state.posture, scenarios: Object.assign({}, state.scenarios), enabled: Object.assign({}, state.enabled), hours: TIME_STEPS[state.tIdx] });
  let pending = null;
  function update() { $('#busy').hidden = false; if (pending) cancelAnimationFrame(pending); pending = requestAnimationFrame(() => setTimeout(() => { const c = ctxNow(); const surface = state.cls === 'all' ? M.combinedSurface(c) : M.classSurface(state.cls, c); const h = M.hdr(surface); cur = { surface, hdr: h, ctx: c }; renderHeat(h.coord); if (state.layers.contours) renderContours(h, SERIES[state.cls]); layers.contours.style.display = state.layers.contours ? '' : 'none'; renderReadout(); renderVarMults(); $('#busy').hidden = true; pending = null; }, 10)); }

  // ---- readouts --------------------------------------------------------------------------------------------------------
  const nDeployed = (cls, posture) => M.deployedOf(cls)[posture] || 0;
  const totalDeployed = posture => CLASSES.reduce((s, k) => s + nDeployed(k, posture), 0);
  const hullsOf = cls => CFG.classes[cls].hulls != null ? CFG.classes[cls].hulls : (CFG.classes[cls].inventory || 0);
  function tpl(s, vars) { return String(s).replace(/\{(\w+)\}/g, (m, k) => (vars[k] == null ? m : vars[k])); }
  function renderReadout() { const { surface, hdr: h, ctx } = cur; const cls = state.cls; const A = h.areas; const n = cls === 'all' ? totalDeployed(state.posture) : nDeployed(cls, state.posture); const hulls = cls === 'all' ? CLASSES.reduce((s, k) => s + (hullsOf(k) || 0), 0) : (hullsOf(cls) || 0); const on = cls === 'all' ? null : M.transitSplit(cls, ctx);
    $('#t-boats').innerHTML = `${fmt(n, 1)}<small>of ≈${hulls} ${V.units}</small>`; $('#t-boats-n').textContent = `${(LEVEL_LABEL[state.posture] || state.posture).toUpperCase()} posture · ${hulls ? fmt(100 * n / hulls, 0) : '–'}% of the class ${V.deployed} — a posture assumption, not an observation`;
    $('#t-50').innerHTML = `${fmt(A[0.5] / 1000, 0)}k<small>nm²</small>`; $('#t-50-n').textContent = `≈ a ${fmt(Math.sqrt(A[0.5]), 0)} × ${fmt(Math.sqrt(A[0.5]), 0)} nm box holds even odds of the ${V.unit}`;
    $('#t-80').innerHTML = `${fmt(A[0.8] / 1000, 0)}k<small>nm²</small>`; $('#t-80-n').textContent = `95 % region ${fmt(A[0.95] / 1000, 0)}k nm² · ${A[0.95] ? fmt(100 * A[0.5] / A[0.95], 0) : '–'}% of the 95 % area carries half the mass`;
    $('#t-onst').innerHTML = on == null ? `mixed<small>${CLASSES.length} classes</small>` : `${fmt(100 * on, 0)}%<small>${V.onstation_l}</small>`; $('#t-onst-n').textContent = on == null ? `${cap(V.unit)}-weighted mixture of the class surfaces at the current posture` : (ctx.hours == null ? `${cap(V.patrol)}-averaged: ${fmt(100 * (1 - on), 0)}% of ${V.deployed} time is ${V.transit} out and back` : `${fmt(100 * (1 - on), 0)}% still ${V.transit} at ${timeLabel(ctx.hours).toLowerCase()}`);
    const rows = M.regionMass(surface); const max = rows[0].mass || 1; const tb = $('#regions tbody'); tb.innerHTML = ''; let cum = 0;
    rows.slice(0, 12).forEach(r => { cum += r.mass; const tr = document.createElement('tr'); if (r.mass < 0.01) tr.className = 'dim'; tr.innerHTML = `<td class="rg">${esc(r.name)}</td><td class="bw"><div class="bar" style="width:${Math.max(2, 100 * r.mass / max)}%;background:${SERIES[cls]}"></div></td><td class="num">${(100 * r.mass).toFixed(1)} %</td><td class="num">${cls === 'all' ? '' : fmt(r.mass * n, 2)}</td>`; tb.appendChild(tr); });
    $('#regions-foot').textContent = `Top 12 regions hold ${fmt(100 * cum, 1)}% of the ${V.deployed} mass · ${timeLabel(ctx.hours)} · ${CLABEL[cls]}`; $('#regions th.boats').textContent = cls === 'all' ? '' : `E[${V.units}]`;
    const vars = { a50k: fmt(A[0.5] / 1000, 0), a80k: fmt(A[0.8] / 1000, 0), a95k: fmt(A[0.95] / 1000, 0), top1: rows[0].name, top1pct: fmt(100 * rows[0].mass, 0), top2: rows[1] ? rows[1].name : '', top2pct: rows[1] ? fmt(100 * rows[1].mass, 0) : '', n: fmt(n, 1), hulls, on_pct: on == null ? '' : fmt(100 * on, 0), box: fmt(Math.sqrt(A[0.5]), 0) };
    const J = cls === 'all' ? { title: `${cap(V.unit)}-weighted mixture.`, confidence: `≈${vars.n} ${V.units} ${V.deployed}`, text: (CFG.text && CFG.text.all_judgment) || `The largest class by ${V.deployed} count dominates the combined surface; read the classes separately for the deterrent question.` } : (CFG.classes[cls].judgment || { title: 'Structural prior.', confidence: 'Confidence not stated', text: 'Half the mass sits in ≈{a50k}k nm² — {top1} ({top1pct}%) then {top2} ({top2pct}%).' });
    $('#judg').innerHTML = `<div class="judg" style="border-left-color:${SERIES[cls]}"><div><span class="t">${esc(J.title)}</span><span class="c">${esc(J.confidence)}</span></div><p>${tpl(J.text, vars)}</p></div>`; }

  // ---- variables panel ----------------------------------------------------------------------------------------------------
  const varList = $('#vars');
  function buildVars() { varList.innerHTML = ''; for (const F of CFG.factors) { const on = state.enabled[F.id] !== false; const div = document.createElement('div'); div.className = 'var' + (on ? '' : ' off'); const refs = (F.refs || []).map(d => `<span class="chip">${esc(d)}</span>`).join('') + (F.external ? '<span class="chip ext">EXTERNAL CONSTANT</span>' : '') + (F.classes ? `<span class="chip">${F.classes.map(c => (CFG.classes[c].short || c).toUpperCase()).join(' · ')} ONLY</span>` : '');
    div.innerHTML = `<input type="checkbox" id="v-${F.id}" ${on ? 'checked' : ''} aria-label="toggle ${esc(F.label)}"><div><label for="v-${F.id}" class="vt">${esc(F.label)}</label><div class="chips">${refs}</div><div class="vn">${F.note || ''}</div><div class="mults" data-f="${F.id}"></div></div>`; div.querySelector('input').addEventListener('change', e => { state.enabled[F.id] = e.target.checked; div.classList.toggle('off', !e.target.checked); update(); }); varList.appendChild(div); } }
  function renderVarMults() { const cls = state.cls === 'all' ? CLASSES[0] : state.cls; const c = cur.ctx || ctxNow(); const bd = {}; for (let i = 0; i < M.N; i += 9) { if (M.land[i]) continue; for (const f of M.factorBreakdown(cls, i, c)) { const b = bd[f.id] || (bd[f.id] = [Infinity, -Infinity]); if (f.mult < b[0]) b[0] = f.mult; if (f.mult > b[1]) b[1] = f.mult; } } for (const id in bd) { const e = varList.querySelector(`.mults[data-f="${id}"]`); if (e) e.textContent = `${(CFG.classes[cls].short || cls).toUpperCase()} multiplier range ×${bd[id][0].toFixed(2)} – ×${bd[id][1].toFixed(2)}`; } }

  // ---- tooltip -----------------------------------------------------------------------------------------------------------------
  const tip = $('#tip'); function hideTip() { tip.hidden = true; }
  function hover(e) { if (!cur.surface) return; const r = viewport.getBoundingClientRect(); const wx = (e.clientX - r.left - view.tx) / view.k, wy = (e.clientY - r.top - view.ty) / view.k; const [lon, lat] = unproj(wx, wy); const i = M.cellIndex(lon, lat); if (i < 0 || M.land[i]) { hideTip(); return; }
    const { surface, hdr: h, ctx } = cur; const cls = state.cls; const p = surface[i], dens = h.dens[i], coord = h.coord[i]; const band = p === 0 ? 'outside the 95 % region' : coord <= 0.5 ? 'inside the 50 % region' : coord <= 0.8 ? 'in the 50–80 % band' : coord <= 0.95 ? 'in the 80–95 % band' : 'outside the 95 % region'; const rg = M.regionOf[i] >= 0 ? M.REGION[M.regionOf[i]].name : `Unassigned ${V.water}`; const n = cls === 'all' ? totalDeployed(state.posture) : nDeployed(cls, state.posture);
    let rows = ''; if (cls !== 'all') { rows = M.factorBreakdown(cls, i, ctx).filter(f => !f.on || Math.abs(f.mult - 1) > 0.005).map(f => `<tr><td class="${f.on ? '' : 'off'}">${esc(f.label)}</td><td>${f.on ? '×' + f.mult.toFixed(2) : 'off'}</td></tr>`).join(''); const cfg = CFG.classes[cls]; let best = null; for (const k in M.srcShares(cls, ctx)) { const d = M.srcForClass(k, cls).dist[i]; if (isFinite(d) && (!best || d < best[1])) best = [k, d]; } if (best) { const spec = M.costSpec(cls); const lbl = spec.tab ? `Effective ${V.distance.toLowerCase()} (cost-weighted)` : (spec.shallow > 1 ? `Effective ${V.distance.toLowerCase()} (shelf ×${spec.shallow})` : V.distance); rows += `<tr><td>${lbl} from ${esc(CFG.bases[best[0]].short || CFG.bases[best[0]].name)}</td><td>${fmt(best[1], 0)} nm</td></tr>`; } }
    else for (const k of CLASSES) { const s = M.classSurface(k, ctx); rows += `<tr><td>${esc(CFG.classes[k].short || k)} expected ${V.units} here</td><td>${(s[i] * nDeployed(k, state.posture)).toFixed(3)}</td></tr>`; }
    tip.innerHTML = `<div class="h">${esc(rg)}</div><div class="big">${(100 * p).toFixed(p < 0.001 ? 3 : 2)} % of ${V.deployed} mass · ${band}</div><div class="sub">${Math.abs(lat).toFixed(1)}°${lat < 0 ? 'S' : 'N'} ${Math.abs(lon).toFixed(1)}°${lon < 0 ? 'W' : 'E'} · ${G.classes[M.depth[i]]} · density ${fmt(dens * 1e4, 2)} % per 10k nm² · E[${V.units} in cell] ${(p * n).toFixed(3)}</div><table>${rows}</table>`;
    tip.hidden = false; const tw = tip.offsetWidth, th = tip.offsetHeight; let x = e.clientX + 16, y = e.clientY + 16; if (x + tw > window.innerWidth - 8) x = e.clientX - tw - 12; if (y + th > window.innerHeight - 8) y = e.clientY - th - 12; tip.style.left = x + 'px'; tip.style.top = y + 'px'; }

  // ---- controls -----------------------------------------------------------------------------------------------------------------
  { const seg = $('#clsseg'); seg.innerHTML = ''; [...CLASSES, 'all'].forEach(c => { const b = document.createElement('button'); b.dataset.cls = c; b.setAttribute('aria-pressed', c === state.cls); b.innerHTML = `<span class="sw" style="background:${SERIES[c]}"></span>${esc(c === 'all' ? 'All' : (CFG.classes[c].short || c))}`; b.addEventListener('click', () => { state.cls = c; seg.querySelectorAll('button').forEach(x => x.setAttribute('aria-pressed', x === b)); $('#legend-cls').textContent = CLABEL[c]; $('#legend-sw').style.background = SERIES[c]; update(); }); seg.appendChild(b); }); }
  const slider = $('#tslider'); slider.max = TIME_STEPS.length - 1; slider.value = state.tIdx; $('#tval').textContent = timeLabel(TIME_STEPS[state.tIdx]); let sliderTimer = null; slider.addEventListener('input', () => { state.tIdx = +slider.value; $('#tval').textContent = timeLabel(TIME_STEPS[state.tIdx]); clearTimeout(sliderTimer); sliderTimer = setTimeout(update, 140); });
  { const sel = $('#posture'); sel.innerHTML = LEVELS.map(l => `<option value="${l}" ${l === state.posture ? 'selected' : ''}>${esc(LEVEL_LABEL[l] || l)}${l === (CFG.meta.posture_default) ? ' (baseline)' : ''}</option>`).join(''); sel.addEventListener('change', e => { state.posture = e.target.value; $('#legend-post').textContent = (LEVEL_LABEL[state.posture] || state.posture).toUpperCase(); update(); }); }
  { const host = $('#scenarios'); host.innerHTML = ''; for (const id in (CFG.scenarios || {})) { const s = CFG.scenarios[id]; const l = document.createElement('label'); l.className = 'chk'; l.title = s.note || ''; l.innerHTML = `<input type="checkbox" data-sc="${id}"> ${esc(s.label)}`; l.querySelector('input').addEventListener('change', e => { state.scenarios[id] = e.target.checked; update(); }); host.appendChild(l); } }
  const menu = $('#layermenu'); $('#layerbtn').addEventListener('click', () => { menu.hidden = !menu.hidden; }); document.addEventListener('click', e => { if (!e.target.closest('.layers')) menu.hidden = true; });
  menu.querySelectorAll('input').forEach(inp => { inp.checked = !!state.layers[inp.dataset.layer]; inp.addEventListener('change', () => { state.layers[inp.dataset.layer] = inp.checked; applyLayers(); }); });
  function applyLayers() { for (const id in state.layers) { const g = layers[id]; if (g) g.style.display = state.layers[id] ? '' : 'none'; } if (state.layers.contours && cur.hdr) renderContours(cur.hdr, SERIES[state.cls]); }
  document.querySelectorAll('.tabs button').forEach(b => b.addEventListener('click', () => { document.querySelectorAll('.tabs button').forEach(x => x.setAttribute('aria-selected', x === b)); document.querySelectorAll('.panel').forEach(p => p.hidden = p.id !== b.dataset.panel); }));

  // ---- boot -----------------------------------------------------------------------------------------------------------------
  buildVars(); applyLayers(); fitTo(...HOME); $('#legend-cls').textContent = CLABEL[state.cls]; $('#legend-sw').style.background = SERIES[state.cls]; $('#legend-post').textContent = (LEVEL_LABEL[state.posture] || state.posture).toUpperCase();
  $('#stat-cells').textContent = `${fmt(M.seaCount)} ${V.cells} · ${G.step}° grid · ${fmt(M.N)} total`;
  update();
  try { window.parent.postMessage({ type: 'lg-map-ready', id: CFG.meta.id, domain: DOMAIN }, '*'); } catch (e) {}
})();
