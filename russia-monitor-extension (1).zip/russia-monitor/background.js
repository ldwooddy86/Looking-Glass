/* ============================================================
   background.js — LOOKING GLASS v3 MV3 service worker
   ------------------------------------------------------------
   Country-agnostic. Responsibilities (and NOTHING else):
     • (LOOKING GLASS) Optionally GET the local collector's JSON —
       feed items, media index, digest — from a LOOPBACK endpoint the
       user configured (127.0.0.1 / localhost only, optional host
       permission granted by the user, shared token in a header). The
       collector is the only thing that ever touches an account, and
       it runs on the user's own machine. Read-only here as well.
     • (LOOKING GLASS) A second ADS-B sector for the Air Watch board.
     • Schedule periodic refreshes via chrome.alarms.
     • Fetch PUBLIC channel previews (t.me/s/<handle>) GET-only,
       against a hard-coded host allowlist. Handles come from
       storage, seeded by the dashboard from data.js.osint.channels
       (plus any custom handles the user adds in Settings).
     • Fetch the public military ADS-B feed (opendata.adsb.fi) and
       keep only the airframe types the active watch cares about.
       Type matchers, map sector and tempo baselines come from
       storage, seeded from data.js.trackWatch — ONE worker serves
       ANY country without code changes.
     • Keep a pattern-of-life store (appeared / went-dark events and
       a 7-day per-type sighting history) with hard caps.
     • Track per-lane health with backoff so a dead lane never turns
       into a hammering loop.
     • Cache results + timestamps in chrome.storage.local (capped).
       Parsing/sanitising of channel HTML happens in the PAGE (which
       has a DOM); the worker never renders anything.
   Security invariants (never regress):
     • No DOM, no eval, no remote code. importScripts loads only a
       local, bundled file (sanitize.js).
     • Every outbound request is re-checked against a hard-coded host
       allowlist even though host_permissions already constrain it.
     • credentials:"omit" and no-referrer on every request — no
       cookies, no session, never logged in anywhere.
     • GET only. Nothing is ever POSTed by the worker. No telemetry.
       (The optional synthesis call is made by the PAGE, only on a
       user click, only to api.anthropic.com, with the user's own key.)
   ============================================================ */
"use strict";
importScripts("sanitize.js");

var ALLOWED_HOSTS = ["t.me"];
var FLIGHT_HOST = "opendata.adsb.fi";
var FLIGHT_URL = "https://opendata.adsb.fi/api/v2/mil";
var ALARM_NAME = "oracle-refresh";
var FLIGHT_ALARM = "oracle-flight";
var FLIGHT_MINUTES = 5;                    // went-dark resolution
var TRACK_MAX_EVENTS = 80;
var TRACK_TTL_MS = 7 * 24 * 3600 * 1000;
var POL_WINDOW_MS = 7 * 24 * 3600 * 1000;  // pattern-of-life window
var MAX_HTML_BYTES = 220 * 1024;
var MAX_CHANNELS = 16;
var MAX_FLIGHT_MATCHES = 40;
var MAX_SECTOR_SCAN = 1500;
var MAX_SECTOR_HITS = 12;
var FETCH_TIMEOUT_MS = 15000;
var BACKOFF_BASE_MS = 10 * 60 * 1000;      // 10 min × 2^fails, capped
var BACKOFF_MAX_MS = 6 * 3600 * 1000;

var DEFAULTS = { refreshMinutes: 30, channels: [], customChannels: [], trackMatch: {}, sector: { lat: 0, lon: 0, dist: 120 }, airSector: null, tempos: {}, collector: { endpoint: "http://127.0.0.1:8787", token: "", enabled: false } };
var COL_MAX_ITEMS = 300, COL_MAX_MEDIA = 200, COL_TIMEOUT_MS = 20000, COL_MAX_BYTES = 6 * 1024 * 1024;

/* ---------- storage helpers ---------- */
function getLocal(keys) { return new Promise(function (res) { chrome.storage.local.get(keys, res); }); }
function setLocal(obj) { return new Promise(function (res) { chrome.storage.local.set(obj, res); }); }
function removeLocal(keys) { return new Promise(function (res) { chrome.storage.local.remove(keys, res); }); }

/* ---------- allowlisted GET with timeout ---------- */
function allowedHost(url, hosts) {
  var host; try { host = new URL(url).host; } catch (e) { return false; }
  return hosts.indexOf(host) !== -1;
}
function safeGet(url, hosts, asJson) {
  if (!allowedHost(url, hosts)) return Promise.resolve({ ok: false, error: "host not allowlisted", ts: Date.now() });
  var controller = new AbortController(); var timer = setTimeout(function () { controller.abort(); }, FETCH_TIMEOUT_MS);
  return fetch(url, { method: "GET", redirect: "follow", credentials: "omit", referrerPolicy: "no-referrer", cache: "no-store", signal: controller.signal })
    .then(function (r) {
      if (!allowedHost(r.url || url, hosts)) throw new Error("redirected off allowlist");
      if (!r.ok) throw new Error("HTTP " + r.status);
      return asJson ? r.json() : r.text();
    })
    .then(function (body) { clearTimeout(timer); return { ok: true, body: body, ts: Date.now() }; })
    .catch(function (err) { clearTimeout(timer); return { ok: false, error: (err && err.message) || "fetch failed", ts: Date.now() }; });
}

/* ---------- channel previews ---------- */
function safeFetchChannel(handle) {
  var clean = self.OracleSanitize.handle(handle);
  if (!clean) return Promise.resolve({ ok: false, error: "invalid handle", ts: Date.now() });
  return safeGet("https://t.me/s/" + clean, ALLOWED_HOSTS, false).then(function (r) {
    if (!r.ok) return r;
    var html = String(r.body || ""); if (html.length > MAX_HTML_BYTES) html = html.slice(0, MAX_HTML_BYTES);
    if (html.indexOf("tgme_widget_message") === -1) return { ok: false, error: "no public post stream (contact page or private channel)", ts: r.ts };
    return { ok: true, html: html, ts: r.ts };
  });
}
function effectiveChannels(cfg) {
  var list = [];
  (cfg.channels && cfg.channels.length ? cfg.channels : DEFAULTS.channels).forEach(function (c) { if (c && c.enabled !== false) list.push(c.handle); });
  (cfg.customChannels || []).forEach(function (c) { if (c && c.enabled !== false) list.push(c.handle); });
  var seen = {}, out = [];
  list.forEach(function (h) { var s = self.OracleSanitize.handle(h); if (s && !seen[s]) { seen[s] = 1; out.push(s); } });
  return out.slice(0, MAX_CHANNELS);
}

/* ---------- ADS-B classification (data-driven matchers) ---------- */
function normType(s) { return String(s == null ? "" : s).toUpperCase().replace(/[^A-Z0-9]/g, ""); }
function num(v) { return typeof v === "number" && isFinite(v) ? v : null; }
function isMilFlag(ac) { return typeof ac.dbFlags === "number" && (ac.dbFlags & 1) === 1; }
function classifyAircraft(ac, matchers, requireMil) {
  var t = normType(ac.t);
  var r = String(ac.r == null ? "" : ac.r).toUpperCase().trim();
  var hex = String(ac.hex == null ? "" : ac.hex).toLowerCase();
  var keys = Object.keys(matchers || {});
  for (var i = 0; i < keys.length; i++) {
    var m = matchers[keys[i]] || {};
    var regs = (m.regs || []).map(function (x) { return String(x).toUpperCase(); }), hexes = (m.hex || []).map(function (x) { return String(x).toLowerCase(); });
    if (regs.length && regs.indexOf(r) !== -1) return keys[i];
    if (hexes.length && hexes.indexOf(hex) !== -1) return keys[i];
    if (requireMil && !isMilFlag(ac)) continue;   // type-only matches in the sector need the military flag
    var types = m.types || [];
    for (var a = 0; a < types.length; a++) { if (normType(types[a]) === t) return keys[i]; }
  }
  return null;
}
function isAirborne(ac) {
  // Positive evidence only — never cry AIRBORNE on ground traffic.
  if (ac.alt_baro === "ground") return false;
  if (typeof ac.alt_baro === "number") return ac.alt_baro > 500;
  if (typeof ac.alt_geom === "number") return ac.alt_geom > 500;
  if (typeof ac.gs === "number") return ac.gs > 120;
  return false;
}
function buildMatch(cls, ac) {
  var hex = String(ac.hex == null ? "" : ac.hex).toLowerCase(); if (!/^[0-9a-f]{6,7}$/.test(hex)) hex = "";
  var lat = num(ac.lat), lon = num(ac.lon);
  return {
    cls: cls, hex: hex,
    r: self.OracleSanitize.text(ac.r || "", 12), flight: self.OracleSanitize.text(ac.flight || "", 12),
    t: self.OracleSanitize.text(ac.t || "", 8), desc: self.OracleSanitize.text(ac.desc || "", 40),
    alt: (ac.alt_baro === "ground") ? "ground" : num(ac.alt_baro), gs: num(ac.gs),
    lat: lat == null ? null : Math.round(lat * 10) / 10, lon: lon == null ? null : Math.round(lon * 10) / 10, // coarse by design
    seen: num(ac.seen), airborne: isAirborne(ac)
  };
}
function clampNum(v, lo, hi, dflt) { var n = Number(v); if (!isFinite(n)) return dflt; return Math.max(lo, Math.min(hi, n)); }

function safeFetchFlights(matchers) {
  return safeGet(FLIGHT_URL, [FLIGHT_HOST], true).then(function (r) {
    if (!r.ok) return r;
    var j = r.body || {}; var list = (j.ac || j.aircraft) || []; var out = [];
    for (var i = 0; i < list.length && out.length < MAX_FLIGHT_MATCHES; i++) { var ac = list[i]; if (!ac) continue; var cls = classifyAircraft(ac, matchers, false); if (cls) out.push(buildMatch(cls, ac)); }
    return { ok: true, ac: out, ts: r.ts, total: (typeof j.total === "number" ? j.total : list.length) };
  });
}
function safeFetchSector(sector, matchers) {
  var s = sector || DEFAULTS.sector;
  var lat = clampNum(s.lat, -90, 90, 0), lon = clampNum(s.lon, -180, 180, 0), dist = Math.round(clampNum(s.dist != null ? s.dist : s.radiusNm, 1, 250, 120));
  var url = "https://" + FLIGHT_HOST + "/api/v3/lat/" + lat + "/lon/" + lon + "/dist/" + dist;
  return safeGet(url, [FLIGHT_HOST], true).then(function (r) {
    if (!r.ok) return r;
    var j = r.body || {}; var list = (j.ac || j.aircraft) || []; var scan = Math.min(list.length, MAX_SECTOR_SCAN); var mil = 0, hits = [];
    for (var i = 0; i < scan; i++) { var ac = list[i]; if (!ac) continue; if (isMilFlag(ac)) mil++; var cls = classifyAircraft(ac, matchers, true); if (cls && hits.length < MAX_SECTOR_HITS) hits.push(buildMatch(cls, ac)); }
    return { ok: true, ts: r.ts, lat: lat, lon: lon, dist: dist, total: (typeof j.total === "number" ? j.total : list.length), mil: mil, ac: hits };
  });
}

/* ---------- pattern-of-life / went-dark store ---------- */
function pushTrackEvent(store, ev) { store.events.unshift(ev); if (store.events.length > TRACK_MAX_EVENTS) store.events.length = TRACK_MAX_EVENTS; }
function updateTrackStore(store, res, now) {
  if (!store || !store.craft) store = { craft: {}, events: [], prevAirborne: [], ts: 0 };
  var prevAirborne = store.prevAirborne || []; var curAirborne = [];
  if (res && res.ok && res.ac) {
    res.ac.forEach(function (m) {
      if (!m || !m.hex) return;
      var rec = store.craft[m.hex] || { cls: m.cls, r: m.r || "", flight: m.flight || "", firstTs: now };
      rec.cls = m.cls; if (m.r) rec.r = m.r; if (m.flight) rec.flight = m.flight; rec.lastTs = now;
      if (typeof m.lat === "number" && typeof m.lon === "number") rec.lastPos = { lat: m.lat, lon: m.lon, alt: (typeof m.alt === "number" ? m.alt : null), ts: now };
      rec.status = m.airborne ? "airborne" : "ground";
      if (m.airborne) { curAirborne.push(m.hex); if (prevAirborne.indexOf(m.hex) === -1) pushTrackEvent(store, { ts: now, kind: "appeared", cls: m.cls, hex: m.hex, r: m.r || "", flight: m.flight || "", lat: num(m.lat), lon: num(m.lon), alt: num(m.alt) }); }
      store.craft[m.hex] = rec;
    });
  }
  prevAirborne.forEach(function (hex) {
    if (curAirborne.indexOf(hex) === -1) { var rec = store.craft[hex]; if (!rec) return; rec.status = "dark"; rec.darkTs = now; var lp = rec.lastPos || {}; pushTrackEvent(store, { ts: now, kind: "dark", cls: rec.cls, hex: hex, r: rec.r || "", flight: rec.flight || "", lat: num(lp.lat), lon: num(lp.lon), alt: num(lp.alt), sinceTs: rec.lastPos ? rec.lastPos.ts : rec.lastTs }); store.craft[hex] = rec; }
  });
  Object.keys(store.craft).forEach(function (h) { if (store.craft[h].lastTs && store.craft[h].lastTs < now - TRACK_TTL_MS) delete store.craft[h]; });
  store.prevAirborne = curAirborne; store.ts = now; return store;
}
// 7-day per-type sighting history: which UTC days each watched type was seen airborne.
function updatePol(pol, res, now) {
  pol = pol || {};
  var day = Math.floor(now / 864e5);
  if (res && res.ok && res.ac) res.ac.forEach(function (m) { if (!m.airborne) return; var p = pol[m.cls] || { days: [], lastSeen: 0 }; if (p.days.indexOf(day) === -1) p.days.push(day); p.lastSeen = now; pol[m.cls] = p; });
  Object.keys(pol).forEach(function (k) { var p = pol[k]; p.days = (p.days || []).filter(function (d) { return d > day - 7; }).slice(-14); p.days7 = p.days.length; });
  return pol;
}

/* ---------- refresh cycles ---------- */
async function refreshChannels() {
  var cfg = await getLocal(["channels", "customChannels", "tg_health"]);
  var handles = effectiveChannels(cfg); var health = cfg.tg_health || {}; var cache = {}; var now = Date.now();
  var prev = (await getLocal(["tg_cache"])).tg_cache || {};
  for (var i = 0; i < handles.length; i++) {
    var h = handles[i]; var hl = health[h] || { fails: 0, nextTry: 0 };
    if (hl.fails > 0 && hl.nextTry > now) { if (prev[h]) cache[h] = prev[h]; continue; }  // in backoff: keep last good copy
    var res = await safeFetchChannel(h); // eslint-disable-line no-await-in-loop
    if (res.ok) { hl = { fails: 0, nextTry: 0, lastOk: now }; cache[h] = res; }
    else { hl.fails = (hl.fails || 0) + 1; hl.nextTry = now + Math.min(BACKOFF_MAX_MS, BACKOFF_BASE_MS * Math.pow(2, hl.fails - 1)); hl.lastError = res.error; cache[h] = prev[h] && prev[h].ok ? prev[h] : res; }
    health[h] = hl;
  }
  Object.keys(health).forEach(function (h) { if (handles.indexOf(h) === -1) delete health[h]; });
  await setLocal({ tg_cache: cache, tg_health: health, tg_last_run: now });
  return Object.keys(cache).length;
}
async function refreshFlights() {
  var cfg = await getLocal(["trackMatch", "flt_track", "flt_pol"]);
  var matchers = cfg.trackMatch || DEFAULTS.trackMatch; var res = await safeFetchFlights(matchers); var now = Date.now();
  var store = updateTrackStore(cfg.flt_track, res, now); var pol = updatePol(cfg.flt_pol, res, now);
  await setLocal({ flt_cache: res, flt_last_run: now, flt_track: store, flt_pol: pol });
  return res.ok ? res.ac.length : 0;
}
async function refreshSector() {
  var cfg = await getLocal(["sector", "airSector", "trackMatch"]);
  var matchers = (cfg && cfg.trackMatch) || DEFAULTS.trackMatch;
  var res = await safeFetchSector(cfg && cfg.sector, matchers);
  var out = { sec_cache: res, sec_last_run: Date.now() };
  if (cfg && cfg.airSector && typeof cfg.airSector === "object") { out.air_sec_cache = await safeFetchSector(cfg.airSector, matchers); }
  await setLocal(out);
  return res.ok ? res.total : 0;
}

/* ---------- local collector (LOOKING GLASS) ----------
   Loopback only. The endpoint is validated by OracleSanitize.localEndpoint; the token travels in a
   header; responses are size-capped, parsed as JSON, trimmed to a bounded number of items/media and
   stored verbatim for the PAGE to sanitise before rendering (text-only there). Never a POST. */
function collectorHostOk(url) { try { var u = new URL(url); return (u.protocol === "http:" || u.protocol === "https:") && (u.hostname === "127.0.0.1" || u.hostname === "localhost" || u.hostname === "[::1]"); } catch (e) { return false; } }
function collectorGet(endpoint, pathname, token) {
  var ep = self.OracleSanitize.localEndpoint(endpoint); if (!ep) return Promise.resolve({ ok: false, error: "endpoint not loopback" });
  var url = ep + pathname; if (!collectorHostOk(url)) return Promise.resolve({ ok: false, error: "host not loopback" });
  var controller = new AbortController(); var timer = setTimeout(function () { controller.abort(); }, COL_TIMEOUT_MS);
  var headers = { "accept": "application/json" }; if (token) headers["x-lg-token"] = token;
  return fetch(url, { method: "GET", redirect: "error", credentials: "omit", referrerPolicy: "no-referrer", cache: "no-store", signal: controller.signal, headers: headers })
    .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); var len = Number(r.headers.get("content-length") || 0); if (len > COL_MAX_BYTES) throw new Error("response too large"); return r.text(); })
    .then(function (t) { clearTimeout(timer); if (t.length > COL_MAX_BYTES) throw new Error("response too large"); return { ok: true, body: JSON.parse(t) }; })
    .catch(function (err) { clearTimeout(timer); return { ok: false, error: (err && err.message) || "fetch failed" }; });
}
function trimCollector(summary, items, media, digest) {
  var it = Array.isArray(items) ? items.slice(0, COL_MAX_ITEMS) : [];
  var md = Array.isArray(media) ? media.slice(0, COL_MAX_MEDIA) : [];
  return { ok: true, ts: Date.now(), summary: summary && typeof summary === "object" ? summary : {}, items: it, media: md, digest: digest && typeof digest === "object" ? digest : null };
}
async function refreshCollector() {
  var cfg = await getLocal(["collector", "col_health"]);
  var col = (cfg && cfg.collector) || DEFAULTS.collector; if (!col || !col.enabled) return 0;
  var health = cfg.col_health || { fails: 0, nextTry: 0 }; var now = Date.now();
  if (health.fails > 0 && health.nextTry > now) return 0;
  var tok = self.OracleSanitize.token(col.token) || "";
  var sum = await collectorGet(col.endpoint, "/api/summary", tok);
  if (!sum.ok) { health.fails = (health.fails || 0) + 1; health.nextTry = now + Math.min(BACKOFF_MAX_MS, BACKOFF_BASE_MS * Math.pow(2, health.fails - 1)); health.lastError = sum.error; await setLocal({ col_health: health, col_cache: { ok: false, error: sum.error, ts: now } }); return 0; }
  var items = await collectorGet(col.endpoint, "/api/items?limit=" + COL_MAX_ITEMS, tok);
  var media = await collectorGet(col.endpoint, "/api/media?limit=" + COL_MAX_MEDIA, tok);
  var digest = await collectorGet(col.endpoint, "/api/digest", tok);
  var cache = trimCollector(sum.body, items.ok ? (items.body.items || items.body) : [], media.ok ? (media.body.media || media.body) : [], digest.ok ? digest.body : null);
  await setLocal({ col_cache: cache, col_last_run: now, col_health: { fails: 0, nextTry: 0, lastOk: now } });
  return cache.items.length;
}
async function refreshAll() {
  var tg = await refreshChannels(); var fl = await refreshFlights(); var sec = await refreshSector(); var col = await refreshCollector();
  return { updated: tg, flights: fl, sector: sec, collector: col, ts: Date.now() };
}

/* ---------- alarm scheduling ---------- */
async function scheduleAlarm() {
  var cfg = await getLocal(["refreshMinutes"]);
  var mins = Math.min(180, Math.max(15, cfg.refreshMinutes || DEFAULTS.refreshMinutes));
  chrome.alarms.clear(ALARM_NAME, function () { chrome.alarms.create(ALARM_NAME, { periodInMinutes: mins }); });
  chrome.alarms.clear(FLIGHT_ALARM, function () { chrome.alarms.create(FLIGHT_ALARM, { periodInMinutes: FLIGHT_MINUTES }); });
}
chrome.runtime.onInstalled.addListener(async function () {
  var cur = await getLocal(["refreshMinutes"]);
  if (!cur.refreshMinutes) await setLocal({ refreshMinutes: DEFAULTS.refreshMinutes });
  await scheduleAlarm(); refreshAll();
});
chrome.runtime.onStartup.addListener(function () { scheduleAlarm(); });
chrome.alarms.onAlarm.addListener(function (alarm) {
  if (!alarm) return;
  if (alarm.name === ALARM_NAME) refreshAll();
  else if (alarm.name === FLIGHT_ALARM) { refreshFlights().then(refreshSector); }
});

/* ---------- message API for the dashboard / popup ---------- */
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type) return false;
  // Only our own extension pages may drive the worker.
  if (!sender || !sender.id || sender.id !== chrome.runtime.id) return false;
  if (msg.type === "seed") {
    // The dashboard seeds channels / matchers / sector / tempos from data.js. Re-seed only when
    // the data changed (seedVersion), so user lane toggles survive page reloads.
    getLocal(["seedVersion", "channels"]).then(function (cur) {
      var seed = {};
      var fresh = !cur.seedVersion || cur.seedVersion !== msg.seedVersion || !cur.channels;
      if (fresh && Array.isArray(msg.channels)) seed.channels = msg.channels.filter(function (c) { return c && self.OracleSanitize.handle(c.handle); }).map(function (c) { return { handle: self.OracleSanitize.handle(c.handle), enabled: c.enabled !== false, verified: c.verified === true }; }).slice(0, MAX_CHANNELS);
      if (msg.trackMatch && typeof msg.trackMatch === "object") seed.trackMatch = msg.trackMatch;
      if (msg.sector && typeof msg.sector === "object") seed.sector = msg.sector;
      if (msg.airSector && typeof msg.airSector === "object") seed.airSector = msg.airSector; else seed.airSector = null;
      if (msg.tempos && typeof msg.tempos === "object") seed.tempos = msg.tempos;
      if (msg.seedVersion) seed.seedVersion = String(msg.seedVersion).slice(0, 32);
      return setLocal(seed);
    }).then(function () { sendResponse({ ok: true }); });
    return true;
  }
  if (msg.type === "refreshNow") { refreshAll().then(sendResponse); return true; }
  if (msg.type === "getCache") {
    getLocal(["tg_cache", "tg_health", "tg_last_run", "flt_track", "flt_cache", "flt_pol", "flt_last_run", "sec_cache", "sec_last_run", "air_sec_cache", "col_cache", "col_last_run", "col_health", "collector", "channels", "customChannels", "trackMatch", "sector", "refreshMinutes"]).then(function (r) {
      if (r && r.collector) r.collector = { endpoint: r.collector.endpoint, enabled: !!r.collector.enabled };   // the token never leaves the worker
      sendResponse(r);
    });
    return true;
  }
  if (msg.type === "collectorTest") {
    getLocal(["collector"]).then(async function (cfg) {
      var col = (cfg && cfg.collector) || DEFAULTS.collector; var tok = self.OracleSanitize.token(col.token) || "";
      var r = await collectorGet(col.endpoint, "/api/summary", tok);
      if (!r.ok) { sendResponse({ ok: false, error: r.error }); return; }
      await setLocal({ col_health: { fails: 0, nextTry: 0, lastOk: Date.now() } });
      var n = await refreshCollector();
      sendResponse({ ok: true, items: n, media: (r.body && r.body.media) || 0, version: (r.body && r.body.version) || "" });
    });
    return true;
  }
  if (msg.type === "reschedule") { scheduleAlarm().then(function () { sendResponse({ ok: true }); }); return true; }
  if (msg.type === "clearCache") { removeLocal(["tg_cache", "tg_health", "tg_last_run", "flt_track", "flt_cache", "flt_pol", "flt_last_run", "sec_cache", "sec_last_run", "air_sec_cache", "col_cache", "col_last_run", "col_health"]).then(function () { sendResponse({ ok: true }); }); return true; }
  return false;
});
