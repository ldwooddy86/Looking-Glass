/* ============================================================
   sanitize.js — dependency-free sanitizer for untrusted content
   ------------------------------------------------------------
   Channel-preview HTML, AI-returned text and anything else that
   arrives over the network is HOSTILE input. Nothing from the
   network is ever assigned to innerHTML anywhere in LOOKING GLASS.
   This module returns plain strings that callers insert via
   textContent / createTextNode only, plus a few validators that
   refuse to let user- or data-supplied values steer a fetch.
   Works in the page (window) and in the service worker (self).
   LOOKING GLASS adds loopback-only validators for the optional local
   collector: an endpoint is accepted only on 127.0.0.1 / localhost.
   ============================================================ */
(function (root) {
  "use strict";

  function stripTags(input) {
    if (input == null) return "";
    var s = String(input);
    s = s.replace(/<!--[\s\S]*?-->/g, " ");
    s = s.replace(/<[^>]*>/g, " ");
    return s;
  }

  var ENTITIES = {
    "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"',
    "&#39;": "'", "&apos;": "'", "&nbsp;": " ", "&hellip;": "…",
    "&mdash;": "—", "&ndash;": "–", "&laquo;": "«", "&raquo;": "»"
  };
  function safeCP(n) { try { return String.fromCodePoint(n); } catch (e) { return " "; } }
  function decodeEntities(s) {
    s = s.replace(/&#x([0-9a-fA-F]+);/g, function (_, h) { var n = parseInt(h, 16); return n >= 32 && n <= 0x10ffff ? safeCP(n) : " "; });
    s = s.replace(/&#(\d+);/g, function (_, d) { var n = parseInt(d, 10); return n >= 32 && n <= 0x10ffff ? safeCP(n) : " "; });
    s = s.replace(/&[a-zA-Z]+;/g, function (m) { return Object.prototype.hasOwnProperty.call(ENTITIES, m) ? ENTITIES[m] : " "; });
    return s;
  }

  // Collapse control characters, bidi overrides (spoofing) and runaway whitespace.
  function collapse(s) {
    return s
      .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, " ")
      .replace(/[\u202a-\u202e\u2066-\u2069]/g, "")
      .replace(/[ \t\u00a0]+/g, " ")
      .replace(/\s*\n\s*/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  // Full pipeline for one untrusted string; hard length cap.
  function text(input, maxLen) {
    var s = collapse(decodeEntities(stripTags(input)));
    var lim = typeof maxLen === "number" ? maxLen : 600;
    if (s.length > lim) s = s.slice(0, lim - 1).trimEnd() + "…";
    return s;
  }

  // Telegram public handle: refuses anything that could steer a fetch off t.me or inject path segments.
  function handle(h) {
    if (h == null) return null;
    var s = String(h).trim().replace(/^@/, "").replace(/^https?:\/\/t\.me\/(s\/)?/i, "");
    return /^[a-zA-Z0-9_]{3,64}$/.test(s) ? s : null;
  }

  // Only https URLs with a plain host are allowed to become <a href>.
  function safeHttpsUrl(u) {
    if (u == null) return null;
    var s = String(u).trim();
    if (!/^https:\/\/[a-z0-9.-]+\.[a-z]{2,}(?:[/?#][^\s"'<>]*)?$/i.test(s)) return null;
    return s;
  }

  // Anthropic model id / alias: letters, digits, dots and dashes only.
  function modelId(m) {
    if (m == null) return null;
    var s = String(m).trim();
    return /^[a-zA-Z0-9.-]{3,64}$/.test(s) ? s : null;
  }

  // API key shape check only (never logged, never sent anywhere but the API host).
  function apiKey(k) {
    if (k == null) return null;
    var s = String(k).trim();
    return /^[A-Za-z0-9_-]{16,256}$/.test(s) ? s : null;
  }

  // Local collector endpoint: http(s) on the loopback interface only, optional port, no path/query.
  function localEndpoint(u) {
    if (u == null) return null;
    var s = String(u).trim().replace(/\/+$/, "");
    var m = s.match(/^(https?):\/\/(127\.0\.0\.1|localhost|\[::1\])(?::(\d{2,5}))?$/i);
    if (!m) return null;
    var port = m[3] ? parseInt(m[3], 10) : (m[1].toLowerCase() === "https" ? 443 : 80);
    if (!(port >= 1 && port <= 65535)) return null;
    return m[1].toLowerCase() + "://" + m[2].toLowerCase() + (m[3] ? ":" + port : "");
  }
  // A URL under an accepted local endpoint (thumbnails, originals served by the collector).
  function safeLocalUrl(u, endpoint) {
    var ep = localEndpoint(endpoint); if (!ep || u == null) return null;
    var s = String(u).trim();
    if (s.indexOf(ep + "/") !== 0) return null;
    if (!/^[A-Za-z0-9:\/._~?=&%-]+$/.test(s) || s.indexOf("..") !== -1) return null;
    return s;
  }
  // Collector shared token: printable, bounded.
  function token(t) {
    if (t == null) return null;
    var s = String(t).trim();
    return /^[A-Za-z0-9_-]{8,128}$/.test(s) ? s : null;
  }

  root.OracleSanitize = { text: text, stripTags: stripTags, handle: handle, safeHttpsUrl: safeHttpsUrl, modelId: modelId, apiKey: apiKey, localEndpoint: localEndpoint, safeLocalUrl: safeLocalUrl, token: token };
})(typeof self !== "undefined" ? self : this);
