"use strict";
(function () {
  var D = window.ORACLE_DATA || {};
  function fmtAgo(ts) {
    if (!ts) return "never";
    var s = Math.max(0, Math.floor((Date.now() - ts) / 1000));
    if (s < 60) return s + "s ago"; var m = Math.floor(s / 60); if (m < 60) return m + "m ago";
    var h = Math.floor(m / 60); if (h < 24) return h + "h ago"; return Math.floor(h / 24) + "d ago";
  }
  function setText(id, v, cls) { var e = document.getElementById(id); if (!e) return; e.textContent = v; if (cls != null) e.className = cls; }
  // Identity + posture straight from data.js (no packaging-time string surgery needed).
  var m = D.meta || {}, p = D.posture || {};
  setText("eyebrow", "OSINT · " + (m.country || "MILITARY").toUpperCase() + " WATCH");
  setText("brand", m.brand || "LOOKING GLASS");
  var lvl = String(p.level || "elevated").toLowerCase();
  setText("flag", lvl.toUpperCase(), "flag " + ((lvl === "high" || lvl === "severe") ? "high" : (lvl === "stable" || lvl === "guarded") ? "calm" : ""));
  function boardState(flt) {
    var types = (D.trackWatch && D.trackWatch.types) || []; var up = 0, crit = 0;
    var seen = {}; if (flt && flt.ok && flt.ac) flt.ac.forEach(function (a) { if (a.airborne) seen[a.cls] = true; });
    types.forEach(function (t) { if (seen[t.key]) { up++; if (t.crit) crit++; } });
    var cfg = (D.trackWatch && D.trackWatch.alert) || {}; var total = types.length;
    var redN = Math.min(total || 1, cfg.red || Math.max(3, Math.ceil(total * 0.6))), alertN = Math.min(total || 1, cfg.alert || Math.max(2, Math.ceil(total * 0.34)));
    if (alertN >= redN) alertN = Math.max(1, redN - 1);
    return (up >= redN || crit >= 2) ? "RED" : (up >= alertN || crit >= 1) ? "ALERT" : up > 0 ? "WATCH" : "QUIET";
  }
  function refreshView() {
    chrome.runtime.sendMessage({ type: "getCache" }, function (resp) {
      if (chrome.runtime.lastError || !resp) return;
      var cache = resp.tg_cache || {}; var handles = Object.keys(cache); var ok = handles.filter(function (h) { return cache[h] && cache[h].ok; }).length;
      setText("tgCount", handles.length ? (ok + " / " + handles.length + " live") : "none enabled");
      var flt = resp.flt_cache && resp.flt_cache.ok ? resp.flt_cache.ac.length : 0;
      setText("fltCount", flt + " airframe(s) matched");
      var st = boardState(resp.flt_cache); setText("fltState", st, st === "RED" ? "red" : "");
      setText("lastRun", fmtAgo(resp.tg_last_run || resp.flt_last_run));
    });
  }
  document.getElementById("open").addEventListener("click", function () { chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") }); });
  document.getElementById("refresh").addEventListener("click", function () {
    var b = document.getElementById("refresh"); b.textContent = "…";
    chrome.runtime.sendMessage({ type: "refreshNow" }, function () { b.textContent = "Refresh"; refreshView(); });
  });
  refreshView();
})();
