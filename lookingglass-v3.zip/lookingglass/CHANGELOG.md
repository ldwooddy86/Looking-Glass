# CHANGELOG

## 3.0.0 — LOOKING GLASS (15 SEP 2026)

The unification of DalesOracle v2.1 and Countdown (Edition 2026.09c) into one platform, plus the
two legs neither had.

### Engine (dashboard, `assets/extension/`)
- New tabs: **Air Watch**, **Launcher Watch**, **Triad Map**, **Feed**, **Media** (21 tabs, five
  groups). Brand LOOKING GLASS; `ENGINE_NAME` in the build record.
- `airWatch` block with a **live board** (`air:`-namespaced keys in the shared worker cache) for
  the subject's transponding support types; `launcherWatch` block; `triadMaps` block (iframes;
  preview embeds map pages as base64 `window.LG_MAPS`; extension packages `dist/maps/ext/*`);
  `collector` block (loopback-only local collector, optional host permission granted on click,
  `x-lg-token` header never returned to the page).
- Live ADS-B overlay on air theatres via `postMessage {type:'lg-live'}`; lazy loading of the
  first theatre on tab activation; `fitTo`/`applyView` guards and a `ResizeObserver` so hidden
  iframes never compute `scale(Infinity)`.
- `sanitize.js`: `localEndpoint`, `safeLocalUrl`, `token`. `background.js`: collector lane
  (`collectorGet`, `collectorHostOk`, `trimCollector`, `refreshCollector`, `collectorTest`), air
  sector (`air_sec_cache`). `manifest.json` 3.0.0: optional loopback hosts; CSP widened only for
  `img/media/connect-src` to `http://127.0.0.1:*` / `http://localhost:*`.
- `dashboard.css`: LG v3 styles; `.map-frame` height `clamp(760px, 94vh, 1500px)`; four-column
  feed stats; `.sw-side-subject` chip.
- Validator: `subWatch.environment.side` accepts `subject` (keeps `prc` for the v2.1 China build);
  Air/Launcher Watch checks (roles, statuses, `transponds`, ICAO designators, `unseen` requirement,
  targeting/position rails); `triadMaps` (config exists, leg = `grid.domain`, edition match);
  `collector` (kinds, loopback endpoint, snowflake ids, https feeds, **secret detection**).

### Maps (`assets/maps/engine/`, `scripts/maps_*`)
- Domains `sea | land | air` with per-domain rasters (land: road corridors, cover, urban, water
  impassable; air: own/allied/neutral/adversary airspace), vocab, layer menus and tile labels.
- Classes: `deployed` (alias `at_sea`), `terrain_suitability` (alias `depth_suitability`),
  `cell_cost[8]`, `sources_scenarios`, combined `{mod, base, gain, scenario, value}` parameters;
  factor type `terrain`; base kinds `garrison | airbase | depot | site`; point kinds `sighting |
  exercise | closure`; generic `GEO.layers`; `confine_iso / own_iso / allied_iso / adversary_iso`,
  `cover_polygons / cover_geojson / road_buffer_km / force_block`.
- `maps_validate_config.js`: domain checks, numeric-share checks, dead-scenario ERROR, sighting
  must be worded as a claim, launcher/bomber/targeting rails, passable-cell floor.
  `maps_test_model.js`: `--posture`, `--scenario`, `--off`. `maps_build.py`: `standalone` and
  `ext` modes (`<id>.html`, `<id>.artifact.html`, `ext/<id>.html` + `.data.js` + `engine.js`).
- Mobile: `.ctl` wraps; `.pill` wraps at ≤640 px; no horizontal overflow at 390 px.
- All ten theatre configs rebranded LOOKING GLASS (sea editions unchanged). The new dead-scenario
  rule caught three inherited dead checkboxes, now wired: India `varsha_open` (SSBN sources swap to
  Rambilli), Israel `berbera` (0.15-weight second source for the AIP boats), North Korea `mass_sortie`
  (coastal-boat envelope 320 → 480 nm).

### Collector (`collector/`)
- Python 3.11+, stdlib HTTP/SQLite/XML + Telethon, discord.py (REST-only), Pillow; ffmpeg and
  yt-dlp optional. Connectors: Telegram user session (MTProto) and bot, Discord bot, Bluesky
  (author feeds + authenticated search), Mastodon, Reddit (public/OAuth), YouTube Data API v3,
  RSS/Atom, adsb.fi military + sectors, NGA MSI broadcast warnings (`P/A/C/12/4`), FAA NOTAM API;
  X v2 slot built and disabled (paid API).
- Keyword pre-triage from `watchlists/<subject>.json` (Cyrillic stems), Claude triage / vision /
  digest agent (JSON-only, "never assert positions" rails), dHash perceptual dedupe, EXIF-stripped
  thumbnails, ffmpeg frames, loopback `ThreadingHTTPServer` with CORS and token, static exports.
- `init --from-data` now also seeds ADS-B sectors, NAVWARN areas/keywords and NOTAM locations
  from `collector.sources`; example config designators corrected (`TU95`, `T22M`, `MG31`, `IL86`,
  `IL18`); dead Barents Observer feed replaced by the russianforces.org Atom feed.
- `tests/test_offline.py` — 8 tests (store, media, triage, server, export, config rails).

### Russia flagship (`assets/extension/data.js`, `data/theatres/russia-*.json`)
- Full dataset compiled 15 SEP 2026 (≈285 KB): posture HIGH; 6 Key Judgments; 10-domain matrix;
  forces with alt figures and a search-verified leadership board; 27 events; 18 I&W rows; ACH 4 × 14;
  movement scanner (9 categories); Track Watch (Baltic sector); OSINT with 43 channels (40 verified
  on the build date, 16 enabled — the worker's cap); state media, social, academia (8 countries), reliability annex (32 entries);
  escalation (16 drivers, 5 scenarios); protective layer (5 actors, 8 indicators, 12 incidents,
  7 target classes, 9 sectors, 13 regions); Sub Watch (8 classes, 6 bases, 11 I&W, 5-layer
  ledger); Air Watch (12 types, 11 bases, 9 I&W, live board: Kola sector, 5 verified designators);
  Launcher Watch (7 systems, 12 garrisons, 8 I&W); Triad Map (4 theatres); collector plan (75
  sources: 41 Telegram, 17 RSS, 5 ADS-B sectors, NAVWARN, NOTAM, Bluesky, Mastodon, Reddit, YouTube, X slot).
- `russia-land` Edition 2026.09a: Yars/Topol-M (198 launchers, seven divisions), Iskander (156,
  eight garrisons in frame), Oreshnik (Krichev-6); `russia-air` Edition 2026.09a: Tu-95MS,
  Tu-160, Tu-22M3, MiG-31K, support; 16 bases; launch-axis and patrol-lane points.
- `references/countries/russia.md`: LG-RU-L1…L22, LG-RU-A1…A22, LG-RU-T1 added.

### References
- SCHEMA (v3 blocks and enums), MAPS-SCHEMA (domains, land/air keys), TRADECRAFT §9,
  MAPS-TRADECRAFT §7b, RESEARCH-PLAYBOOK §7, ADSB-TYPES (Russian designators verified at
  doc8643.com), new AIRCRAFT.md, LAUNCHERS.md, CONNECTORS.md; SKILL.md, README.md, extension
  README rewritten.

## 2.1 — DalesOracle (08 SEP 2026)
Sub Watch block; China / PLA reference build. See the DalesOracle skill for the earlier history.

## Countdown Edition 2026.09c (10 SEP 2026)
Eight sea theatres. See the Countdown skill for the earlier history.
