# LOOKING GLASS collector

The part of LOOKING GLASS that runs on **your** machine, through **your** accounts, and only ever
**reads**. It pulls posts, photos and video from the channels you point it at, keeps them in a local
SQLite store with EXIF-stripped thumbnails, runs a keyword pre-triage and (optionally) a Claude
triage / vision / digest agent, and serves everything to the dashboard over the loopback interface.

```
Telegram (your user session · MTProto)   ─┐
Telegram bot (chats it is added to)      ─┤
Discord bot (servers you invite it to)   ─┤        ┌──────────────┐    http://127.0.0.1:8787     ┌───────────────────────┐
Bluesky · Mastodon · Reddit · YouTube    ─┼──► pull ►│  SQLite +    │◄── GET /api/… (token) ─────│  LOOKING GLASS        │
RSS / Atom                               ─┤        │  media files │                             │  extension (Feed ·    │
adsb.fi military ADS-B · sectors         ─┤        └──────┬───────┘                             │  Media · digest)      │
NGA navigational warnings · FAA NOTAMs   ─┘               │ triage agent (your Anthropic key)    └───────────────────────┘
X / Twitter (slot, disabled: paid API)                    ▼ feed.json · media.json · digest.md/html (export)
```

## Rails

- **Reads only.** No posting, reacting, joining, DMs, follows, or scraping behind another person's login.
  Discord is a *bot* you invite (self-bots violate Discord's terms and are not supported). Telegram is
  the official API through your own session and/or a BotFather bot.
- **Loopback only.** The API binds to 127.0.0.1 and refuses any other host; a shared token is required.
- **Local only.** Items, media, thumbnails and the session file stay under `data_dir`. Nothing is
  uploaded anywhere except sanitised text (and thumbnails, when vision is on) to the Anthropic API for
  triage — with your key, only if you configure one.
- **No positions.** The triage agent records what posts *claim* as claims, graded, labelled unverified.
  It never asserts where a launcher, aircraft, boat or warhead is, and never produces targeting detail.
- **Media hygiene.** Every image is re-encoded (metadata dropped), perceptual-hashed for recycled-footage
  detection, size-capped; video gets three ffmpeg frames and a duration, no re-hosting.

## Install

Python 3.11+. From this folder:

```bash
python -m venv .venv && source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt                            # telethon, discord.py, Pillow
# optional: ffmpeg on PATH (video frames), yt-dlp (YouTube downloads)
python -m lg_collector init --from-data ../assets/extension/data.js    # writes config.toml + a watchlist seeded from the dashboard
```

`init` prints a token — paste it into the dashboard: **Settings → Local collector → token → Connect & test**.

## Credentials (put them in `config.toml`, never in data.js)

| lane | what you need | where |
|---|---|---|
| Telegram (user) | `api_id` + `api_hash`, then `python -m lg_collector login telegram` (phone, code, 2FA) | https://my.telegram.org → API development tools |
| Telegram (bot) | bot token; add the bot to the channels/groups it should read | @BotFather |
| Discord | bot token; invite with *View Channels* + *Read Message History*; channel ids via Developer Mode → Copy ID | https://discord.com/developers |
| Bluesky | nothing for author feeds; an app password (`handle:xxxx-xxxx-xxxx-xxxx`) for keyword searches | Settings → App passwords |
| Mastodon | nothing (public API) | — |
| Reddit | nothing for public JSON (often blocked from cloud IPs); a *script* app id/secret for OAuth | https://www.reddit.com/prefs/apps |
| YouTube | Data API v3 key | Google Cloud console |
| RSS | nothing | — |
| X / Twitter | bearer token — **paid tier for read access**; disabled by default | https://developer.x.com |
| ADS-B | nothing (adsb.fi open data, personal non-commercial use, 1 req/s) | — |
| Navigational warnings | nothing (NGA MSI public API) | — |
| NOTAM | FAA NOTAM API client id/secret (free registration) | https://api.faa.gov |
| Triage agent | Anthropic API key (`LG_ANTHROPIC_API_KEY` or `triage.anthropic_api_key`) | https://console.anthropic.com |

## Run

```bash
python -m lg_collector test        # every enabled connector once, no triage — read the errors
python -m lg_collector once        # one full cycle (collect → triage → digest)
python -m lg_collector run         # cycle every interval_minutes + serve the API (leave it running)
python -m lg_collector status      # counts, per-source health, redacted config
python -m lg_collector export --out exports/   # feed.json · media.json · thumbs/ · digest.md · digest.html
```

Run it under a user session (a terminal, `screen`/`tmux`, a launchd/systemd *user* unit). It does not
need root and should not have it.

## What the dashboard shows

- **Feed** — every item with source, leg (air / land / sea), kind (sortie, launch, exercise, deployment,
  imagery, rhetoric, NOTAM/NAVWARN, ADS-B), entities, the machine-suggested triage (relevance, Admiralty
  grade, one-line summary, the claims it makes) and a link to the source post. Filters by leg, kind,
  source and text.
- **Media** — photo / video thumbnails with *what the machine sees*, suggested aircraft or launcher
  types, the *claimed* place from the post, a consistency check, and the number of near-duplicates
  seen (recycled footage is the norm).
- **Watch digest** — an I&W-style read of the last window written by the agent: leads, corroboration
  status, what is NOT seen, bottom line. All of it unverified by construction.

## Watchlists

`watchlists/<name>.json` — aircraft, launchers, bases, units, exercises, kinds and legs as alias lists
(native script + romanised; Cyrillic *stems* catch inflections). `init --from-data` seeds one from the
dashboard's scanner dictionaries only when none exists (pass `--reseed-watchlist` to overwrite a
curated one on purpose); the bundled `russia.json` is the curated flagship (12 aircraft types, 8
launcher systems, 50 bases, 14 unit groups, 7 exercise families). A term the list lacks cannot be
caught — extend it as the ecosystem shifts.

## Troubleshooting

| symptom | fix |
|---|---|
| `telegram session not authorised` | `python -m lg_collector login telegram` (once per machine) |
| Reddit `HTTP 403 Blocked` | cloud / VPN IPs are blocked from the public JSON; use OAuth app credentials or run from home |
| Bluesky search `403` | keyword search needs `bluesky.app_password = "handle:app-password"` |
| YouTube quota exceeded | Data API v3 default quota is 10,000 units/day; lower channels or interval |
| No digest | triage needs an Anthropic key; keyword pre-triage still runs without one |
| Dashboard says *not connected* | is `run`/`serve` up? same port? token pasted? Chrome granted the loopback origin (Settings → Connect)? |
| Thumbnails missing for video | install ffmpeg (`ffprobe`/`ffmpeg` on PATH) |

## Tests

`python collector/tests/test_offline.py` — store, media pipeline (thumbnails, perceptual-hash dedupe),
keyword triage on Russian text, the API server (token, 404s, CORS preflight), export sanitisation and the
config rails. No network, no accounts.
