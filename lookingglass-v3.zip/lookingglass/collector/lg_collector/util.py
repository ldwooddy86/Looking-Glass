"""Small shared helpers: HTTP (stdlib), hashing, time, text cleaning, bounded retries."""
from __future__ import annotations

import gzip
import hashlib
import html
import json
import logging
import os
import re
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Optional

log = logging.getLogger("lg")

UA = "lookingglass-collector/3.0 (+read-only OSINT monitor; contact: local operator)"
DEFAULT_TIMEOUT = 25


class HttpError(Exception):
    def __init__(self, status: int, msg: str = "", body: bytes = b""):
        super().__init__(f"HTTP {status} {msg}".strip())
        self.status = status
        self.body = body


def http_get(url: str, headers: Optional[dict] = None, timeout: int = DEFAULT_TIMEOUT, max_bytes: int = 8 * 1024 * 1024, params: Optional[dict] = None) -> bytes:
    """GET with a bounded body, gzip support and a descriptive User-Agent. No cookies, no redirects off-host surprises."""
    if params:
        sep = "&" if "?" in url else "?"
        url = url + sep + urllib.parse.urlencode(params, doseq=True)
    req = urllib.request.Request(url, method="GET")
    req.add_header("User-Agent", UA)
    req.add_header("Accept-Encoding", "gzip")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = r.read(max_bytes + 1)
            if len(data) > max_bytes:
                raise HttpError(413, "response too large")
            if r.headers.get("Content-Encoding", "") == "gzip":
                data = gzip.decompress(data)
            return data
    except urllib.error.HTTPError as e:
        raise HttpError(e.code, e.reason, e.read(2048) if hasattr(e, "read") else b"") from None
    except urllib.error.URLError as e:
        raise HttpError(0, str(e.reason)) from None


def http_get_json(url: str, headers: Optional[dict] = None, timeout: int = DEFAULT_TIMEOUT, params: Optional[dict] = None) -> Any:
    h = {"Accept": "application/json"}
    h.update(headers or {})
    return json.loads(http_get(url, h, timeout=timeout, params=params).decode("utf-8", "replace"))


def http_post_json(url: str, body: Any, headers: Optional[dict] = None, timeout: int = 90) -> Any:
    """POST JSON — used ONLY for the Anthropic Messages API (triage agent) and OAuth token exchanges.
    Never used against a social platform's write endpoints."""
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("User-Agent", UA)
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read(16 * 1024 * 1024).decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        body_ = e.read(4096) if hasattr(e, "read") else b""
        raise HttpError(e.code, e.reason, body_) from None
    except urllib.error.URLError as e:
        raise HttpError(0, str(e.reason)) from None


def http_post_form(url: str, form: dict, headers: Optional[dict] = None, timeout: int = 30) -> Any:
    data = urllib.parse.urlencode(form).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("User-Agent", UA)
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read(1024 * 1024).decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        raise HttpError(e.code, e.reason) from None


def download(url: str, dest: str, max_bytes: int, headers: Optional[dict] = None, timeout: int = 120) -> int:
    """Stream a file to disk with a hard size cap. Returns bytes written; raises HttpError on failure."""
    req = urllib.request.Request(url, method="GET")
    req.add_header("User-Agent", UA)
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    n = 0
    tmp = dest + ".part"
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r, open(tmp, "wb") as f:
            while True:
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                n += len(chunk)
                if n > max_bytes:
                    raise HttpError(413, "file exceeds media_max_mb")
                f.write(chunk)
        os.replace(tmp, dest)
        return n
    except urllib.error.HTTPError as e:
        raise HttpError(e.code, e.reason) from None
    except urllib.error.URLError as e:
        raise HttpError(0, str(e.reason)) from None
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass


_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"[ \t ]+")
_CTRL_RE = re.compile("[\\x00-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f\\u202a-\\u202e\\u2066-\\u2069]")


def clean_text(s: Any, limit: int = 4000) -> str:
    """HTML → text, entities decoded, control / bidi characters removed, whitespace collapsed, capped."""
    if s is None:
        return ""
    t = str(s)
    t = re.sub(r"<br\s*/?>|</p>|</div>", "\n", t, flags=re.I)
    t = _TAG_RE.sub(" ", t)
    t = html.unescape(t)
    t = _CTRL_RE.sub(" ", t)
    t = _WS_RE.sub(" ", t)
    t = re.sub(r"\s*\n\s*", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t).strip()
    if len(t) > limit:
        t = t[: limit - 1].rstrip() + "…"
    return t


def sha1(*parts: Any) -> str:
    h = hashlib.sha1()
    for p in parts:
        h.update(str(p).encode("utf-8", "replace"))
        h.update(b"\x1f")
    return h.hexdigest()


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def now() -> int:
    return int(time.time())


def iso(ts: Optional[int]) -> str:
    if not ts:
        return ""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts))


def parse_iso(s: str) -> Optional[int]:
    """Best-effort ISO-8601 / RFC-2822 → epoch seconds."""
    if not s:
        return None
    s = str(s).strip()
    for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            import datetime as _dt
            d = _dt.datetime.strptime(s.replace("+00:00", "+0000"), fmt)
            if d.tzinfo is None:
                d = d.replace(tzinfo=_dt.timezone.utc)
            return int(d.timestamp())
        except ValueError:
            continue
    try:
        from email.utils import parsedate_to_datetime
        return int(parsedate_to_datetime(s).timestamp())
    except Exception:
        return None


def gen_token() -> str:
    return secrets.token_urlsafe(24)


def ensure_dir(p: str) -> str:
    os.makedirs(p, exist_ok=True)
    return p


def safe_name(s: str, limit: int = 80) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", str(s))[:limit] or "x"
