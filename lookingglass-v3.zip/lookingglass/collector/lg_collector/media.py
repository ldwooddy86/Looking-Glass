"""Media handling: bounded download, sha-256, perceptual hash (dHash, 64-bit), EXIF-stripped
thumbnails, video duration and frame extraction via ffmpeg (if present). Nothing here ever
re-uploads anything; files stay under data_dir/media."""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
from typing import Optional

from .store import MediaRef, Store
from .util import download, ensure_dir, safe_name, sha1, sha256_file, HttpError

log = logging.getLogger("lg.media")

try:
    from PIL import Image, ImageOps
    HAVE_PIL = True
except Exception:  # pragma: no cover
    HAVE_PIL = False

IMG_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff", ".heic"}
VID_EXT = {".mp4", ".mov", ".webm", ".mkv", ".m4v", ".avi"}
THUMB_PX = 720


def ffmpeg_ok() -> bool:
    return shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None


def dhash(img) -> str:
    """64-bit difference hash as 16 hex chars (row gradients on a 9×8 grayscale)."""
    g = ImageOps.exif_transpose(img).convert("L").resize((9, 8), Image.Resampling.LANCZOS)
    px = list(g.getdata())
    bits = 0
    for row in range(8):
        for col in range(8):
            left = px[row * 9 + col]
            right = px[row * 9 + col + 1]
            bits = (bits << 1) | (1 if left > right else 0)
    return f"{bits:016x}"


def make_thumb(src: str, dest: str) -> tuple[int, int, str]:
    """Re-encode to a JPEG thumbnail (strips EXIF/GPS by construction). Returns (w, h, phash)."""
    with Image.open(src) as im:
        im = ImageOps.exif_transpose(im)
        w, h = im.size
        ph = dhash(im)
        t = im.convert("RGB")
        t.thumbnail((THUMB_PX, THUMB_PX), Image.Resampling.LANCZOS)
        t.save(dest, "JPEG", quality=82, optimize=True)
    return w, h, ph


def video_probe(path: str) -> float:
    if not ffmpeg_ok():
        return 0.0
    try:
        out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", path], capture_output=True, text=True, timeout=60)
        return float(out.stdout.strip() or 0)
    except Exception:
        return 0.0


def video_frames(path: str, dest_prefix: str, n: int = 3, duration: float = 0.0) -> list[str]:
    """Extract n evenly spaced JPEG frames (the first doubles as the thumbnail source)."""
    if not ffmpeg_ok():
        return []
    out = []
    dur = duration or video_probe(path) or 1.0
    for i in range(n):
        t = max(0.2, dur * (i + 0.5) / n)
        fp = f"{dest_prefix}.f{i}.jpg"
        try:
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", path, "-frames:v", "1", "-q:v", "4", "-vf", "scale='min(960,iw)':-2", fp], capture_output=True, timeout=120)
            if os.path.exists(fp) and os.path.getsize(fp) > 0:
                out.append(fp)
        except Exception:
            continue
    return out


class MediaPipeline:
    def __init__(self, store: Store, data_dir: str, max_mb: int = 40):
        self.store = store
        self.dir = ensure_dir(os.path.join(data_dir, "media"))
        self.thumbs = ensure_dir(os.path.join(data_dir, "thumbs"))
        self.max_bytes = int(max_mb) * 1024 * 1024

    def ingest(self, item_id: str, source_id: str, ts: int, ref: MediaRef, headers: Optional[dict] = None) -> Optional[str]:
        """Download (or adopt a connector-downloaded file), hash, thumbnail, register. Returns media id."""
        mid = sha1(item_id, ref.url or ref.local_path)
        if self.store.has_media(mid):
            return mid
        ext = os.path.splitext((ref.filename or ref.url or ref.local_path).split("?")[0])[1].lower()
        kind = "video" if (ref.kind == "video" or ext in VID_EXT) else "photo"
        if not ext or (ext not in IMG_EXT and ext not in VID_EXT):
            ext = ".mp4" if kind == "video" else ".jpg"
        dest = os.path.join(self.dir, f"{mid}{ext}")
        nbytes = 0
        try:
            if ref.local_path and os.path.exists(ref.local_path):
                if os.path.abspath(ref.local_path) != os.path.abspath(dest):
                    shutil.move(ref.local_path, dest)
                nbytes = os.path.getsize(dest)
            elif ref.url:
                if ref.bytes and ref.bytes > self.max_bytes:
                    log.info("skip oversize media %s (%d bytes)", ref.url[:80], ref.bytes)
                    self.store.add_media(mid, item_id, kind, ref.url, "", "", "", "", 0, 0, 0.0, ref.bytes, source_id, ts)
                    return mid
                nbytes = download(ref.url, dest, self.max_bytes, headers=headers)
            else:
                return None
        except HttpError as e:
            log.warning("media download failed %s: %s", ref.url[:80], e)
            self.store.add_media(mid, item_id, kind, ref.url, "", "", "", "", 0, 0, 0.0, 0, source_id, ts)
            return mid
        except OSError as e:
            log.warning("media store failed: %s", e)
            return None
        sha = sha256_file(dest)
        thumb = os.path.join(self.thumbs, f"{mid}.jpg")
        w = h = 0; ph = ""; dur = 0.0
        try:
            if kind == "photo" and HAVE_PIL:
                w, h, ph = make_thumb(dest, thumb)
            elif kind == "video":
                dur = video_probe(dest)
                frames = video_frames(dest, os.path.join(self.thumbs, mid), 3, dur)
                if frames and HAVE_PIL:
                    w, h, ph = make_thumb(frames[0], thumb)
        except Exception as e:
            log.warning("thumbnail failed for %s: %s", mid, e)
            thumb = "" if not os.path.exists(thumb) else thumb
        if not os.path.exists(thumb):
            thumb = ""
        dups = len(self.store.phash_neighbours(ph)) if ph else 0
        self.store.add_media(mid, item_id, kind, ref.url, dest, thumb, sha, ph, w, h, dur, nbytes, source_id, ts, dups)
        return mid
