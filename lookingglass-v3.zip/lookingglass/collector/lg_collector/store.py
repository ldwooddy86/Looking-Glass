"""SQLite store: sources, items, media, runs, digests. One connection per thread; WAL mode."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional

from .util import now

SCHEMA = """
CREATE TABLE IF NOT EXISTS sources (
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, label TEXT, lane TEXT, enabled INTEGER DEFAULT 1,
  cursor TEXT, last_ok INTEGER, last_error TEXT, last_run INTEGER, items INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS items (
  id TEXT PRIMARY KEY, source_id TEXT NOT NULL, ts INTEGER NOT NULL, author TEXT, text TEXT, url TEXT, lang TEXT,
  raw TEXT, leg TEXT, kind TEXT, entities TEXT, triage TEXT, dup_of TEXT, created INTEGER NOT NULL, triaged INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS items_ts ON items(ts DESC);
CREATE INDEX IF NOT EXISTS items_src ON items(source_id);
CREATE TABLE IF NOT EXISTS media (
  id TEXT PRIMARY KEY, item_id TEXT NOT NULL, kind TEXT NOT NULL, url TEXT, path TEXT, thumb TEXT, sha256 TEXT, phash TEXT,
  w INTEGER, h INTEGER, duration REAL, bytes INTEGER, source_id TEXT, ts INTEGER, triage TEXT, dups INTEGER DEFAULT 0, created INTEGER NOT NULL, triaged INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS media_ts ON media(ts DESC);
CREATE INDEX IF NOT EXISTS media_phash ON media(phash);
CREATE TABLE IF NOT EXISTS runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, started INTEGER, finished INTEGER, connector TEXT, items INTEGER, media INTEGER, error TEXT
);
CREATE TABLE IF NOT EXISTS digests (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, window_hours INTEGER, text TEXT, model TEXT
);
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT);
"""


@dataclass
class Item:
    id: str
    source_id: str
    ts: int
    text: str = ""
    author: str = ""
    url: str = ""
    lang: str = ""
    raw: dict = field(default_factory=dict)
    media: list = field(default_factory=list)      # list of MediaRef
    kind_hint: str = ""                            # connector's own guess (adsb, notam, navwarn, …)


@dataclass
class MediaRef:
    url: str
    kind: str = "photo"                            # photo | video
    filename: str = ""
    bytes: int = 0
    local_path: str = ""                           # already downloaded by the connector (Telethon does this)
    duration: float = 0.0


class Store:
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        self.path = os.path.join(data_dir, "lookingglass.sqlite")
        self._local = threading.local()
        with self.conn() as c:
            c.executescript(SCHEMA)

    def conn(self) -> sqlite3.Connection:
        c = getattr(self._local, "conn", None)
        if c is None:
            c = sqlite3.connect(self.path, timeout=30, check_same_thread=False)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            self._local.conn = c
        return c

    # ---- sources ------------------------------------------------------------------
    def upsert_source(self, sid: str, kind: str, label: str = "", lane: str = "", enabled: bool = True) -> None:
        with self.conn() as c:
            c.execute("INSERT INTO sources(id,kind,label,lane,enabled) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET kind=excluded.kind, label=excluded.label, lane=excluded.lane, enabled=excluded.enabled", (sid, kind, label, lane, 1 if enabled else 0))

    def source_ok(self, sid: str, cursor: Optional[str] = None, n_items: int = 0) -> None:
        with self.conn() as c:
            c.execute("UPDATE sources SET last_ok=?, last_run=?, last_error=NULL, cursor=COALESCE(?, cursor), items=items+? WHERE id=?", (now(), now(), cursor, n_items, sid))

    def source_error(self, sid: str, err: str) -> None:
        with self.conn() as c:
            c.execute("UPDATE sources SET last_run=?, last_error=? WHERE id=?", (now(), str(err)[:400], sid))

    def cursor(self, sid: str) -> Optional[str]:
        r = self.conn().execute("SELECT cursor FROM sources WHERE id=?", (sid,)).fetchone()
        return r["cursor"] if r else None

    def sources(self) -> list[dict]:
        return [dict(r) for r in self.conn().execute("SELECT * FROM sources ORDER BY kind, id").fetchall()]

    # ---- items ---------------------------------------------------------------------
    def has_item(self, iid: str) -> bool:
        return self.conn().execute("SELECT 1 FROM items WHERE id=?", (iid,)).fetchone() is not None

    def add_item(self, it: Item, leg: str = "", kind: str = "", entities: Optional[dict] = None, dup_of: str = "") -> bool:
        if self.has_item(it.id):
            return False
        with self.conn() as c:
            c.execute("INSERT INTO items(id,source_id,ts,author,text,url,lang,raw,leg,kind,entities,triage,dup_of,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (it.id, it.source_id, int(it.ts or now()), it.author[:200], it.text, it.url[:800], it.lang[:8], json.dumps(it.raw, ensure_ascii=False)[:20000], leg, kind or it.kind_hint, json.dumps(entities or {}, ensure_ascii=False), None, dup_of, now()))
        return True

    def set_triage(self, iid: str, triage: dict, leg: str = "", kind: str = "", entities: Optional[dict] = None) -> None:
        with self.conn() as c:
            c.execute("UPDATE items SET triage=?, leg=COALESCE(NULLIF(?,''), leg), kind=COALESCE(NULLIF(?,''), kind), entities=COALESCE(?, entities), triaged=1 WHERE id=?",
                      (json.dumps(triage, ensure_ascii=False), leg, kind, json.dumps(entities, ensure_ascii=False) if entities is not None else None, iid))

    def untriaged_items(self, limit: int) -> list[dict]:
        return [self._row_item(r) for r in self.conn().execute("SELECT * FROM items WHERE triaged=0 ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()]

    def items(self, limit: int = 200, since: Optional[int] = None, leg: str = "", kind: str = "", source_kind: str = "", min_relevance: float = 0.0) -> list[dict]:
        q = "SELECT items.*, sources.kind AS skind, sources.label AS slabel, sources.lane AS slane FROM items JOIN sources ON sources.id=items.source_id WHERE 1=1"
        args: list[Any] = []
        if since:
            q += " AND items.ts>=?"; args.append(int(since))
        if leg:
            q += " AND items.leg=?"; args.append(leg)
        if kind:
            q += " AND items.kind=?"; args.append(kind)
        if source_kind:
            q += " AND sources.kind=?"; args.append(source_kind)
        q += " ORDER BY items.ts DESC LIMIT ?"; args.append(int(limit))
        out = []
        for r in self.conn().execute(q, args).fetchall():
            d = self._row_item(r)
            if min_relevance and float((d.get("triage") or {}).get("relevance") or 0) < min_relevance:
                continue
            out.append(d)
        return out

    def _row_item(self, r: sqlite3.Row) -> dict:
        d = dict(r)
        for k in ("raw", "entities", "triage"):
            try:
                d[k] = json.loads(d[k]) if d.get(k) else ({} if k != "triage" else None)
            except Exception:
                d[k] = {} if k != "triage" else None
        d["media"] = [m["id"] for m in self.conn().execute("SELECT id FROM media WHERE item_id=?", (d["id"],)).fetchall()]
        if "skind" in d:
            d["source"] = {"kind": d.pop("skind"), "id": d["source_id"], "label": d.pop("slabel", "") or d["source_id"], "lane": d.pop("slane", "") or ""}
        return d

    # ---- media ---------------------------------------------------------------------
    def has_media(self, mid: str) -> bool:
        return self.conn().execute("SELECT 1 FROM media WHERE id=?", (mid,)).fetchone() is not None

    def add_media(self, mid: str, item_id: str, kind: str, url: str, path: str, thumb: str, sha: str, phash: str, w: int, h: int, duration: float, nbytes: int, source_id: str, ts: int, dups: int = 0) -> None:
        with self.conn() as c:
            c.execute("INSERT OR REPLACE INTO media(id,item_id,kind,url,path,thumb,sha256,phash,w,h,duration,bytes,source_id,ts,triage,dups,created,triaged) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL,?,?,0)",
                      (mid, item_id, kind, url[:800], path, thumb, sha, phash, w, h, duration, nbytes, source_id, int(ts or now()), dups, now()))

    def set_media_triage(self, mid: str, triage: dict) -> None:
        with self.conn() as c:
            c.execute("UPDATE media SET triage=?, triaged=1 WHERE id=?", (json.dumps(triage, ensure_ascii=False), mid))

    def untriaged_media(self, limit: int) -> list[dict]:
        return [self._row_media(r) for r in self.conn().execute("SELECT * FROM media WHERE triaged=0 AND thumb<>'' ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()]

    def media(self, limit: int = 120, since: Optional[int] = None) -> list[dict]:
        q = "SELECT media.*, sources.kind AS skind, sources.label AS slabel FROM media JOIN sources ON sources.id=media.source_id WHERE 1=1"
        args: list[Any] = []
        if since:
            q += " AND media.ts>=?"; args.append(int(since))
        q += " ORDER BY media.ts DESC LIMIT ?"; args.append(int(limit))
        return [self._row_media(r) for r in self.conn().execute(q, args).fetchall()]

    def media_by_id(self, mid: str) -> Optional[dict]:
        r = self.conn().execute("SELECT media.*, sources.kind AS skind, sources.label AS slabel FROM media JOIN sources ON sources.id=media.source_id WHERE media.id=?", (mid,)).fetchone()
        return self._row_media(r) if r else None

    def _row_media(self, r: sqlite3.Row) -> dict:
        d = dict(r)
        try:
            d["triage"] = json.loads(d["triage"]) if d.get("triage") else None
        except Exception:
            d["triage"] = None
        if "skind" in d:
            d["source"] = {"kind": d.pop("skind"), "id": d["source_id"], "label": d.pop("slabel", "") or d["source_id"]}
        it = self.conn().execute("SELECT url, text FROM items WHERE id=?", (d["item_id"],)).fetchone()
        d["item_url"] = it["url"] if it else ""
        d["item_text"] = (it["text"] or "")[:600] if it else ""
        return d

    def phash_neighbours(self, phash: str, max_dist: int = 6) -> list[str]:
        """ids of media whose perceptual hash is within Hamming distance max_dist (64-bit hex)."""
        if not phash:
            return []
        try:
            target = int(phash, 16)
        except ValueError:
            return []
        out = []
        for r in self.conn().execute("SELECT id, phash FROM media WHERE phash<>'' AND phash IS NOT NULL").fetchall():
            try:
                d = bin(int(r["phash"], 16) ^ target).count("1")
            except ValueError:
                continue
            if d <= max_dist:
                out.append(r["id"])
        return out

    # ---- runs / digests / kv ---------------------------------------------------------
    def run_start(self, connector: str) -> int:
        with self.conn() as c:
            cur = c.execute("INSERT INTO runs(started, connector) VALUES(?,?)", (now(), connector))
            return int(cur.lastrowid)

    def run_end(self, rid: int, items: int, media: int, error: str = "") -> None:
        with self.conn() as c:
            c.execute("UPDATE runs SET finished=?, items=?, media=?, error=? WHERE id=?", (now(), items, media, error[:400] if error else None, rid))

    def recent_runs(self, limit: int = 30) -> list[dict]:
        return [dict(r) for r in self.conn().execute("SELECT * FROM runs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]

    def add_digest(self, text: str, window_hours: int, model: str) -> None:
        with self.conn() as c:
            c.execute("INSERT INTO digests(ts, window_hours, text, model) VALUES(?,?,?,?)", (now(), window_hours, text, model))

    def latest_digest(self) -> Optional[dict]:
        r = self.conn().execute("SELECT * FROM digests ORDER BY id DESC LIMIT 1").fetchone()
        return dict(r) if r else None

    def kv_get(self, k: str, default: str = "") -> str:
        r = self.conn().execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
        return r["v"] if r else default

    def kv_set(self, k: str, v: str) -> None:
        with self.conn() as c:
            c.execute("INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, v))

    def counts(self) -> dict:
        c = self.conn()
        return {"items": c.execute("SELECT COUNT(*) FROM items").fetchone()[0], "media": c.execute("SELECT COUNT(*) FROM media").fetchone()[0], "sources": c.execute("SELECT COUNT(*) FROM sources").fetchone()[0], "untriaged": c.execute("SELECT COUNT(*) FROM items WHERE triaged=0").fetchone()[0]}

    def prune(self, keep_days: int) -> int:
        cutoff = now() - keep_days * 86400
        c = self.conn()
        rows = c.execute("SELECT path, thumb FROM media WHERE ts<?", (cutoff,)).fetchall()
        for r in rows:
            for p in (r["path"], r["thumb"]):
                if p and os.path.exists(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
        with c:
            c.execute("DELETE FROM media WHERE ts<?", (cutoff,))
            n = c.execute("DELETE FROM items WHERE ts<?", (cutoff,)).rowcount
        return int(n)
