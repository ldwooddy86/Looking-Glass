"""Static exports: feed.json, media.json (+ copied thumbnails), digest.md and a standalone digest.html —
for attaching to a Cowork session, for the preview build, or for reading offline."""
from __future__ import annotations

import html
import json
import os
import shutil

from .server import _public_item, _public_media
from .store import Store
from .util import ensure_dir, iso, now


def export(store: Store, out_dir: str, limit_items: int = 400, limit_media: int = 200, copy_thumbs: bool = True) -> dict:
    ensure_dir(out_dir)
    items = [_public_item(i) for i in store.items(limit=limit_items)]
    media = [_public_media(m) for m in store.media(limit=limit_media)]
    if copy_thumbs:
        td = ensure_dir(os.path.join(out_dir, "thumbs"))
        for m in media:
            src = (store.media_by_id(m["id"]) or {}).get("thumb")
            if src and os.path.exists(src):
                shutil.copy2(src, os.path.join(td, f"{m['id']}.jpg")); m["thumb"] = f"thumbs/{m['id']}.jpg"
    d = store.latest_digest()
    summary = {"exported": iso(now()), "items": len(items), "media": len(media), "sources": [{"id": s["id"], "kind": s["kind"], "label": s["label"], "ok": bool(s["last_ok"]) and not s["last_error"]} for s in store.sources()]}
    with open(os.path.join(out_dir, "feed.json"), "w", encoding="utf-8") as f:
        json.dump({"summary": summary, "items": items}, f, ensure_ascii=False, indent=1)
    with open(os.path.join(out_dir, "media.json"), "w", encoding="utf-8") as f:
        json.dump({"summary": summary, "media": media}, f, ensure_ascii=False, indent=1)
    with open(os.path.join(out_dir, "digest.md"), "w", encoding="utf-8") as f:
        f.write(f"# LOOKING GLASS collector digest — exported {summary['exported']}\n\n")
        if d:
            f.write(f"_Unverified machine digest · {iso(d['ts'])} · last {d['window_hours']} h · {d['model']}_\n\n{d['text']}\n\n")
        f.write("## Highest-relevance items\n\n")
        for it in sorted(items, key=lambda x: -float((x.get('triage') or {}).get('relevance') or 0))[:40]:
            tr = it.get("triage") or {}
            f.write(f"- **{iso(it['ts'])}** [{it['source']['kind']} · {it['source']['label']}] {it['leg']}/{it['kind']} rel {tr.get('relevance')} {tr.get('grade', '')} — {tr.get('summary_en') or it['text'][:200]}" + (f" ([source]({it['url']}))" if it.get("url") else "") + "\n")
    # standalone HTML digest (text-only rendering of untrusted strings)
    rows = "".join(f"<li><b>{html.escape(iso(it['ts']))}</b> <span class='k'>{html.escape(it['source']['kind'])} · {html.escape(it['source']['label'])} · {html.escape(it['leg'])}/{html.escape(it['kind'])}</span><br>{html.escape((it.get('triage') or {}).get('summary_en') or '')}{(' <i>' + html.escape(it['text'][:240]) + '</i>') if it.get('text') else ''}" + (f" <a href='{html.escape(it['url'])}' rel='noopener noreferrer'>source</a>" if it.get("url", "").startswith("https://") else "") + "</li>" for it in items[:120])
    gal = "".join(f"<figure><img src='{html.escape(m['thumb'])}' alt=''><figcaption>{html.escape(m['source']['kind'])} · {html.escape(iso(m['ts']))}<br>{html.escape(((m.get('triage') or {}).get('what') or '')[:160])}</figcaption></figure>" for m in media[:60] if m.get("thumb"))
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LOOKING GLASS digest — {html.escape(summary['exported'])}</title>
<style>body{{font-family:system-ui,sans-serif;background:#0A111E;color:#E9EEF6;margin:0;padding:24px;max-width:1100px}} h1{{font-size:20px}} .k{{color:#8DA0BC;font-size:12px}} li{{margin:8px 0}} pre{{white-space:pre-wrap;background:#101A2C;border:1px solid #223350;padding:12px;border-radius:3px}} .gal{{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px}} figure{{margin:0;background:#101A2C;border:1px solid #223350;border-radius:3px;overflow:hidden}} img{{width:100%;display:block}} figcaption{{font-size:11px;color:#8DA0BC;padding:6px 8px}} .warn{{border-left:3px solid #FF5B47;padding:8px 12px;background:#1a1420;color:#E9EEF6}} a{{color:#FFB454}}</style></head><body>
<h1>LOOKING GLASS · collector digest · {html.escape(summary['exported'])}</h1>
<div class="warn"><b>Unverified.</b> Everything below is open-source chatter and imagery pulled by your own read-only collector. Triage text is a machine suggestion. Nothing here is a position, a track or a target.</div>
<h2>Digest</h2><pre>{html.escape(d['text']) if d else 'No digest yet (needs an API key and one cycle).'}</pre>
<h2>Items ({len(items)})</h2><ol>{rows}</ol>
<h2>Media ({len(media)})</h2><div class="gal">{gal}</div>
</body></html>"""
    with open(os.path.join(out_dir, "digest.html"), "w", encoding="utf-8") as f:
        f.write(page)
    return summary
