"""Technical public feeds: ADS-B (adsb.fi open data — personal, non-commercial), navigational warnings
(NGA Maritime Safety Information — NAVAREA / HYDROPAC broadcast warnings), NOTAMs (FAA NOTAM API,
keyed). These emit structured items (kind adsb / navwarn / notam) that the triage treats as technical
collection: a closure box or a tanker orbit is an observable, never a position of the subject's forces."""
from __future__ import annotations

import logging
import math
import time

from ..store import Item
from ..util import http_get_json, sha1, now
from .base import Connector, Stats, register_connector

log = logging.getLogger("lg.technical")


def _norm_type(t) -> str:
    return "".join(ch for ch in str(t or "").upper() if ch.isalnum())


@register_connector
class Adsb(Connector):
    kind = "adsb"
    lane = "official"
    MIL = "https://opendata.adsb.fi/api/v2/mil"

    def _coarse(self, ac: dict) -> dict:
        lat, lon = ac.get("lat"), ac.get("lon")
        return {"hex": str(ac.get("hex", ""))[:7], "t": str(ac.get("t", ""))[:8], "r": str(ac.get("r", ""))[:12], "flight": str(ac.get("flight", "")).strip()[:12],
                "lat": round(float(lat), 1) if isinstance(lat, (int, float)) else None, "lon": round(float(lon), 1) if isinstance(lon, (int, float)) else None,
                "alt": ac.get("alt_baro") if ac.get("alt_baro") == "ground" or isinstance(ac.get("alt_baro"), (int, float)) else None, "gs": ac.get("gs") if isinstance(ac.get("gs"), (int, float)) else None}

    async def collect(self) -> Stats:
        st = Stats()
        match = {_norm_type(t) for t in self.cfg.get("match", [])}
        hour = int(now() // 3600)
        sid = self.register("mil", "adsb.fi military feed")
        try:
            r = http_get_json(self.MIL)
            hits = [self._coarse(a) for a in (r.get("ac") or []) if _norm_type(a.get("t")) in match]
            if hits:
                hits.sort(key=lambda a: (a["t"], a["hex"]))
                text = "Public ADS-B (adsb.fi military feed) — watched types transponding this hour: " + "; ".join(f"{a['t']} {a['r'] or a['hex']} {'GROUND' if a['alt'] == 'ground' else (str(a['alt']) + ' ft' if a['alt'] is not None else 'no alt')}{(' near ' + str(a['lat']) + ',' + str(a['lon'])) if a['lat'] is not None else ''}" for a in hits[:40])
                it = Item(id=sha1("adsb", "mil", hour), source_id=sid, ts=now(), text=text, author="adsb.fi", url="https://globe.adsb.fi/?largeMode=2&filterMilitary", raw={"aircraft": hits[:60], "total_mil": len(r.get("ac") or [])}, kind_hint="adsb")
                a, _ = self.emit(it); st.items += a
            self.store.source_ok(sid, None, 0)
        except Exception as e:
            self.store.source_error(sid, str(e)); st.errors.append(f"mil: {e}")
        for sec in self.cfg.get("sectors", []):
            try:
                lat = float(sec["lat"]); lon = float(sec["lon"]); dist = int(min(250, max(1, sec.get("dist", 150)))); label = str(sec.get("label", f"{lat},{lon}"))
            except (KeyError, TypeError, ValueError):
                st.errors.append(f"bad sector {sec}"); continue
            ssid = self.register(f"sector:{label}", f"sector {label}")
            try:
                r = http_get_json(f"https://opendata.adsb.fi/api/v3/lat/{lat}/lon/{lon}/dist/{dist}")
                acs = r.get("ac") or []
                mil = [a for a in acs if isinstance(a.get("dbFlags"), int) and (a["dbFlags"] & 1)]
                hits = [self._coarse(a) for a in mil if _norm_type(a.get("t")) in match]
                if hits:
                    text = f"Public ADS-B sector {label} ({dist} nm): {len(acs)} aircraft in view, {len(mil)} military-flagged, watched types: " + "; ".join(f"{a['t']} {a['r'] or a['hex']} {'GROUND' if a['alt'] == 'ground' else (str(a['alt']) + ' ft' if a['alt'] is not None else '')}" for a in hits[:20])
                    it = Item(id=sha1("adsb", label, hour), source_id=ssid, ts=now(), text=text, author="adsb.fi", url="https://globe.adsb.fi/", raw={"aircraft": hits[:30], "in_view": len(acs), "mil": len(mil), "sector": {"lat": lat, "lon": lon, "dist": dist}}, kind_hint="adsb")
                    a, _ = self.emit(it); st.items += a
                self.store.source_ok(ssid, None, 0)
                time.sleep(1.1)   # adsb.fi public endpoints: 1 request / second
            except Exception as e:
                self.store.source_error(ssid, str(e)); st.errors.append(f"sector {label}: {e}")
        return st


@register_connector
class NavWarn(Connector):
    """NGA MSI broadcast warnings — the US-coordinated areas NAVAREA IV ('4') and XII ('12') plus HYDROPAC ('P'),
    HYDROLANT ('A') and HYDROARC ('C'). Public, no key. Russian- and Chinese-coordinated areas (NAVAREA XIII, XI, XX/XXI)
    are not served here; NGA repeats the ones that matter to US shipping as HYDROPAC/HYDROLANT, and missile-test closure
    boxes near Kamchatka, the Pacific ranges or the Arctic usually surface that way. One call per cycle, filtered locally."""
    kind = "navwarn"
    lane = "official"
    API = "https://msi.nga.mil/api/publications/broadcast-warn"
    AREA_CODES = {"IV": "4", "4": "4", "XII": "12", "12": "12", "HYDROPAC": "P", "P": "P", "HYDROLANT": "A", "A": "A", "HYDROARC": "C", "C": "C", "XIII": "P", "XX": "P", "XXI": "P", "XI": "P"}
    AREA_NAMES = {"4": "NAVAREA IV", "12": "NAVAREA XII", "P": "HYDROPAC", "A": "HYDROLANT", "C": "HYDROARC"}

    async def collect(self) -> Stats:
        st = Stats()
        kws = [str(k).upper() for k in self.cfg.get("keywords", [])]
        want = {self.AREA_CODES.get(str(a).strip().upper(), str(a).strip().upper()) for a in (self.cfg.get("areas") or ["P", "12", "4"])}
        sid = self.register("active", "NGA broadcast warnings (" + ", ".join(sorted(self.AREA_NAMES.get(w, w) for w in want)) + ")")
        try:
            r = http_get_json(self.API, params={"status": "active", "output": "json"})
            warns = r.get("broadcast-warn") or r.get("broadcastWarn") or (r if isinstance(r, list) else [])
            n = 0
            for w in warns:
                area = str(w.get("navArea", "")).upper()
                if area not in want:
                    continue
                text = str(w.get("text") or "")
                up = text.upper()
                if kws and not any(k in up for k in kws):
                    continue
                num = f"{w.get('msgYear', '')}/{w.get('msgNumber', '')}"
                name = self.AREA_NAMES.get(area, area)
                it = Item(id=sha1("navwarn", area, num), source_id=sid, ts=now(), text=f"{name} {num} (subregion {w.get('subregion', '')}): " + " ".join(text.split())[:3000], author="NGA MSI", url="https://msi.nga.mil/NavWarnings", raw={"issued": w.get("issueDate"), "cancel": w.get("cancelDate"), "status": w.get("status"), "navArea": area}, kind_hint="navwarn")
                a, _ = self.emit(it); n += a
            self.store.source_ok(sid, None, n); st.items += n
        except Exception as e:
            self.store.source_error(sid, str(e)); st.errors.append(f"navwarn: {e}")
        return st


@register_connector
class Notam(Connector):
    """FAA NOTAM API (api.faa.gov; free registration). International coverage is what the FAA receives —
    treat absence as uninformative. Emits one item per new NOTAM at the configured ICAO locations."""
    kind = "notam"
    lane = "official"
    API = "https://external-api.faa.gov/notamapi/v1/notams"

    async def collect(self) -> Stats:
        st = Stats()
        cid, sec = str(self.cfg.get("client_id", "")).strip(), str(self.cfg.get("client_secret", "")).strip()
        if not (cid and sec):
            st.errors.append("notam.client_id / client_secret missing"); return st
        h = {"client_id": cid, "client_secret": sec}
        for loc in self.cfg.get("locations", []):
            loc = str(loc).strip().upper(); sid = self.register(loc, f"NOTAM {loc}")
            try:
                r = http_get_json(self.API, headers=h, params={"icaoLocation": loc, "responseFormat": "geoJson", "pageSize": 50})
                n = 0
                for f in r.get("items", []):
                    core = ((f.get("properties") or {}).get("coreNOTAMData") or {}).get("notam") or {}
                    if not core:
                        continue
                    text = f"NOTAM {core.get('location', loc)} {core.get('number', '')} ({core.get('type', '')}) {core.get('effectiveStart', '')} → {core.get('effectiveEnd', '')}: {core.get('text', '')}"
                    it = Item(id=sha1("notam", core.get("id") or core.get("number"), loc), source_id=sid, ts=now(), text=" ".join(str(text).split())[:3000], author="FAA NOTAM API", url="https://notams.aim.faa.gov/notamSearch/", raw={"issued": core.get("issued"), "start": core.get("effectiveStart"), "end": core.get("effectiveEnd")}, kind_hint="notam")
                    a, _ = self.emit(it); n += a
                self.store.source_ok(sid, None, n); st.items += n
            except Exception as e:
                self.store.source_error(sid, str(e)); st.errors.append(f"{loc}: {e}")
        return st
