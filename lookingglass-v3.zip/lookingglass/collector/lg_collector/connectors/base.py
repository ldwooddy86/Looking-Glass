"""Connector base class and registry. Every connector only READS."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

from ..media import MediaPipeline
from ..store import Item, MediaRef, Store
from ..util import now

log = logging.getLogger("lg.connector")


@dataclass
class Stats:
    items: int = 0
    media: int = 0
    errors: list = field(default_factory=list)


class Connector:
    kind = "base"
    lane = "custom"

    def __init__(self, section: dict, general: dict, store: Store, media: MediaPipeline):
        self.cfg = section or {}
        self.general = general
        self.store = store
        self.media = media
        self.download_media = bool(self.cfg.get("download_media", True))

    # registration --------------------------------------------------------------
    def source_id(self, ident: str) -> str:
        return f"{self.kind}:{ident}"

    def register(self, ident: str, label: str = "", lane: Optional[str] = None) -> str:
        sid = self.source_id(ident)
        self.store.upsert_source(sid, self.kind, label or ident, lane or self.lane, True)
        return sid

    # emission --------------------------------------------------------------------
    def emit(self, it: Item, refs: Optional[list[MediaRef]] = None, headers: Optional[dict] = None) -> tuple[int, int]:
        """Store one item and its media. Returns (new_items, new_media)."""
        if not it.ts:
            it.ts = now()
        new = self.store.add_item(it, kind=it.kind_hint)
        n_media = 0
        if new and self.download_media:
            for ref in (refs or [])[:6]:
                if self.media.ingest(it.id, it.source_id, it.ts, ref, headers=headers):
                    n_media += 1
        elif new and refs:
            for ref in refs[:6]:   # keep the URL even when downloads are off
                self.media.ingest(it.id, it.source_id, it.ts, MediaRef(url=ref.url, kind=ref.kind, bytes=10 ** 12))
        return (1 if new else 0), n_media

    async def collect(self) -> Stats:  # pragma: no cover - abstract
        raise NotImplementedError

    def enabled(self) -> bool:
        return bool(self.cfg.get("enabled"))


REGISTRY: dict[str, type] = {}


def register_connector(cls):
    REGISTRY[cls.kind] = cls
    return cls
