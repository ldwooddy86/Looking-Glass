"""Telegram — user session via Telethon (the official MTProto API). Reads any public channel and any
group/channel the account has joined; downloads photos and videos under the size cap. Never sends,
never joins, never reacts. The session file lives in data_dir; log in once with
`python -m lg_collector login telegram`."""
from __future__ import annotations

import logging
import os

from ..store import Item, MediaRef
from ..util import clean_text, safe_name, sha1
from .base import Connector, Stats, register_connector

log = logging.getLogger("lg.telegram")


@register_connector
class TelegramUser(Connector):
    kind = "telegram"
    lane = "milblogger"

    def session_path(self) -> str:
        return os.path.join(self.general["data_dir"], self.cfg.get("session", "lg_user"))

    def client(self):
        try:
            from telethon import TelegramClient
        except ImportError as e:
            raise RuntimeError("telethon is not installed: pip install telethon") from e
        if not self.cfg.get("api_id") or not self.cfg.get("api_hash"):
            raise RuntimeError("telegram.api_id / api_hash missing (https://my.telegram.org)")
        return TelegramClient(self.session_path(), int(self.cfg["api_id"]), str(self.cfg["api_hash"]))

    async def login(self) -> None:
        client = self.client()
        await client.start()   # interactive: phone, code, 2FA password
        me = await client.get_me()
        log.info("Telegram session ready for %s", getattr(me, "username", None) or getattr(me, "first_name", "user"))
        await client.disconnect()

    async def collect(self) -> Stats:
        st = Stats()
        client = self.client()
        await client.connect()
        try:
            if not await client.is_user_authorized():
                raise RuntimeError("Telegram session not authorised — run: python -m lg_collector login telegram")
            limit = int(self.cfg.get("max_messages_per_channel", 120))
            tmp = os.path.join(self.general["data_dir"], "tmp"); os.makedirs(tmp, exist_ok=True)
            for ch in self.cfg.get("channels", []):
                ident = str(ch).strip().lstrip("@")
                sid = self.register(ident)
                try:
                    ent = await client.get_entity(int(ident) if ident.lstrip("-").isdigit() else ident)
                    title = getattr(ent, "title", None) or getattr(ent, "username", None) or ident
                    uname = getattr(ent, "username", None)
                    self.store.upsert_source(sid, self.kind, title, self.lane, True)
                    min_id = int(self.store.cursor(sid) or 0)
                    msgs = await client.get_messages(ent, limit=limit, min_id=min_id)
                    newest = min_id; n_i = n_m = 0
                    for m in msgs:
                        newest = max(newest, int(m.id))
                        text = clean_text(m.message or "")
                        refs = []
                        if self.download_media and (m.photo or (m.video and getattr(m.file, "size", 0) <= self.media.max_bytes) or (m.document and str(getattr(m.file, "mime_type", "")).startswith(("image/", "video/")) and getattr(m.file, "size", 0) <= self.media.max_bytes)):
                            try:
                                path = await m.download_media(file=os.path.join(tmp, f"tg_{safe_name(ident)}_{m.id}"))
                                if path:
                                    refs.append(MediaRef(url=(f"https://t.me/{uname}/{m.id}" if uname else ""), kind="video" if (m.video or str(getattr(m.file, 'mime_type', '')).startswith('video/')) else "photo", local_path=path, filename=os.path.basename(path)))
                            except Exception as e:
                                log.warning("download failed @%s/%s: %s", ident, m.id, e)
                        if not text and not refs:
                            continue
                        author = title
                        if self.general.get("store_authors", True) and getattr(m, "sender", None) is not None and not getattr(ent, "broadcast", False):
                            s = m.sender; author = (getattr(s, "title", None) or " ".join(x for x in [getattr(s, "first_name", ""), getattr(s, "last_name", "")] if x) or title)
                        elif not getattr(ent, "broadcast", False):
                            author = "member"
                        it = Item(id=sha1("telegram", ident, m.id), source_id=sid, ts=int(m.date.timestamp()), text=text, author=author, url=(f"https://t.me/{uname}/{m.id}" if uname else ""), raw={"id": m.id, "views": getattr(m, "views", None), "fwd": bool(m.fwd_from)})
                        a, b = self.emit(it, refs); n_i += a; n_m += b
                    self.store.source_ok(sid, str(newest), n_i); st.items += n_i; st.media += n_m
                except Exception as e:
                    self.store.source_error(sid, str(e)); st.errors.append(f"@{ident}: {e}")
        finally:
            await client.disconnect()
        return st
