"""Telegram — Bot API. A bot only sees chats it has been added to (channel posts where it is an admin,
group messages where privacy mode allows), so this lane covers the channels you keep at arm's
length from your own account. Read-only: getUpdates + getFile."""
from __future__ import annotations

import logging

from ..store import Item, MediaRef
from ..util import clean_text, http_get_json, sha1
from .base import Connector, Stats, register_connector

log = logging.getLogger("lg.telegram_bot")


@register_connector
class TelegramBot(Connector):
    kind = "telegram-bot"
    lane = "community"

    def api(self, method: str, **params):
        tok = str(self.cfg.get("token", "")).strip()
        if not tok:
            raise RuntimeError("telegram_bot.token missing (@BotFather)")
        return http_get_json(f"https://api.telegram.org/bot{tok}/{method}", params=params)

    async def collect(self) -> Stats:
        st = Stats()
        sid_all = self.register("updates", "Telegram bot lane")
        try:
            offset = int(self.store.cursor(sid_all) or 0)
            r = self.api("getUpdates", offset=offset, timeout=0, limit=100, allowed_updates='["message","channel_post"]')
            if not r.get("ok"):
                raise RuntimeError(r.get("description", "getUpdates failed"))
            last = offset; n_i = n_m = 0
            tok = str(self.cfg.get("token", "")).strip()
            for u in r.get("result", []):
                last = max(last, int(u["update_id"]) + 1)
                m = u.get("channel_post") or u.get("message")
                if not m:
                    continue
                chat = m.get("chat", {})
                cid = str(chat.get("id"))
                title = chat.get("title") or chat.get("username") or cid
                sid = self.register(cid, title, "community")
                text = clean_text(m.get("text") or m.get("caption") or "")
                refs = []
                fid = None; kind = "photo"; fname = ""
                if m.get("photo"):
                    fid = m["photo"][-1]["file_id"]
                elif m.get("video") and int(m["video"].get("file_size", 0)) <= self.media.max_bytes:
                    fid = m["video"]["file_id"]; kind = "video"; fname = m["video"].get("file_name", "video.mp4")
                elif m.get("document") and str(m["document"].get("mime_type", "")).startswith(("image/", "video/")) and int(m["document"].get("file_size", 0)) <= self.media.max_bytes:
                    fid = m["document"]["file_id"]; kind = "video" if str(m["document"]["mime_type"]).startswith("video/") else "photo"; fname = m["document"].get("file_name", "")
                if fid and self.download_media:
                    try:
                        f = self.api("getFile", file_id=fid)
                        if f.get("ok"):
                            refs.append(MediaRef(url=f"https://api.telegram.org/file/bot{tok}/{f['result']['file_path']}", kind=kind, filename=fname or f["result"]["file_path"]))
                    except Exception as e:
                        log.warning("getFile failed: %s", e)
                if not text and not refs:
                    continue
                uname = chat.get("username")
                url = f"https://t.me/{uname}/{m.get('message_id')}" if uname else ""
                author = title if chat.get("type") == "channel" else ((m.get("from") or {}).get("first_name", "member") if self.general.get("store_authors", True) else "member")
                it = Item(id=sha1("telegram-bot", cid, m.get("message_id")), source_id=sid, ts=int(m.get("date", 0)), text=text, author=author, url=url, raw={"message_id": m.get("message_id"), "chat_type": chat.get("type")})
                a, b = self.emit(it, refs); n_i += a; n_m += b
                self.store.source_ok(sid, None, a)
            self.store.source_ok(sid_all, str(last), n_i); st.items += n_i; st.media += n_m
        except Exception as e:
            self.store.source_error(sid_all, str(e)); st.errors.append(f"bot: {e}")
        return st
