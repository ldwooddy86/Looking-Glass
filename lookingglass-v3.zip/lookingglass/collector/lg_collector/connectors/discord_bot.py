"""Discord — a bot token, REST-only (login + fetch_channel + history; no gateway). The bot must be a
member of the server with View Channel + Read Message History on each configured channel.
User-account automation ("self-bots") violates Discord's terms and is deliberately not supported."""
from __future__ import annotations

import datetime as dt
import logging

from ..store import Item, MediaRef
from ..util import clean_text, sha1
from .base import Connector, Stats, register_connector

log = logging.getLogger("lg.discord")


@register_connector
class DiscordBot(Connector):
    kind = "discord"
    lane = "community"

    async def collect(self) -> Stats:
        st = Stats()
        try:
            import discord
        except ImportError:
            st.errors.append("discord.py is not installed: pip install discord.py"); return st
        tok = str(self.cfg.get("token", "")).strip()
        if not tok:
            st.errors.append("discord.token missing"); return st
        intents = discord.Intents.none()
        client = discord.Client(intents=intents)
        try:
            await client.login(tok)
            limit = int(self.cfg.get("max_messages_per_channel", 100))
            for cid in self.cfg.get("channels", []):
                cid = str(cid).strip()
                if not cid.isdigit():
                    st.errors.append(f"discord channel id must be numeric: {cid}"); continue
                sid = self.register(cid)
                try:
                    ch = await client.fetch_channel(int(cid))
                    guild = getattr(ch, "guild", None)
                    label = f"{getattr(guild, 'name', '') or 'DM'} #{getattr(ch, 'name', cid)}"
                    self.store.upsert_source(sid, self.kind, label, self.lane, True)
                    cur = self.store.cursor(sid)
                    after = dt.datetime.fromtimestamp(int(cur), tz=dt.timezone.utc) if cur else None
                    newest = int(cur or 0); n_i = n_m = 0
                    async for m in ch.history(limit=limit, after=after, oldest_first=False):
                        ts = int(m.created_at.timestamp()); newest = max(newest, ts)
                        text = clean_text(m.content or "")
                        for e in (m.embeds or []):
                            text = (text + "\n" + clean_text(" ".join(x for x in [getattr(e, "title", ""), getattr(e, "description", "")] if x))).strip()
                        refs = []
                        for a in (m.attachments or []):
                            ct = str(getattr(a, "content_type", "") or "")
                            if ct.startswith(("image/", "video/")) or str(a.filename).lower().endswith((".jpg", ".jpeg", ".png", ".webp", ".gif", ".mp4", ".mov", ".webm")):
                                refs.append(MediaRef(url=a.url, kind="video" if (ct.startswith("video/") or str(a.filename).lower().endswith((".mp4", ".mov", ".webm"))) else "photo", filename=a.filename, bytes=int(getattr(a, "size", 0) or 0)))
                        if not text and not refs:
                            continue
                        author = (m.author.display_name if self.general.get("store_authors", True) else "member")
                        url = f"https://discord.com/channels/{guild.id if guild else '@me'}/{cid}/{m.id}"
                        it = Item(id=sha1("discord", cid, m.id), source_id=sid, ts=ts, text=text, author=author, url=url, raw={"id": str(m.id), "attachments": len(m.attachments or [])})
                        a_, b_ = self.emit(it, refs); n_i += a_; n_m += b_
                    self.store.source_ok(sid, str(newest), n_i); st.items += n_i; st.media += n_m
                except Exception as e:
                    self.store.source_error(sid, str(e)); st.errors.append(f"#{cid}: {e}")
        except Exception as e:
            st.errors.append(f"discord login: {e}")
        finally:
            try:
                await client.close()
            except Exception:
                pass
        return st
