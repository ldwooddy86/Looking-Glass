"""Connector registry — importing the modules registers them."""
from .base import REGISTRY, Connector, Stats  # noqa: F401
from . import telegram_user, telegram_bot, discord_bot, social, technical  # noqa: F401,E402

# config section → connector kind
SECTIONS = {
    "telegram": "telegram", "telegram_bot": "telegram-bot", "discord": "discord", "bluesky": "bluesky", "mastodon": "mastodon",
    "reddit": "reddit", "youtube": "youtube", "rss": "rss", "x": "x", "adsb": "adsb", "navwarn": "navwarn", "notam": "notam",
}


def build(cfg: dict, store, media) -> list[Connector]:
    out = []
    for section, kind in SECTIONS.items():
        sec = cfg.get(section) or {}
        if not sec.get("enabled"):
            continue
        cls = REGISTRY.get(kind)
        if cls:
            out.append(cls(sec, cfg["general"], store, media))
    return out
