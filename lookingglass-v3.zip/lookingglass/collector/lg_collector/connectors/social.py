"""Bluesky (AT Protocol public API), Mastodon (public API), Reddit (public JSON / optional OAuth),
YouTube (Data API v3), RSS/Atom (stdlib), X (v2 API, disabled by default). All read-only."""
from __future__ import annotations

import base64
import logging
import re
import xml.etree.ElementTree as ET

from ..store import Item, MediaRef
from ..util import clean_text, http_get, http_get_json, http_post_form, parse_iso, sha1
from .base import Connector, Stats, register_connector

log = logging.getLogger("lg.social")


@register_connector
class Bluesky(Connector):
    kind = "bluesky"
    lane = "analyst"
    BASE = "https://public.api.bsky.app/xrpc/"

    def _post_item(self, sid: str, p: dict) -> tuple[Item, list[MediaRef]]:
        rec = p.get("record") or {}
        author = p.get("author") or {}
        handle = author.get("handle", "")
        rkey = str(p.get("uri", "")).split("/")[-1]
        refs = []
        emb = p.get("embed") or {}
        imgs = emb.get("images") or ((emb.get("media") or {}).get("images") if isinstance(emb.get("media"), dict) else None) or []
        for im in imgs[:4]:
            if im.get("fullsize"):
                refs.append(MediaRef(url=im["fullsize"], kind="photo", filename="bsky.jpg"))
        if emb.get("$type", "").endswith("video#view") and emb.get("thumbnail"):
            refs.append(MediaRef(url=emb["thumbnail"], kind="photo", filename="bsky_video_thumb.jpg"))
        it = Item(id=sha1("bluesky", p.get("uri")), source_id=sid, ts=parse_iso(rec.get("createdAt", "")) or 0, text=clean_text(rec.get("text", "")), author=(author.get("displayName") or handle), url=f"https://bsky.app/profile/{handle}/post/{rkey}", raw={"likes": p.get("likeCount"), "reposts": p.get("repostCount")})
        return it, refs

    def _session(self) -> tuple[str, dict]:
        """Public endpoint by default; an authenticated bsky.social session when app_password = 'handle:app-password'
        (searchPosts is often refused unauthenticated; app passwords are read-scoped and revocable)."""
        ap = str(self.cfg.get("app_password", "")).strip()
        if ":" not in ap:
            return self.BASE, {}
        ident, pw = ap.split(":", 1)
        from ..util import http_post_json
        r = http_post_json("https://bsky.social/xrpc/com.atproto.server.createSession", {"identifier": ident.lstrip("@"), "password": pw})
        return "https://bsky.social/xrpc/", {"Authorization": f"Bearer {r['accessJwt']}"}

    async def collect(self) -> Stats:
        st = Stats()
        base, auth = self.BASE, {}
        if self.cfg.get("searches"):
            try:
                base, auth = self._session()
            except Exception as e:
                st.errors.append(f"bluesky session: {e} (searches need bluesky.app_password = 'handle:app-password')")
        for h in self.cfg.get("handles", []):
            h = str(h).strip().lstrip("@"); sid = self.register(h, f"@{h}")
            try:
                r = http_get_json(self.BASE + "app.bsky.feed.getAuthorFeed", params={"actor": h, "limit": 50, "filter": "posts_no_replies"})
                n_i = n_m = 0
                for f in r.get("feed", []):
                    p = f.get("post") or {}
                    if not p or (f.get("reason") or {}).get("$type", "").endswith("reasonRepost"):
                        continue
                    it, refs = self._post_item(sid, p); a, b = self.emit(it, refs); n_i += a; n_m += b
                self.store.source_ok(sid, None, n_i); st.items += n_i; st.media += n_m
            except Exception as e:
                self.store.source_error(sid, str(e)); st.errors.append(f"@{h}: {e}")
        for q in self.cfg.get("searches", []):
            sid = self.register("search:" + str(q), f"search “{q}”", "community")
            try:
                r = http_get_json(base + "app.bsky.feed.searchPosts", headers=auth, params={"q": str(q), "limit": 50, "sort": "latest"})
                n_i = n_m = 0
                for p in r.get("posts", []):
                    it, refs = self._post_item(sid, p); a, b = self.emit(it, refs); n_i += a; n_m += b
                self.store.source_ok(sid, None, n_i); st.items += n_i; st.media += n_m
            except Exception as e:
                self.store.source_error(sid, str(e)); st.errors.append(f"search {q}: {e}")
        return st


@register_connector
class Mastodon(Connector):
    kind = "mastodon"
    lane = "analyst"

    def _status(self, sid: str, s: dict) -> tuple[Item, list[MediaRef]]:
        if s.get("reblog"):
            s = s["reblog"]
        refs = [MediaRef(url=m.get("url") or m.get("preview_url"), kind="video" if m.get("type") in ("video", "gifv") else "photo", filename="masto") for m in (s.get("media_attachments") or [])[:4] if (m.get("url") or m.get("preview_url"))]
        acct = (s.get("account") or {})
        it = Item(id=sha1("mastodon", s.get("uri") or s.get("url") or s.get("id")), source_id=sid, ts=parse_iso(s.get("created_at", "")) or 0, text=clean_text(s.get("content", "")), author=acct.get("display_name") or acct.get("acct", ""), url=s.get("url", ""), raw={"boosts": s.get("reblogs_count"), "favs": s.get("favourites_count")})
        return it, refs

    async def collect(self) -> Stats:
        st = Stats()
        for acct in self.cfg.get("accounts", []):
            acct = str(acct).strip().lstrip("@")
            if "@" not in acct:
                st.errors.append(f"mastodon account must be user@instance: {acct}"); continue
            user, inst = acct.split("@", 1)
            sid = self.register(acct, f"@{acct}")
            try:
                a = http_get_json(f"https://{inst}/api/v1/accounts/lookup", params={"acct": user})
                r = http_get_json(f"https://{inst}/api/v1/accounts/{a['id']}/statuses", params={"limit": 40, "exclude_replies": "true"})
                n_i = n_m = 0
                for s in r:
                    it, refs = self._status(sid, s); x, y = self.emit(it, refs); n_i += x; n_m += y
                self.store.source_ok(sid, None, n_i); st.items += n_i; st.media += n_m
            except Exception as e:
                self.store.source_error(sid, str(e)); st.errors.append(f"@{acct}: {e}")
        for inst in self.cfg.get("hashtag_instances", []):
            for tag in self.cfg.get("hashtags", []):
                tag = str(tag).strip().lstrip("#"); sid = self.register(f"{inst}#{tag}", f"#{tag} @ {inst}", "community")
                try:
                    r = http_get_json(f"https://{inst}/api/v1/timelines/tag/{tag}", params={"limit": 40})
                    n_i = n_m = 0
                    for s in r:
                        it, refs = self._status(sid, s); x, y = self.emit(it, refs); n_i += x; n_m += y
                    self.store.source_ok(sid, None, n_i); st.items += n_i; st.media += n_m
                except Exception as e:
                    self.store.source_error(sid, str(e)); st.errors.append(f"#{tag}@{inst}: {e}")
        return st


@register_connector
class Reddit(Connector):
    kind = "reddit"
    lane = "community"

    def _token(self) -> str:
        cid, sec = str(self.cfg.get("client_id", "")).strip(), str(self.cfg.get("client_secret", "")).strip()
        if not (cid and sec):
            return ""
        basic = base64.b64encode(f"{cid}:{sec}".encode()).decode()
        r = http_post_form("https://www.reddit.com/api/v1/access_token", {"grant_type": "client_credentials"}, headers={"Authorization": f"Basic {basic}", "User-Agent": self.cfg.get("user_agent", "lookingglass-collector/3.0")})
        return r.get("access_token", "")

    async def collect(self) -> Stats:
        st = Stats()
        ua = {"User-Agent": self.cfg.get("user_agent", "lookingglass-collector/3.0 (read-only OSINT monitor)")}
        tok = ""
        try:
            tok = self._token()
        except Exception as e:
            log.info("reddit oauth unavailable, using public JSON: %s", e)
        for sub in self.cfg.get("subreddits", []):
            sub = str(sub).strip().removeprefix("r/"); sid = self.register("r/" + sub, f"r/{sub}")
            try:
                if tok:
                    r = http_get_json(f"https://oauth.reddit.com/r/{sub}/new", headers={**ua, "Authorization": f"Bearer {tok}"}, params={"limit": 50, "raw_json": 1})
                else:
                    r = http_get_json(f"https://www.reddit.com/r/{sub}/new.json", headers=ua, params={"limit": 50, "raw_json": 1})
                n_i = n_m = 0
                for ch in (r.get("data") or {}).get("children", []):
                    d = ch.get("data") or {}
                    text = clean_text((d.get("title") or "") + "\n" + (d.get("selftext") or ""))
                    refs = []
                    prev = ((d.get("preview") or {}).get("images") or [{}])[0].get("source", {}).get("url")
                    if prev:
                        refs.append(MediaRef(url=prev, kind="photo", filename="reddit.jpg"))
                    elif str(d.get("url", "")).lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
                        refs.append(MediaRef(url=d["url"], kind="photo", filename="reddit.jpg"))
                    if d.get("is_video") and ((d.get("media") or {}).get("reddit_video") or {}).get("fallback_url"):
                        refs.append(MediaRef(url=d["media"]["reddit_video"]["fallback_url"], kind="video", filename="reddit.mp4"))
                    it = Item(id=sha1("reddit", d.get("id")), source_id=sid, ts=int(d.get("created_utc") or 0), text=text, author=(d.get("author") if self.general.get("store_authors", True) else "member"), url="https://www.reddit.com" + str(d.get("permalink", "")), raw={"score": d.get("score"), "flair": d.get("link_flair_text"), "ext": d.get("url")})
                    x, y = self.emit(it, refs, headers=ua); n_i += x; n_m += y
                self.store.source_ok(sid, None, n_i); st.items += n_i; st.media += n_m
            except Exception as e:
                self.store.source_error(sid, str(e)); st.errors.append(f"r/{sub}: {e}")
        return st


@register_connector
class YouTube(Connector):
    kind = "youtube"
    lane = "independent"
    API = "https://www.googleapis.com/youtube/v3/"

    async def collect(self) -> Stats:
        st = Stats()
        key = str(self.cfg.get("api_key", "")).strip()
        if not key:
            st.errors.append("youtube.api_key missing"); return st
        for ch in self.cfg.get("channels", []):
            ch = str(ch).strip(); sid = self.register(ch)
            try:
                params = {"part": "id,snippet,contentDetails", "key": key}
                params["forHandle" if ch.startswith("@") else "id"] = ch
                r = http_get_json(self.API + "channels", params=params)
                items = r.get("items") or []
                if not items:
                    raise RuntimeError("channel not found")
                c = items[0]; title = c["snippet"]["title"]; uploads = c["contentDetails"]["relatedPlaylists"]["uploads"]
                self.store.upsert_source(sid, self.kind, title, self.lane, True)
                r2 = http_get_json(self.API + "playlistItems", params={"part": "snippet,contentDetails", "playlistId": uploads, "maxResults": 25, "key": key})
                n_i = n_m = 0
                for v in r2.get("items", []):
                    sn = v["snippet"]; vid = v["contentDetails"]["videoId"]
                    text = clean_text(sn.get("title", "") + "\n" + sn.get("description", ""))
                    thumb = ((sn.get("thumbnails") or {}).get("high") or (sn.get("thumbnails") or {}).get("default") or {}).get("url")
                    refs = [MediaRef(url=thumb, kind="photo", filename="yt_thumb.jpg")] if thumb else []
                    it = Item(id=sha1("youtube", vid), source_id=sid, ts=parse_iso(sn.get("publishedAt", "")) or 0, text=text, author=title, url=f"https://www.youtube.com/watch?v={vid}", raw={"videoId": vid})
                    x, y = self.emit(it, refs); n_i += x; n_m += y
                self.store.source_ok(sid, None, n_i); st.items += n_i; st.media += n_m
            except Exception as e:
                self.store.source_error(sid, str(e)); st.errors.append(f"{ch}: {e}")
        return st


NS = {"atom": "http://www.w3.org/2005/Atom", "media": "http://search.yahoo.com/mrss/", "content": "http://purl.org/rss/1.0/modules/content/", "dc": "http://purl.org/dc/elements/1.1/"}


@register_connector
class Rss(Connector):
    kind = "rss"
    lane = "wire"

    async def collect(self) -> Stats:
        st = Stats()
        for url in self.cfg.get("feeds", []):
            url = str(url).strip(); sid = self.register(url, url)
            try:
                raw = http_get(url, headers={"Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml"})
                root = ET.fromstring(raw)
                n_i = n_m = 0
                ftitle = (root.findtext("channel/title") or root.findtext("atom:title", namespaces=NS) or url)
                self.store.upsert_source(sid, self.kind, clean_text(ftitle, 120), self.lane, True)
                entries = root.findall("channel/item") or root.findall("atom:entry", NS)
                for e in entries[:60]:
                    is_atom = e.tag.endswith("entry")
                    title = e.findtext("title") if not is_atom else e.findtext("atom:title", namespaces=NS)
                    link = e.findtext("link") if not is_atom else next((l.get("href") for l in e.findall("atom:link", NS) if l.get("rel") in (None, "alternate")), "")
                    body = e.findtext("content:encoded", namespaces=NS) or e.findtext("description") or (e.findtext("atom:content", namespaces=NS) or e.findtext("atom:summary", namespaces=NS) if is_atom else "") or ""
                    when = e.findtext("pubDate") or e.findtext("dc:date", namespaces=NS) or (e.findtext("atom:published", namespaces=NS) or e.findtext("atom:updated", namespaces=NS) if is_atom else "")
                    guid = e.findtext("guid") or (e.findtext("atom:id", namespaces=NS) if is_atom else "") or link
                    refs = []
                    for mc in e.findall("media:content", NS) + e.findall("media:thumbnail", NS):
                        u = mc.get("url")
                        if u and (str(mc.get("medium", "")).startswith(("image", "video")) or str(mc.get("type", "")).startswith(("image/", "video/")) or mc.tag.endswith("thumbnail")):
                            refs.append(MediaRef(url=u, kind="video" if str(mc.get("type", "")).startswith("video/") or str(mc.get("medium", "")).startswith("video") else "photo", filename="rss"))
                    enc = e.find("enclosure")
                    if enc is not None and enc.get("url") and str(enc.get("type", "")).startswith(("image/", "video/")):
                        refs.append(MediaRef(url=enc["url"] if isinstance(enc, dict) else enc.get("url"), kind="video" if str(enc.get("type", "")).startswith("video/") else "photo", filename="enclosure"))
                    m = re.search(r'<img[^>]+src="([^"]+)"', body or "")
                    if m and not refs:
                        refs.append(MediaRef(url=m.group(1), kind="photo", filename="inline.jpg"))
                    text = clean_text((title or "") + "\n" + (body or ""), 3000)
                    it = Item(id=sha1("rss", url, guid), source_id=sid, ts=parse_iso(when or "") or 0, text=text, author=clean_text(ftitle, 80), url=str(link or ""), raw={"guid": guid})
                    x, y = self.emit(it, refs[:2]); n_i += x; n_m += y
                self.store.source_ok(sid, None, n_i); st.items += n_i; st.media += n_m
            except Exception as e:
                self.store.source_error(sid, str(e)); st.errors.append(f"{url}: {e}")
        return st


@register_connector
class XApi(Connector):
    """X / Twitter v2 API. DISABLED BY DEFAULT — read access requires a paid developer tier. The slot exists so a
    bearer token can be dropped into config.toml later; nothing here posts."""
    kind = "x"
    lane = "analyst"

    async def collect(self) -> Stats:
        st = Stats()
        tok = str(self.cfg.get("bearer_token", "")).strip()
        if not tok:
            st.errors.append("x.bearer_token missing — the X connector stays disabled without one"); return st
        h = {"Authorization": f"Bearer {tok}"}
        queries = [(f"from:{str(u).lstrip('@')} -is:retweet", f"@{str(u).lstrip('@')}", self.lane) for u in self.cfg.get("handles", [])] + [(str(q), f"search “{q}”", "community") for q in self.cfg.get("searches", [])]
        for q, label, lane in queries:
            sid = self.register(label, label, lane)
            try:
                r = http_get_json("https://api.x.com/2/tweets/search/recent", headers=h, params={"query": q, "max_results": 50, "tweet.fields": "created_at,attachments,author_id", "expansions": "attachments.media_keys,author_id", "media.fields": "url,preview_image_url,type", "user.fields": "username,name"})
                media = {m["media_key"]: m for m in (r.get("includes") or {}).get("media", [])}
                users = {u["id"]: u for u in (r.get("includes") or {}).get("users", [])}
                n_i = n_m = 0
                for t in r.get("data", []):
                    u = users.get(t.get("author_id"), {})
                    refs = []
                    for mk in (t.get("attachments") or {}).get("media_keys", [])[:4]:
                        m = media.get(mk) or {}
                        url = m.get("url") or m.get("preview_image_url")
                        if url:
                            refs.append(MediaRef(url=url, kind="video" if m.get("type") in ("video", "animated_gif") else "photo", filename="x.jpg"))
                    it = Item(id=sha1("x", t.get("id")), source_id=sid, ts=parse_iso(t.get("created_at", "")) or 0, text=clean_text(t.get("text", "")), author=u.get("name") or u.get("username", ""), url=f"https://x.com/{u.get('username', 'i')}/status/{t.get('id')}", raw={})
                    x, y = self.emit(it, refs); n_i += x; n_m += y
                self.store.source_ok(sid, None, n_i); st.items += n_i; st.media += n_m
            except Exception as e:
                self.store.source_error(sid, str(e)); st.errors.append(f"{label}: {e}")
        return st
