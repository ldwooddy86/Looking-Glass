"""Triage: a keyword pre-pass (always) and an optional Claude agent pass (items, media, digest).

Rails baked into every prompt: label everything UNVERIFIED; never assert or infer a launcher,
aircraft or warhead position — record what a post CLAIMS as a claim with a place name and a
grade; flag recycled / mislabelled footage; no targeting or operational detail; JSON only.
"""
from __future__ import annotations

import base64
import json
import logging
import os
import re
from typing import Any, Optional

from .store import Store
from .util import HttpError, http_post_json, iso, now

log = logging.getLogger("lg.triage")

ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"
LEGS = ("air", "land", "sea", "other")
KINDS = ("sortie", "launch", "exercise", "deployment", "imagery", "rhetoric", "notam", "adsb", "noise")
LANE_WEIGHT = {"official": 0.15, "wire": 0.15, "analyst": 0.2, "independent": 0.1, "milblogger": 0.1, "aggregator": 0.05, "community": 0.0, "propaganda": -0.05, "custom": 0.0}


# ---------------------------------------------------------------- watchlists
def load_watchlist(name: str, base_dir: str) -> dict:
    fp = os.path.join(base_dir, "watchlists", f"{name}.json")
    if not os.path.exists(fp):
        fp = os.path.join(base_dir, "watchlists", "generic.json")
    with open(fp, "r", encoding="utf-8") as f:
        wl = json.load(f)
    # pre-lowercase alias tables once
    wl["_idx"] = {}
    for cat in ("aircraft", "launchers", "bases", "units", "exercises"):
        wl["_idx"][cat] = [(canon, [a.lower() for a in aliases]) for canon, aliases in (wl.get(cat) or {}).items()]
    wl["_kinds"] = [(k, [a.lower() for a in v]) for k, v in (wl.get("kinds") or {}).items()]
    wl["_legs"] = [(k, [a.lower() for a in v]) for k, v in (wl.get("legs") or {}).items()]
    return wl


def keyword_triage(text: str, wl: dict, lane: str = "", kind_hint: str = "") -> dict:
    """Entities by category, leg, kind and a 0–1 relevance from vocabulary alone."""
    low = (text or "").lower()
    ents: dict[str, list[str]] = {"aircraft": [], "launchers": [], "bases": [], "units": [], "exercises": [], "places": []}
    for cat, table in wl["_idx"].items():
        for canon, aliases in table:
            if any(a in low for a in aliases):
                ents[cat].append(canon)
    legs = {}
    for leg, aliases in wl["_legs"]:
        n = sum(1 for a in aliases if a in low)
        if n:
            legs[leg] = n
    if ents["aircraft"]:
        legs["air"] = legs.get("air", 0) + 2 * len(ents["aircraft"])
    if ents["launchers"]:
        legs["land"] = legs.get("land", 0) + 2 * len(ents["launchers"])
    leg = max(legs, key=legs.get) if legs else "other"
    kind = kind_hint or ""
    if not kind:
        for k, aliases in wl["_kinds"]:
            if any(a in low for a in aliases):
                kind = k
                break
    if not kind:
        kind = "noise" if not any(ents[c] for c in ("aircraft", "launchers", "bases", "units", "exercises")) else "rhetoric"
    score = 0.0
    score += 0.25 * min(2, len(ents["aircraft"]) + len(ents["launchers"]))
    score += 0.15 * min(2, len(ents["bases"]) + len(ents["units"]))
    score += 0.1 if ents["exercises"] else 0.0
    score += {"sortie": 0.2, "launch": 0.25, "deployment": 0.2, "exercise": 0.12, "imagery": 0.1, "notam": 0.15, "adsb": 0.1, "rhetoric": 0.0, "noise": -0.3}.get(kind, 0.0)
    score += LANE_WEIGHT.get(lane or "custom", 0.0)
    if kind_hint in ("adsb", "navwarn", "notam"):
        score = max(score, 0.45)
    return {"leg": leg, "kind": kind if kind in KINDS else "rhetoric", "entities": {k: v[:8] for k, v in ents.items()}, "relevance": round(max(0.0, min(1.0, score)), 2), "source": "keywords"}


# ---------------------------------------------------------------- LLM pass
SYSTEM_ITEMS = (
    "You are an open-source intelligence watch officer supporting LOOKING GLASS, a strategic-warning monitor of a country's nuclear forces "
    "(strike and support aircraft, road-mobile launchers, submarines). INPUT: a JSON array of unverified public posts pulled from Telegram, "
    "Discord, Bluesky, Mastodon, Reddit, YouTube, RSS, ADS-B snapshots and navigational warnings — plus a keyword pre-triage per post. "
    "TASK: for EACH post return one JSON object: {id, leg (air|land|sea|other), kind (sortie|launch|exercise|deployment|imagery|rhetoric|notam|adsb|noise), "
    "relevance (0-1: how much this bears on nuclear-force posture or movement), grade (NATO Admiralty like B2/C3/F6 — reliability of the lane × credibility of this claim), "
    "summary_en (<=40 words, English, plain), reason (<=25 words: why this grade/relevance), "
    "entities {aircraft[], launchers[], bases[], units[], places[]} (canonical names), claims [{text, place, unverified:true}] (what the post CLAIMS happened and where, verbatim-ish)}. "
    "RULES: everything is UNVERIFIED — never state that a launcher, aircraft, submarine or warhead IS somewhere; record claims as claims. Never produce targeting, strike or operational-planning detail. "
    "Recycled or undated footage, propaganda lanes and anonymous claims get low credibility. Absence of reporting is not evidence. Output ONLY a JSON array, no prose."
)
SYSTEM_MEDIA = (
    "You are an imagery triage assistant for an open-source strategic-warning monitor. You will see ONE photo or video frame posted publicly, plus the post's text. "
    "Return ONLY a JSON object: {what (<=40 words: what is visibly in the image — objects, setting, weather, season cues; say 'unclear' when unclear), "
    "aircraft [] (aircraft types you can SUGGEST from visible features, each suffixed '(suggested)'), launchers [] (vehicle / launcher types suggested, same suffix), "
    "claimed_place (the place the POST claims, verbatim, or ''), consistency (<=30 words: whether the visible scene is consistent with the claim — terrain, markings, "
    "season, resolution — and whether it looks recycled or screen-captured), note (<=20 words)}. "
    "RULES: you are suggesting, never confirming; never geolocate to coordinates; never assert that a unit or weapon is at a location; no targeting detail; JSON only."
)
SYSTEM_DIGEST = (
    "You are an open-source intelligence watch officer. INPUT: unverified public posts (already triaged) from the last window, about a country's nuclear forces and military posture. "
    "TASK: write a short I&W read in plain text: (1) up to six LEADS worth corroborating — lane, claim, why it matters to posture or movement, corroboration status (single-lane / multi-lane / contradicted); "
    "(2) what is NOT seen that would matter; (3) one bottom line. RULES: label everything UNVERIFIED; never state or infer real-time aircraft, launcher, submarine or warhead locations; "
    "never produce targeting or operational detail; note information-operations risk where a claim serves a lane's known bias. Max 350 words. Plain text only."
)


class Agent:
    def __init__(self, api_key: str, model: str):
        self.key = api_key
        self.model = model

    @property
    def enabled(self) -> bool:
        return bool(self.key)

    def _call(self, system: str, content: Any, max_tokens: int = 2000) -> str:
        body = {"model": self.model, "max_tokens": max_tokens, "system": system, "messages": [{"role": "user", "content": content}]}
        r = http_post_json(ANTHROPIC_URL, body, headers={"x-api-key": self.key, "anthropic-version": ANTHROPIC_VERSION}, timeout=120)
        parts = [c.get("text", "") for c in (r.get("content") or []) if c.get("type") == "text"]
        return "\n".join(parts)

    @staticmethod
    def _json(text: str, want: str = "array") -> Any:
        s = text.strip()
        s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.S)
        o, c = ("[", "]") if want == "array" else ("{", "}")
        i, j = s.find(o), s.rfind(c)
        if i == -1 or j == -1:
            raise ValueError("no JSON in response")
        return json.loads(s[i:j + 1])

    def triage_items(self, items: list[dict], language_hint: str = "") -> dict[str, dict]:
        payload = []
        for it in items:
            payload.append({"id": it["id"], "lane": (it.get("source") or {}).get("lane", ""), "source_kind": (it.get("source") or {}).get("kind", ""), "when": iso(it.get("ts")), "author": it.get("author", ""), "text": (it.get("text") or "")[:1500], "pre_triage": it.get("pre") or {}, "media_count": len(it.get("media") or [])})
        hint = f" Language hint: {language_hint}." if language_hint else ""
        text = self._call(SYSTEM_ITEMS + hint, json.dumps(payload, ensure_ascii=False), max_tokens=350 * max(1, len(payload)))
        out = {}
        try:
            for o in self._json(text, "array"):
                if isinstance(o, dict) and o.get("id"):
                    out[str(o["id"])] = o
        except (ValueError, json.JSONDecodeError) as e:
            log.warning("triage JSON parse failed: %s", e)
        return out

    def triage_media(self, thumb_path: str, post_text: str, kind: str) -> Optional[dict]:
        try:
            with open(thumb_path, "rb") as f:
                b64 = base64.b64encode(f.read()).decode("ascii")
        except OSError:
            return None
        content = [{"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": b64}}, {"type": "text", "text": f"Media kind: {kind}. Post text (unverified): {post_text[:800]}"}]
        text = self._call(SYSTEM_MEDIA, content, max_tokens=500)
        try:
            return self._json(text, "object")
        except (ValueError, json.JSONDecodeError):
            return {"what": text[:200], "aircraft": [], "launchers": [], "claimed_place": "", "consistency": "", "note": "unparsed"}

    def digest(self, items: list[dict], country: str) -> str:
        lines = [f"Country: {country}. Posts (newest first):"]
        for it in items[:80]:
            tr = it.get("triage") or {}
            lines.append(f"- [{iso(it.get('ts'))}] [{(it.get('source') or {}).get('kind')}/{(it.get('source') or {}).get('lane')}] leg={it.get('leg')} kind={it.get('kind')} rel={tr.get('relevance')} grade={tr.get('grade')} :: {(tr.get('summary_en') or it.get('text') or '')[:300]}")
        return self._call(SYSTEM_DIGEST, "\n".join(lines)[:24000], max_tokens=900)


# ---------------------------------------------------------------- orchestration
def run_triage(store: Store, wl: dict, cfg: dict, country: str = "") -> dict:
    """Keyword pre-pass on everything untriaged; LLM pass (items + media + digest) when a key is set."""
    tcfg = cfg["triage"]
    stats = {"keywords": 0, "llm_items": 0, "llm_media": 0, "digest": False, "errors": 0}
    agent = Agent(tcfg.get("anthropic_api_key", ""), tcfg.get("model", "claude-sonnet-4-6"))
    batch = store.untriaged_items(int(tcfg.get("max_items_per_cycle", 60)))
    pre: dict[str, dict] = {}
    for it in batch:
        k = keyword_triage(it.get("text", ""), wl, (it.get("source") or {}).get("lane", ""), it.get("kind") if it.get("kind") in ("adsb", "navwarn", "notam") else "")
        pre[it["id"]] = k
        stats["keywords"] += 1
        if not agent.enabled or not tcfg.get("enabled", True):
            store.set_triage(it["id"], {"relevance": k["relevance"], "grade": "", "summary_en": "", "reason": "keyword pre-triage only (no API key)", "claims": [], "source": "keywords"}, leg=k["leg"], kind=k["kind"], entities=k["entities"])
    if agent.enabled and tcfg.get("enabled", True) and batch:
        for i in range(0, len(batch), 15):
            chunk = batch[i:i + 15]
            for it in chunk:
                it["pre"] = pre.get(it["id"], {})
            try:
                res = agent.triage_items(chunk, cfg["general"].get("language_hint", ""))
            except HttpError as e:
                log.warning("LLM triage failed: %s", e); stats["errors"] += 1; res = {}
            for it in chunk:
                k = pre[it["id"]]
                o = res.get(it["id"])
                if not o:
                    store.set_triage(it["id"], {"relevance": k["relevance"], "grade": "", "summary_en": "", "reason": "LLM pass unavailable; keyword triage", "claims": [], "source": "keywords"}, leg=k["leg"], kind=k["kind"], entities=k["entities"])
                    continue
                leg = o.get("leg") if o.get("leg") in LEGS else k["leg"]
                kind = o.get("kind") if o.get("kind") in KINDS else k["kind"]
                ents = o.get("entities") if isinstance(o.get("entities"), dict) else k["entities"]
                for c in ("aircraft", "launchers", "bases", "units", "places"):
                    ents.setdefault(c, [])
                    ents[c] = [str(x)[:60] for x in (ents[c] or [])][:8]
                try:
                    rel = float(o.get("relevance", k["relevance"]))
                except (TypeError, ValueError):
                    rel = k["relevance"]
                claims = [{"text": str(c.get("text", ""))[:300], "place": str(c.get("place", ""))[:80], "unverified": True} for c in (o.get("claims") or []) if isinstance(c, dict)][:6]
                store.set_triage(it["id"], {"relevance": round(max(0.0, min(1.0, rel)), 2), "grade": str(o.get("grade", ""))[:12], "summary_en": str(o.get("summary_en", ""))[:400], "reason": str(o.get("reason", ""))[:240], "claims": claims, "source": "llm", "model": agent.model}, leg=leg, kind=kind, entities=ents)
                stats["llm_items"] += 1
        if tcfg.get("vision", True):
            for m in store.untriaged_media(min(20, int(tcfg.get("max_items_per_cycle", 60)) // 3)):
                try:
                    t = agent.triage_media(m["thumb"], m.get("item_text", ""), m["kind"])
                except HttpError as e:
                    log.warning("vision triage failed: %s", e); stats["errors"] += 1; t = None
                if t:
                    t = {"what": str(t.get("what", ""))[:300], "aircraft": [str(x)[:60] for x in (t.get("aircraft") or [])][:6], "launchers": [str(x)[:60] for x in (t.get("launchers") or [])][:6], "claimed_place": str(t.get("claimed_place", ""))[:120], "consistency": str(t.get("consistency", ""))[:240], "note": str(t.get("note", ""))[:120], "source": "llm-vision", "model": agent.model}
                    store.set_media_triage(m["id"], t)
                    stats["llm_media"] += 1
        hours = int(tcfg.get("digest_hours", 6) or 0)
        last = store.latest_digest()
        if hours and (not last or now() - int(last["ts"]) >= hours * 3600 - 60):
            recent = [it for it in store.items(limit=120, since=now() - hours * 3600) if float((it.get("triage") or {}).get("relevance") or 0) >= 0.4]
            if recent:
                try:
                    store.add_digest(agent.digest(recent, country), hours, agent.model)
                    stats["digest"] = True
                except HttpError as e:
                    log.warning("digest failed: %s", e); stats["errors"] += 1
    return stats
