"""Configuration: TOML file + environment overrides + defaults. Secrets stay in config.toml."""
from __future__ import annotations

import copy
import os
import sys
from typing import Any

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:  # pragma: no cover
    try:
        import tomli as tomllib  # type: ignore
    except ModuleNotFoundError:
        tomllib = None  # type: ignore

DEFAULTS: dict[str, Any] = {
    "general": {"name": "generic", "data_dir": "./data", "interval_minutes": 20, "keep_days": 45, "media_max_mb": 40, "store_authors": True, "language_hint": ""},
    "server": {"host": "127.0.0.1", "port": 8787, "token": ""},
    "triage": {"enabled": True, "anthropic_api_key": "", "model": "claude-sonnet-4-6", "vision": True, "digest_hours": 6, "max_items_per_cycle": 60},
    "telegram": {"enabled": False, "api_id": 0, "api_hash": "", "session": "lg_user", "channels": [], "download_media": True, "max_messages_per_channel": 120},
    "telegram_bot": {"enabled": False, "token": "", "download_media": True},
    "discord": {"enabled": False, "token": "", "channels": [], "download_media": True, "max_messages_per_channel": 100},
    "bluesky": {"enabled": False, "handles": [], "searches": [], "app_password": ""},
    "mastodon": {"enabled": False, "accounts": [], "hashtags": [], "hashtag_instances": []},
    "reddit": {"enabled": False, "subreddits": [], "client_id": "", "client_secret": "", "user_agent": "lookingglass-collector/3.0 (read-only OSINT monitor)"},
    "youtube": {"enabled": False, "api_key": "", "channels": [], "download_video": False},
    "rss": {"enabled": False, "feeds": []},
    "x": {"enabled": False, "bearer_token": "", "handles": [], "searches": []},
    "adsb": {"enabled": False, "match": [], "sectors": []},
    "navwarn": {"enabled": False, "areas": [], "keywords": ["ROCKET", "MISSILE", "LAUNCH", "HAZARDOUS OPERATIONS"]},
    "notam": {"enabled": False, "client_id": "", "client_secret": "", "locations": []},
}

LOOPBACK = {"127.0.0.1", "localhost", "::1"}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load(path: str | None) -> dict:
    cfg = copy.deepcopy(DEFAULTS)
    if path and os.path.exists(path):
        if tomllib is None:
            sys.exit("Python 3.11+ (tomllib) or `pip install tomli` is required to read config.toml")
        with open(path, "rb") as f:
            cfg = _merge(cfg, tomllib.load(f))
        cfg["_path"] = os.path.abspath(path)
    else:
        cfg["_path"] = os.path.abspath(path or "config.toml")
    # environment overrides for secrets (never printed)
    env = os.environ
    if env.get("LG_ANTHROPIC_API_KEY"):
        cfg["triage"]["anthropic_api_key"] = env["LG_ANTHROPIC_API_KEY"]
    if env.get("LG_TOKEN"):
        cfg["server"]["token"] = env["LG_TOKEN"]
    if env.get("LG_TELEGRAM_BOT_TOKEN"):
        cfg["telegram_bot"]["token"] = env["LG_TELEGRAM_BOT_TOKEN"]
    if env.get("LG_DISCORD_TOKEN"):
        cfg["discord"]["token"] = env["LG_DISCORD_TOKEN"]
    # rails
    if cfg["server"]["host"] not in LOOPBACK:
        sys.exit(f"server.host must be a loopback address (127.0.0.1 / localhost), got {cfg['server']['host']!r} — the collector never listens on a network interface")
    base = os.path.dirname(cfg["_path"])
    dd = cfg["general"]["data_dir"]
    cfg["general"]["data_dir"] = dd if os.path.isabs(dd) else os.path.normpath(os.path.join(base, dd))
    return cfg


def redacted(cfg: dict) -> dict:
    """A copy safe to print / export: every secret replaced."""
    out = copy.deepcopy(cfg)
    for sect, keys in (("server", ["token"]), ("triage", ["anthropic_api_key"]), ("telegram", ["api_hash"]), ("telegram_bot", ["token"]), ("discord", ["token"]), ("bluesky", ["app_password"]), ("reddit", ["client_secret"]), ("youtube", ["api_key"]), ("x", ["bearer_token"]), ("notam", ["client_secret"])):
        for k in keys:
            if out.get(sect, {}).get(k):
                out[sect][k] = "•••"
    out.pop("_path", None)
    return out
