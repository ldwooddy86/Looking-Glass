"""Loopback HTTP API for the LOOKING GLASS dashboard (GET only).

  GET /api/summary            counts, sources, version
  GET /api/items?limit&since&leg&kind&source&min_relevance
  GET /api/media?limit&since
  GET /api/digest
  GET /media/thumb/<id>.jpg   re-encoded thumbnail (EXIF-free)
  GET /media/file/<id>        the stored original (local copy)

Binds to 127.0.0.1 only. A shared token (x-lg-token header or ?token=) is required when configured.
CORS is open for GET (the caller is a chrome-extension:// page on the same machine); no credentials.
"""
from __future__ import annotations

import json
import logging
import os
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import __version__
from .config import LOOPBACK
from .store import Store
from .util import now

log = logging.getLogger("lg.server")


def _public_item(d: dict) -> dict:
    return {"id": d["id"], "ts": d["ts"], "source": d.get("source") or {"kind": "?", "id": d.get("source_id"), "label": d.get("source_id"), "lane": ""}, "author": d.get("author", ""), "text": d.get("text", ""), "url": d.get("url", ""), "lang": d.get("lang", ""),
            "leg": d.get("leg") or "other", "kind": d.get("kind") or "", "entities": d.get("entities") or {}, "triage": d.get("triage"), "media": d.get("media") or [], "dup_of": d.get("dup_of") or ""}


def _public_media(d: dict) -> dict:
    return {"id": d["id"], "item_id": d["item_id"], "kind": d["kind"], "thumb": f"/media/thumb/{d['id']}.jpg" if d.get("thumb") else "", "w": d.get("w"), "h": d.get("h"), "duration": d.get("duration"), "phash": d.get("phash"), "dups": d.get("dups", 0),
            "source": d.get("source") or {"kind": "?", "id": d.get("source_id"), "label": d.get("source_id")}, "ts": d.get("ts"), "triage": d.get("triage"), "url": d.get("item_url") or d.get("url") or "", "text": d.get("item_text", "")}


def make_handler(store: Store, token: str, name: str):
    class H(BaseHTTPRequestHandler):
        server_version = "LookingGlassCollector/" + __version__

        def log_message(self, fmt, *args):  # quiet
            log.debug("%s " + fmt, self.address_string(), *args)

        def _cors(self):
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "x-lg-token, accept")
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")

        def _json(self, code: int, obj):
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code); self._cors(); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

        def _auth(self, q) -> bool:
            if not token:
                return True
            t = self.headers.get("x-lg-token") or (q.get("token") or [""])[0]
            return t == token

        def do_OPTIONS(self):
            self.send_response(204); self._cors(); self.end_headers()

        def do_GET(self):
            u = urllib.parse.urlsplit(self.path); q = urllib.parse.parse_qs(u.query); p = u.path
            if not self._auth(q):
                self._json(401, {"ok": False, "error": "token"}); return
            try:
                if p == "/api/summary":
                    c = store.counts(); srcs = [{"id": s["id"], "kind": s["kind"], "label": s["label"], "lane": s["lane"], "ok": bool(s["last_ok"]) and not s["last_error"], "last": s["last_run"], "error": s["last_error"], "items": s["items"]} for s in store.sources()]
                    d = store.latest_digest()
                    self._json(200, {"ok": True, "version": __version__, "name": name, "ts": now(), "items": c["items"], "media": c["media"], "untriaged": c["untriaged"], "sources": srcs, "digest_ts": d["ts"] if d else None, "runs": store.recent_runs(8)})
                elif p == "/api/items":
                    lim = max(1, min(500, int((q.get("limit") or ["200"])[0]))); since = int((q.get("since") or ["0"])[0]) or None
                    items = store.items(limit=lim, since=since, leg=(q.get("leg") or [""])[0], kind=(q.get("kind") or [""])[0], source_kind=(q.get("source") or [""])[0], min_relevance=float((q.get("min_relevance") or ["0"])[0]))
                    self._json(200, {"ok": True, "items": [_public_item(i) for i in items]})
                elif p == "/api/media":
                    lim = max(1, min(300, int((q.get("limit") or ["120"])[0]))); since = int((q.get("since") or ["0"])[0]) or None
                    self._json(200, {"ok": True, "media": [_public_media(m) for m in store.media(limit=lim, since=since)]})
                elif p == "/api/digest":
                    d = store.latest_digest()
                    self._json(200, {"ok": True, "ts": d["ts"], "text": d["text"], "window_hours": d["window_hours"], "model": d["model"]} if d else {"ok": True, "ts": None, "text": ""})
                elif p.startswith("/media/thumb/") or p.startswith("/media/file/"):
                    mid = p.rsplit("/", 1)[1].split(".")[0]
                    if not mid.isalnum():
                        self._json(404, {"ok": False}); return
                    m = store.media_by_id(mid)
                    fp = (m or {}).get("thumb" if p.startswith("/media/thumb/") else "path") or ""
                    if not m or not fp or not os.path.exists(fp):
                        self._json(404, {"ok": False, "error": "no file"}); return
                    ctype = "image/jpeg" if p.startswith("/media/thumb/") else ("video/mp4" if m["kind"] == "video" else "image/jpeg")
                    size = os.path.getsize(fp)
                    self.send_response(200); self._cors(); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(size)); self.send_header("Content-Disposition", "inline"); self.end_headers()
                    with open(fp, "rb") as f:
                        while True:
                            chunk = f.read(256 * 1024)
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                else:
                    self._json(404, {"ok": False, "error": "not found"})
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as e:
                log.exception("request failed")
                self._json(500, {"ok": False, "error": str(e)[:200]})
    return H


class Api:
    def __init__(self, store: Store, host: str, port: int, token: str, name: str):
        if host not in LOOPBACK:
            raise ValueError("the collector API only binds to loopback")
        self.httpd = ThreadingHTTPServer((host, int(port)), make_handler(store, token, name))
        self.httpd.daemon_threads = True
        self.thread = threading.Thread(target=self.httpd.serve_forever, name="lg-api", daemon=True)
        self.host, self.port = host, int(port)

    def start(self):
        self.thread.start()
        log.info("API listening on http://%s:%d (loopback only)", self.host, self.port)

    def stop(self):
        try:
            self.httpd.shutdown(); self.httpd.server_close()
        except Exception:
            pass
