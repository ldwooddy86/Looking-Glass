"""LOOKING GLASS collector — read-only OSINT collection through your own accounts.

Pulls items, photos and video from Telegram (user session and/or bot), Discord (bot), Bluesky,
Mastodon, Reddit, YouTube, RSS/Atom, public ADS-B, navigational warnings and (optionally) NOTAMs;
stores them locally (SQLite + files); runs a keyword pre-triage and an optional Claude triage /
vision / digest agent; serves JSON on the loopback interface for the LOOKING GLASS dashboard.

Rails: reads only — never posts, reacts, joins, DMs or scrapes behind someone else's login; keeps
everything on the local machine; never asserts a launcher, aircraft or warhead position — claims
in posts are recorded as claims, graded, and labelled unverified.
"""
__version__ = "3.0.0"
