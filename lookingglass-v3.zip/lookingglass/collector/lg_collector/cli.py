"""Command line: init · login · once · run · serve · status · export · test.

  python -m lg_collector init [--from-data ../assets/extension/data.js] [--name russia]
  python -m lg_collector login telegram
  python -m lg_collector once            # one collection + triage cycle
  python -m lg_collector run             # cycle forever + API
  python -m lg_collector serve           # API only
  python -m lg_collector status
  python -m lg_collector export --out exports/
  python -m lg_collector test            # exercise every enabled connector once, no triage
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time

from . import __version__
from . import config as cfgmod
from .connectors import build as build_connectors
from .export import export as do_export
from .media import MediaPipeline
from .server import Api
from .store import Store
from .triage import load_watchlist, run_triage
from .util import gen_token, iso, now

HERE = os.path.dirname(os.path.abspath(__file__))
COLLECTOR_ROOT = os.path.dirname(HERE)
log = logging.getLogger("lg")


def _store(cfg) -> tuple[Store, MediaPipeline]:
    st = Store(cfg["general"]["data_dir"])
    mp = MediaPipeline(st, cfg["general"]["data_dir"], int(cfg["general"].get("media_max_mb", 40)))
    return st, mp


async def cycle(cfg: dict, store: Store, media: MediaPipeline, triage: bool = True) -> dict:
    wl = load_watchlist(cfg["general"].get("name", "generic"), COLLECTOR_ROOT)
    report = {"started": iso(now()), "connectors": {}, "triage": None}
    for c in build_connectors(cfg, store, media):
        rid = store.run_start(c.kind)
        try:
            st = await c.collect()
            store.run_end(rid, st.items, st.media, "; ".join(st.errors)[:400])
            report["connectors"][c.kind] = {"items": st.items, "media": st.media, "errors": st.errors}
            log.info("%-13s items=%d media=%d%s", c.kind, st.items, st.media, (" errors: " + "; ".join(st.errors)[:300]) if st.errors else "")
        except Exception as e:
            store.run_end(rid, 0, 0, str(e)); report["connectors"][c.kind] = {"items": 0, "media": 0, "errors": [str(e)]}
            log.exception("%s failed", c.kind)
    if triage:
        try:
            report["triage"] = run_triage(store, wl, cfg, cfg["general"].get("name", ""))
            log.info("triage %s", report["triage"])
        except Exception as e:
            log.exception("triage failed"); report["triage"] = {"error": str(e)}
    pruned = store.prune(int(cfg["general"].get("keep_days", 45)))
    if pruned:
        log.info("pruned %d old items", pruned)
    store.kv_set("last_cycle", json.dumps(report))
    return report


# ---------------------------------------------------------------- init (from data.js)
def _eval_data_js(path: str) -> dict:
    js = ("const fs=require('fs');const vm=require('vm');const sb={window:{},self:{}};vm.createContext(sb);"
          "vm.runInContext(fs.readFileSync(process.argv[1],'utf8'),sb,{timeout:5000});"
          "const d=sb.window.ORACLE_DATA||{};process.stdout.write(JSON.stringify({meta:d.meta||{},collector:d.collector||null,"
          "air:(d.airWatch&&d.airWatch.scanner)||null,launcher:(d.launcherWatch&&d.launcherWatch.scanner)||null,move:(d.movementWatch&&d.movementWatch.scanner)||null,"
          "sub:(d.subWatch&&d.subWatch.scanner)||null,airLive:(d.airWatch&&d.airWatch.live)||null,track:d.trackWatch||null}));")
    if not shutil.which("node"):
        sys.exit("node is required to read data.js (or write config.toml by hand from config.example.toml)")
    out = subprocess.run(["node", "-e", js, path], capture_output=True, text=True, timeout=30)
    if out.returncode != 0:
        sys.exit("could not evaluate data.js: " + out.stderr.strip()[:300])
    return json.loads(out.stdout)


def _toml_str(s: str) -> str:
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def _toml_list(xs) -> str:
    return "[" + ", ".join(_toml_str(x) for x in xs) + "]"


def cmd_init(args) -> int:
    target = args.config
    if os.path.exists(target) and not args.force:
        print(f"{target} exists — use --force to overwrite"); return 1
    name = args.name or "generic"
    plan = {"telegram": [], "discord": [], "bluesky": [], "mastodon": [], "reddit": [], "youtube": [], "rss": [], "x": []}
    adsb_types, sectors, nav_areas, nav_keywords, notam_locs = [], [], [], [], []
    data = None
    if args.from_data:
        data = _eval_data_js(args.from_data)
        name = args.name or re.sub(r"[^a-z0-9-]", "", (data["meta"].get("slug") or "generic").lower()) or "generic"
        col = data.get("collector") or {}
        for s in col.get("sources") or []:
            k = s.get("kind"); ident = s.get("handle") or s.get("id") or s.get("url") or ""
            if k == "telegram": plan["telegram"].append(ident.lstrip("@"))
            elif k == "discord": plan["discord"].append(ident.split("/")[-1])
            elif k == "bluesky": plan["bluesky"].append(ident.lstrip("@"))
            elif k == "mastodon": plan["mastodon"].append(ident.lstrip("@"))
            elif k == "reddit": plan["reddit"].append(ident)
            elif k == "youtube": plan["youtube"].append(ident)
            elif k in ("rss", "web"): plan["rss"].append(ident)
            elif k == "x": plan["x"].append(ident.lstrip("@"))
            elif k == "adsb" and isinstance(s.get("lat"), (int, float)) and isinstance(s.get("lon"), (int, float)):
                sectors.append({"lat": s["lat"], "lon": s["lon"], "dist": int(s.get("dist", 150)), "label": str(s.get("label", ident))[:60]})
            elif k == "navwarn":
                nav_areas += [str(a) for a in (s.get("areas") or [])]; nav_keywords += [str(x) for x in (s.get("keywords") or [])]
            elif k == "notam":
                notam_locs += [str(x).upper() for x in re.split(r"[,\s]+", ident) if x]
        for blk in (data.get("airLive"), data.get("track")):
            for m in ((blk or {}).get("match") or {}).values():
                adsb_types += [str(t) for t in (m.get("types") or [])]
            sec = (blk or {}).get("sector")
            if sec and isinstance(sec.get("lat"), (int, float)):
                sectors.append({"lat": sec["lat"], "lon": sec["lon"], "dist": int(sec.get("dist", 150)), "label": str(sec.get("label", ""))[:60]})
        # watchlist from the scanners
        wl_path = os.path.join(COLLECTOR_ROOT, "watchlists", f"{name}.json")
        if not os.path.exists(wl_path) or getattr(args, 'reseed_watchlist', False):
            base = json.load(open(os.path.join(COLLECTOR_ROOT, "watchlists", "generic.json"), encoding="utf-8"))
            base["name"] = name; base["language"] = ""
            def terms_of(sc):
                out = []
                for cat in ((sc or {}).get("dictionary") or []):
                    for t in cat.get("terms") or []:
                        for part in re.split(r"\s*/\s*", str(t)):
                            m = re.match(r"^(.*?)\s*\(([^)]*)\)\s*$", part)
                            out += [x.strip() for x in ([m.group(1), m.group(2)] if m else [part]) if x.strip()]
                return out
            air, land, sea, move = terms_of(data.get("air")), terms_of(data.get("launcher")), terms_of(data.get("sub")), terms_of(data.get("move"))
            base["legs"] = {"air": sorted(set(base["legs"]["air"] + air)), "land": sorted(set(base["legs"]["land"] + land)), "sea": sorted(set(base["legs"]["sea"] + sea))}
            if move:
                base["kinds"]["deployment"] = sorted(set(base["kinds"]["deployment"] + move[:40]))
            base["note"] = f"Seeded from {os.path.basename(args.from_data)} scanner dictionaries on {iso(now())[:10]}; add the subject's aircraft / launcher / base / unit aliases under their own headings."
            with open(wl_path, "w", encoding="utf-8") as f:
                json.dump(base, f, ensure_ascii=False, indent=2)
            print(f"watchlist written: {wl_path}")
    token = gen_token()
    ex = open(os.path.join(COLLECTOR_ROOT, "config.example.toml"), encoding="utf-8").read()
    ex = ex.replace('name = "russia"', f'name = {_toml_str(name)}').replace('token = "REPLACE-ME"', f'token = {_toml_str(token)}')
    ex = re.sub(r'(\[telegram\][\s\S]*?channels = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(plan["telegram"] or ["rybar"]), ex)
    ex = re.sub(r'(\[discord\][\s\S]*?channels = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(plan["discord"] or ["123456789012345678"]), ex)
    ex = re.sub(r'(\[bluesky\][\s\S]*?handles = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(plan["bluesky"] or ["osintdefender.bsky.social"]), ex)
    ex = re.sub(r'(\[mastodon\][\s\S]*?accounts = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(plan["mastodon"] or ["osint@infosec.exchange"]), ex)
    ex = re.sub(r'(\[reddit\][\s\S]*?subreddits = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(plan["reddit"] or ["r/CredibleDefense"]), ex)
    ex = re.sub(r'(\[youtube\][\s\S]*?channels = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(plan["youtube"] or ["@RealTimeWars"]), ex)
    ex = re.sub(r'(\[rss\][\s\S]*?feeds = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(plan["rss"] or ["https://www.bellingcat.com/feed/"]), ex)
    ex = re.sub(r'(\[x\][\s\S]*?handles = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(plan["x"] or ["osinttechnical"]), ex)
    if adsb_types:
        ex = re.sub(r'(\[adsb\][\s\S]*?match = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(sorted(set(adsb_types))), ex)
    if sectors:
        seen = set(); uniq = []
        for s in sectors:
            key = (round(float(s["lat"]), 1), round(float(s["lon"]), 1))
            if key in seen: continue
            seen.add(key); uniq.append(s)
        ex = re.sub(r'(\[adsb\][\s\S]*?sectors = )\[[^\n]*\]', lambda m: m.group(1) + "[" + ", ".join("{ lat = %s, lon = %s, dist = %d, label = %s }" % (s["lat"], s["lon"], s["dist"], _toml_str(s["label"])) for s in uniq) + "]", ex)
    if nav_areas:
        ex = re.sub(r'(\[navwarn\][\s\S]*?areas = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(sorted(set(nav_areas))), ex)
    if nav_keywords:
        ex = re.sub(r'(\[navwarn\][\s\S]*?keywords = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(sorted(set(nav_keywords))), ex)
    if notam_locs:
        ex = re.sub(r'(\[notam\][\s\S]*?locations = )\[[^\]]*\]', lambda m: m.group(1) + _toml_list(sorted(set(notam_locs))), ex)
    with open(target, "w", encoding="utf-8") as f:
        f.write(ex)
    print(f"config written: {target}\n  token (paste into the dashboard Settings → Local collector): {token}\n  next: fill in the credentials for the lanes you want, then `python -m lg_collector login telegram` (user session) and `python -m lg_collector test`.")
    return 0


def cmd_login(args) -> int:
    cfg = cfgmod.load(args.config)
    if args.service != "telegram":
        print("only `login telegram` is interactive (the others use tokens/keys in config.toml)"); return 1
    from .connectors.telegram_user import TelegramUser
    st, mp = _store(cfg)
    t = TelegramUser(dict(cfg["telegram"], enabled=True), cfg["general"], st, mp)
    asyncio.run(t.login())
    print("Telegram user session stored under data_dir. Set telegram.enabled = true in config.toml.")
    return 0


def cmd_once(args) -> int:
    cfg = cfgmod.load(args.config); st, mp = _store(cfg)
    rep = asyncio.run(cycle(cfg, st, mp, triage=not args.no_triage))
    print(json.dumps(rep, ensure_ascii=False, indent=1))
    return 0


def cmd_test(args) -> int:
    cfg = cfgmod.load(args.config); st, mp = _store(cfg)
    rep = asyncio.run(cycle(cfg, st, mp, triage=False))
    ok = all(not v.get("errors") for v in rep["connectors"].values())
    for k, v in rep["connectors"].items():
        print(f"{k:13s} items={v['items']:4d} media={v['media']:3d} {'OK' if not v['errors'] else 'ERRORS: ' + '; '.join(v['errors'])[:300]}")
    if not rep["connectors"]:
        print("no connectors enabled — edit config.toml")
    return 0 if ok else 1


def cmd_run(args) -> int:
    cfg = cfgmod.load(args.config); st, mp = _store(cfg)
    api = Api(st, cfg["server"]["host"], int(cfg["server"]["port"]), str(cfg["server"].get("token", "")), cfg["general"].get("name", ""))
    api.start()
    mins = max(3, int(cfg["general"].get("interval_minutes", 20)))
    log.info("LOOKING GLASS collector %s · cycle every %d min · data in %s", __version__, mins, cfg["general"]["data_dir"])
    try:
        while True:
            t0 = time.time()
            try:
                asyncio.run(cycle(cfg, st, mp))
            except Exception:
                log.exception("cycle failed")
            time.sleep(max(30, mins * 60 - (time.time() - t0)))
    except KeyboardInterrupt:
        pass
    finally:
        api.stop()
    return 0


def cmd_serve(args) -> int:
    cfg = cfgmod.load(args.config); st, _ = _store(cfg)
    api = Api(st, cfg["server"]["host"], int(cfg["server"]["port"]), str(cfg["server"].get("token", "")), cfg["general"].get("name", ""))
    api.start()
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        api.stop()
    return 0


def cmd_status(args) -> int:
    cfg = cfgmod.load(args.config); st, _ = _store(cfg)
    c = st.counts()
    print(f"LOOKING GLASS collector {__version__} · {cfg['general'].get('name')} · data {cfg['general']['data_dir']}")
    print(f"items {c['items']} · media {c['media']} · sources {c['sources']} · untriaged {c['untriaged']}")
    for s in st.sources():
        print(f"  {s['kind']:13s} {s['label'][:40]:40s} items={s['items'] or 0:5d} last={iso(s['last_run'])} {'OK' if s['last_ok'] and not s['last_error'] else (s['last_error'] or 'never')}")
    d = st.latest_digest()
    print("digest:", iso(d["ts"]) if d else "none")
    print("config:", json.dumps(cfgmod.redacted(cfg), indent=1)[:1500])
    return 0


def cmd_export(args) -> int:
    cfg = cfgmod.load(args.config); st, _ = _store(cfg)
    s = do_export(st, args.out)
    print(json.dumps(s, indent=1))
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="lg_collector", description="LOOKING GLASS read-only OSINT collector")
    ap.add_argument("--config", default=os.path.join(COLLECTOR_ROOT, "config.toml"))
    ap.add_argument("-v", "--verbose", action="store_true")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init"); p.add_argument("--from-data", help="path to the dashboard's data.js"); p.add_argument("--name"); p.add_argument("--force", action="store_true", help="overwrite config.toml"); p.add_argument("--reseed-watchlist", action="store_true", help="overwrite an existing curated watchlists/<name>.json with a fresh seed (normally keep the curated one)"); p.set_defaults(fn=cmd_init)
    p = sub.add_parser("login"); p.add_argument("service", choices=["telegram"]); p.set_defaults(fn=cmd_login)
    p = sub.add_parser("once"); p.add_argument("--no-triage", action="store_true"); p.set_defaults(fn=cmd_once)
    p = sub.add_parser("test"); p.set_defaults(fn=cmd_test)
    p = sub.add_parser("run"); p.set_defaults(fn=cmd_run)
    p = sub.add_parser("serve"); p.set_defaults(fn=cmd_serve)
    p = sub.add_parser("status"); p.set_defaults(fn=cmd_status)
    p = sub.add_parser("export"); p.add_argument("--out", default=os.path.join(COLLECTOR_ROOT, "exports")); p.set_defaults(fn=cmd_export)
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    return int(args.fn(args) or 0)
