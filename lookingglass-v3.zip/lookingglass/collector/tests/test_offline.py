"""Offline tests — no network, no accounts. Run: python -m pytest collector/tests -q  (or python collector/tests/test_offline.py)"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import urllib.request
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from lg_collector import config as cfgmod  # noqa: E402
from lg_collector.export import export  # noqa: E402
from lg_collector.media import MediaPipeline, dhash, make_thumb  # noqa: E402
from lg_collector.server import Api  # noqa: E402
from lg_collector.store import Item, MediaRef, Store  # noqa: E402
from lg_collector.triage import keyword_triage, load_watchlist  # noqa: E402
from lg_collector.util import clean_text, parse_iso, sha1  # noqa: E402
from lg_collector.connectors.social import NS  # noqa: E402


def _tmp():
    return tempfile.mkdtemp(prefix="lgtest_")


def test_clean_text_strips_hostile_markup():
    t = clean_text("<b>Tu-95</b> pair <img src=x onerror=alert(1)> took off &amp; ‮abc")
    assert "<" not in t and "onerror" not in t and "&amp;" not in t and "‮" not in t
    assert "Tu-95 pair took off & abc" == t


def test_parse_iso():
    assert parse_iso("2026-09-15T10:00:00Z") == 1789466400 or parse_iso("2026-09-15T10:00:00Z") > 1.7e9
    assert parse_iso("Tue, 15 Sep 2026 10:00:00 GMT") > 1.7e9
    assert parse_iso("garbage") is None


def test_keyword_triage_russia():
    wl = load_watchlist("russia", ROOT)
    k = keyword_triage("Пара Ту-95МС взлетела с аэродрома Энгельс, сообщают мониторинговые каналы", wl, "milblogger")
    assert k["leg"] == "air" and k["kind"] == "sortie" and "Tu-95MS/MSM" in k["entities"]["aircraft"] and "Engels-2" in k["entities"]["bases"]
    assert k["relevance"] >= 0.5
    k2 = keyword_triage("Полки Ярс Тейковской дивизии выведены на маршруты боевого патрулирования", wl, "official")
    assert k2["leg"] == "land" and k2["kind"] == "exercise" and "RS-24 Yars road-mobile ICBM" in k2["entities"]["launchers"]
    k3 = keyword_triage("Cat pictures and a recipe", wl, "community")
    assert k3["kind"] == "noise" and k3["relevance"] < 0.2


def test_store_items_media_and_dedupe():
    d = _tmp(); st = Store(d); mp = MediaPipeline(st, d, 5)
    st.upsert_source("rss:x", "rss", "Example", "wire")
    it = Item(id=sha1("a"), source_id="rss:x", ts=1_800_000_000, text="hello", url="https://example.org/a")
    assert st.add_item(it) and not st.add_item(it)
    # a real image through the media pipeline (local_path adoption)
    from PIL import Image
    src = os.path.join(d, "src.png"); Image.new("RGB", (400, 300), (200, 120, 30)).save(src)
    mid = mp.ingest(it.id, "rss:x", it.ts, MediaRef(url="https://example.org/a.png", kind="photo", local_path=src, filename="a.png"))
    m = st.media_by_id(mid)
    assert m and m["thumb"].endswith(".jpg") and os.path.exists(m["thumb"]) and m["w"] == 400 and len(m["phash"]) == 16
    # near-duplicate detection via perceptual hash
    src2 = os.path.join(d, "src2.png"); Image.new("RGB", (401, 301), (201, 121, 31)).save(src2)
    mid2 = mp.ingest(sha1("b"), "rss:x", it.ts, MediaRef(url="https://example.org/b.png", kind="photo", local_path=src2, filename="b.png"))
    assert st.media_by_id(mid2)["dups"] >= 1
    items = st.items(limit=10)
    assert items[0]["source"]["kind"] == "rss" and items[0]["media"] == [mid]
    st.set_triage(it.id, {"relevance": 0.8, "grade": "B2", "summary_en": "x", "reason": "y", "claims": [], "source": "test"}, leg="air", kind="sortie", entities={"aircraft": ["Tu-95MS"]})
    assert st.items(min_relevance=0.7)[0]["triage"]["grade"] == "B2"
    assert st.counts()["untriaged"] == 0


def test_dhash_stability():
    from PIL import Image
    im = Image.new("L", (64, 64)); px = im.load()
    for y in range(64):
        for x in range(64):
            px[x, y] = (x * 4) % 256
    h1 = dhash(im); h2 = dhash(im.resize((128, 96)))
    assert h1 == h2


def test_server_and_export():
    d = _tmp(); st = Store(d)
    st.upsert_source("bluesky:x", "bluesky", "@x", "analyst")
    st.add_item(Item(id="i1", source_id="bluesky:x", ts=1_800_000_000, text="<script>alert(1)</script> Yars regiments on combat patrol", url="https://bsky.app/x"))
    st.set_triage("i1", {"relevance": 0.9, "grade": "C3", "summary_en": "claimed patrol", "reason": "r", "claims": [], "source": "test"}, leg="land", kind="exercise", entities={})
    st.add_digest("UNVERIFIED digest text", 6, "test-model")
    api = Api(st, "127.0.0.1", 0, "secret-token", "test"); api.start()
    port = api.httpd.server_address[1]
    try:
        def get(path, tok="secret-token"):
            req = urllib.request.Request(f"http://127.0.0.1:{port}{path}"); req.add_header("x-lg-token", tok)
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, json.loads(r.read().decode())
        s, j = get("/api/summary"); assert s == 200 and j["ok"] and j["items"] == 1 and j["sources"][0]["kind"] == "bluesky"
        s, j = get("/api/items?leg=land"); assert j["items"][0]["triage"]["grade"] == "C3" and j["items"][0]["source"]["label"] == "@x"
        s, j = get("/api/digest"); assert j["text"].startswith("UNVERIFIED")
        try:
            get("/api/summary", tok="wrong"); assert False, "token check failed"
        except urllib.error.HTTPError as e:
            assert e.code == 401
        try:
            get("/media/thumb/nope.jpg"); assert False
        except urllib.error.HTTPError as e:
            assert e.code == 404
    finally:
        api.stop()
    out = os.path.join(d, "exp"); summ = export(st, out)
    assert summ["items"] == 1 and os.path.exists(os.path.join(out, "feed.json")) and os.path.exists(os.path.join(out, "digest.html"))
    html = open(os.path.join(out, "digest.html"), encoding="utf-8").read()
    assert "<script>alert(1)</script>" not in html and "&lt;script&gt;" in html


def test_config_loopback_rail_and_redaction():
    d = _tmp(); p = os.path.join(d, "config.toml")
    open(p, "w").write('[server]\nhost = "127.0.0.1"\nport = 8787\ntoken = "abcdefghijkl"\n[triage]\nanthropic_api_key = "sk-ant-secret"\n')
    cfg = cfgmod.load(p)
    assert cfg["server"]["port"] == 8787 and cfgmod.redacted(cfg)["triage"]["anthropic_api_key"] == "•••" and cfgmod.redacted(cfg)["server"]["token"] == "•••"
    open(p, "w").write('[server]\nhost = "0.0.0.0"\n')
    try:
        cfgmod.load(p); assert False, "non-loopback host must be refused"
    except SystemExit:
        pass


def test_rss_fixture_parses():
    xml = """<?xml version="1.0"?><rss version="2.0" xmlns:media="http://search.yahoo.com/mrss/"><channel><title>Wire</title>
    <item><title>Yars test launch from Plesetsk</title><link>https://example.org/1</link><guid>g1</guid><pubDate>Tue, 15 Sep 2026 08:00:00 GMT</pubDate>
    <description>&lt;p&gt;Ministry footage&lt;/p&gt;</description><media:content url="https://example.org/1.jpg" medium="image"/></item></channel></rss>"""
    root = ET.fromstring(xml)
    items = root.findall("channel/item"); assert len(items) == 1
    mc = items[0].find("media:content", NS); assert mc is not None and mc.get("url").endswith(".jpg")


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn(); print("ok  ", name)
            except Exception as e:  # noqa: BLE001
                fails += 1; print("FAIL", name, "→", repr(e))
    sys.exit(1 if fails else 0)
