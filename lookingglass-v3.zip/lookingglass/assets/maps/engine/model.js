/* ============================================================================
   LOOKING GLASS · maps/model.js — operating-area likelihood engine (domain-agnostic)
   Pure computation, no DOM. Expects globals GRID (from maps_prep_geo.py) and CFG (theatre config).
   Output: a STRUCTURAL PRIOR over where a DEPLOYED unit of a class would be — never a
   detection, track, patrol box or position. Every factor is declared in the config and
   carries the reference IDs it was built from.
   ---------------------------------------------------------------------------
   Domains (GRID.domain / CFG.grid.domain):
     sea   raster classes = bathymetry bands, 255 = land (impassable). The COUNTDOWN engine.
     land  raster classes = terrain/movement classes (road corridor, cover, open, urban …),
           255 = water or outside the confined territory (impassable). Road-mobile launchers.
     air   raster classes = airspace classes (own, allied, neutral, adversary), nothing
           impassable; movement cost per class stands in for airspace avoidance.
   The engine does not care which: "impassable" and "class" are all it reads. The names
   `land` and `depth` are kept for the sea heritage (and for app.js) — read them as
   `impassable` and `cellClass`.
   ---------------------------------------------------------------------------
   Factor types (config.factors[].type):
     depth | terrain  suitability per raster class (config.depth_suitability[cls] or
                      config.terrain_suitability[cls] — eight multipliers)
     zones          polygon multipliers: zones:[{polygon, mult:{cls:param}}]
     hubs           1 + Σ amp·exp(-d/scale): sets:[{set, scale_nm, amp:{cls:param}}]
     points         Π (1 + amp·exp(-(d/r)^2)): points:[{point, radius_nm, amp:{cls:param}}]
     line_exposure  inside/beyond a polygon + near-line penalty + beyond decay
     pressure       exp(-k·P), P = Σ w·exp(-d/scale) over a weighted point set; optional shield polygon
     proximity      1 + amp·exp(-(dmin/r)^2) over a point set (negative amp = avoidance)
     envelope       soft wall on routed distance from own base: 0.05 + 0.95/(1+exp((d-wall)/60))
   Per-class params: number | {mod, base, gain} (posture) | {default, scenario, value}
   Per-class movement cost: classes[c].shallow_cost (sea heritage: shelf-to-shelf edges ×cost)
   or classes[c].cell_cost (eight multipliers by raster class, averaged over an edge).
   Deployed counts: classes[c].deployed[posture] (alias: at_sea).
   ============================================================================ */
(function (root) {
  'use strict';
  const G = root.GRID, CFG = root.CFG;
  const NC = G.nc, NR = G.nr, STEP = G.step, LON0 = G.lon0, LAT0 = G.lat0;
  const N = NC * NR, NM_PER_DEG = 60.0, R_NM = 3440.065;
  const CELL_NM = STEP * NM_PER_DEG;                   // cell height in nm
  const nmToCells = nm => Math.max(0.35, nm / CELL_NM);
  const DOMAIN = (G.domain || (CFG.grid && CFG.grid.domain) || 'sea');

  // ---- raster ------------------------------------------------------------------
  const ras = new Uint8Array(N); { let p = 0; for (const [v, n] of G.rle) { ras.fill(v, p, p + n); p += n; } }
  const land = new Uint8Array(N), depth = new Uint8Array(N);   // land = impassable, depth = raster class
  for (let i = 0; i < N; i++) { if (ras[i] === 255) { land[i] = 1; } else depth[i] = ras[i]; }
  const lat = new Float64Array(N), lon = new Float64Array(N), cellW = new Float64Array(N), area = new Float64Array(N);
  for (let i = 0; i < N; i++) { const r = (i / NC) | 0, c = i - r * NC; lat[i] = LAT0 + (r + 0.5) * STEP; lon[i] = LON0 + (c + 0.5) * STEP; cellW[i] = CELL_NM * Math.cos(lat[i] * Math.PI / 180); area[i] = cellW[i] * CELL_NM; }
  let seaCount = 0; for (let i = 0; i < N; i++) if (!land[i]) seaCount++;

  // ---- geometry helpers --------------------------------------------------------------
  function hav(lon1, lat1, lon2, lat2) { const la1 = lat1 * Math.PI / 180, la2 = lat2 * Math.PI / 180, dlon = (lon2 - lon1) * Math.PI / 180, dlat = la2 - la1; const a = Math.sin(dlat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dlon / 2) ** 2; return 2 * R_NM * Math.asin(Math.sqrt(Math.min(1, Math.max(0, a)))); }
  const distField = (plon, plat) => { const o = new Float64Array(N); for (let i = 0; i < N; i++) o[i] = hav(lon[i], lat[i], plon, plat); return o; };
  const minField = fields => { const o = new Float64Array(N).fill(Infinity); for (const f of fields) for (let i = 0; i < N; i++) if (f[i] < o[i]) o[i] = f[i]; return o; };
  function pointInPoly(px, py, poly) { let inside = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) { const xi = poly[i][0], yi = poly[i][1], xj = poly[j][0], yj = poly[j][1]; if (((yi > py) !== (yj > py)) && (px < (xj - xi) * (py - yi) / ((yj - yi) || 1e-12) + xi)) inside = !inside; } return inside; }
  const polyMask = poly => { const m = new Uint8Array(N); for (let i = 0; i < N; i++) if (pointInPoly(lon[i], lat[i], poly)) m[i] = 1; return m; };
  function polylineDist(pts) { const out = new Float64Array(N).fill(Infinity); for (let s = 0; s < pts.length - 1; s++) { const x1 = pts[s][0], y1 = pts[s][1], x2 = pts[s + 1][0], y2 = pts[s + 1][1]; const cl = Math.cos(((y1 + y2) / 2) * Math.PI / 180); const bx = (x2 - x1) * cl, by = y2 - y1, bb = bx * bx + by * by || 1e-12; for (let i = 0; i < N; i++) { const ax = (lon[i] - x1) * cl, ay = lat[i] - y1; let t = (ax * bx + ay * by) / bb; t = t < 0 ? 0 : t > 1 ? 1 : t; const dx = ax - t * bx, dy = ay - t * by; const d = Math.sqrt(dx * dx + dy * dy) * NM_PER_DEG; if (d < out[i]) out[i] = d; } } return out; }

  // ---- static layers from config -----------------------------------------------------------
  const POLY = {}; for (const k in (CFG.polygons || {})) POLY[k] = polyMask(CFG.polygons[k].pts);
  const LINE = {}; for (const k in (CFG.lines || {})) LINE[k] = polylineDist(CFG.lines[k].pts);
  const PT = {}; for (const k in (CFG.points || {})) PT[k] = distField(CFG.points[k].lon, CFG.points[k].lat);
  const SET = {}; for (const k in (CFG.point_sets || {})) { const s = CFG.point_sets[k]; SET[k] = { min: minField(s.pts.map(p => distField(p.lon ?? p[0], p.lat ?? p[1]))), pts: s.pts }; }
  const REGION = (CFG.regions || []).map(r => ({ id: r.id, name: r.name, mask: polyMask(r.pts) }));
  const regionOf = new Int16Array(N).fill(-1); REGION.forEach((rg, ri) => { for (let i = 0; i < N; i++) if (regionOf[i] < 0 && rg.mask[i]) regionOf[i] = ri; });
  const pressureCache = {};
  function pressureField(setKey, scale) { const key = setKey + '|' + scale; if (pressureCache[key]) return pressureCache[key]; const P = new Float64Array(N); for (const p of CFG.point_sets[setKey].pts) { const f = distField(p.lon, p.lat); const w = p.w == null ? 1 : p.w; for (let i = 0; i < N; i++) P[i] += w * Math.exp(-f[i] / scale); } pressureCache[key] = P; return P; }

  // ---- movement cost -----------------------------------------------------------------------
  // Sea heritage: shallow_cost multiplies shelf-to-shelf edges (class 0 → class 0).
  // General form: cell_cost[8] multiplies every edge by the mean cost of its two cells.
  function costSpec(cls) { const c = CFG.classes[cls] || {}; const tab = Array.isArray(c.cell_cost) && c.cell_cost.length === 8 ? c.cell_cost.map(Number) : null; return { shallow: c.shallow_cost || 1, tab }; }
  const costKey = spec => (spec.tab ? 'T' + spec.tab.join(',') : 'S' + spec.shallow);

  // ---- 16-neighbour Dijkstra ----------------------------------------------------------------
  const MOVES = []; for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) { if (!dr && !dc) continue; if (Math.abs(dr) === 2 && Math.abs(dc) === 2) continue; if ((Math.abs(dr) === 2 && dc === 0) || (Math.abs(dc) === 2 && dr === 0)) continue; MOVES.push([dr, dc]); }
  function passable(r, c, dr, dc) { const rr = r + dr, cc = c + dc; if (rr < 0 || rr >= NR || cc < 0 || cc >= NC) return false; if (land[rr * NC + cc]) return false; if (Math.abs(dr) === 1 && Math.abs(dc) === 1) { if (land[r * NC + cc] && land[rr * NC + c]) return false; } else if (Math.abs(dr) === 2 || Math.abs(dc) === 2) { const m1r = r + (Math.abs(dr) === 2 ? dr / 2 : dr), m1c = c + (Math.abs(dc) === 2 ? dc / 2 : 0); const m2r = r + (Math.abs(dr) === 2 ? dr / 2 : 0), m2c = c + (Math.abs(dc) === 2 ? dc / 2 : dc); if (land[m1r * NC + m1c] || land[m2r * NC + m2c]) return false; } return true; }
  function nearestSea(plon, plat) { const c0 = Math.floor((plon - LON0) / STEP), r0 = Math.floor((plat - LAT0) / STEP); let best = -1, bd = Infinity; for (let dr = -8; dr <= 8; dr++) for (let dc = -8; dc <= 8; dc++) { const r = r0 + dr, c = c0 + dc; if (r < 0 || r >= NR || c < 0 || c >= NC) continue; const i = r * NC + c; if (land[i]) continue; const d = dr * dr + dc * dc; if (d < bd) { bd = d; best = i; } } return best; }
  class Heap { constructor() { this.k = []; this.v = []; } push(key, val) { const k = this.k, v = this.v; k.push(key); v.push(val); let i = k.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (k[p] <= k[i]) break; [k[p], k[i]] = [k[i], k[p]]; [v[p], v[i]] = [v[i], v[p]]; i = p; } } pop() { const k = this.k, v = this.v; const top = [k[0], v[0]]; const lk = k.pop(), lv = v.pop(); if (k.length) { k[0] = lk; v[0] = lv; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < k.length && k[l] < k[m]) m = l; if (r < k.length && k[r] < k[m]) m = r; if (m === i) break; [k[m], k[i]] = [k[i], k[m]]; [v[m], v[i]] = [v[i], v[m]]; i = m; } } return top; } get size() { return this.k.length; } }
  function dijkstra(src, spec) {
    const dist = new Float64Array(N).fill(Infinity); dist[src] = 0; const h = new Heap(); h.push(0, src);
    const shallowCost = spec.shallow, tab = spec.tab;
    while (h.size) { const [d, u] = h.pop(); if (d > dist[u]) continue; const r = (u / NC) | 0, c = u - r * NC;
      for (const [dr, dc] of MOVES) { if (!passable(r, c, dr, dc)) continue; const v = (r + dr) * NC + (c + dc); let w = Math.hypot(dc * cellW[u], dr * CELL_NM);
        if (tab) w *= 0.5 * (tab[depth[u]] + tab[depth[v]]);
        else if (shallowCost > 1 && depth[v] === 0 && depth[u] === 0) w *= shallowCost;
        const nd = d + w; if (nd < dist[v]) { dist[v] = nd; h.push(nd, v); } } }
    const idx = []; for (let i = 0; i < N; i++) if (isFinite(dist[i])) idx.push(i); idx.sort((a, b) => dist[b] - dist[a]);
    return { dist, order: Uint32Array.from(idx) };
  }
  const SRC = {};   // key: base|cost
  function srcFor(baseKey, shallowOrSpec) { const spec = (shallowOrSpec && typeof shallowOrSpec === 'object') ? shallowOrSpec : { shallow: shallowOrSpec || 1, tab: null }; const k = baseKey + '|' + costKey(spec); if (!SRC[k]) { const b = CFG.bases[baseKey]; if (!b) throw new Error('unknown base ' + baseKey); const cell = nearestSea(b.lon, b.lat); if (cell < 0) throw new Error('no passable cell near base ' + baseKey); SRC[k] = dijkstra(cell, spec); SRC[k].cell = cell; } return SRC[k]; }
  const srcForClass = (baseKey, cls) => srcFor(baseKey, costSpec(cls));

  // ---- multiple-flow-direction accumulation --------------------------------------------------
  const MFD_P = 4;
  function flow(p, src) { const { dist, order } = src; const F = Float64Array.from(p); const nb = new Array(16), nw = new Float64Array(16);
    for (let oi = 0; oi < order.length; oi++) { const u = order[oi]; if (F[u] === 0) continue; const r = (u / NC) | 0, c = u - r * NC, du = dist[u]; let k = 0, wsum = 0;
      for (const [dr, dc] of MOVES) { if (!passable(r, c, dr, dc)) continue; const v = (r + dr) * NC + (c + dc), dv = dist[v]; if (dv < du - 1e-6) { const len = Math.hypot(dc * cellW[u], dr * CELL_NM); const w = Math.pow((du - dv) / len, MFD_P); nb[k] = v; nw[k] = w; wsum += w; k++; } }
      if (!wsum) continue; const fu = F[u]; for (let j = 0; j < k; j++) F[nb[j]] += fu * nw[j] / wsum; }
    return F; }
  function blurSea(x, sigmaCells) { const sigma = Math.max(0.3, sigmaCells); const rad = Math.ceil(sigma * 3); const ker = []; let ks = 0; for (let k = -rad; k <= rad; k++) { const w = Math.exp(-(k * k) / (2 * sigma * sigma)); ker.push(w); ks += w; } for (let k = 0; k < ker.length; k++) ker[k] /= ks;
    const tmp = new Float64Array(N), tmpm = new Float64Array(N), out = new Float64Array(N); let tot = 0; for (let i = 0; i < N; i++) tot += x[i];
    for (let r = 0; r < NR; r++) for (let c = 0; c < NC; c++) { let s = 0, sm = 0; for (let k = -rad; k <= rad; k++) { const cc = c + k; if (cc < 0 || cc >= NC) continue; const j = r * NC + cc; if (land[j]) continue; const w = ker[k + rad]; s += x[j] * w; sm += w; } tmp[r * NC + c] = s; tmpm[r * NC + c] = sm; }
    for (let r = 0; r < NR; r++) for (let c = 0; c < NC; c++) { const i = r * NC + c; if (land[i]) continue; let s = 0, sm = 0; for (let k = -rad; k <= rad; k++) { const rr = r + k; if (rr < 0 || rr >= NR) continue; const j = rr * NC + c; if (land[j]) continue; const w = ker[k + rad]; s += tmp[j] * w; sm += tmpm[j] * w; } out[i] = sm > 0 ? s / sm : 0; }
    let ot = 0; for (let i = 0; i < N; i++) ot += out[i]; if (ot > 0) { const f = tot / ot; for (let i = 0; i < N; i++) out[i] *= f; } return out; }

  // ---- parameter resolution ---------------------------------------------------------------------
  function withCtx(ctx) { if (!ctx.pm) ctx.pm = (CFG.postures && CFG.postures.modifiers && CFG.postures.modifiers[ctx.posture]) || {}; if (!ctx.enabled) ctx.enabled = {}; if (!ctx.scenarios) ctx.scenarios = {}; return ctx; }
  function resolve(v, ctx, dflt) { if (v == null) return dflt == null ? 1 : dflt; if (typeof v === 'number') return v; if (typeof v === 'object') { if (v.scenario && ctx.scenarios[v.scenario]) return v.value; if (v.mod != null) { const m = ctx.pm[v.mod]; const mv = m == null ? 1 : m; return (v.base == null ? 0 : v.base) + (v.gain == null ? 1 : v.gain) * mv; } if (v.default != null) return v.default; } return dflt == null ? 1 : dflt; }
  const P = (obj, cls, ctx, dflt) => resolve(obj ? obj[cls] : undefined, ctx, dflt);
  const suitTable = cls => (CFG.terrain_suitability && CFG.terrain_suitability[cls]) || (CFG.depth_suitability && CFG.depth_suitability[cls]) || [1, 1, 1, 1, 1, 1, 1, 1];
  const deployedOf = cls => (CFG.classes[cls].deployed || CFG.classes[cls].at_sea || {});
  // Source shares may switch under a scenario: classes[c].sources_scenarios = { <scenarioId>: { base: share } }.
  function srcShares(cls, ctx) { withCtx(ctx); const c = CFG.classes[cls]; const alt = c.sources_scenarios || {}; for (const id in alt) if (ctx.scenarios[id]) return alt[id]; return c.sources; }

  // ---- factor evaluators --------------------------------------------------------------------------
  const bump = (d, r, a) => 1 + a * Math.exp(-((d / r) * (d / r)));
  const EVAL = {
    depth: (F, cls, ctx) => { const t = suitTable(cls); return i => t[depth[i]]; },
    zones: (F, cls, ctx) => { const zs = F.zones.map(z => ({ m: POLY[z.polygon], v: P(z.mult, cls, ctx, 1) })).filter(z => z.m); return i => { let v = 1; for (const z of zs) if (z.m[i]) v *= z.v; return v; }; },
    hubs: (F, cls, ctx) => { const ss = F.sets.map(s => ({ d: SET[s.set].min, sc: s.scale_nm, a: P(s.amp, cls, ctx, 0) })); return i => { let v = 1; for (const s of ss) v += s.a * Math.exp(-s.d[i] / s.sc); return v; }; },
    points: (F, cls, ctx) => { const ps = F.points.map(p => ({ d: PT[p.point], r: p.radius_nm || (CFG.points[p.point] && CFG.points[p.point].radius_nm) || 60, a: P(p.amp, cls, ctx, 0) })).filter(p => p.d); return i => { let v = 1; for (const p of ps) v *= bump(p.d[i], p.r, p.a); return v; }; },
    line_exposure: (F, cls, ctx) => { const inside = F.inside_polygon ? POLY[F.inside_polygon] : null; const dl = F.line ? LINE[F.line] : null; const near = P(F.near_penalty, cls, ctx, 0), width = F.width_nm || 70; const beyond = P(F.beyond_mult, cls, ctx, 1); const bd = F.beyond_decay_nm ? P(F.beyond_decay_nm, cls, ctx, 0) : 0;
      return i => { let v = 1; const isIn = inside ? !!inside[i] : true; if (!isIn) { v *= beyond; if (bd > 0 && dl) v *= Math.exp(-dl[i] / bd); } if (dl && near > 0) v *= 1 - near * Math.exp(-((dl[i] / width) ** 2)); return v; }; },
    pressure: (F, cls, ctx) => { const Pf = pressureField(F.set, F.scale_nm || 280); const k = P(F.k, cls, ctx, 0); const shield = F.shield && POLY[F.shield.polygon] ? { m: POLY[F.shield.polygon], s: P(F.shield.scale, cls, ctx, F.shield.scale) } : null; return i => { let p = Pf[i]; if (shield && shield.m[i]) p *= (typeof shield.s === 'number' ? shield.s : 1); return Math.exp(-k * p); }; },
    proximity: (F, cls, ctx) => { const d = SET[F.set].min; const r = P(F.radius_nm, cls, ctx, 45), a = P(F.amp, cls, ctx, 0); return i => 1 + a * Math.exp(-((d[i] / r) ** 2)); },
    envelope: () => () => 1   // handled per source in sourceTerms (needs own-base distance)
  };
  EVAL.terrain = EVAL.depth;
  function factorFns(cls, ctx) { withCtx(ctx); const out = []; for (const F of CFG.factors) { if (ctx.enabled[F.id] === false) continue; const mk = EVAL[F.type]; if (!mk) continue; if (F.classes && !F.classes.includes(cls)) continue; out.push({ id: F.id, fn: mk(F, cls, ctx) }); } return out; }
  function prior(cls, ctx) { const fns = factorFns(cls, ctx); const f = new Float64Array(N); for (let i = 0; i < N; i++) { if (land[i]) continue; let v = 1; for (const F of fns) v *= F.fn(i); f[i] = v; } return f; }
  function factorBreakdown(cls, i, ctx) { withCtx(ctx); return CFG.factors.filter(F => !F.classes || F.classes.includes(cls)).map(F => { const on = ctx.enabled[F.id] !== false; let mult = 1; if (F.type === 'envelope') { const cfg = CFG.classes[cls]; const wall = P(F.wall_nm, cls, ctx, 0); if (wall > 0) { let best = Infinity; for (const sk in srcShares(cls, ctx)) { const d = srcForClass(sk, cls).dist[i]; if (d < best) best = d; } mult = isFinite(best) ? 0.05 + 0.95 / (1 + Math.exp((best - wall) / 60)) : 1; } } else { const mk = EVAL[F.type]; mult = mk ? mk(F, cls, ctx)(i) : 1; } return { id: F.id, label: F.label, on, mult }; }); }

  // ---- surfaces -------------------------------------------------------------------------------------
  function sourceTerms(cls, key, basePrior, ctx) {
    const cfg = CFG.classes[cls]; const src = srcForClass(key, cls);
    const lam = (cfg.source_decay && cfg.source_decay[key]) || cfg.decay_nm || 600;
    const envF = CFG.factors.find(F => F.type === 'envelope' && ctx.enabled[F.id] !== false && (!F.classes || F.classes.includes(cls))); const wall = envF ? P(envF.wall_nm, cls, ctx, 0) : 0;
    const p = new Float64Array(N); let tot = 0;
    for (let i = 0; i < N; i++) { const d = src.dist[i]; if (!isFinite(d) || land[i]) continue; let v = basePrior[i] * Math.exp(-d / lam); if (wall > 0) v *= 0.05 + 0.95 / (1 + Math.exp((d - wall) / 60)); p[i] = v; tot += v; }
    if (tot > 0) for (let i = 0; i < N; i++) p[i] /= tot;
    return { p, F: flow(p, src), dist: src.dist };
  }
  const BL = Object.assign({ transit_blur_nm: 36, ring_blur_nm: 24, ring_width_nm: 9, speed_mix: [[0.75, 0.25], [1.0, 0.5], [1.25, 0.25]] }, CFG.routing || {});
  const STEP_NM = CELL_NM * 1.15;
  function timeSurface(terms, v, hours, patrolDays) { const { p, F, dist } = terms; const out = new Float64Array(N);
    if (hours == null) { const vT = v * patrolDays * 24; const tr = new Float64Array(N); for (let i = 0; i < N; i++) { if (!isFinite(dist[i])) continue; out[i] = p[i] * Math.max(0, 1 - 2 * dist[i] / vT); tr[i] = Math.max(0, F[i] - p[i]) * (2 * STEP_NM / vT); } const trb = blurSea(tr, nmToCells(BL.transit_blur_nm)); for (let i = 0; i < N; i++) out[i] += trb[i]; }
    else { for (const [vf, vw] of BL.speed_mix) { const R = v * vf * hours; const ring = new Float64Array(N), onst = new Float64Array(N); let mOn = 0, rs = 0; for (let i = 0; i < N; i++) { const d = dist[i]; if (!isFinite(d)) continue; if (d <= R) { onst[i] = p[i]; mOn += p[i]; } const k = Math.exp(-(((d - R) / BL.ring_width_nm) ** 2)); const t = Math.max(0, F[i] - p[i]) * k; ring[i] = t; rs += t; } const mTr = Math.max(0, 1 - mOn); if (rs > 0) { const f = mTr / rs; for (let i = 0; i < N; i++) ring[i] *= f; } const rb = blurSea(ring, nmToCells(BL.ring_blur_nm)); for (let i = 0; i < N; i++) out[i] += vw * (onst[i] + rb[i]); } }
    let s = 0; for (let i = 0; i < N; i++) s += out[i]; if (s > 0) for (let i = 0; i < N; i++) out[i] /= s; return out; }
  const MAINT = {};
  function maintenanceRoute(cls) { if (MAINT[cls]) return MAINT[cls]; const mt = CFG.classes[cls].maintenance_transit; const src = mt.plain_routing ? srcFor(mt.from, 1) : srcForClass(mt.from, cls); const target = nearestSea(CFG.bases[mt.to].lon, CFG.bases[mt.to].lat); const p = new Float64Array(N); p[target] = 1; const F = flow(p, src); const out = new Float64Array(N); let s = 0; for (let i = 0; i < N; i++) { if (!isFinite(src.dist[i])) continue; out[i] = Math.max(0, F[i] - p[i]); s += out[i]; } if (s > 0) for (let i = 0; i < N; i++) out[i] /= s; MAINT[cls] = blurSea(out, nmToCells(mt.blur_nm || 26)); return MAINT[cls]; }
  const CACHE = {};
  function classSurface(cls, ctx) { withCtx(ctx); const cfg = CFG.classes[cls]; const key = JSON.stringify([cls, ctx.posture, ctx.scenarios, ctx.enabled]); let terms = CACHE[key];
    const shares = srcShares(cls, ctx);
    if (!terms) { const bp = prior(cls, ctx); terms = {}; for (const sk in shares) terms[sk] = sourceTerms(cls, sk, bp, ctx); for (const k in CACHE) delete CACHE[k]; CACHE[key] = terms; }
    const out = new Float64Array(N); let wsum = 0; for (const sk in shares) { const w = shares[sk]; wsum += w; const s = timeSurface(terms[sk], cfg.speed_kts, ctx.hours, cfg.patrol_days || 30); for (let i = 0; i < N; i++) out[i] += w * s[i]; } for (let i = 0; i < N; i++) out[i] /= wsum;
    const mt = cfg.maintenance_transit; if (mt && (!mt.factor || ctx.enabled[mt.factor] !== false)) { const M = maintenanceRoute(cls); const wm = mt.weight || 0.03; for (let i = 0; i < N; i++) out[i] = (1 - wm) * out[i] + wm * M[i]; }
    return out; }
  function combinedSurface(ctx) { withCtx(ctx); const out = new Float64Array(N); let tot = 0; for (const cls in CFG.classes) { const n = deployedOf(cls)[ctx.posture] || 0; if (!n) continue; const s = classSurface(cls, ctx); for (let i = 0; i < N; i++) out[i] += n * s[i]; tot += n; } if (tot > 0) for (let i = 0; i < N; i++) out[i] /= tot; return out; }

  // ---- analytics ---------------------------------------------------------------------------------------
  function hdr(pdf) { const dens = new Float64Array(N); const idx = []; for (let i = 0; i < N; i++) { if (land[i] || pdf[i] <= 0) continue; dens[i] = pdf[i] / area[i]; idx.push(i); } idx.sort((a, b) => dens[b] - dens[a]); const coord = new Float64Array(N); let cum = 0, ar = 0; const levels = { 0.5: null, 0.8: null, 0.95: null }, areas = { 0.5: 0, 0.8: 0, 0.95: 0 }; for (const i of idx) { cum += pdf[i]; ar += area[i]; coord[i] = cum; for (const q of [0.5, 0.8, 0.95]) if (levels[q] === null && cum >= q) { levels[q] = dens[i]; areas[q] = ar; } } return { dens, coord, levels, areas, ranked: idx }; }
  function regionMass(pdf) { const m = new Float64Array(REGION.length); let other = 0; for (let i = 0; i < N; i++) { if (!pdf[i]) continue; const r = regionOf[i]; if (r >= 0) m[r] += pdf[i]; else other += pdf[i]; } const rows = REGION.map((rg, k) => ({ id: rg.id, name: rg.name, mass: m[k] })); rows.push({ id: 'other', name: 'Elsewhere in frame', mass: other }); rows.sort((a, b) => b.mass - a.mass); return rows; }
  function transitSplit(cls, ctx) { withCtx(ctx); const cfg = CFG.classes[cls]; const key = JSON.stringify([cls, ctx.posture, ctx.scenarios, ctx.enabled]); const terms = CACHE[key]; if (!terms) return null; const shares = srcShares(cls, ctx); let on = 0, wsum = 0; for (const sk in shares) { const w = shares[sk]; wsum += w; const { p, dist } = terms[sk]; let s = 0; if (ctx.hours == null) { const vT = cfg.speed_kts * (cfg.patrol_days || 30) * 24; for (let i = 0; i < N; i++) if (isFinite(dist[i])) s += p[i] * Math.max(0, 1 - 2 * dist[i] / vT); } else { const R = cfg.speed_kts * ctx.hours; for (let i = 0; i < N; i++) if (isFinite(dist[i]) && dist[i] <= R) s += p[i]; } on += w * s; } return on / wsum; }
  function contours(dens, level) { const segs = []; const val = (r, c) => { const i = r * NC + c; return land[i] ? 0 : dens[i]; }; const lerp = (a, b) => { const d = b - a; return Math.abs(d) < 1e-30 ? 0.5 : Math.min(1, Math.max(0, (level - a) / d)); };
    for (let r = 0; r < NR - 1; r++) for (let c = 0; c < NC - 1; c++) { const v0 = val(r, c), v1 = val(r, c + 1), v2 = val(r + 1, c + 1), v3 = val(r + 1, c); const code = (v0 >= level ? 1 : 0) | ((v1 >= level ? 1 : 0) << 1) | ((v2 >= level ? 1 : 0) << 2) | ((v3 >= level ? 1 : 0) << 3); if (code === 0 || code === 15) continue; const top = [c + lerp(v0, v1), r], right = [c + 1, r + lerp(v1, v2)], bottom = [c + lerp(v3, v2), r + 1], left = [c, r + lerp(v0, v3)]; const add = (a, b) => segs.push([a, b]);
      switch (code) { case 1: case 14: add(left, top); break; case 2: case 13: add(top, right); break; case 3: case 12: add(left, right); break; case 4: case 11: add(right, bottom); break; case 5: add(left, top); add(right, bottom); break; case 6: case 9: add(top, bottom); break; case 7: case 8: add(left, bottom); break; case 10: add(top, right); add(left, bottom); break; } }
    return segs; }

  root.MODEL = { N, NC, NR, STEP, LON0, LAT0, DOMAIN, land, depth, lat, lon, area, seaCount, regionOf, REGION, POLY, LINE, SET, PT, srcFor, srcForClass, costSpec, deployedOf, srcShares, prior, classSurface, combinedSurface, hdr, regionMass, transitSplit, contours, factorBreakdown, hav, pressureField,
    cellIndex: (plon, plat) => { const c = Math.floor((plon - LON0) / STEP), r = Math.floor((plat - LAT0) / STEP); if (c < 0 || c >= NC || r < 0 || r >= NR) return -1; return r * NC + c; } };
})(typeof window !== 'undefined' ? window : globalThis);
