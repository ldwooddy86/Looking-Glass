# LOOKING GLASS — the unified nuclear-forces watch

**What it is.** One platform that fuses DalesOracle (the all-source OSINT posture monitor and its
hardened Chrome extension) with Countdown (the Bayesian operating-area heatmaps) and extends both
to the whole triad: a **Sub Watch** for the sea leg, an **Air Watch** for strike and support
aircraft, a **Launcher Watch** for road-mobile launchers, a **Triad Map** tab that embeds the
heatmaps for every leg, and a **collector** that pulls OSINT channels, social media, Telegram and
Discord through your own accounts and lets a Claude agent triage posts, photos and video into a
feed, a gallery and a watch digest. Flagship build: **Russia**, compiled 15 SEP 2026.

**What it is not.** A position, a track, a patrol box, a field position, a route, an alert state or
a target. Every heatmap is a structural prior conditional on deployment; every live lane is
unverified; every custody question is marked UNSEEN. The validators enforce that in code.

## Run it on a country

```
1. Research on the build date           references/RESEARCH-PLAYBOOK.md §1–§7, MAPS-RESEARCH-PLAYBOOK.md
2. Scaffold + fill data.js              node scripts/scaffold_data.js … --sub --air --launcher --maps --collector
3. Theatre configs                      data/theatres/<slug>-{north,pacific,land,air}.json + references/countries/<slug>.md
4. Verify lanes and designators         node scripts/verify_channels.js · doc8643.com · curl -sI <feed>
5. Validate                             node scripts/validate_data.js --strict · node scripts/maps_validate_config.js …
6. Build maps                           bash scripts/maps_build_all.sh <ids>          (LG_GEODATA / LG_BUILD / LG_DIST)
7. Build + package + render-check       build_preview.py --artifact · package_extension.py · render_check.js --ext · maps_render_check.js
8. Collector                            cd collector && python -m lg_collector init --from-data ../assets/extension/data.js
```

`SKILL.md` is the operating manual; `references/` holds the contracts (SCHEMA, MAPS-SCHEMA), the
standards (TRADECRAFT, MAPS-TRADECRAFT), the playbooks, and the catalogues (AIRCRAFT, LAUNCHERS,
CONNECTORS, ADSB-TYPES, MAPS-GEODATA, countries/).

## Outputs

| output | what | where it runs |
|---|---|---|
| `<slug>-lookingglass-preview.html` (+ `.artifact.html`) | the whole dashboard, all 21 tabs, four heatmaps embedded, self-contained | anywhere, offline; the fragment publishes as an Artifact |
| `<slug>-monitor-extension.zip` | the MV3 extension: live lanes, ADS-B boards, scanner, map pages, collector bridge | Chrome (Load unpacked) |
| `dist/maps/<id>.html` (+ `.artifact.html`, `ext/`) | each heatmap standalone | anywhere |
| `collector/` exports (`feed.json`, `media.json`, `digest.md/html`) | the collector's items and digest for a Cowork session | your machine |

## Reading the product

- **Posture gauge** → the fused read with its uncertainty range and the observation that would
  move it. **BLUF / Key Judgments** → ICD-203 bands with confidence stated separately.
- **I&W boards** (main, sea, air, land) → a warning meter over the observable rows and a **blind
  fraction** over the invisible ones. Quiet on an `unseen` row is not calm.
- **Fleet boards** → two counts where sources disagree; single-side war claims graded B2/C3.
- **Heatmaps** → the 50 % contour is the smallest area holding even odds of a deployed unit;
  posture scales the deployed fraction and reach; scenarios switch fall-backs; the Method tab says
  which class is tight at LOW confidence and which is diffuse at MODERATE.
- **Feed / Media** → leads, never facts; the digest is a machine read of the last window.

## The Russia flagship (15 SEP 2026)

Posture HIGH (elevated–high): New START lapsed 5 Feb 2026; a 19–21 May 2026 out-of-season strategic
exercise framed as employment "under a threat of aggression" with Belarus for the first time;
Oreshnik on combat duty at Krichev-6; Sarmat one claimed success and no regiment; the bomber
fleet at Ukrainka but attrited at Engels-2 (16 Jul, 28 Aug 2026); Kinzhal reportedly out of
production; the Leipzig explosive-drone attack on NATO's airlift hub attributed to Russia. Four
theatres: Northern Fleet, Pacific Fleet, land (seven Yars positional districts, Iskander brigades,
the Oreshnik battalion), air (Long-Range Aviation, Kinzhal carriers, enablers). 40 Telegram
handles and 17 RSS feeds verified on the build date.

## Refresh cadence

Perishables (leadership, exercises, tests, losses, deployments, handles, feeds) every build;
baselines (FAS Notebook, IISS, SIPRI) when a new edition lands; theatres when basing or doctrine
changes. Log every delta in `product.changes` and bump `meta.edition` / the theatre `edition`.

## Licence

For Dale Wooddy / Top Shelf Logic internal use. Flight data: adsb.fi open data (personal,
non-commercial; cite). Geodata: Natural Earth (public domain).
