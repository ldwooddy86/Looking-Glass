# ADS-B type designators for Track Watch matchers

`trackWatch.match.<key>.types[]` is compared (upper-cased, alphanumerics only) against the `t`
field of the public adsb.fi feed, which carries **ICAO Doc 8643 type designators**. A wrong code
silently matches nothing. Use this table; verify anything else at `https://doc8643.com/aircraft/<CODE>`
(404 = the code does not exist). Prefer `regs[]` (registration / serial as shown in the feed)
or `hex[]` (Mode-S address) for a specific airframe.

| airframe | designator(s) | status |
|---|---|---|
| Boeing P-8A Poseidon | `P8` | verified (Doc 8643) |
| Boeing RC-135 Rivet Joint / Cobra Ball / TC-135 | `R135` | verified |
| Boeing WC-135 Constant Phoenix | `R135` (feeds sometimes show `WC135`) | R135 verified; WC135 feed-variant, include both |
| Boeing E-3 Sentry (USAF, TF33) | `E3TF` | verified |
| Boeing E-3 Sentry (NATO/RAF/RSAF, CFM56) | `E3CF` | verified |
| Boeing E-6B Mercury (TACAMO) | `E6` | verified |
| Boeing E-4B Nightwatch | `B742` (no `E4` in Doc 8643) | use `B742` + regs |
| Boeing E-7A Wedgetail / 737 AEW&C | `E737` | verified |
| Boeing E-767 (JASDF AWACS) | `E767` | verified |
| Boeing KC-135R/T | `K35R` | verified |
| Boeing KC-46A Pegasus | `B762` (no `K46`/`K46A` in Doc 8643) | use `B762` + regs |
| Northrop Grumman RQ-4 Global Hawk / MQ-4C Triton / EQ-4 | `Q4` | verified |
| Lockheed U-2S / ER-2 | `U2` | verified |
| Boeing C-17 Globemaster III | `C17` | verified |
| Lockheed C-130 / C-130J | `C130` / `C30J` | verified |
| Lockheed P-3 Orion / EP-3 | `P3` | verified |
| Beechcraft King Air 350 / MC-12W | `B350` | verified |
| Gulfstream V / C-37A (G550-based ISR shows as GLF5/GL5T) | `GLF5` | verified — beware: matches civilian Gulfstreams; pair with `regs` |
| Bombardier Global Express / E-11A BACN | `GLEX` | verified — same caveat |
| Boeing B-52H | `B52` | verified |
| Ilyushin Il-76 / Il-78 / Il-82 (Doc 8643 lists Il-78 and Il-82 under IL76) | `IL76` | verified (15 Sep 2026) |
| Beriev A-50 / A-50U Mainstay | `A50` | verified (15 Sep 2026) — feeds may also show `IL76` |
| Ilyushin Il-86 / Il-87 (the Il-80 Maxdome is the Il-87 airframe) | `IL86` | verified (15 Sep 2026) |
| Ilyushin Il-18 / Il-20 / Il-22 / Il-24 | `IL18` | verified (15 Sep 2026) |
| Tupolev Tu-95 / Tu-142 (Doc 8643 lists Tu-20, Tu-95, Tu-142) | `TU95` | verified (15 Sep 2026) — `T95` does NOT exist |
| Tupolev Tu-160 | `T160` | verified (15 Sep 2026) |
| Tupolev Tu-22M | `T22M` | verified (15 Sep 2026) |
| Mikoyan MiG-31 (incl. MiG-31K/I) | `MG31` | verified (15 Sep 2026) |
| Tupolev Tu-204 / Tu-214 (Tu-214R ISR shows as the civilian family) | `T204` | Doc 8643 family code — pair with `regs` |
| Airbus A400M | `A400` | verified |
| Airbus A330 MRTT | `A332` | Doc 8643 A330-200 |
| Boeing 737 (C-40, P-8 confusion note) | `B737`/`B738` | civilian designators; C-40 shows as `B737` |

Notes
- `/api/v2/mil` returns only aircraft the network flags as military (`dbFlags & 1`); the sector
  endpoint (`/api/v3/lat/…/lon/…/dist/…`) returns everything in range, so the worker only
  classifies sector aircraft that are military-flagged OR match a `regs`/`hex` entry — this keeps
  a `GLF5` matcher from lighting the board on a business jet.
- Most PLA, Russian and Iranian military types fly with ADS-B off; the workable live signal is
  the allied ISR fleet collecting against the subject (a mirror indicator) plus the rare
  transponding type (transports, VIP, some maritime patrol). Absence is uninformative (`F6`).
- Feed fields used: `hex`, `t` (type), `r` (reg), `flight`, `alt_baro` (`"ground"` or feet),
  `alt_geom`, `gs`, `lat`, `lon`, `dbFlags`, `seen`.
- adsb.fi open data is for personal, non-commercial use; cite the project. Public endpoints are
  rate-limited to 1 request/second — the worker polls minutes apart.
