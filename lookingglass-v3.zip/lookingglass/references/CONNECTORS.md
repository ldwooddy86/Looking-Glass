# CONNECTORS.md — the collector's lanes, credentials, rails and the agent workflow

The collector (`collector/`) is the part of LOOKING GLASS that runs on the operator's machine,
through the operator's own accounts, and only reads. This file is the contract between the
dashboard's `collector.sources` plan, the collector's `config.toml`, and the analyst who has to
say honestly what each lane can and cannot see.

## Lanes

| kind | connector | account model | what it reads | limits and honesty notes |
|---|---|---|---|---|
| `telegram` | `telegram_user.py` (Telethon, MTProto) | the operator's own Telegram account (`api_id` + `api_hash` from my.telegram.org; `login telegram` once per machine) | public channels and any private channel/group the account is already in; media downloads | the account must already have access — the collector never joins, never DMs, never scrapes another person's session. Roskomnadzor throttling and channel privatisation (Fighterbomber) make the own-session lane the mitigation for dead `t.me/s` previews |
| `telegram-bot` | `telegram_bot.py` (Bot API) | a BotFather token | only chats the bot has been added to | good for groups the operator administers; useless for channels it is not in |
| `discord` | `discord_bot.py` (REST-only) | a bot the operator creates and a server admin invites (View Channels + Read Message History) | channel history on those servers | self-bots violate Discord's terms and are not supported; ids are numeric snowflakes; never paste a token or invite into data.js |
| `bluesky` | `social.py` (AT Protocol) | none for author feeds; a read-scoped app password (`handle:xxxx-xxxx-xxxx-xxxx`) for `searches` | author feeds; keyword search | confirm each handle exists (custom domains work: `bellingcat.com`); search 403s without a session |
| `mastodon` | `social.py` | none (public API) | account timelines | instance rate limits |
| `reddit` | `social.py` | none for public JSON; a script-app id/secret for OAuth | subreddit new/top | public JSON is blocked from cloud/VPN IPs — use OAuth or run from home |
| `youtube` | `social.py` (Data API v3) | an API key | channel uploads (metadata; optional yt-dlp download) | 10,000 units/day quota |
| `rss` / `web` | `social.py` | none | RSS/Atom feeds (https only) | verify each feed with a fetch — many sites have none (the Barents Observer) or 403 bots (ISW, the Bulletin) |
| `x` | `social.py` (v2, disabled) | a bearer token on a paid tier | user timelines / search | built, off by default; the free tier cannot read |
| `adsb` | `technical.py` | none (adsb.fi open data, 1 req/s, personal non-commercial) | military-flagged aircraft by type designator; fixed public sectors | bombers never transpond — absence is uninformative; positions are coarsened to 0.1° |
| `navwarn` | `technical.py` (NGA MSI) | none | active broadcast warnings for HYDROPAC (`P`), HYDROLANT (`A`), HYDROARC (`C`), NAVAREA XII (`12`) and IV (`4`), filtered by keyword | Russian- and Chinese-coordinated areas are not served directly; the Kura/Barents boxes surface as HYDROPAC/HYDROARC repeats |
| `notam` | `technical.py` (FAA NOTAM API) | free registration (client id/secret) | NOTAMs by ICAO location | international coverage is what the FAA receives — absence is uninformative |

## Rails (enforced in code, restated for the analyst)

- **Reads only.** No posting, reacting, joining, following, DMs, scraping behind another person's
  login. The Telegram user session reads what the account can already read.
- **Loopback only.** The API binds to 127.0.0.1; a shared token (`x-lg-token`) is required; the
  extension asks Chrome for the loopback origin as an *optional* host permission when the operator
  clicks Connect, and never returns the token to the page.
- **Local only.** SQLite store, media, thumbnails and the session file live under `data_dir`. The
  only outbound writes are sanitised text (and thumbnails, when vision is on) to the Anthropic API
  for triage — with the operator's own key, only if configured.
- **No positions, no targeting.** The triage agent records claims as claims, graded, labelled
  unverified; it never asserts where a launcher, aircraft, boat or warhead is and never produces
  targeting detail. The dashboard renders collector text as TEXT ONLY.
- **Media hygiene.** Images are re-encoded with metadata dropped, perceptual-hashed for recycled
  footage, size-capped; video gets three ffmpeg frames and a duration; nothing is re-hosted.
- **No secrets in data.js.** The validator ERRORS on anything that looks like a bot token, api_hash,
  phone number, API key or bearer token in shipped content. Credentials live in `config.toml`.

## The agent workflow (triage → vision → digest)

```
collect (every interval_minutes)
  └─ keyword pre-triage (watchlists/<subject>.json — aircraft, launchers, bases, units, exercises, kinds, legs; Cyrillic stems)
       └─ Claude triage (JSON only): relevance 0–1, leg (air/land/sea), kind (sortie/launch/exercise/deployment/imagery/rhetoric/notam/navwarn/adsb), entities, Admiralty grade, one-line summary, claims[] {claim, place_claimed, corroboration}
            └─ vision on media (optional): what the machine sees, suggested types, claimed place from the post, consistency check, near-duplicate count
                 └─ digest (last window): leads worth corroborating, corroboration status, what is NOT seen, bottom line — all labelled UNVERIFIED
```

The agent's system prompt carries the rails verbatim ("never assert positions", "claims are claims",
"note information-operations risk where a claim serves a lane's known bias"). Its output is a
machine suggestion the analyst reads in the Feed / Media / Digest views; nothing it writes reaches
the sourced boards without a human and a source.

## Setup checklist (operator)

1. `python -m venv .venv && pip install -r requirements.txt` (Python 3.11+; ffmpeg optional).
2. `python -m lg_collector init --from-data ../assets/extension/data.js` → `config.toml` + a
   watchlist seeded from the dashboard's scanner dictionaries; copy the printed token into the
   extension (Settings → Local collector → Connect & test).
3. Fill credentials in `config.toml`; `python -m lg_collector login telegram` once.
4. `python -m lg_collector test` — every enabled connector once; read the errors.
5. `python -m lg_collector run` — collect, triage, serve (leave it running under a user session).
6. `python -m lg_collector export --out exports/` — `feed.json`, `media.json`, `digest.md/html` for
   a Cowork session or offline reading.

Tests: `python collector/tests/test_offline.py` (store, media pipeline, keyword triage on Russian
text, API server token/CORS, export sanitisation, config rails) — no network, no accounts.

## What "working connectors" means here

The Claude connector registry has no Telegram or Discord connector, so LOOKING GLASS ships its own:
the collector's Telegram (user session + bot), Discord (bot), Bluesky, Mastodon, Reddit, YouTube,
RSS, ADS-B, NAVWARN and NOTAM lanes, its loopback API for the extension, and its static exports for
a Cowork session. All of them work with the operator's own accounts and read only.
