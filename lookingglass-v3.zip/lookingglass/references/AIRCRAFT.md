# AIRCRAFT.md — nuclear strike & support aircraft catalogue (Air Watch)

What the Air Watch tab tracks, per subject, and what each type looks like in open sources. Use it
to fill `airWatch.fleet[]`, the live board's `types`/`match`, the collector watchlist and the air
theatre's classes. Counts are the analyst's job each build — this file is about *signatures*.
Nothing here is a position; ADS-B designators are for public broadcasts only.

## Roles (the `role` enum)

| role | what it is | why the nuclear watch cares |
|---|---|---|
| `strike` | heavy bombers carrying nuclear ALCMs / gravity weapons | the visible leg: sorties, basing, dispersal, attrition |
| `dual-capable` | fighters/fighter-bombers and theatre bombers with a nuclear option | nonstrategic employment instrument; forward deployment is the tell |
| `tanker` | aerial refuelling | enables dispersal and long sorties; often the first fleet to move |
| `c2` | airborne command posts (NC3) | continuous airborne alert = the highest-value air-leg indicator |
| `relay` | airborne relay / radio-relay / jammer | links command posts to dispersed forces |
| `aew` | airborne early warning & control | supports strategic patrols and homeland air defence |
| `isr` | strategic reconnaissance and maritime patrol | bastion defence (MPA) and pattern-of-life |
| `support` / `transport` | special-mission transports (warhead movement is a 12th-GUMO-class role) | custody proxies, always unseen |

## Russia (flagship) — types, signatures, designators

| type | role | signature in open sources | ICAO (verified 15 Sep 2026) |
|---|---|---|---|
| Tu-95MS / MSM Bear-H | strike | take-off calls by Ukrainian monitors (minutes); satellite counts at Ukrainka (31–40 in 2025–26) and Engels-2; loss imagery (Engels 16 Jul 2026); joint patrols with H-6 (JASDF releases); Alaskan ADIZ intercepts (NORAD) | `TU95` — never transponds |
| Tu-160 / Tu-160M Blackjack | strike | Ukrainka / Engels / Anadyr / Yelizovo counts; Kazan deliveries (bmpd); Victory Day flypasts | `T160` — never |
| Tu-22M3 / M3M Backfire | dual-capable | Black Sea Kh-22 launch alerts; Belaya / Olenya / Shaykovka / Soltsy imagery; crash and strike reporting | `T22M` — never |
| MiG-31K / I (Kinzhal) | dual-capable | nationwide Ukrainian alert on every take-off; Savasleyka imagery; production/inventory claims (HUR) | `MG31` — never |
| Su-34 / Su-24M / Su-57 | dual-capable | frontal-aviation reporting; no nuclear-specific signature | — |
| Il-78 / Il-78M Midas | tanker | Dyagilevo home; detachments at Ukrainka/Engels in counts; occasional Mode-S | `IL76` (shared with Il-76 transports — pair with `regs`) |
| Il-80 / Il-82 Maxdome | c2 | Chkalovsky; parade rehearsals and strategic exercises; Taganrog maintenance | `IL86` (Il-80) / `IL76` (Il-82) — rarely |
| Il-22M / Il-22PP | relay | Chkalovsky; forward near Azov (2024 loss) | `IL18` — rarely |
| A-50 / A-50U Mainstay | aew | Ivanovo-Severny; escorts strategic patrols; losses 2024–25; new airframe 31 May 2026 | `A50` (also `IL76`) — rarely |
| Tu-142 / Il-38N | isr (MPA) | Kipelovo, Yelizovo, Severomorsk; joint patrols; NATO intercepts over the Norwegian Sea | `TU95` (Tu-142) — never |
| Tu-214R / Il-20M | isr | Kazan / Chkalovsky; occasional ADS-B on ferry flights | `T204` (civil family — pair with `regs`) / `IL18` |
| PAK DA | strike (building) | static-test prototype (2026); no fleet | — |

### Bases that matter (Russia)

Ukrainka (main, post-Spiderweb) · Engels-2 (staging; attrition Jul/Aug 2026) · Belaya · Olenya ·
Shaykovka · Soltsy · Dyagilevo (tankers, training) · Chkalovsky (NC3) · Ivanovo-Severny (AEW) ·
Savasleyka (Kinzhal) · Anadyr–Ugolny, Vorkuta, Tiksi (Arctic dispersal) · Yelizovo (Tu-160
dispersal, MPA) · Mozdok (southern forward field) · Kipelovo (MPA).

### The air-leg signal, in order of arrival

1. NOTAM / NAVAREA closure box (days before a test or exercise volley).
2. MoD / Kremlin announcement (hours) — exercise, patrol, launch video.
3. Monitoring-channel take-off call (minutes) — base named.
4. Allied intercept release (hours) — NORAD, Japan Joint Staff, Nordic QRA.
5. Imagery count / loss confirmation (days) — AviVector-class spotters, Planet via press.
6. Enabler movements (Il-78 detachments, A-50U orbits) — the posture tell when they do not track a strike cycle.

What never arrives: weapons loaded, crews on alert, an Il-80 on airborne alert. Mark those UNSEEN.

## Other subjects (starting points)

| subject | strike | dual-capable | enablers | designators to verify |
|---|---|---|---|---|
| United States | B-52H (`B52`), B-2A, B-21 | F-15E, F-16, F-35A (B61-12) | KC-135 (`K35R`), KC-46 (`B762`), E-6B (`E6`), E-4B (`B742`), RC-135 (`R135`) | US enablers transpond routinely — the live board is rich |
| China | H-6K/N (JL-1 ALBM) | J-16, JH-7 (no confirmed nuclear role) | Y-20U tanker, KJ-500 AEW, Y-9 variants | most fly dark; `Y20`, `KJ500` variants unverified — check doc8643 |
| France | Rafale (ASMP-A) — FAS | — | A330 MRTT (`A332`), E-3F (`E3CF`) | MRTTs transpond |
| United Kingdom | — (sea leg only) | — | Voyager (`A332`), RC-135W (`R135`), P-8A (`P8`) | mirror fleet only |
| India | Mirage 2000, Jaguar, Rafale (reported) | — | Il-78 (`IL76`), Netra AEW (`E145`) | — |
| Pakistan | Mirage III/V, JF-17 (Ra'ad ALCM) | — | Il-78 (`IL76`), Saab 2000 Erieye (`SB20`) | — |
| Israel | F-15I, F-16I, F-35I (undeclared) | — | KC-707/KC-46, G550 CAEW (`GLF5`) | never assert the capability |
| North Korea | none credible (Il-28/H-5) | — | — | — |

Verify every designator at `https://doc8643.com/aircraft/<CODE>` before it goes in a matcher; a
wrong code silently matches nothing (see `ADSB-TYPES.md`).
