# Analytic tradecraft — the standards the product is held to

LOOKING GLASS (the DalesOracle engine) is an **open-source strategic-warning product**. It borrows the discipline of the
US Intelligence Community's analytic standards (ICD 203), the NATO Admiralty source-grading
system, Heuer's Analysis of Competing Hypotheses, and classic Indications & Warning practice —
and it applies them to public reporting only. This file is the reference for every judgment,
grade and meter in `data.js`. Read it before writing content; the validator enforces the
mechanical parts, the rest is on the analyst.

## 1. ICD-203 — estimative language and confidence

**Probability and confidence are different statements.** Probability is how likely the
judgment is to be true; confidence is how good the evidence behind it is. State both, separately,
on every Key Judgment.

| term | band |
|---|---|
| almost no chance / remote | 01–05 % |
| very unlikely / highly improbable | 05–20 % |
| unlikely / improbable | 20–45 % |
| roughly even chance | 45–55 % |
| likely / probable | 55–80 % |
| very likely / highly probable | 80–95 % |
| almost certain(ly) | 95–99 % |

Do not mix terms from different rows in one judgment ("likely, roughly even"), and do not use
"possible" as an estimate (it is not one). A judgment that is a *description* ("the purge is the
most ambiguous variable") is labelled `Assessment`, not given a band.

**Confidence** (`High | Moderate | Low`) reflects source reliability, corroboration across
independent collection, the size of the relevant gaps, and the fragility of the reasoning chain.
Rules of thumb the validator partly enforces:
- Single-source or state-media-only reporting → at most `Moderate`, usually `Low`.
- Evidence graded D/E/F or credibility 4–6 cannot carry `High` confidence.
- A matrix domain whose coverage is mostly `gap` cannot carry `High` confidence.
- "Likely" on thin evidence is `likely / Low confidence` — say so in the text.

Each KJ should also say **what would change it** (`whatWouldChange`): the observation that
would move the probability or the confidence. That sentence is what turns a judgment into a
monitor.

## 2. NATO Admiralty (source reliability × information credibility)

| reliability of the source | credibility of the report |
|---|---|
| A completely reliable | 1 confirmed by other sources |
| B usually reliable | 2 probably true |
| C fairly reliable | 3 possibly true |
| D not usually reliable | 4 doubtful |
| E unreliable | 5 improbable |
| F cannot be judged | 6 cannot be judged |

Grade the **source**, then the **report**, independently. A state outlet can be `B` for
fact-of-statement (it reliably reports what the state said) and `4` for truth-about-the-world.
Absence on a technical feed (ADS-B/AIS silence) is `F6` — it cannot be judged — never `A1`
evidence that nothing happened. Put the grade where the claim is (KJ, matrix row, I&W row, ACH
row, reliability annex) so the reader can see how load-bearing each piece is.

## 3. Analysis of Competing Hypotheses (Heuer)

1. Write 3–4 **mutually exclusive-enough** hypotheses that together cover the plausible space,
   including the one you find least comfortable.
2. List 6–10 pieces of evidence, each graded (Admiralty) and flagged `diag:true` when it
   discriminates between hypotheses. Include **absences** ("no requisition of civilian shipping
   observed") — they are often the most diagnostic evidence available.
3. Score every cell `C / I / N`. Score honestly against each hypothesis, not for your favourite.
4. **Rank by least weighted disconfirmation**, not most confirmation. The engine weights each
   inconsistency by the row's reliability (A 1.0 … E 0.2) and doubles diagnostic rows, so a
   contradiction from a reliable, discriminating source sinks a hypothesis harder than one from a
   weak, non-diagnostic source. A board with **no `I` cells is an argument, not an analysis.**
5. Write the conclusion as a *blend and a residual*: which hypotheses survive, which is
   contradicted and by what, and which collection gap decides between the survivors.

## 4. Indications & Warning

An indicator is worth a row only if it is **observable in open sources, diagnostic of the
question, timely enough to matter, and unambiguous enough to threshold**. For each: name the
observable, the threshold that trips it, the current read, its consequence weight (`crit` 1–5),
your confidence in the observation, and the grade of what you saw.

Mark the near-invisible indicators (`warhead custody`, `munitions marshalling`, `mobilisation
orders`) as `observed: "unseen"`, not `normal`. The board then reports two numbers: the
**warning meter** over what can be seen, and the **blind fraction** — the crit-weighted share of
the board that cannot be seen at all. *Quiet = unseen, not absent* is a number, not a caveat.

## 5. Key Assumptions Check and collection gaps

List the assumptions the whole estimate rests on and, for each, the risk that it is wrong and
what the product would look like if it were. Rank collection gaps **by consequence** (what a
wrong answer costs), name a mitigation for each, and make sure the highest-consequence gaps
appear in the BLUF's confidence statement.

## 6. Red-team before you build (mandatory)

- State the single strongest piece of evidence **against** the headline judgment. If you cannot,
  you have not looked.
- Confirm the ACH carries genuine disconfirming evidence for the leading hypothesis.
- Check each KJ's confidence against its sourcing (§1 rules).
- Reconcile numbers across sections: the posture headline, the forces totals, the matrix findings
  and the events must agree with each other and with their source editions. Internal
  contradictions are the signature of stale copy-paste.
- Re-derive every currency conversion at a stated rate; show two estimates where sources diverge.
- Ask what a competent adversary analyst would say the product missed; write it into the gaps.

## 7. Honesty rails (features, not caveats)

- **Estimates carry uncertainty** — show the spread, never single-unit precision.
- **Quiet = unseen, not absent** — blind fraction on the I&W board; `F6` on feed silence.
- **Correlation, not intent** — Track Watch and the scanner see tempo and vocabulary, never
  decisions.
- **Feeds are unverified** — every live lane is walled off from the sourced baseline and labelled.
- **Public reporting only** — the product's value is currency and synthesis, not secrets.

## 8. The protective-intelligence layer — defensive framing only

The four protective tabs (Terror Threat, Soft Targets, Critical Infrastructure & Data Centers,
Threat Geography) are written in the idiom of national protective-security authorities (CISA,
the UK's NPSA, ANZCTC): **threat levels, target classes, sector exposure, protective posture and
where advisories apply.** They exist to help defenders prioritise, and to give a country monitor a
view of the non-military threats to that country's people, sites and systems.

Allowed: threat-level judgments with basis; actor intent × capability boards; attack-warning
indicators at the level of "increased hostile reconnaissance reporting"; incident timelines from
public reporting; target **classes** with precedent counts and the protective measures that
mitigate them; sector exposure/resilience with recent public incidents; regional advisory levels.

Never: named facilities as targets; coordinates or addresses; vulnerabilities, access routes,
guard patterns or "weak points"; methods, materials, devices or timing; a map of targets; anything
whose purpose is to help an attacker rather than a defender. Write every measure as something a
defender does. The validator scans the block for this vocabulary and refuses to build on a hit —
that is a rail, not a bug to route around.


## 9. The air and land legs — what open sources can and cannot see (v3)

The Sub Watch rules (§7) carry over to Air Watch and Launcher Watch with two adjustments.

**Air leg.** The air leg is the *observed* leg — bombers at war are announced by the adversary's
monitors within minutes and counted from orbit weekly — so the tradecraft problem is separating a
nuclear-posture signal from conventional routine. Write the fleet board as *airframes with
uncertainty* (two counts where lanes disagree: FAS launcher counts vs. imagery vs. single-side loss
claims); write basing as *what OSINT sees there*; write the I&W board so that the nuclear-only
indicators (weapons generated, airborne command post alert) are marked UNSEEN by construction,
because conventional loading at a staging base is indistinguishable from nuclear generation in
imagery. The live board is a courtesy: the subject's strike aircraft never transpond, the enablers
rarely do, and the allied fleet watching them (Track Watch) is the mirror. Never write targeting,
strike-planning or force-defeat vocabulary — the validator refuses it.

**Mobile land leg.** The mobile leg is the *announced* leg — the subject publishes patrol drills
because they are deterrence messaging — and the tradecraft problem is reading the announcement
layer (Tier 1) without pretending it reveals the field layer (Tier 3). Garrisons are towns and
regions, never field positions; dispersal is doctrine (patrol radius, positional districts,
cadence), never a route; the heatmap is a structural prior conditional on deployment. Coordinate
pairs, present-tense location claims and named field positions are validator ERRORS unless the
sentence denies them.

**Belarus-style forward deployments.** A partner-territory deployment is written as *construction,
statements and exercises* (the observables) plus *custody unproven* (the gap). "No warhead has been
observed" is a finding; "warheads are present" is a claim until two independent lanes show custody
signatures.

**Single-side war reporting.** Loss claims, production-halt claims and "operational" counts from a
belligerent's intelligence service are B2 when later confirmed by imagery and C3 until then; carry
them, label them, never let one move a board above `elevated` alone.

**The collector's items.** Everything the local collector carries is unverified OSINT and its
triage text is a machine suggestion; the Feed/Media tabs are walled off from the sourced baseline
exactly as the Telegram previews are. A collector item can open a lead; only the sourced boards
carry a grade.
