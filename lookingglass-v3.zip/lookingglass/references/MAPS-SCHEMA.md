# LOOKING GLASS theatre config — the contract (sea · land · air)

One JSON file per theatre in `data/theatres/<id>.json`. It is the **only** country-specific file: the
engine, the styling and the scripts are shared. `scripts/maps_validate_config.js` enforces everything
below; run it with `--strict` before you build. The sea contract is Countdown's, unchanged; the
**land** and **air** domains (v3) add the keys marked `land`/`air` below and alias a few sea names
(`deployed` ≡ `at_sea`, `terrain_suitability` ≡ `depth_suitability`, `inventory` ≡ `hulls`).

Contents: [meta](#meta) · [grid](#grid) · [postures](#postures) · [scenarios](#scenarios) ·
[bases](#bases) · [classes](#classes) · [depth_suitability](#depth_suitability) ·
[factors](#factors) · [polygons / lines / points / point_sets / circles](#geometry-containers) ·
[regions](#regions) · [labels](#labels) · [routing](#routing) · [ui](#ui) · [text](#text) ·
[triad](#triad)

---

## meta

```json
{ "id": "russia-north", "country": "Russia", "adjective": "Russian",
  "navy": "Russian Navy — Northern Fleet", "brand": "LOOKING GLASS",
  "line": "Sea-leg operating-area likelihood · Northern Fleet",
  "title": "Northern Fleet Submarine Operating-Area Likelihood",
  "theatre": "Barents · Kara · White Sea · Norwegian Sea · GIUK",
  "compiled": "10 SEP 2026", "edition": "Edition 2026.09c",
  "posture_default": "elevated", "handling": "UNCLASSIFIED // OPEN SOURCE // …",
  "description": "one line for the artifact card",
  "pills": [{ "text": "…", "tone": "amber|red|" }] }
```

`id` is the filename stem and the output name. `posture_default` must appear in
`postures.levels`. `pills` render in the command bar; use the red one for the honesty caveat that
matters most in this theatre (`Boats-at-sea: UNSEEN`, `Patrol areas: CLASSIFIED — prior only`).

## grid

```json
{ "lon0": -35, "lon1": 75, "lat0": 56, "lat1": 84, "step": 0.25,
  "projection": { "type": "lcc", "lon0": 25, "lat1": 62, "lat2": 79, "lat0": 71 },
  "graticule": 5,
  "home_view": [lon0, lat0, lon1, lat1],
  "focus_view": [lon0, lat0, lon1, lat1], "focus_label": "Barents bastion",
  "force_open": [[lon, lat, lon, lat], …] }
```

- `step` 0.05–0.5. Keep the cell count under ~130,000 or the browser build gets slow.
- `projection.type` is `mercator` or `lcc` (Lambert conformal conic). See `GEODATA.md`.
- `force_open` segments are drawn as open water into the raster **after** rasterising: one per
  strait, canal, harbour entrance or channel the routing needs. Cell-centre sampling closes
  anything narrower than a cell; every base must reach open water.
- `home_view` is the opening frame; `focus_view` is the ◎ button.

**Domain (v3).** `grid.domain` is `sea` (default), `land` or `air`; it drives the rasteriser, the
vocabulary, the layer menu and the dashboard's leg check (`triadMaps.theatres[].leg` must match).

- `land`: raster classes `0` road corridor open · `1` road corridor under cover · `2` open off-road ·
  `3` covered off-road · `4` urban · `255` impassable (water). Keys: `confine_iso` (ISO-3 list — cells
  outside these countries are impassable), `road_buffer_km` (corridor half-width around Natural Earth
  roads, default 8), `cover_polygons` (names in `polygons` that define forest/cover) or
  `cover_geojson` (a file in `LG_GEODATA`), `force_block` segments (optional).
- `air`: raster classes `0` own · `1` allied · `2` neutral/international · `3` adversary airspace.
  Keys: `own_iso`, `allied_iso`, `adversary_iso` (ISO-3 lists; everything else is neutral). Nothing
  is impassable; adversary airspace is made a near-exclusion by `terrain_suitability`.
- `sea`: unchanged (bathymetry classes, `force_open`).

## postures

```json
{ "levels": ["guarded", "elevated", "high", "severe"],
  "labels": { "guarded": "Guarded", … },
  "modifiers": { "elevated": { "ssn_forward": 1.0, "ssbn_concentration": 1.0 }, … } }
```

Modifier keys are free-form; factors reference them by name via `{ "mod": "ssn_forward" }`.
Every level needs the same keys.

## scenarios

```json
{ "type096": { "label": "Type 096 scenario", "note": "what it changes and why it is off by default" } }
```

Rendered as checkboxes. Factors switch on them via `{ "default": x, "scenario": "type096", "value": y }`.
Use a scenario for a *contingent* change of shape (a new class, a surge, a season), never to
smuggle in a claim the evidence does not support.

## bases

```json
{ "gadzhiyevo": { "name": "Gadzhiyevo (Yagelnaya Bay)", "short": "Gadzhiyevo",
    "lon": 33.33, "lat": 69.25, "ref": "CD-RU-B1", "role": "what is based here",
    "kind": "port|yard", "label_side": "left|right", "label_dy": -8 } }
```

`kind: "yard"` draws a diamond and is for builders and repair yards. Only bases that appear in a
class's `sources` (or a `maintenance_transit`) must resolve to a sea cell — decorative yards can
sit inland. `label_side` / `label_dy` are the collision controls; use them.

## classes

```json
{ "ssbn": {
    "label": "SSBN · Delta IV · Borei / Borei-A", "short": "SSBN",
    "refs": ["CD-RU-01"], "hulls": 8, "colour": "#C97F1E",
    "at_sea": { "guarded": 1.0, "elevated": 1.5, "high": 3.0, "severe": 5.0 },
    "speed_kts": 10, "decay_nm": 430, "patrol_days": 60, "shallow_cost": 1.1,
    "sources": { "gadzhiyevo": 1.0 },
    "source_decay": { "severodvinsk": 420 },
    "maintenance_transit": { "from": "gadzhiyevo", "to": "severodvinsk",
                             "weight": 0.04, "blur_nm": 30, "plain_routing": true,
                             "factor": "revealed" },
    "judgment": { "title": "…", "confidence": "Confidence MODERATE", "text": "… {a50k}k nm² …" } } }
```

- `sources` shares must sum to 1. `source_decay` overrides `decay_nm` per port (use it for
  trials out of a yard).
- `shallow_cost` > 1 makes shelf water (<200 m) costlier in the routing, so nuclear boats prefer
  deep transits. 1.0 for conventional boats.
- `maintenance_transit` adds a small route component from `from` to `to` (`plain_routing: true`
  ignores `shallow_cost` — use it when the observed route is through shallow water, as with the
  Taiwan Strait or La Pérouse). `factor` names the toggle that switches it off with its evidence.
- `colour` must be `#rrggbb` and validated against the dark surface — the three series colours
  `#C97F1E` / `#7466E0` / `#3C9B72` pass the CVD and contrast checks; do not invent new ones
  without re-validating.
- `judgment.text` placeholders: `{a50k} {a80k} {a95k} {top1} {top1pct} {top2} {top2pct} {n}
  {hulls} {on_pct} {box}`. Anything else fails validation.

**Land / air additions (v3).**

```json
{ "yars": {
    "label": "RS-24 Yars & Topol-M road-mobile ICBM regiments", "short": "Yars/Topol-M",
    "refs": ["LG-RU-L1"], "hulls": 198, "colour": "#C97F1E",
    "deployed": { "guarded": 20, "elevated": 36, "high": 80, "severe": 150 },
    "speed_kts": 18, "decay_nm": 38, "patrol_days": 30,
    "cell_cost": [1, 1, 4, 5, 2.5, 3, 3, 3],
    "sources": { "teykovo": 0.18, "…": 0 },
    "sources_scenarios": { "exercise_surge": { "teykovo": 0.2, "…": 0 } },
    "judgment": { … } } }
```

- `deployed` (alias `at_sea`) is the count in the field / airborne per posture — a posture
  assumption, never an observation; it may be fractional and must not exceed `hulls`.
- `cell_cost[8]` replaces `shallow_cost`: the routing cost multiplier per raster class (land: road
  corridors cheap, off-road and urban expensive; air: own/allied cheap, adversary near-blocked).
- `sources_scenarios{scenario:{base:share}}` swaps the whole source-share table while a scenario is
  checked (bomber dispersal to Arctic fields; an exercise moving regiments) — shares must sum to 1.
- Every scenario declared in `scenarios` must be referenced by some `sources_scenarios`, combined
  parameter or factor, or the validator ERRORS (a dead checkbox is a lie).
- Combined parameter form `{ "mod": "dispersal_reach", "base": 0, "gain": 60, "scenario": "exercise_surge", "value": 110 }`
  = posture-scaled value, overridden by `value` while the scenario is on.
- `kind` on bases: `port` `yard` (sea) · `garrison` `depot` `site` (land) · `airbase` (air).

## depth_suitability / terrain_suitability

One array of **eight** multipliers per class, indexed by raster class (sea: bathymetry; land: the
five land classes above, indices 5–7 unused; air: the four airspace classes, 4–7 unused).
Sea classes:
`0:<200 m · 1:200–1000 · 2:1000–2000 · 3:2000–3000 · 4:3000–4000 · 5:4000–5000 · 6:5000–6000 · 7:>6000`.
Plus a `note` string explaining the theatre's own bathymetry (the Barents is shelf and Russian
SSBNs patrol it; the South China Sea's basin is 4,000 m and a Type 094 wants it).

## factors

An array. Each entry needs `id`, `type`, `label`, `note`, and either `refs` (country-brief IDs)
or `external: true`. Optional `classes: [...]` restricts it to some hull classes.

**Per-class parameter forms** — anywhere a factor takes `{cls: value}`:

| form | meaning |
|---|---|
| `1.4` | constant |
| `{ "mod": "ssn_forward", "base": 1, "gain": 0.5 }` | `base + gain × posture_modifier` |
| `{ "default": 0.12, "scenario": "type096", "value": 0.5 }` | switched by a scenario checkbox |

**Types:**

| type | shape | what it does |
|---|---|---|
| `depth` / `terrain` | — | applies `depth_suitability[cls]` / `terrain_suitability[cls]` (same code path) |
| `zones` | `zones: [{polygon, mult:{cls:param}}]` | multiplies inside each named polygon |
| `hubs` | `sets: [{set, scale_nm, amp:{cls:param}}]` | `1 + Σ amp·exp(−d/scale)` — an umbrella that *helps* |
| `points` | `points: [{point, radius_nm, amp:{cls:param}}]` | `Π (1 + amp·exp(−(d/r)²))`; negative `amp` repels |
| `line_exposure` | `inside_polygon, line, width_nm, near_penalty, beyond_mult, beyond_decay_nm` | inside/beyond a barrier line + a penalty for sitting *on* it |
| `pressure` | `set, scale_nm, k:{cls:param}, shield:{polygon,scale}` | `exp(−k·Σ w·exp(−d/scale))` — adversary ASW that *hurts*; `shield` cuts it inside a polygon (ice, sensor umbrella) |
| `proximity` | `set, radius_nm, amp` | one bump over a whole point set; negative `amp` = avoidance |
| `envelope` | `wall_nm:{cls:param}` | soft wall on routed distance from the unit's own base: `0.05 + 0.95/(1+exp((d−wall)/60))` — patrol radius (land), unrefuelled radius (air), sea distance (sea) |

Order does not matter — the factors multiply. Keep each one *one idea*, so unchecking it in the
Variables tab is legible.

## geometry containers

```json
"polygons": { "key": { "label": "…", "refs": [...], "pts": [[lon,lat], …],
                       "style": { "colour": "#C97F1E", "dash": "4 3", "width": 1.1,
                                  "fill": 0.05, "label": true, "show": false } } }
"lines":    { "key": { "label": "…", "label_short": "…", "refs": [...], "pts": [...],
                       "style": {...}, "label_at": [lon,lat],
                       "nodes": [{ "name": "…", "lon": …, "lat": …, "label_pos": [dx,dy,"start"] }] } }
"points":   { "key": { "label": "…", "label_short": "…", "label_pos": [dx,dy,"start|end|middle"],
                       "kind": "launch|detection|survey|visit|other", "refs": [...],
                       "lon": …, "lat": …, "radius_nm": 70, "note": "…" } }
"point_sets": { "key": { "label": "…", "refs": [...], "style": "hub|asw|choke|generic",
                       "outline": true, "label_at": [lon,lat],
                       "pts": [{ "name": "…", "lon": …, "lat": …, "w": 1.0,
                                 "label": [dx,dy,"start"] | false }] } }
"circles":  [ { "lon": …, "lat": …, "radius_nm": 180, "colour": "#FFB454", "dash": "2 5",
                "layer": "hubs|asw|events", "label": "…", "label_at": [lon,lat] } ]
```

`style.show: false` keeps a polygon in the model but off the map — use it for exclusion zones and
for the `inside_polygon` of a `line_exposure`. `point_sets[].pts[].w` weights a `pressure` field
(base capability, not a claim about sortie rates).

Point `kind` drives the marker: `launch` = red starburst with a radius circle, `detection` = red
diamond, `survey` = violet cross, `visit` = amber ring, `other` = grey dot; v3 adds `sighting`
(amber diamond — a *claimed* sighting, which the validator requires to be worded as a claim),
`exercise` (violet ring) and `closure` (dashed red circle — a NOTAM/NAVAREA box).

## regions

```json
[ { "id": "barents_central", "name": "Central Barents (Kildin – Bear Island water)",
    "pts": [[lon,lat], …] } ]
```

The mass table. **Cut them to comparable areas** — a region twice the size of its neighbour will
top the table on area alone, and the readout's judgment text quotes the top two by name. First
match wins where they overlap, so order matters. Cover the frame; whatever is left lands in
"Elsewhere in frame", and more than ~10 % there means the regions have a hole.

## labels

```json
{ "seas":   [{ "name": "Barents Sea", "lon": 38, "lat": 73.5 }],
  "places": [{ "name": "Novaya Zemlya", "lon": 56.5, "lat": 74.5 }] }
```

## routing

```json
{ "transit_blur_nm": 40, "ring_blur_nm": 26, "ring_width_nm": 10 }
```

Blurs stand in for evasive routing — real tracks are not shortest paths. Scale them to the
theatre: ~14 nm for a coastal box, ~45 nm for an ocean.

## ui

```json
{ "default_class": "ssbn",
  "time_steps": [6, 12, 24, 48, 72, 120, 168, 240, 336, null],
  "layers": { "zones": false } }
```

`null` in `time_steps` is the patrol average and should be last. `layers` sets the initial
checkbox state.

## text

All HTML strings, all rendered as-is: `banner`, `banner_bottom`, `h1_html`, `tagline`,
`lead_html`, `bluf_html`, `bluf_warn_html`, `structural_html`, `method_html`, `movers_html`,
`limits_html`, `sources_html`.

`bluf_warn_html` **must** contain one of *assum / not observable / unobservable / cannot be seen /
unseen* — the validator checks. The whole text block is scanned for position claims.

`structural_html` is where every non-toggleable input goes: basing shares, decay constants,
speeds, patrol lengths, at-sea counts, posture modifiers, scenarios. If a number shapes the map
and is not a factor, it belongs there.

## triad

```json
{ "summary_html": "…",
  "legs": [ { "leg": "Land|Air|Sea", "systems_html": "…", "warheads_html": "…",
              "posture_html": "…", "refs": ["CD-RU-15"] } ],
  "notes_html": "…" }
```

A `Sea` leg is required — the validator checks for it, and the sea row is highlighted because it
is the one the map models. Keep the land and air rows short: they are context, not the product.
For an undeclared arsenal, say in `notes_html` that every figure is an external estimate.
