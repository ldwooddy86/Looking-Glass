# Israel — COUNTDOWN country brief

Compiled 10 SEP 2026. Theatre: `israel-eastmed`.

> **Read this first.** Israel maintains a policy of *amimut* — opacity. It has never confirmed or
> denied a nuclear arsenal, never declared a doctrine, never acknowledged a delivery system, and
> publishes nothing about submarine operations except when it chooses to be seen. Everything in
> this brief that touches nuclear capability is **external estimate and reporting**, and the map
> is built so that it does not depend on any of it: COUNTDOWN models **where the flotilla
> operates**, and the reader may attach whatever weapon they believe is aboard.

---

## The flotilla

**CD-IL-01 · Dolphin I.** Three German-built diesel-electric boats: *Dolphin* (commissioned
27 July 1999), *Leviathan* (November 1999), *Tekumah* (October 2000). No AIP. To be replaced by
the Dakar class from 2027.

**CD-IL-02 · Dolphin II (AIP).** Three boats with air-independent propulsion: *Tanin*
(23 September 2014), *Rahav* (12 January 2016), and **INS *Drakon*, delivered by TKMS on
1 September 2026** — the third and final Dolphin II. Analysts note an **unusually large sail**
believed to accommodate vertical launch tubes; specifications are classified and unconfirmed by
Israel. Reported cost ≈US$634 m.
*Naval News (1 Sep 2026); Jerusalem Post; Ynet (2026).*

**Dakar class.** Three ordered from TKMS in 2022, construction began several years ago,
deliveries from 2027 — the next generation, replacing the Dolphin I boats.

**CD-IL-B1 · Haifa naval base** is the flotilla's only home port. **CD-IL-B2 · Eilat** is a Red
Sea port used for signalling calls, not a submarine base.

---

## Reported capability

**CD-IL-14 · The external estimate.** FAS and SIPRI put Israel's stockpile at roughly **90
warheads**, delivered by Jericho II/III ballistic missiles at Sdot Micha, gravity bombs on F-15I
and F-16I aircraft, and — the sea leg — the **Popeye Turbo** submarine-launched cruise missile,
reported range **≥1,500 km**, reported yield 200 kt, fired from the boats' 650 mm tubes. The
sourcing is old and thin: a June 2002 claim by former US State Department and Pentagon officials
of Israeli missile tests in the Indian Ocean in 2000; an assertion by the German defence official
Hans Rühle; NTI's summary noting expert disagreement about how the missile would be adapted.
Grade it C3 and say so.

The `israel-eastmed` map draws a **≈1,500 km circle from the Levantine basin** as an illustrative
reach, explicitly labelled as reported. That circle is the strategic point of the theatre: if the
reporting is right, a Dolphin II never has to leave the eastern Mediterranean to hold Iranian
targets at risk.

---

## Where the boats have been seen

**CD-IL-08 · Publicised transits.**
- **June 2009** — a Dolphin docked at **Eilat**, read at the time as a message to Tehran.
- **December 2020** — an IDF submarine **transited the Suez Canal** into the Red Sea toward the
  Persian Gulf, publicised after the Fakhrizadeh assassination. This is the pattern the theatre's
  Iran-deployment scenario reproduces.
- **CD-IL-10 · July 2026** — a Dolphin reportedly seen leaving Eilat toward the **Straits of
  Tiran** and the Red Sea. **Single commentary source**; carried on the map as a lead at low
  weight, labelled as such.

**CD-IL-09 · Attributed operations.** A July 2013 submarine-launched cruise-missile strike on the
Syrian port of Latakia was attributed in press reporting and never confirmed. Intelligence
collection, special operations and land attack along the Lebanese, Syrian and Egyptian coasts are
tasks Israel has not denied.

**CD-IL-11 · Berbera.** German outlet *Defence-Network*, citing Israeli correspondent Arie Egozi,
reported in June 2026 that Israel was **exploring** naval access at Berbera, Somaliland, for
Dolphin-class boats — near Bab el-Mandeb, removing the Suez round-trip. Israel recognised
Somaliland on 26 December 2025; President Cirro visited Israel in June 2026; **Somaliland's
defence minister denied any military base on 17 June 2026**, confirming only training
cooperation. Reported and denied: described on the map, weighted at zero.

---

## The environment

**CD-IL-07 · The Levantine basin.** 1,500–2,000 m deep within 40 nm of Haifa, inside Israeli air
and naval cover — the flotilla's normal water.

**CD-IL-12 · Israeli cover.** Haifa, Ashdod, Palmachim (Sa'ar 6, Heron TP), Ramat David, Nevatim.

**CD-IL-13 · Adversary and third-party presence.** Russian ASW aviation and ships at Hmeimim and
Tartus on the Syrian coast; Iranian Kilo and Ghadir boats and shore-based anti-ship missiles at
Bandar Abbas, Bandar-e Jask and Chabahar; the Houthi-controlled Yemeni coast at Bab el-Mandeb,
which since 2023 has made the southern Red Sea a contested transit; Egyptian and Turkish navies
in the Mediterranean.

**Chokepoints** that define the theatre: the Suez Canal (Egyptian sovereignty, surfaced transit),
the Gulf of Suez, the Straits of Tiran, Bab el-Mandeb, the Strait of Hormuz. The Persian Gulf
inside Hormuz is excluded — too shallow, too confined, and unnecessary if the reported missile
range is right.

---

## Triad context

Undeclared, and every figure external. **Land:** Jericho II (~1,500–3,500 km) and Jericho III
(4,800–6,500 km) at Sdot Micha, estimated; a Jericho IV reported in development. **Air:** F-15I
Ra'am and F-16I Sufa with gravity bombs, estimated; the oldest leg. **Sea:** the Dolphin boats
with Popeye Turbo, per external reporting; the survivable leg, and the reason the flotilla is
treated as strategic at all.
