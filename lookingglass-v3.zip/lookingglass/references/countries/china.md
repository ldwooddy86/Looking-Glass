# China — COUNTDOWN country brief

Compiled 08 SEP 2026. Theatre: `china-scs`.

This theatre is the one case where the config cites a **live dashboard** rather than this brief:
the reference IDs (`SB-`, `BS-`, `SO-`, `SW-`, `UE-`, `SD-`, `CV-`, `I-`, `KJ-`, `CM-`) are rows
in the DalesOracle v2.1 *PLA Military Posture Monitor*, edition 2026.09b, Sub Watch tab. This
file is the standalone equivalent for anyone rebuilding without that dashboard.

---

## Sea leg — order of battle

**SB-01 · Type 094 / 094A Jin, SSBN.** Six in service (2 × 094 + 4 × 094A), all at Longpo
(Yulin), Hainan; two further 094A hulls built and expected to commission. 12 tubes. JL-2
(7,200 km — cannot reach CONUS from Chinese waters) giving way to JL-3 (~10,000 km). Assessed
"two orders of magnitude louder" than US and Russian SSBNs, improved on the 094A. "Probably"
near-continuous at-sea deterrence since 2024; peacetime arming unconfirmed.
*FAS/Bulletin Nuclear Notebook (Jul 2026); Naval News (Jan, Jul 2026).*

**SB-02 · Type 096.** Not launched. DoD says construction "soon"; IISS expects production at
Bohai this decade. CMSI expects quieting near an Improved Akula — enough to change how far from
the bastion the sea leg could operate. This is the theatre's scenario switch.

**SB-03 / SB-04 / SB-05 · Attack boats.** Six Type 093/093A SSN (Jianggezhuang, Longpo); seven to
nine Type 093B SSGN launched since 2022 with two or three commissioned (VLS, CJ-10 land attack,
pump-jet); the first Type 095/09V in Huludao's launch bay since February 2026.

**SB-06 / SB-07 · Unresolved hulls.** A sail-less ~120 m boat fitting out at Jiangnan since
May–June 2026 (too narrow for JL-3 tubes, so not an SSBN); the Type 041 Zhou-class that sank
alongside at Wuchang in 2024, status unverified.

**SB-08 · Conventional force.** ≈46–50 SSK (Type 039 ×13, 039A/B ×21, a small number of 039C,
Kilo ×10) across **all three fleets** — the dashboard gives no per-fleet split, which is why the
theatre's SSK basing shares are the map's largest single judgment call.

---

## Bases and yards

| id | facility | role |
|---|---|---|
| BS-01 | Longpo / Yulin (Sanya, Hainan) | SSBN home port for all six 094s; tunnel pens; the southern bastion's shore |
| BS-02 | Bohai Shipbuilding, Huludao | sole builder of every PLAN nuclear submarine; 093/094 maintenance |
| BS-03 | Jiangnan (Changxing, Shanghai) | carrier/destroyer yard; a nuclear-sized hull fitting out since Jun 2026 |
| BS-04 | Wuchang (Wuhan) | conventional builder; Type 041; Hangor exports |
| BS-05 | Jianggezhuang (Qingdao) and Yuchi | first nuclear-submarine base, SSN home; the northern bastion's shore |
| BS-06 | Hainan approaches and the Paracels | Ocean E-Stations, seabed observatories, cabled hubs |

Also modelled as SSK sources: Lüshun/Xiaopingdao (Dalian), Ningbo–Zhoushan (Daxie Dao),
Zhanjiang (South Sea Fleet HQ).

---

## Doctrine

**SD-01 · Assured retaliation from the bastion, not the open ocean.** FAS assesses 094s would stay
in protected South China Sea or Bohai areas in a conflict; JL-3 range makes the bastion itself a
launch position.

**SD-02 · From possession to near-continuous at-sea deterrence.** "Probably" continuous patrols
since 2024. At least one boat at sea is baseline, not warning.

**SD-03 · Blind the watcher.** PLAN officers writing in *Military Art* (Nov 2023) prescribe
integrated detection nets, training to survey and destroy adversary arrays, concealment and
interference tactics, and the mobilisation of maritime militia and fishing fleets — which is why
the survey-ship and militia lanes belong on a submarine map.
*CIMSEC, "Exposed Undersea" (Jun 2025).*

**SD-04 · No first use with a launch-on-warning-capable force.** Peacetime arming of the sea leg
is the doctrinal question the open record cannot answer.

**SD-06 · Production as strategy.** Ten nuclear boats launched 2021–25 against seven American;
roughly 1 SSBN + 2 SSN a year; three yards now handle nuclear-sized hulls.

---

## Observables and events

**SO-01 / SW-04 · The 6 July 2026 SLBM shot.** ~12:00 Beijing time, from the South China Sea,
~7,300 km over northern Luzon to a box between Nauru and Tonga inside the South Pacific
Nuclear-Free Zone. A JL-2 with a dummy warhead per Taiwan; JL-3 not excluded; most likely a 094A.
Japan was informed, Australia and New Zealand within hours — ad hoc, not institutional. Asia
Times' "from the Bohai" report is contradicted by USNI and Naval News.
**Inferred launch geometry:** back-projecting the impact box through the reported Luzon overflight
at the stated range puts the firing point near **20–21°N, 115–118°E**. Labelled *(inferred)* on
the map, with a 170 nm radius.
*USNI News (6 Jul 2026); Naval News (Jul 2026); CSIS (Jul 2026).*

**SO-04 / SW-05 · Published detections.** Jan 2018, a Type 093 submerged in the Senkaku contiguous
zone. Sep 2021, a contact off Amami-Ōshima. Jun 2024, a Type 094 **surfaced** in the Taiwan
Strait near Penghu, photographed by fishermen and confirmed by Taiwan's MND — the maintenance
transit Longpo ↔ Huludao. Japan publishes selected contacts, not all of them; silence is a
collection gap, not an absence.

**SO-05 / SW-07 / UE-07 · Survey and battlefield preparation.** Six research vessels around Taiwan
May–Jul 2026 (*Da Yang Hao*, *Xiang Yang Hong 22*, *Jia Geng*, *Shen Hai 1*, *Shiyan 1*,
*Tongji*); an MNR-declared seabed survey east of Taiwan 10–31 Aug 2026; *Xiang Yang Hong 22*
lowering equipment 37 nm from Uotsuri inside Japan's EEZ on 30 Mar 2026; *Shiyan 1* loitering
over the Pacific Light cable 28 Jul–2 Aug. Dutton and Martinson read the campaign as 战场准备 —
Kuroshio and water-column data for submarine acoustics, cable routes and the location of foreign
sensor arrays.
*War on the Rocks (8 Sep 2026); Army Recognition (2026); Reuters (2 Sep 2026).*

**SW-02 / SW-03 · The blind rows.** SSBN alert and boats-at-sea; warhead loading and peacetime
arming. Both marked UNSEEN on the dashboard and both absent from this map by design.

---

## The undersea environment

**UE-01 · Allied fixed arrays — the "Fish Hook" line.** Public geography (Ball & Tanter, 2015):
Kagoshima → the Osumi Islands → Okinawa → Miyako → Yonaguni → past Taiwan → Balabac → Lombok →
the Sunda Strait → northern Sumatra → the Andamans, with key nodes at Okinawa and Guam. Reuters
(2023) reported an IUSS revamp: deep-sound-channel hydrophones, modernised cable arrays, portable
seabed sensors, UUVs, and ~US$3 bn for seven TAGOS(X) ships.

**UE-02 · PRC undersea sensor network.** The "Underwater Great Wall" announced by CSSC in 2016;
a five-layer architecture concentrated between Lingshui and the Paracels; Ocean E-Stations around
Hainan and Bombay Reef; Spratly outposts as an outer ring. Coverage and performance unknown — a
C3-graded lead, which is why the bonus it earns is moderate.

**UE-03 · Acoustics.** The Type 094 is two orders of magnitude louder than US/Russian SSBNs; PLAN
officers concede the probability of detection on leaving port inside the first island chain is
"extremely high". This is the single largest reason the sea leg stays in bastions.

**UE-09 · Allied ASW posture.** Japan's P-1/P-3C fleet screens the Ryukyu chokepoints; Kadena,
Naha, Kanoya, Iwakuni, Misawa, Atsugi, Clark, Pingtung, Pohang and Andersen are the basing that
shapes the pressure field. Taiwan's two Hai Lung boats were upgraded in Aug 2026.

---

## Triad context

≈620 warheads (FAS, Jul 2026), on a DoD-projected path past 1,000 by 2030. **Land (CM-04/CM-05):**
≈475 ICBM launchers with 300+ armed; >100 of ~320 new solid-fuel silos loaded at Yumen, Hami and
Yulin-Ordos; DF-41, DF-31A/AG, DF-31BJ, DF-5B/C, DF-61; DF-26 dual-capable IRBM. **Air:** ~20
H-6N with the JL-1 ALBM; H-20 slipped to the 2030s. **Sea:** as above. Five early-warning
satellites enable launch-on-warning; declaratory no-first-use since 1964.
