# Russia — LOOKING GLASS country brief

Sea leg compiled 10 SEP 2026 (Countdown, theatres `russia-north`, `russia-pacific`); land and air legs
added 15 SEP 2026 (theatres `russia-land`, `russia-air`; dashboard `assets/extension/data.js`).
Every `CD-RU-nn` (sea) and `LG-RU-Lnn` / `LG-RU-Ann` (land / air) below is cited by a factor, point,
base or class in those configs. The dashboard's own citations live inline in data.js.

---

## Sea leg — order of battle

**CD-RU-01 · Borei / Borei-A (Project 955/955A), 16 × Bulava.**
Eight in service by 2026. Northern Fleet at Gadzhiyevo: *Yuriy Dolgorukiy*, *Knyaz Vladimir*,
*Knyaz Pozharsky* (commissioned Jul 2025, the fifth Borei-A). Pacific Fleet at Rybachiy:
*Aleksandr Nevsky*, *Vladimir Monomakh*, *Knyaz Oleg*, *Generalissimus Suvorov*, *Imperator
Aleksandr III* (commissioned Dec 2023, joined the Pacific Fleet Sep 2024). *Dmitry Donskoy* and
*Knyaz Potemkin* building at Sevmash. Planned to serve into the 2060s.
*FAS/Bulletin Nuclear Notebook 2026; Naval News (Jul 2025); Army Recognition (2026).*

**CD-RU-02 · Delta IV (Project 667BDRM), 16 × Sineva/Layner.**
Five boats, all Northern Fleet, all Gadzhiyevo, 31st Submarine Division: *Verkhoturye*, *Tula*,
*Bryansk*, *Karelia*, *Novomoskovsk*. All five operational as of 2026 — *Bryansk* completed
overhaul Dec 2024 and returned to sea 28 May 2026; *Karelia* finished an overhaul with reactor
refuelling. Replacement was expected ~2029; the current plan runs them to about 2038.
Each missile carries up to four warheads.
*russianforces.org (Mar 2026, May 2026); Bulletin 2026.*

**CD-RU-03 · Yasen / Yasen-M (Project 885/885M) SSGN.**
*Severodvinsk*, *Kazan*, *Novosibirsk*, *Krasnoyarsk*, *Arkhangelsk*, *Perm* (on trials 2026).
Kalibr, Oniks and now Tsirkon. Northern Fleet at Zapadnaya Litsa; *Novosibirsk* and
*Krasnoyarsk* in the Pacific at Rybachiy. The class NATO's ASW build-up is aimed at.
*Bulletin 2026; Barents Observer (Aug 2026).*

**CD-RU-04 · Older nuclear and conventional boats.**
Oscar II (Project 949A/AM) SSGN and Akula/Sierra SSN in both fleets — Vidyaevo in the north,
Rybachiy in the Pacific. Kilo (877) diesel boats at Polyarny; Improved Kilo (636.3) at Malyy
Ulliss Bay, Vladivostok. Hull counts and readiness are the softest numbers in this brief.

**CD-RU-09 · Poseidon carriers.** *Belgorod* (Project 09852) in service; *Khabarovsk*
(Project 09851) on trials from Sevmash in 2026 alongside *Perm*. Nuclear-armed torpedo/UUV; a
special-mission share rather than a patrol class. Modelled only as a scenario.
*Barents Observer (18 Aug 2026).*

---

## Doctrine and patrol practice

**CD-RU-05 · The Barents bastion.** Gadzhiyevo sits 12–24 hours from the patrol water. Sineva/
Layner (~8,300 km) and Bulava (~8,000+ km) reach the continental United States from the Kola
approaches, so there is no requirement to leave. Missile loading at Okolnaya Bay; Severomorsk is
the fleet HQ. Under-ice operations are described within roughly 500–1,000 km of the Kola.
*Army Recognition (2026).*

**CD-RU-06 · Patrol rate.** Public estimate: **one to three SSBNs on patrol** at a time, with the
rest in port, transit or refit. This is the number the at-sea tiles encode, and it is an estimate,
not an observation.

**CD-RU-07 · Layered defence.** Bastion-P coastal missile batteries along the Kola, the Kurils
(a battalion on Matua) and Kamchatka; the 50th Coastal Defence Regiment in Chukotka; Su-35s at
Yelizovo; Tu-142 and Il-38 maritime patrol; Arctic "trefoil" bases at Nagurskoye (Franz Josef
Land), Rogachevo (Novaya Zemlya) and Sredny Ostrov. This is the umbrella an SSBN sits under.
*Defence Viewpoints; Army Recognition (2026).*

**CD-RU-08 · Under ice.** Umka-2021 (March 2021) surfaced three SSBNs through the ice near Franz
Josef Land simultaneously — a demonstration that the marginal ice zone is a usable refuge.
Sonobuoys and magnetic-anomaly detection do not work through ice, which is why the theatre model
shields adversary MPA pressure there.

**CD-RU-10 · Launches.** The annual **Grom / Thunder** strategic exercise fires SLBMs from the
Barents just north of Kildin Island, first-stage splashdown between 70° and 72°N east of the
Norwegian delimitation line, warheads to the Kura range on Kamchatka. Navigational warnings
publish the closure areas. The **May 2026** exercise (19–21 May) was unusual in timing and scale:
over 200 launchers, 13 submarines including 8 strategic missile submarines, one Delta IV Sineva
launch from the Barents, a Yars from Plesetsk, Tu-95MS ALCM launches from Ukrainka, a Tsirkon
from a surface ship. In the Pacific, *Vladimir Monomakh* fired a **four-missile Bulava salvo from
the Sea of Okhotsk** toward Chizha in December 2020. Sevmash fires Bulava trials from the White Sea.
*russianforces.org (May 2026); Barents Observer.*

**CD-RU-13 · Command and custody.** Not modelled. Warhead custody, mating and alert state are
unobservable and appear nowhere in this product.

---

## The environment

**CD-RU-11 · The listening lines.** Two, nested. The **Bear Island line** (North Cape → Bear
Island → Svalbard) is NATO's inner line; the **GIUK gap** (Greenland → Iceland → Faroes →
Shetland) is the outer one, with the US IUSS revival behind it. In the Pacific the equivalent is
the **Kuril chain** plus La Pérouse and Tsugaru, watched by Japan.

**CD-RU-12 · NATO maritime patrol.** P-8A operators now include the US, UK, Norway and Germany.
Norwegian basing at Evenes (with Andøya, Bardufoss, Banak, Bodø); Keflavik for US aircraft;
Lossiemouth for the RAF and a German detachment; Ørland for RC-135W. On **18 August 2026** Norway
relaxed its Cold-War restriction on allied surveillance missions north of the Kola, letting RAF
P-8 and RC-135W sorties stage directly from Norwegian bases toward the Barents.
*Barents Observer (18 Aug 2026); Navy Lookout; Maritime Executive on the IUSS revamp (2023).*

**CD-RU-14 · Atlantic deployments.** Yasen-class boats have deployed into the North Atlantic
repeatedly since 2021; *Kazan* called at Havana in June 2024 with a surface task group. The
Northern Fleet's forward habit is real but episodic — modelled as a posture-scaled forward
weight plus an "Atlantic surge" scenario.

**CD-RU-16 · The Okhotsk bastion.** Both Pacific Fleet nuclear divisions are at Vilyuchinsk
(Rybachiy) on Kamchatka; a conventional brigade at Malyy Ulliss Bay near Vladivostok. The Sea of
Okhotsk's Kuril Basin is 3,000 m deep and enclosed by Kamchatka, the Kurils, Hokkaido and
Sakhalin. *Imperator Aleksandr III* spent three months deployed in the Pacific in summer 2025.
*Defence Viewpoints; FAS on Pacific Fleet preparations.*

**CD-RU-17 · Ice in the Okhotsk.** December–April ice covers the northern and western sea. Modelled
as a scenario, not a season.

**CD-RU-18 · The Sea of Japan.** In **August 2025** Russia and China ran their first joint
submarine patrol there: the Improved Kilo *Volkhov* (B-603) **surfaced** through the Tsushima
Strait — deliberately visible — with a submerged Chinese Yuan (*Great Wall 210*), escorted by
*Gromkiy*, CNS *Urumqi*, and two submarine rescue ships. JMSDF detected and tracked it.
*Defence Security Asia (2025).*

**CD-RU-19 · What Japan publishes.** On **24 September 2025** the JMSDF reported a Borei-class
SSBN sailing west through the La Pérouse Strait with the cruiser *Varyag* and the tug *Fotiy
Krylov* — the first time a Borei was observed near Japan. Tracked by JS *Watakata* and a P-3C.
The route is the Pacific Fleet's maintenance run to Zvezda at Bolshoy Kamen.
*USNI News (24 Sep 2025).*

---

## Bases cited

| id | base | role |
|---|---|---|
| CD-RU-B1 | Gadzhiyevo (Yagelnaya Bay) | 31st Division — all Northern Fleet SSBNs |
| CD-RU-B2 | Zapadnaya Litsa (Nerpichya) | 11th Division — Yasen/Yasen-M |
| CD-RU-B3 | Vidyaevo (Ara Bay) | 7th Division — Akula, Sierra, Oscar II |
| CD-RU-B4 | Polyarny / Olenya Bay | Kilo brigade; GUGI special-mission boats |
| CD-RU-B5 | Severodvinsk — Sevmash / Zvezdochka | sole SSBN/SSGN builder; White Sea trials |
| CD-RU-B6 | Severomorsk | Northern Fleet HQ; Tu-142 / Il-38 |
| CD-RU-B7 | Rybachiy — Vilyuchinsk | both Pacific Fleet nuclear divisions |
| CD-RU-B8 | Malyy Ulliss Bay, Vladivostok | Improved Kilo brigade |
| CD-RU-B9 | Bolshoy Kamen — Zvezda | Pacific nuclear refits |
| CD-RU-B10 | Sovetskaya Gavan | secondary Pacific base |

---

## Triad context (CD-RU-15)

≈4,300 warheads in the military stockpile. **Land:** Yars silo and road-mobile, Sarmat entering
service, Avangard HGV on UR-100N, remaining Topol-M — ≈300+ ICBMs, ≈800–900 deployed warheads,
the highest-readiness leg. **Air:** Tu-95MS/MSM and Tu-160/160M with Kh-55/Kh-102, weapons stored
at Engels and Ukrainka, ≈580 assigned. **Sea:** thirteen SSBNs as above, ≈900 warheads if fully
loaded. New START expired 5 February 2026.
*FAS/Bulletin, Russian nuclear weapons 2026; SIPRI 2026.*


---

## Land leg — LOOKING GLASS references (theatre `russia-land`)

**LG-RU-L1 · Mobile ICBM force.** 180 RS-24 Yars road-mobile launchers in seven divisions (18–36 each)
plus 18 Topol-M at Teykovo (54th Guards: 2 Topol-M + 2 Yars regiments); ≈540 Yars warheads at three
per missile. Silo: Kozelsk 30 Yars (complete Dec 2025), Tatishchevo Topol-M → Yars from 2025,
Dombarovsky 12 Avangard + SS-18, Uzhur SS-18 with 6 silos converting for Sarmat. *FAS/Bulletin,
Russian nuclear weapons 2026 (May 2026); russianforces.org, Notes on the status of Russian strategic
nuclear forces in 2026 (Jan 2026).*

**LG-RU-L2 · Patrol pattern.** TASS, 22 Oct 2024: Yoshkar-Ola division Yars autonomous launchers
"entered combat patrol routes" — a 100-km march, field positions prepared and camouflaged, combat
security and counter-sabotage — "intensive maneuvers along combat patrol routes in combat alert
operations". The same vocabulary recurs in MoD announcements through 2025–26 at near-monthly cadence.

**LG-RU-L3 · May 2026 exercise.** 19–21 May 2026 strategic-forces exercise, announced the day it
began: >200 launchers, >140 aircraft, 73 ships, 13 submarines; Yars fired from a Krona shelter at
Plesetsk; framed as employment "under a threat of aggression"; Belarus's 465th Brigade received
"special munitions" at field storage in a drill and fired Iskander-M at Kapustin Yar.
*russianforces.org (May 2026); OSW (25 May 2026); NIPP No.666 (3 Aug 2026).*

**LG-RU-L4 · Sarmat.** 12 May 2026, 11:15 MSK, Plesetsk → Kura, claimed success; first regiment
promised at Uzhur by end-2026; failures Feb 2023 and Sep 2024; no independent confirmation.
*The Barents Observer (12 May 2026); russianforces.org (May 2026).*

**LG-RU-L8…L15 · Iskander-M brigades.** ≈156 launchers (FAS) in ≈13 brigades of 12 TELs plus a
Kapustin Yar unit: 26th Luga (L8), 152nd Gds Chernyakhovsk (L9), 112th Gds Shuya (L10), 448th Kursk
(L11), Belarus 465th Asipovichy (L12), 92nd Kamenka/Penza (L13), 119th Yelanskiy (L14), 103rd
Ulan-Ude (L15); 12th Mozdok, 464th Znamensk, 1st Gds, 3rd, 107th and 20th Gds lie outside the frame.
≈600 Iskander-M + ≈300 Iskander-K missiles (Jun 2025 estimate). *Open order-of-battle compilations
(Wikipedia 9K720 operators; russiandefpolicy); FAS (May 2026).*

**LG-RU-L12 · Asipovichy.** The 465th Brigade's Iskander battalion (Belarusian control since Feb
2023) south of the town; the Cold-War depot upgraded with a four-layer perimeter and a rail spur
nearing completion (Mar 2026) — the candidate Russian nuclear storage site in Belarus; no warhead
observed. *FAS (May 2026); OSW (May 2026); Defense Express; Belaruski Hajun archive.*

**LG-RU-L16 · Krichev-6.** MoD, 30 Dec 2025: an RVSN unit with Oreshnik "on combat duty" in Belarus.
Former Krichev-6 airfield, Mogilev region, ≈4–5 km from the Russian border: rebuilt railhead and
elongated secure structure, perimeter across the runway, barracks under construction (imagery to
20 Nov 2025). *Janes OSINT (Jan 2026); Militarnyi (27 Dec 2025).*

**LG-RU-L17 · Krichev-6 assessment.** Technical area ≈0.035 km², cleared area ≈0.02 km², concrete
pad covered with dirt at the runway's end (possible launch point or hardstand); battalion-level,
2–3 launchers rather than a 12-launcher regiment; possibly a second site. *Arms Control Wonk /
Middlebury (Dec 2025).*

**LG-RU-L20 · Terrain.** Field positions on prepared roads under tree cover; open steppe and towns
avoided. Modelled from Natural Earth 10 m land cover, roads (8-km buffer) and urban areas with three
forest-belt polygons (European, West Siberian, East Siberian). *TASS drill descriptions; Natural
Earth.*

**LG-RU-L21 · Envelope.** Routed-distance soft wall at the doctrinal ≈100-km march for the RVSN
divisions (gain 60 nm, 110 nm in the exercise-surge scenario), ≈90 nm for Iskander brigades and a
short envelope for the Oreshnik battalion, scaled by posture. *Derived from LG-RU-L2/L3.*

**LG-RU-L22 · Iskander at war.** HUR (Aug 2026): Iskander production at 110 % of plan in July 2026,
Kinzhal halted in April; August 2026 Russian salvo included 14 ballistic missiles. The western
brigades' wartime deployment areas against Ukraine are deliberately not modelled. *Euromaidan Press /
HUR (19 Aug 2026); Russia Matters (9 Sep 2026).*

---

## Air leg — LOOKING GLASS references (theatre `russia-air`)

**LG-RU-A1 · Engels-2.** 22nd Guards Heavy Bomber Division; arming, refuelling and maintenance staging
for Kh-101 strikes after the post-Spiderweb dispersal; Tu-95MS destroyed 16 Jul 2026 (Planet imagery
via RFE/RL Schemes, AviVector: tail section destroyed) and claimed destroyed 28 Aug 2026 (SSU 'Alpha'
MICH 2000 drones). *United24 (Jul 2026); TechTimes / Defense Express (28 Aug 2026).*

**LG-RU-A2 · Ukrainka.** 326th Heavy Bomber Division; AviVector counts: 40 Tu-95MS, 3 Tu-160, 4 Il-78M
(14 Jul 2025); 31 Tu-95MS, 8 Tu-160M, 1 Il-78M (27 Apr 2026, after two Tu-95MS from Olenya and one
from Dyagilevo redeployed). ≈8,000 km from the war. *AviVector; The Insider (Jun 2025).*

**LG-RU-A3…A6 · Backfire bases.** Belaya (200th Gds; Spiderweb losses; Tu-22M3 crash near Svirsk
15 Jun 2026 → 56 airframes), Olenya, Shaykovka, Soltsy. *The Aviationist (15 Jun 2026); Defense Express;
FAS.*

**LG-RU-A7 · Tankers.** Il-78/Il-78M of the 203rd Guards regiment at Dyagilevo (Ryazan), detachments
following the strike cycle to Ukrainka and Engels. *AviVector; IISS 2026.*

**LG-RU-A8 · Airborne command posts.** Il-80 (4) and Il-82 (2) of the 8th Special Purpose Aviation
Division at Chkalovsky; Il-22M relay; one Il-80 damaged by drone at Taganrog (Feb 2023).
*Open compilations.*

**LG-RU-A9 · AEW.** 5–7 A-50U at Ivanovo-Severny (2457th Aviation Base) after losses on 14 Jan 2024,
23 Feb 2024 and 1 Jun 2025; a new A-50U delivered 31 May 2026. *The Aviationist (1 Jun 2026).*

**LG-RU-A11 / A15 · Dispersal fields.** Tu-160s dispersed to Anadyr–Ugolny (3 'occasionally') and
Yelizovo after Spiderweb. *FAS (May 2026); The Insider (Jun 2025).*

**LG-RU-A14 · Savasleyka.** MiG-31K/I Kinzhal regiment (≈two dozen carriers); struck 14 Aug 2024
(T-6 fuel). *NV (Aug 2024); Euromaidan Press / HUR (19 Aug 2026).*

**LG-RU-A16 · Maritime patrol.** Tu-142 at Kipelovo–Fedotovo (Northern Fleet) and Yelizovo (Pacific);
two Tu-142s flew the 27 Jun 2026 joint patrol. *IISS 2026; USNI News (30 Jun 2026).*

**LG-RU-A17 · Launch axes.** Kh-101/Kh-55 launches over Saratov, Volgograd and Astrakhan regions or
the Caspian; the Kola/White Sea axis for Olenya sorties; Tu-95MS ALCM volley from Ukrainka-based
aircraft in the May 2026 exercise. *The Insider (Jun 2025); russianforces.org (May 2026).*

**LG-RU-A18 · Patrol lanes.** NORAD, 19 Feb 2026: 2 Tu-95 + 2 Su-35 + 1 A-50 in the Alaskan ADIZ,
intercepted ('occurs regularly'); 27 Jun 2026 11th Russia–China joint patrol (2 Tu-95MS, 2 H-6,
2 Tu-142, J-16, Su-35/Su-30) over the Sea of Japan, East China Sea and Pacific. *NORAD; USNI News.*

**LG-RU-A19 · Kh-22/Kh-32 water.** Tu-22M3 launches over the Black Sea against southern Ukraine.
*Crimean Wind; open reporting.*

**LG-RU-A20 · Airspace.** Own (RUS), allied (BLR), international, adversary (NATO, Ukraine, Japan,
Korea) from Natural Earth country unions; strategic sorties stay in own and international airspace.

**LG-RU-A21 · Radii.** Published unrefuelled combat radii: Tu-95MS ≈2,400 nm, Tu-160 ≈3,000, Tu-22M3
≈1,200, MiG-31K ≈700, support ≈900; scaled by posture as tanker support is assumed.

**LG-RU-A22 · Kinzhal status.** HUR (19 Aug 2026): production stopped April 2026 (44 in 2024, 144 in
2025); last documented strike 14 May 2026 (3 missiles); accuracy 30+ m. Single-side claim.

**LG-RU-T1 · Triad totals.** ≈4,400 stockpile; ≈1,796 deployed strategic (≈892 ICBM, ≈704 SLBM,
≈200 at bomber bases); ICBMs up to ≈1,092 warheads; ≈586 bomber weapons; ≈1,794 nonstrategic.
*FAS/Bulletin (May 2026); russianforces.org (Jan 2026).*

## Dashboard build notes (15 SEP 2026)

Telegram handles verified with `scripts/verify_channels.js` on 15 Sep 2026 (38 live public streams;
Hajun closed Feb 2025; Fighterbomber private). RSS feeds verified the same day (Barents Observer has no
discoverable feed). ICAO designators verified at doc8643.com: TU95 (Tu-95/Tu-142), T160, T22M, MG31,
IL76 (Il-76/78/82), IL86 (Il-80/87), IL18 (Il-20/22), A50.
