# India — COUNTDOWN country brief

Compiled 10 SEP 2026. Theatre: `india-bay-of-bengal`.

---

## Sea leg — order of battle

**CD-IN-01 · INS Arihant (S2/S1).** Commissioned August 2016. Four missile tubes. Completed the
first — and still only declared — **deterrence patrol in November 2018, about 20 days**. Now
serves largely as a training vessel and technology demonstrator; most recent test launch from her
was October 2022.

**CD-IN-02 · INS Arighaat.** Launched November 2017, commissioned **29 August 2024**. Four tubes,
same dimensions as Arihant. Fired the K-4 in December 2025.

**CD-IN-03 · INS Aridhaman.** Commissioned **3 April 2026**. Noticeably longer and wider than the
first two, with **eight missile tubes** — double the capacity. The boat that makes the sea leg
count for something.

**Fourth boat (INS Arisudan).** Sea trials to complete end-2026, commissioning scheduled 2027,
similar design to Aridhaman. **S5 class** — 12 or more tubes, significantly larger — expected
after the four Arihant-class boats; a large new shipbuilding hall is under construction at
Visakhapatnam.

**CD-IN-06 · Conventional force.** Kalvari-class (Scorpène), Sindhughosh-class (Kilo) and
Shishumar-class (HDW) — about sixteen boats split between the Western Fleet (Mumbai, Karwar) and
the Eastern Fleet (Visakhapatnam). Per-fleet counts and readiness are analyst estimates. The
leased Akula (*Chakra*) returned to Russia in 2021; *Chakra III* is expected around 2028.

*Sources: Bulletin of the Atomic Scientists, "Indian nuclear weapons, 2026" (Sep 2026); Carnegie,
"The Coming of Age of India's Nuclear Triad" (Apr 2026); Army Recognition (2025); Indian Defence
News (Aug 2026).*

---

## Missiles

**CD-IN-04 · K-4.** ~3,500 km. At least ten test launches; the most recent reported from INS
Arighaat in **December 2025**, following one in November 2024 and an earlier shot in October 2022.
All from the Bay of Bengal "off Visakhapatnam" — the public description that the map's launch
point is the centroid of. Reports indicate induction with the Arihant class, but there is **no
official confirmation of operational deployment**.

**CD-IN-05 · K-5.** 5,000 km. Development completion claimed June 2025; second-stage motor test
September 2025; cold-launch ejection test March 2026. **Not yet flight-tested.** Induction is the
theatre's scenario switch: it would let a boat cover China from deeper in the Bay or from the
Arabian Sea.

**K-15 (Sagarika/B-05).** 700 km, inducted 2018, only ever tested from Arihant — a technology
step rather than a strategic deterrent.

---

## Doctrine and geography

**CD-IN-07 · The Bay of Bengal as the operating area.** Deep water starts within 40 nm of
Visakhapatnam; the Andaman–Nicobar chain screens the eastern approaches; the K-4's reach covers
Pakistan and southwest China from the central Bay; and the Indian Navy's own maritime patrol
covers it. India's declared doctrine is no first use with massive retaliation, warheads held
de-mated under the Strategic Forces Command — a posture that makes a survivable sea leg the point
of the programme and makes home waters sufficient for it.

**CD-IN-08 · The northern Bay** (Bangladesh and Myanmar approaches) is shallow, crowded, and
increasingly overlooked by PRC-built infrastructure — modelled at reduced weight.

**CD-IN-10 · Indian ASW and support.** P-8I squadrons at INS Rajali (Arakkonam), INS Dega
(Visakhapatnam) and INS Hansa (Goa); the Andaman & Nicobar Command's airfields — INS Utkrosh
(Port Blair), INS Baaz (Campbell Bay), INS Kohassa (Shibpur).

**CD-IN-11 · Adversary presence.** Pakistan's P-3C and ATR-72 maritime patrol and its Agosta and
incoming Hangor-class submarines out of Karachi (PNS Mehran), Ormara and Gwadar; PRC-built or
PRC-linked facilities at Pekua (BNS Sheikh Hasina), Kyaukpyu, Hambantota and the Coco Islands.

**CD-IN-09 · Chinese survey and tracking ships.** CSIS *Hidden Reach* identifies thirteen Chinese
research and survey vessels operating in the Indian Ocean over four years, collecting subsurface
topography, water density, currents, thermoclines and salinity — the data needed to navigate
submarines in distant waters. *Hai Yang Shi You 760* ran a four-month "lawnmower" seabed survey
inside Bangladesh's EEZ in early 2023; a Chinese research vessel was found operating covertly
about 120 nm from Indian waters in July 2025; *Yuan Wang* tracking ships appear in the Bay before
Indian missile tests. Where the adversary is collecting hydrography is where an Indian SSBN would
rather not linger — modelled as small negative bumps.

---

## Bases cited

| id | base | role |
|---|---|---|
| CD-IN-B1 | Visakhapatnam (Eastern Naval Command dockyard) | current SSBN berthing; Kilo-class SSKs |
| CD-IN-B2 | INS Varsha, Rambilli | dedicated SSBN base under construction 50 km south — underground tunnels, piers, two water entrances into a tunnel complex, possibly for missile loading |
| CD-IN-B3 | Mumbai (Western Naval Command) | Kalvari, Shishumar |
| CD-IN-B4 | INS Kadamba, Karwar | western fleet base, expanding under Project Seabird |
| CD-IN-B5 | Port Blair (Andaman & Nicobar Command) | forward tri-service command |

---

## Triad context (CD-IN-12)

Up to **190 assembled warheads** (Bulletin, Sep 2026), from an estimated 140–225 warheads'
production capacity based on ~730 ± 170 kg of weapon-grade plutonium. **Land:** six operational
types — Prithvi-II, Agni-I through Agni-V — with Agni-P nearing deployment and canistered Agni-V
MIRV-tested in March 2024 and May 2026; ≈88 operational nuclear-capable land-based missiles as of
July 2026. **Air:** Mirage 2000H and Jaguar IS, transitioning to Rafale; three to four squadrons
assigned. **Sea:** as above. The Dhanush ship-launched missile on Sukanya-class patrol vessels is
assessed no longer operational.
