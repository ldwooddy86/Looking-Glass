# United States — COUNTDOWN country brief

Compiled 10 SEP 2026. Theatres: `us-atlantic`, `us-pacific`.

---

## Sea leg — order of battle

**CD-US-01 · Ohio-class SSBN.** Fourteen boats, each with 20 Trident II D5LE missiles (reduced
from 24 under New START). **Eight at Bangor** (Kitsap, Washington): *Henry M. Jackson*, *Alabama*,
*Nevada*, *Pennsylvania*, *Kentucky*, *Nebraska*, *Maine*, *Louisiana*. **Six at Kings Bay**
(Georgia): *Alaska*, *Tennessee*, *West Virginia*, *Maryland*, *Rhode Island*, *Wyoming*.
Roughly **70 % of deployed US strategic warheads** ride on them.

**CD-US-02 · Columbia-class.** SSBN-826 *District of Columbia* delivery has slipped to **2030**,
full operational status 2031, first patrol 2031; *Wisconsin* about 35 % complete as of mid-2026.
The programme is roughly 17 months late and the Ohio fleet is being extended past 2040 to keep
continuous at-sea deterrence unbroken. Ohio decommissioning runs FY2027–31.
*USNI News (Feb 2026); Zona Militar (May 2026); CRS R41129.*

**CD-US-03 · Attack boats.** Virginia, Los Angeles and Seawolf classes. Atlantic: Groton
(Connecticut) and Norfolk (Virginia). Pacific: Pearl Harbor and San Diego, with the Seawolf boats
at Bangor.

**CD-US-04 · Ohio SSGN.** Four converted boats — *Ohio* and *Michigan* (Bangor), *Florida* and
*Georgia* (Kings Bay) — up to 154 Tomahawks each, **all four decommissioning by 2029**. They
deploy forward for a year at a time and surface for effect; the 2010 triple surfacing (Subic Bay,
Busan, Diego Garcia — 462 missiles) is the canonical demonstration.

---

## Doctrine and practice

**CD-US-06 · Open-ocean patrol, continuous at-sea deterrence.** No bastion. Trident II D5LE
(>7,400 km) covers the target set from almost anywhere in the ocean, and the design goal is that
nobody knows where a boat is. Public estimates: roughly **8–10 of 14 boats at sea** at any time,
**4–5 on "hard alert"**. Average patrol length about 77 days. **Patrol areas are classified**, and
this map is a prior over water, never a claim about a boat.

**CD-US-07 · What shapes the prior is exclusion.** Continental shelves, fishing banks (Grand
Banks, Georges Bank, the Bering shelf), confined seas (Caribbean, Gulf of Mexico), the Alaska
panhandle's inside waters, busy lanes, and the escorted egress channels — St Marys at Kings Bay,
Hood Canal → Admiralty Inlet → Juan de Fuca at Bangor.

**CD-US-08 · Launch water.** Demonstration-and-shakedown and follow-on commander's evaluation
tests are fired on announced ranges: the **Eastern Range off Cape Canaveral** for Kings Bay boats
(USS *Wyoming*, September 2023 and September 2025 among others) and the **Point Mugu / SoCal sea
range** for Bangor boats (USS *Louisiana*, September 2023). Navigational warnings publish the
boxes. Launch water is not patrol water.

**CD-US-09 · Publicised presence.** The Navy uses SSBN visibility as signalling: USS *Alaska* at
Gibraltar (June 2021) and Faslane (September 2023); USS *Nevada* at Guam (January 2022, again
2024); USS *Kentucky* at Busan (July 2023), the first SSBN port call in Korea since 1981. These
say where a boat was *allowed to be seen*.

**CD-US-10 · Own ASW and support.** P-8A wings at Jacksonville, Whidbey Island and Kaneohe Bay;
Norfolk/Oceana; the Pacific Missile Range Facility at Kauai; Point Mugu; Kodiak; the legacy
Bermuda and Adak nodes; Keflavik, Lajes and Rota forward.

**CD-US-11 · Adversary presence.** Russian intelligence ships have worked the US East Coast for
decades; *Kazan* (Yasen-M) and a task group visited Havana in June 2024; the intelligence ship
*Kareliya* has loitered off Hawaii (2021, 2023); Russia and China have run joint naval patrols
near the Aleutians (September 2021, August 2023). Small, episodic — but it is why a boat clears
the coast quickly.

**CD-US-14 · Forward attack-boat geography.** Atlantic SSNs work up on the East Coast ranges,
hunt at the GIUK and Norwegian Sea approaches, and transit Gibraltar to the Sixth Fleet. Pacific
SSNs work up on the SoCal and Hawaiian ranges and deploy west to Guam, Japan and the Philippine
Sea — outside the `us-pacific` frame.

---

## Bases cited

| id | base | role |
|---|---|---|
| CD-US-B1 | Kings Bay, Georgia | 6 SSBN + 2 SSGN; Trident Refit Facility; SWFLANT |
| CD-US-B2 | Groton (New London), Connecticut | Virginia/LA-class SSN; Electric Boat |
| CD-US-B3 | Norfolk, Virginia | Virginia/LA-class SSN; Norfolk Naval Shipyard |
| CD-US-B4 | Faslane (HMNB Clyde) | allied; occasional US SSBN port visits |
| CD-US-B5 | Bangor (Kitsap), Washington | 8 SSBN + 2 SSGN; SWFPAC; Seawolf SSNs |
| CD-US-B6 | Pearl Harbor, Hawaii | Virginia/LA-class SSN (SUBRON 1 and 7) |
| CD-US-B7 | Point Loma, San Diego | LA/Virginia-class SSN (SUBRON 11) |

---

## Triad context (CD-US-15)

**Land:** 400 Minuteman III in 450 silos (Malmstrom, Minot, F.E. Warren), single-RV since 2014
with upload capacity; Sentinel (LGM-35A) delayed and restructured into the 2030s; a GT-255
two-RV test in March 2026. **Air:** B-52H with AGM-86B ALCM moving to LRSO, B-2A with B61-12,
B-21 Raider entering service, dual-capable F-35A in Europe; bombers off day-to-day alert since
1991. **Sea:** as above — the largest and most survivable leg. New START expired 5 February 2026.
