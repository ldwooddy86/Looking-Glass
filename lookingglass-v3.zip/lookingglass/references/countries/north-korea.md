# North Korea — COUNTDOWN country brief

Compiled 10 SEP 2026. Theatre: `north-korea-east-sea`.

---

## Sea leg — order of battle

**CD-KP-01 · What the hulls actually are.** North Korea's missile submarines are **Romeo-class
(Type 033) derivatives** — a 1950s Soviet design. Outside analysts describe them as noisy, slow
and short-ranged, with "fundamental limitations and vulnerabilities". No North Korean submarine
has been observed completing anything resembling a deterrent patrol. That is the fact the whole
theatre model turns on.

**CD-KP-02 · Sinpo-C, "Hero Kim Kun Ok".** Launched **6 September 2023** at Sinpo South shipyard.
About 86 m, ~3,000 t, with **four large and six small missile hatches** (ten launch positions),
intended for the Pukguksong-3 SLBM, nuclear-capable cruise missiles and possibly *Haeil* UUVs. As
of July 2025 satellite imagery showed her under the same canopy for five months without
deploying; SI Analytics detected **maintenance completion in late March 2026** (security covers
removed, vehicle activity at the test facility and dry dock), suggesting sea trials.
*CSIS Beyond Parallel; UPI (6 Apr 2026); Wikipedia, "Hero Kim Kun Ok".*

**CD-KP-03 · Sinpo-B "Gorae" (8.24 Yongung).** The single-tube experimental boat that fired the
first Pukguksong-1.

**CD-KP-04 · The nuclear-powered boat.** Revealed **8 March 2025** in KCNA imagery of Kim Jong Un
at the Pongdae Submarine Factory, Sinpo South. Estimated 11.5–12.5 m diameter, 5,000–8,000 t,
at least 117 m; North Korea calls it an **"8,700-tonne class strategic guided missile submarine"**.
2026 KCNA imagery showed a **largely completed hull** in an assembly hall — not launched. Moon
Keun-sik assessed most equipment installed and sea testing possible within months. No reactor has
been confirmed; 38 North found no open-source evidence of Russian assistance, though Russia is the
obvious candidate. The likeliest missile is the **Pukguksong-6**, paraded April 2022, never
flight-tested. **This is the theatre's scenario switch, not a class.**
*38 North (Mar 2025); NBC News (2026).*

**CD-KP-06 · Coastal boats.** About seventy Romeo, Sang-O and Yono hulls across the East Coast and
West Coast Fleets — the largest submarine force in the world by hull count and among the least
capable. Estimates range from 64 to 86; readiness is very low.

---

## Where the shots have come from

**CD-KP-05 · Every submarine-launched test on the public record** has come from the same narrow
strip of the East Sea off Sinpo and Wonsan, or from the **submersible test barge moored at Sinpo**
— which has carried more of the programme's ejection tests than any boat has:

- **24 August 2016** — Pukguksong-1 from a submarine off Sinpo, ~500 km into the East Sea.
- **2 October 2019** — Pukguksong-3 from the sea off Wonsan into the East Sea.
- **28 January 2024** — Pulhwasal-3-31 strategic cruise missile from a submarine, East Sea off Sinpo.

**CD-KP-11 · The surface stopgap.** The *Choe Hyon* and *Kang Kon* destroyers (~144 m, 5,000 t,
44 + 30 VLS cells, Russian Pantsir-M) test-fired strategic cruise and anti-ship missiles off the
**west coast in April 2026**, with Kim observing. Analysts doubt a 13-month build without outside
help. Pyongyang is using them as the sea-based nuclear signalling platform while the submarine
programme matures.
*Asia Times (Apr 2026); Defence Security Asia (2026).*

---

## Geography and the environment

**CD-KP-07 · The coastal box.** Sinpo, Mayang-do, Chaho and Toejo-dong are within a few dozen
miles of each other on the east coast; the East Sea drops past 2,000 m within 40 nm of Sinpo —
the deepest water any North Korean boat can reach. Shore batteries, coastal radar and airfields
at the Sinpo complex, Wonsan-Kalma, Hamhung, Chongjin, Nampo and Haeju are the only cover the KPA
Navy can offer. The Pukguksong-3's range already covers South Korea and Japan from this box: the
missile does the reaching, not the boat.

**CD-KP-08 · The densest ASW environment on this map.** ROK P-3CK and P-8A from Pohang, the 1st
Fleet at Donghae, the 2nd Fleet at Pyeongtaek, ROK submarines from Jinhae; JMSDF P-1s from
Maizuru and across the East Sea; US P-8As within reach; U-2S from Osan. A North Korean boat is
under this coverage from the moment it clears the harbour.

**CD-KP-09 · The mass sortie.** In August 2015, during a crisis, about **fifty** North Korean
submarines left port at once and the ROK lost track of them — the pattern the theatre's
mass-sortie scenario reproduces. It is a dispersal, not a deployment.

**CD-KP-10 · The Northern Limit Line.** The de facto, disputed maritime boundary in the Yellow
Sea. **ROKS *Cheonan* was sunk near Baengnyeong Island on 26 March 2010**, attributed by the joint
investigation to a Yono-class midget submarine — the only confirmed North Korean submarine attack,
and the reason the coastal boats' most likely water is also the most dangerous.

---

## Bases cited

| id | base | role |
|---|---|---|
| CD-KP-B1 | Sinpo South Shipyard (Pongdae Submarine Factory) | the only missile-submarine yard; the test barge |
| CD-KP-B2 | Mayang-do | East Coast Fleet's main submarine base, opposite Sinpo |
| CD-KP-B3 | Chaho | East Coast Fleet submarine base |
| CD-KP-B4 | Toejo-dong | East Coast Fleet submarine base, Hamhung Bay |
| CD-KP-B5 | Pipa-got | West Coast Fleet submarine base, Yellow Sea |

---

## Triad context (CD-KP-12)

North Korea is **building toward** a triad rather than operating one. **Land:** the credible leg —
Hwasong-17, -18 (solid), -19 and -20 ICBMs, Hwasong-12/16 IRBM, KN-23/24/25 theatre systems, road
mobile and increasingly solid-fuelled; SIPRI estimates **≈50 assembled warheads** with fissile
material for more. **Air:** H-5 (Il-28) bombers — obsolete, no demonstrated nuclear role; the leg
exists on paper. **Sea:** as above — one converted Romeo, a test boat, a barge, an unlaunched
nuclear hull and two new destroyers.

Kim Jong Un has called the nuclear submarine's completion an "epoch-making" change and denounced
South Korea's own nuclear-submarine plans as an "offensive act".
