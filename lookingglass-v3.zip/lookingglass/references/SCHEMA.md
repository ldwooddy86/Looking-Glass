# ORACLE_DATA v2 / LOOKING GLASS v3 — schema contract

`window.ORACLE_DATA` in `assets/extension/data.js` is the single source of truth for the
dashboard, the preview build and the installed extension. **Structure is fixed; content is
per-country.** Keep every key name and shape — `dashboard.js` reads them directly and
`scripts/validate_data.js` enforces this contract before every build.

Conventions used below: `req` = required (validator ERROR if missing/invalid),
`rec` = recommended (WARN), `opt` = optional (renderer hides the element or the whole tab).

## Enums (drive colours, gauges and meters)

| enum | values | colour mapping |
|---|---|---|
| level (posture, matrix, indicators) | `stable` `guarded` `elevated` `high` `severe` | green · green · amber · red · red |
| observed (I&W) | `normal` `note` `elevated` `warning` `unseen` | green · amber · amber · red · grey (excluded from the meter, counted as blind) |
| coverage (matrix INTs) | `strong` ● `partial` ◐ `gap` ○ `na` · | gap renders red |
| trend | `up` ▲ `flat` ▬ `down` ▼ | |
| confidence | `High` `Moderate` `Low` | ICD-203 analytic confidence, stated separately from probability |
| tone (scenarios, scanner categories) | `watch` `alert` `red` | grey/calm · amber · red |
| ACH cell | `C` `I` `N` | consistent · inconsistent · neutral |
| tempo (Track Watch) | `neardaily` `frequent` `rare` | drives the expected-sighting baseline |
| lane (channels) | `propaganda` `official` `wire` `milblogger` `independent` `analyst` `community` `aggregator` `custom` | |
| stance (academia) | `independent` `mixed` `state` | |
| leadership status | `confirmed` `acting` `vacant` `purged` `unknown` | |
| threat level (protective) | `low` `moderate` `substantial` `severe` `critical` | UK/NPSA-style five-step scale |
| protective posture | `baseline` `heightened` `reinforced` | |
| exposure / likelihood / impact | `low` `moderate` `high` `critical` | |
| resilience | `weak` `moderate` `strong` | |
| change kind (`product.changes`) | `up` `down` `new` `watch` `resolved` | |
| air role (`airWatch.fleet`) | `strike` `dual-capable` `tanker` `c2` `relay` `aew` `isr` `support` `transport` | v3 |
| launcher role (`launcherWatch.fleet`) | `ICBM` `IRBM` `MRBM` `SRBM` `GLCM` `HGV` `dual-capable` `SAM` `other` | v3 |
| leg status (`airWatch` / `launcherWatch` fleet) | `in-service` `building` `modernising` `storage` `trials` `unknown` `retired` | v3 |
| transponds (`airWatch.fleet`) | `never` `rarely` `often` `mode-s-only` `unknown` | v3 |
| sub-watch side (`subWatch.environment`) | `allied` `subject` `both` (`prc` kept for the v2.1 China build) | |
| theatre leg (`triadMaps.theatres`) | `sea` `land` `air` | must equal the config's `grid.domain` |
| collector kind (`collector.sources`) | `telegram` `telegram-bot` `discord` `bluesky` `mastodon` `reddit` `youtube` `rss` `x` `adsb` `notam` `navwarn` `web` | v3 |

Admiralty grades are free strings but must contain a reliability letter A–F (e.g. `A2`,
`B3 (contested)`, `F6 (gap)`).

---

## Top level

```
meta{}             identity (drives header, titles, package name, filenames)      req
posture{}          top-line gauge + narrative (+ optional uncertainty range)       req
product{}          BLUF, Key Judgments, changes since last edition                 req
matrix{}           all-source capability / threat matrix                          req
forces{}           order of battle + leadership / command-chain board             req
indicators[]       readiness snapshot cards                                       rec
doctrine[]         + doctrineNote (string)                                        rec
events[]           dated timeline (newest first)                                  rec
iwBoard{}          Indications & Warning watchboard                               req
ach{}              Analysis of Competing Hypotheses                               req
keyAssumptions[]   Key Assumptions Check                                          rec
collectionGaps[]   prioritised gaps                                               rec
escalation{}       intent / scenario model — OPTIONAL (tab hides when absent)     opt
movementWatch{}    force-movement signatures + live language scanner              rec
trackWatch{}       pattern-of-life over public ADS-B                              req
protective{}       protective-intelligence layer (4 tabs) — OPTIONAL              opt
subWatch{}         nuclear-submarine watch (Sub Watch tab) — OPTIONAL             opt
airWatch{}         nuclear strike & support aircraft watch (Air Watch tab) — OPT  opt   v3
launcherWatch{}    road-mobile launcher watch (Launcher Watch tab) — OPTIONAL     opt   v3
triadMaps{}        embedded heatmap theatres (Triad Map tab) — OPTIONAL           opt   v3
collector{}        local-collector plan (Feed / Media tabs, config seed) — OPT    opt   v3
osint{}            collection: lanes, directory, signal chain                     rec
stateMedia{}       state / system-media directory                                 rec
social{}           social-platform directory + method + ethics rail               rec
academia{}         research-institution source base                               opt
sourceReliability{} NATO Admiralty annex                                          rec
security[]         security-model items (≥5)                                     req
sources            footer source string (must name editions / years)             req
```

---

## Field detail

### meta (req)
`{ version:2, country, adjective, subject, flag(emoji), slug(kebab-case), brand, line, tagline, compiled, edition?, previousCompiled?, region? }`
- `slug` drives output filenames (`<slug>-military-posture-monitor-preview.html`, `<slug>-monitor-extension.zip`).
- `compiled` is a parseable date ("01 SEP 2026"). The validator warns when >120 days old.
- `previousCompiled` lets the BLUF "changes since last edition" strip name the prior edition.

### posture (req)
`{ level(enum), headline(1–2 sentences), body(paragraph), range?:[levelLo, levelHi], mover? }`
- `range` draws an uncertainty bracket on the gauge (the level must lie inside it).
- `mover` — one sentence: what observation would move the level (shown under the gauge).

### product (req)
`{ handling, line, asOf, horizon?, scopeNote, estimativeKey[{term,band}], confidenceDef, bluf, keyJudgments[], changes[]? }`
- `keyJudgments[]` (≥4): `{ id, text, prob, confidence(enum), grade(Admiralty), basis, whatWouldChange? }`.
  `prob` must use ICD-203 vocabulary or a % band (validator warns otherwise). `confidence` is
  stated separately from `prob` and must fit the sourcing (High confidence on D/E/F-graded or
  credibility-4+ evidence is flagged).
- `changes[]` (rec): `{ date, kind(enum), text }` — what moved since `meta.previousCompiled`.
  A monitor that cannot say what changed is a snapshot, not a monitor.

### matrix (req)
`{ updated, note, intCols[{key,label,full}], levels[{key,label}], collectionPosture, domains[] }`
- Keep the five standard `intCols` keys: `osint, geoint, sigint, humint, masint`.
- `domains[]` (≥6, 8+ recommended): `{ id(unique), domain, pri(1–5), level(enum), trend(enum), conf(enum), finding, primary, src, ints{osint,geoint,sigint,humint,masint: coverage}, lastChange? }`.
  A domain whose coverage is mostly `gap` should not carry `High` confidence (warned).

### forces (req)
`{ updated, note, totals[], branches[], systems{}, leadership[]? }`
- `totals[]`: `{ label, val, note?, alt? }` — `alt` is the second, independent estimate
  ("SIPRI: $336B") rendered beside `val` so the spread is visible. At least one total should
  carry an `alt` (warned otherwise): single figures are false precision.
- `branches[]`: `{ branch, personnel, pct(0–100), detail }` — pct should sum ≈100.
- `systems{}`: groups `ground[] air[] naval[] missile[] strategic[] enabling[]` of strings.
- `leadership[]` (rec): `{ post, name, since?, status(enum), note?, src? }` — the command-chain
  board. These are the most perishable facts in the product; every row must be search-verified
  on the build date and `src` should say where.

### indicators[] (rec)
`{ cat, level(enum), title, body, src }` — readiness snapshot cards.

### doctrine[] / doctrineNote (rec)
Array of strings + a note string.

### events[] (rec)
`{ date, iso?(YYYY-MM-DD), hot(bool), title, body, src? }` — newest first. When `iso` is present
the validator checks ordering.

### iwBoard (req)
`{ note, scaleLegend[{key,label,body}], indicators[] }`
- `indicators[]` (≥6, 8+ recommended): `{ id, domain, threshold, observed(enum), crit(1–5), conf(enum), grade, read, src, trend? }`.
- The UI computes a crit-weighted warning meter from `observed` **excluding `unseen` rows**, and
  a separate **blind fraction** (crit-weighted share of indicators that are `unseen`). Mark the
  near-invisible indicators `unseen` rather than `normal` — "quiet" must never read as "clear".

### ach (req)
`{ question, method, hypotheses[{id,label,desc}], evidence[], conclusion }`
- `evidence[]` (≥6): `{ id, text, grade, scores{<hypId>:"C|I|N"}, diag(bool), src? }`.
- Ranking = least reliability- and diagnosticity-weighted inconsistency: Admiralty letter → weight
  (A 1.0 · B 0.8 · C 0.6 · D 0.4 · E 0.2 · F/other 0.5); `diag:true` rows ×2 (1.6 vs 0.8).
- Every `scores` key must be a hypothesis id (ERROR). A board with zero `I` cells is an argument,
  not an analysis (WARN). At least one `diag:true` row (WARN).

### keyAssumptions[] (rec) `{ id, text, risk, ifWrong }`
### collectionGaps[] (rec) `{ rank, gap, detail, mitigation }`

### escalation (opt)
`{ title, horizon, question, bluf, judgments[{id,text,conf,grade}], driverGroups[{key,label}], drivers[{id,group,name,dir,value,lev("vhigh|high|med|low"),conf}], scenarios[{id,name,type,prob,tone,gate}], scenarioNote, crossImpactNote, net{likely,dangerous,movers}, paperNote }`

### movementWatch (rec)
`{ intro, tiers[{tier("t1|t2|t3"),label,vis,note}], signatures[{id,tier,sig,iw,feed,blind(bool),note}], scanner{note, dictionary[{cat,tone,terms[]}]}, note }`
- The scanner runs live in the installed extension across every cached lane. Each `terms` entry is
  matched on its native form AND any parenthetical romanisation (`"动员 (dongyuan)"` matches on
  either), and `/`-separated alternatives are split. Hits are grouped by term with **cross-lane
  corroboration** (distinct lanes / lane classes carrying the same term). Include the country's
  own-language vocabulary — a term the dictionary lacks cannot be caught.

### trackWatch (req)
`{ intro, note, types[], sector{lat,lon,dist,label,why}, links[{label,href}], match{}, alert?{alert,red}, alertRule }`
- `types[]`: `{ key, type, nick, tempo(enum), role, bases, src, crit?(bool), note? }`. `crit:true` marks
  an airframe whose lone sortie is itself high-signal: one crit type airborne → ALERT, two → RED.
- `match{}`: `{ <key>: { types[ICAO designators], regs[], hex[] } }` — keys MUST equal the set of
  `types[].key` (ERROR either way). Designators are 2–4 upper-case alphanumerics (see
  `references/ADSB-TYPES.md`); a wrong code silently classifies nothing.
- `sector`: lat −90..90, lon −180..180, dist 1..250 nm — a fixed public map location of interest.
- `alert` (opt): explicit tripwires; omitted → thresholds scale to the watch-list size (ALERT ≈34 %,
  RED ≈60 %, RED always reachable). Describe the rule in words in `alertRule`.
- The worker keeps a 7-day sighting history per type and reports **deviation from the expected
  tempo** (`neardaily` ≈ 1/day, `frequent` ≈ 0.4/day, `rare` ≈ 0.07/day) — pattern-of-life, not intent.

### protective (opt — omit the block to hide all four tabs)
A **defensive / protective-security** layer in the CISA–NPSA idiom: threat levels, target
*classes*, sector exposure and where advisories apply. It must never carry facility-level
vulnerabilities, attack methods, timings, coordinates or a target map — the validator scans the
block for that vocabulary and errors.

```
protective: {
  framingNote,                                   req — the defensive-framing statement rendered on every protective tab
  threat: {                                      Terror Threat tab
    level(threat enum), headline, body, updated,
    actors[{ id, name, type, intent(1–5), capability(1–5), reach("domestic|regional|global"),
             trend(enum), targets(string — target CLASSES), grade, note, src }],
    iw[{ id, indicator, threshold, observed(enum), crit(1–5), conf(enum), grade, read, src }],
    incidents[{ date, iso?, place, kind, actor, casualties, note, src, hot? }],
    note
  },
  softTargets: {                                 Soft Targets tab
    intro,
    classes[{ id, class, examples, precedent(0–5), risk(exposure enum), posture(posture enum),
              measures[strings], note, src }],
    note
  },
  infrastructure: {                              Critical Infrastructure & Data Centers tab
    intro,
    sectors[{ id, sector, spotlight?(bool), exposure(enum), resilience(enum),
              vectors[strings], recent, measures[strings], src }],
    dataCenters: { intro, vectors[{ vector, likelihood(enum), impact(enum), measure, src }], note },
    note
  },
  geography: {                                   Threat Geography tab
    intro,
    regions[{ id, region, scope("domestic|overseas"), advisory(threat enum), drivers[strings],
              actors[actor ids], trend(enum), note, src }],
    note
  }
}
```
`actors[].id` referenced from `geography.regions[].actors` must exist (ERROR).

### subWatch (opt — omit the block to hide the Sub Watch tab)
A **nuclear-submarine watch** for a subject that operates nuclear-powered boats: the sea leg's
order of battle, basing and industrial base, the pattern-of-life observables that open sources
can actually see, a sea-leg I&W board with its own blind fraction, an **undersea-surveillance
ledger** that states, layer by layer, what public reporting establishes and what is classified
on each side, the naval doctrine behind the boats, the civil–military maritime elements
(ferries, survey ships, militia, commercial fleets) that touch the undersea picture, a
sea-leg timeline, and an undersea-language dictionary that the live scanner matches across
the same cached lanes as the Movement tab (`subTabDot` lights on a hit).

**Rail (validator ERROR):** the block must never carry a live, current or predicted position,
track, patrol box or coordinate pair for a boat. Sentences that *deny* observability ("alert
state is not observable") are the honesty rail and pass; anything that reads as a position
claim fails the build. Submarine positions are unobservable in open sources on every side —
say so, never draw it.

```
subWatch: {
  title?, updated,                              updated = assessed-on date (WARN if absent)
  framingNote,                                  req — public-OSINT / no-positions statement (rendered first)
  intro?,
  status?: { level(posture enum), range?:[lo,hi], headline, body?, mover }   sea-leg posture meter
  fleet[] (≥3):  { id, cls, role, nick?, hulls, alt?, status("in-service|building|fitting-out|trials|unknown|retired"),
                   weapons?, base?, trend(enum), conf(enum), grade(Admiralty), note?, src }
                 at least one class should carry `alt` (WARN) — hull counts are contested
  bases[]:       { id, name, role, sees, lastChange?, conf(enum), src? }     what commercial imagery sees per site
  observables[]: { id, signature, tier("t1|t2|t3"), iw?, feed, cadence?, blind?(bool), read, src? }
  iw[] (≥5):     same shape as iwBoard.indicators — at least one row must be `unseen` (ERROR otherwise)
  environment[] (4+ rec): { id, layer, side("allied|prc|both"), known, unknown, effect, grade, src? }
                 the classified-factor ledger: `known` = public reporting, `unknown` = classified /
                 unobservable, `effect` = how that bends the board
  doctrine[]:    { id, tenet, basis?, implication?, src? }
  civilMaritime[]: { id, element, mechanism, observable, status, tone(enum), src? }
  timeline[]:    { date, iso?, hot?, title, body, src? } — newest first
  scanner?:      { note, dictionary[{cat, tone, terms[]}] } — undersea vocabulary, native forms included
  sources, note?
}
```

### airWatch (opt, v3) — the air leg
```
airWatch: {
  title, updated, framingNote (req — public-OSINT / no-targeting statement), intro,
  status{ level(enum), range[lo,hi], headline, body, mover },
  fleet[] (≥3): { id, type, role(air role enum), nick?, airframes (count + uncertainty), alt?,
                  status(leg status), weapons, bases, units, icao[] (ICAO Doc 8643 designators,
                  2–5 upper-case alphanumerics — see references/ADSB-TYPES.md), transponds(enum),
                  trend, conf, grade, note, src }
  bases[]:      { id, name, role, sees (what OSINT sees there), lastChange, conf, src }
  observables[]:{ id, signature, tier(t1|t2|t3), iw (AW-nn), feed, cadence, blind(bool), read, src }
  iw[] (≥5, ≥1 unseen): { id, domain, threshold, observed(enum), crit(1–5), conf, grade, read, src }
  doctrine[]:   { id, tenet, basis, implication, src }
  timeline[]:   { date, iso?, hot?, title, body, src } — newest first
  scanner:      { note, dictionary[{cat, tone, terms[]}] } — ≥15 terms, native forms included
  live?:        { intro, note (honesty rules), types[{key, type, nick, tempo, crit?, role, bases, src}],
                  sector{lat, lon, dist ≤250, label, why}, links[], match{key:{types[],regs[],hex[]}},
                  alert{alert, red}, alertRule }   — keys WITHOUT the `air:` prefix (the page adds it)
  sources, note
}
```
Rails: the validator refuses targeting / strike-planning / force-defeat vocabulary anywhere in the
block, and warns on non-designator `icao` codes. `live.match` keys must equal `live.types` keys.

### launcherWatch (opt, v3) — the mobile land leg
```
launcherWatch: {
  title, updated, framingNote (req — no positions statement), intro,
  status{ level, range, headline, body, mover },
  fleet[] (≥2): { id, system, role(launcher role enum), nick?, launchers (count + uncertainty), alt?,
                  status(leg status), chassis, warheads, range, units, trend, conf, grade, note, src }
  garrisons[]:  { id, name (a town / region — never a field position), formation, sees, lastChange, conf, src }
  dispersal:    { pattern, inputs[{k, v, src}], note }
  observables[], iw[] (≥5, ≥1 unseen), doctrine[], timeline[], scanner{}, sources, note   — as airWatch
}
```
Rails: coordinate pairs, live/current-position vocabulary, present-tense launcher-location claims,
named field-position claims and targeting vocabulary are validator ERRORS unless the sentence
denies them (the honesty rail).

### triadMaps (opt, v3) — embedded heatmaps
```
triadMaps: { intro, framingNote (req — structural-prior statement),
             theatres[{ id (= data/theatres/<id>.json), leg(sea|land|air), label, summary, edition? }], note }
```
Each `id` must have a config in `data/theatres/`; `leg` must equal the config's `grid.domain`; the
validator warns when Sub / Launcher / Air Watch is present without a matching leg. The preview
embeds `dist/maps/<id>.html` as base64 (`window.LG_MAPS`); the extension packages
`dist/maps/ext/<id>.html` and overlays live ADS-B hits on air theatres via `postMessage`.

### collector (opt, v3) — the local collector plan
```
collector: { framingNote (req — reads-only / own accounts / loopback / unverified), endpoint (loopback URL only),
             sources[{ kind(enum), handle|id|url, label, lane(enum), enabled(bool), note,
                       lat?, lon?, dist? (adsb sectors), areas[]?, keywords[]? (navwarn) }], note }
```
`python -m lg_collector init --from-data assets/extension/data.js` seeds `config.toml` and the
watchlist from this block plus the scanner dictionaries and the live/track sectors. Discord ids are
numeric snowflakes, never tokens or invites; rss/web urls must be https; the validator ERRORS on
anything that looks like a secret (bot token, api_hash, phone number, API key) anywhere in data.js.

### osint (rec)
`{ signalChain[{t,layer,what,src}], signalChainNote, channels[], channelNote, channelSuggestions[], directory[] }`
- `channels[]`: `{ handle, label, lane(enum), note, enabled(bool), verified(bool), verifiedOn? }`.
  **Only verified public handles ship enabled** — the validator ERRORS on `enabled` (or unset,
  which the worker treats as enabled) while `verified !== true`, and warns when `verified` lacks a
  `verifiedOn` date. Verify by fetching `https://t.me/s/<handle>` and confirming a post stream
  (`scripts/verify_channels.js` automates the check).
- `directory[]`: `{ group, sub, items[{name,handle,note,rel,src}] }`.
- The extension's worker seeds at most the FIRST 16 `channels[]` entries (`MAX_CHANNELS`) — put the
  enabled set first and keep the verified bench (`enabled:false`) after it; the collector reads the
  bench through your own session via `collector.sources`.

### stateMedia (rec) `{ intro, framing[{k,v}], outlets[{name,native,grade,kind,control,beat}], rss[] }`
### social (rec) `{ intro, ethics, platforms[{name,native,hot(bool),control,caught,access}], method[{when,what,src,limit(bool)}] }`
### academia (opt) `{ updated, headline, intro, framingNote, gradeNote, stanceLegend[{key,label,body}], countries[{cc,flag,name,stance(enum),stanceNote,institutions[{name,org,url,focus,grade}]}] }`
### sourceReliability (rec) `{ legend{reliability,credibility}, note, entries[{source,grade,role}] }`
### security[] (req, ≥5) `{ k(letter), h(heading), p(paragraph) }` — keep accurate to the actual build.
### sources (req) — string naming the baselines with their editions / years.

---

## Minimum viable per-country fill

`meta`, `posture`, `product` (BLUF + ≥4 KJs + changes), `matrix.domains` (≥8),
`forces` (totals with ≥1 `alt`, branches, 2–3 systems groups, leadership board),
`iwBoard.indicators` (≥8, with the invisible ones marked `unseen`), `ach` (3–4 hyps × 6–10
evidence with real `I` cells), `movementWatch` (dictionary in the country's language),
`trackWatch` (real designators, sector, tripwire), `osint.channels` (verified or OFF),
`sourceReliability`, `security`, `sources`. Add `protective` when the protective layer is in
scope; `escalation` when a conflict pathway is the analytic question.

For a nuclear-forces build add `subWatch` (sea leg), `airWatch` (air leg), `launcherWatch` (mobile
land leg), `triadMaps` (one theatre per leg present) and `collector` (the collection plan).

Never leave `TODO` in shipped content — the validator errors on it.
