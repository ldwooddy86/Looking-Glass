# Geodata, grids and projections

## The layers

`scripts/maps_fetch_geodata.sh` pulls the Natural Earth 10 m GeoJSON layers (sea, land and air domains) (~85 MB, public
domain) into `geodata/` (override with `$LG_GEODATA` or an argument):

- `ne_10m_land`, `ne_10m_minor_islands` — the coastline. Both are needed: minor islands carry the
  Paracels, the Spratlys, Bear Island, the Kurils and most of what matters for a submarine map.
- `ne_10m_bathymetry_{L_0,K_200,J_1000,I_2000,H_3000,G_4000,F_5000,E_6000,D_7000,C_8000,B_9000,A_10000}`
  — nested depth polygons. `maps_prep_geo.py` tests them outward-in and stops at the first miss, which
  is why they must all be present even though only eight classes survive into the raster.

Natural Earth is public domain (CC0-equivalent); the attribution line in the map footer is
courtesy, not obligation.

## What `maps_prep_geo.py` produces

`build/<id>/grid.json`
: The lat/lon raster, run-length encoded. Values 0–7 are bathymetry classes; **255 is land**.
  Row-major from `lat0` upward, cell centres at `lon0 + (c+0.5)·step`.

`build/<id>/geo.json`
: `W`, `H`, the projection constants, and four SVG path strings — `land`, `shelf` (200 m),
  `deep` (2,000 m), `abyss` (4,000 m) — projected and simplified. Path precision is one decimal
  place at a 1,000-unit width, which is about 50 m at ocean scale.

Both are inlined into the HTML at build time. A theatre's geodata is typically 100–250 KB of the
final file; the rest is the model, the config and the styling.

## Choosing a grid

| theatre kind | step | cells | note |
|---|---|---|---|
| coastal box (North Korea) | 0.1° | ~18k | ~6 nm cells; resolves harbour entrances |
| regional sea (Israel, India, China) | 0.15–0.2° | 25–70k | ~9–12 nm |
| ocean basin (US, Russia) | 0.25° | 55–85k | ~15 nm; anything finer is slow in the browser |

The validator warns above 130,000 cells. The browser cost is dominated by the Dijkstra passes
(one per base per shallow-cost setting) and the per-class prior; both are linear in cells, and
the first render happens once at load.

## Projections

**`mercator`** below about 60° of latitude. Simple, conformal, and what everyone expects a sea
chart to look like.

**`lcc`** (Lambert conformal conic) above it. Mercator at 75°N stretches by a factor of four and
makes the Barents look like the Pacific. Set the two standard parallels inside the frame — a good
default is one-sixth and five-sixths of the latitude span:

```json
"projection": { "type": "lcc", "lon0": 25, "lat1": 62, "lat2": 79, "lat0": 71 }
```

`lon0` is the central meridian (put it through the middle of the frame), `lat0` the reference
parallel. `maps_prep_geo.py` computes `n`, `F`, `rho0` and the fit constants and writes them into
`geo.json`; `app.js` re-implements exactly the same maths for the hover inverse. **If you change
one, change both** — they are the same eight lines twice, deliberately, so the page has no
projection dependency.

Under LCC the lat/lon bbox draws as a **trapezoid**, not a rectangle. `app.js` draws that
trapezoid as the map sheet (a filled path in the `#base` SVG, under everything) so the frame
reads as deliberate.

## `force_open` — the one thing that always bites

`maps_prep_geo.py` samples the **centre** of each cell. Any channel narrower than one cell closes, and
a closed channel means:

- a base that cannot reach open water (the validator catches this: *no sea cell within 8 cells*),
- a sea area that gets zero mass because it is unreachable (the validator does **not** catch this
  — you have to notice the region table),
- a transit route that detours absurdly.

`force_open` is a list of `[lon, lat, lon, lat]` segments, each drawn as 60 open-water samples
along a straight line, applied after rasterising. Segments chain: give a canal several.

Channels that needed forcing in the reference theatres:

| theatre | forced |
|---|---|
| china-scs | Qiongzhou, Taiwan Strait, Bashi/Balintang/Babuyan, Miyako, Kerama, Osumi, Tokara, Bohai Strait, Balabac, Mindoro, San Bernardino, Surigao, Singapore, Malacca, Sunda, Lombok, and every base's own approach |
| russia-north | Kola Inlet and the Gadzhiyevo/Litsa/Ara/Olenya bays, the White Sea throat and Severodvinsk approach, Kara Gate, Matochkin Shar |
| russia-pacific | Avacha Bay mouth, La Pérouse, Tsugaru, Tatar Strait, First Kuril, the Vladivostok and Bolshoy Kamen approaches |
| india | Visakhapatnam and Rambilli entrances, Mumbai, Karwar, Port Blair, Palk Strait |
| us-atlantic | St Marys (Kings Bay), the Thames (Groton), Chesapeake entrance, Gibraltar |
| us-pacific | Hood Canal → Admiralty Inlet → Juan de Fuca (four chained segments), Pearl Harbor, Point Loma |
| israel | the Suez Canal (six chained segments), the Gulf of Aqaba, Tiran, Bab el-Mandeb, Hormuz |
| north-korea | Korea Strait, Jeju, the NLL islands, Korea Bay entrance |

**How to find a missing one:** build, then probe the sea distance to the far side.

```js
const d = M.srcFor('haifa', 1.3).dist;
const i = M.cellIndex(43.0, 13.0);       // Bab el-Mandeb approach
console.log(isFinite(d[i]) ? Math.round(d[i]) + ' nm' : 'UNREACHABLE');
```

`UNREACHABLE`, or a distance far longer than a chart says, means a channel is closed.

## Other geometry traps

- **Antimeridian.** Nothing in the engine wraps longitude. A theatre that spans 180° must be cut
  (us-pacific stops at −180, russia-pacific at 178°E) and the limits text must say so.
- **Polygon vertices outside the bbox** are a warning, not an error — the mask simply clips. But
  a region polygon that runs outside loses the mass it was meant to catch.
- **Point sets outside the bbox** are silently useless: a `pressure` source at a base beyond the
  frame contributes nothing. Either move the frame or add an in-frame proxy point labelled
  *(out of frame)* with a reduced weight, as russia-pacific and north-korea do.
- **Bases on the wrong side of a spit.** Gadzhiyevo, Bangor and Sinpo all sit inside inlets;
  check the sea cell the model actually picked (`srcFor(key, cost).cell`) rather than assuming.
- **Region overlap.** First match wins, in array order. Put the small specific regions before the
  large general ones.

## Ice

There is no ice layer. `russia-north` treats the marginal ice zone as an analyst polygon with a
`pressure` shield (MPA sonobuoys and MAD do not work through ice), and `russia-pacific` makes
winter ice a scenario switch. Both say in `limits_html` that the edge is a seasonal
approximation. If you need real ice, NSIDC publishes monthly extent shapefiles — but then the map
needs a date, and dating a structural prior invites exactly the misreading the rails exist to
prevent.
