# LAUNCHERS.md — road-mobile launcher catalogue (Launcher Watch)

What the Launcher Watch tab tracks and what each system looks like in open sources. Use it to fill
`launcherWatch.fleet[]` and `garrisons[]`, the collector watchlist and the land theatre's classes.
Garrisons are towns and regions. Field positions, routes and alert states are never observable and
never written; the land theatre draws a structural prior over dispersal areas, nothing more.

## Roles (the `role` enum)

`ICBM` · `IRBM` · `MRBM` · `SRBM` · `GLCM` · `HGV` · `dual-capable` · `SAM` (nuclear-armed interceptors) · `other`

## The three layers a mobile force shows

| tier | layer | Russia example | how it reaches OSINT |
|---|---|---|---|
| t1 | announced | "APUs entered combat patrol routes; 100-km march; field positions prepared and camouflaged; counter-sabotage" (TASS, Oct 2024 template) | MoD/TASS within hours; monthly cadence per division |
| t1 | tested | Yars from a Krona shelter at Plesetsk (21 May 2026); Sarmat claim (12 May 2026) | closure boxes days before; launch video after |
| t2 | garrison / construction | vehicle sheds, Krona shelters, Asipovichy's four-layer perimeter and rail spur, Krichev-6's railhead and pad | commercial imagery via FAS / ACW / Janes, weeks late |
| t3 | field / custody | regiments on patrol; 12th GUMO convoys; warheads mated | never — mark UNSEEN |

## Russia (flagship)

| system | role | launchers (Sep 2026) | chassis | garrisons (towns) | what OSINT sees |
|---|---|---|---|---|---|
| RS-24 Yars (SS-27 Mod 2) mobile | ICBM | 180 in 7 divisions (18–36 each) | MZKT-79221 16×16 | Teykovo, Yoshkar-Ola, Vypolzovo/Bologoye, Nizhny Tagil, Novosibirsk, Barnaul, Irkutsk | patrol announcements; exercise launches; garrison imagery |
| RS-12M2 Topol-M mobile | ICBM | 18 (Teykovo) | MZKT-79221 | Teykovo | as above; retirement/conversion is the next change |
| 9K720 Iskander-M | dual-capable | 156 in ≈13 brigades (+ Kapustin Yar unit) | MZKT-7930 8×8 | Luga, Chernyakhovsk, Shuya, Kursk, Kamenka, Mozdok, Yelanskiy, Goryachiye Klyuchi, Gorny, Ulan-Ude, Birobidzhan, Spassk-Dalniy, Znamensk; Belarus: Asipovichy (465th) | daily combat use against Ukraine; production claims (HUR); Belarusian drills |
| Oreshnik | IRBM | battalion (2–3) at Krichev-6, Belarus; test unit at Kapustin Yar | RS-26-lineage TEL | Krichev (Mogilev region) | construction imagery; MoD combat-duty claim; Nov 2024 Dnipro use |
| 9M729 / SSC-8 | GLCM | 16 | Iskander-family TEL | within Iskander brigades | indistinguishable from Iskander-K in imagery |
| RS-28 Sarmat (silo) | ICBM | 0 on duty; 6 Uzhur silos converting | silo | Uzhur | test claims; silo work in imagery |
| Avangard | HGV | 12 (silo) | UR-100N silo | Dombarovsky | — |

**Dispersal inputs used by the land theatre:** ≈100-km marches (patrol radius); one positional
district per division; regiment-level drills near-monthly, division-level in strategic exercises;
brigade dispersal by battalion (4 TELs) for Iskander; a short envelope for the Oreshnik battalion.

**Custody:** the 12th Main Directorate (12th GUMO) holds warheads at central 'Object S' sites and
forward storage; nothing public sees a transfer. Belarus's Asipovichy depot is the candidate
forward site — perimeter and rail work are the observables; no warhead has been seen.

## Other subjects (starting points)

| subject | mobile systems | garrisons as towns | notes |
|---|---|---|---|
| China | DF-41, DF-31AG (ICBM); DF-26 (IRBM, dual-capable); DF-21 (MRBM); DF-17 (HGV); CJ-100 (GLCM) | PLARF brigade garrisons (Xinyang, Yuxi, Nanyang, Tongdao, Shaoyang, Kunming, Jianshui, Danyang…) | brigade numbering (61x–66x) and garrison towns are public; DF-41 road-mobile brigades ≈3 |
| North Korea | Hwasong-15/17/18/19 (ICBM); Hwasong-12 (IRBM); KN-23/24/25 (SRBM); Hwasong-16B (HGV) | Sunchon, Kusong, Sinpo-area, Pyongyang-area | TEL counts are the binding constraint; parades and state media are the observables |
| India | Agni-P / Agni-V (canisterised, road/rail), Prithvi, Shaurya | Secunderabad, Wheeler Island tests | SFC basing largely unpublished |
| Pakistan | Shaheen, Ghauri, Nasr (dual-capable SRBM), Babur GLCM | Army Strategic Forces Command garrisons | — |
| United States | none road-mobile (Minuteman III / Sentinel silo; Typhon/Dark Eagle conventional) | — | Launcher Watch not applicable; use for allied GLCM/IRBM deployments if in scope |
| Iran | Khorramshahr, Emad, Sejjil, Fattah (conventional; nuclear status undeclared) | IRGC-ASF missile cities | never assert a nuclear capability |

Every garrison row carries `sees` (what imagery/announcements show) and a `src`; every fleet row
carries two counts where sources disagree (`launchers` + `alt`).
