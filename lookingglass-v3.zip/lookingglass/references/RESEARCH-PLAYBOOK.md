# Research playbook — bringing a country current on the build date

The main failure mode of a monitor is a **frozen snapshot**: numbers carried from a prior build
or from the model's training, stamped with today's date. This playbook is the search plan that
prevents it. Run it in order; every figure in `data.js` should be traceable to a hit from it.

## 0. Rules

1. **Search every perishable fact on the build date** with a recency-scoped query (year +
   "latest"/month). Perishable = commanders and command-chain changes, the latest budget, the
   newest exercise/test/deployment/incident, treaty and sanction status, leadership rhetoric.
2. **Dual-source anything load-bearing** and show the spread: official budget vs. SIPRI real
   spend; IISS vs. DoD hull/launcher counts; FAS vs. DoD warheads. One source → grade it down
   and phrase it as such.
3. **Date-stamp to the source edition.** `meta.compiled`/`product.asOf` are today; each figure
   is no older than its source's latest edition; the footer names those editions.
4. **Prefer primary and reference sources** in this order: official releases (MoD/MND, NPC,
   national statistics) → reference databases (IISS Military Balance, SIPRI, FAS Nuclear
   Notebook, DoD/allied assessments) → institutes (CSIS, RAND, ASPI, RUSI, NIDS, INDSR, CNA)
   → specialist press (Defense News, USNI News, Naval News, The Aviationist, Janes, The
   Diplomat, War on the Rocks) → wire/quality press → aggregators. State media is a primary
   source for *what the state said*, never for ground truth.
5. **If unsure, omit.** A blank cell honestly graded `F6` beats an invented number.

## 1. Baseline (force structure, budget, doctrine)

- `<country> "Military Balance" <year> personnel budget order of battle`
- `<country> defense budget <year>` + `SIPRI <country> military expenditure <year>` (real spend)
- `<country> nuclear weapons <year> "Nuclear Notebook"` (nuclear states) · `<country> missile forces <year>`
- `<country> navy ships <year>` (hull counts, commissioning) · `<country> air force aircraft <year>`
- `<country> army brigades divisions <year>` · `<country> space counterspace <year>` (SWF report)
- `<country> cyber advisory <year>` (CISA/NCSC/ASD advisories, vendor threat reports)
- `<country> military doctrine white paper <year>` · `<country> arms control treaty status <year>`

## 2. Perishables (the monitor's heartbeat)

- `<country> military leadership <year>` · `<country> <service> commander appointed <year>` ·
  `<country> general purged OR dismissed OR investigated <month year>`
- `<country> military exercise <month year>` · `<country> missile test <month year>` ·
  `<country> deployment OR patrol <month year>`
- `<country> incident OR clash OR collision <month year>` (gray-zone, coast guard, intercepts)
- `<country> sanctions OR export controls <month year>` · `<country> summit <year>` (leader-level
  diplomacy that reprices risk)
- Regional counterpart releases: e.g. Taiwan MND daily PLA-activity counts, Japan Joint Staff
  transit notices, Philippine Coast Guard statements — the authoritative baselines the OSINT
  community anchors to.

## 3. Domain sweeps (populate the matrix, forces and I&W rows)

Ground · naval · air/air defence · missile/rocket · nuclear/strategic (custody, silos, SSBN
patrols, early warning) · space/counterspace · cyber/EW/IO · gray-zone & coast guard ·
amphibious/lift · logistics/sustainment · leadership/command reliability · allied collection
posture (the mirror indicator). For each, note the *primary* discipline that sees it and where the
gaps are — that is the `ints{}` coverage row.

## 4. Protective-intelligence layer (when in scope)

- `<country> terrorism <year>` · `"Global Terrorism Index" <year> <country>`
- `<country> attack <month year>` (mass-casualty incidents: vehicle, knife, arson, aviation)
- `<actor> threat <country> <year>` for each relevant actor (domestic separatists, transnational
  jihadist branches, diaspora militants, lone actors)
- `<country> nationals attacked abroad <year>` · `<country> embassy travel advisory <year>`
- `<country> critical infrastructure attack OR sabotage <year>` · `<country> data center <year>`
  (sector scale, hubs, policy) · `data center drone attack <year>` (global precedent)
- `<country> counter-terrorism law OR security measures <year>` (the protective posture)
Write what you find as threat levels, target classes, exposure and posture — see
`TRADECRAFT.md` §8 for the framing rails.

## 5. Live-layer verification

- Telegram: fetch `https://t.me/s/<handle>` for every candidate; a public post stream shows
  `tgme_widget_message` elements. Contact-only pages ("send a message") are NOT channels.
  Record `verifiedOn`. Check the newest post date — a stream dead for months is a suggestion, not
  a lane. `scripts/verify_channels.js` does this for the whole `osint.channels` list.
- ADS-B: pick designators from `references/ADSB-TYPES.md` (verified against ICAO Doc 8643) or
  verify at `doc8643.com/aircraft/<CODE>`. Prefer `regs`/`hex` for a specific airframe.
- Sector: a fixed public map location relevant to the question (a strait, an approach, a base
  region the allied ISR fleet works from) — never a live position of the subject's forces.

## 6. Recording

Put the source in a `src`/`basis`/`note` field beside the claim, name editions in `meta`/footer
`sources`, and keep a scratch research log (facts + URLs + dates) while you fill `data.js` so the
red-team pass (`TRADECRAFT.md` §6) can reconcile numbers across sections.


## 7. Nuclear-forces legs (v3: Sub · Air · Launcher Watch, Triad Map, collector)

Run these sweeps after §1–§3 and before scaffolding:

- **Baseline:** the FAS/Bulletin Nuclear Notebook for the subject (warheads, launchers, bases,
  per-division/regiment structure), russianforces.org-class status notes, IISS, SIPRI. Record two
  figures where they diverge (`alt`).
- **Air leg:** bomber and dual-capable basing from imagery counts (AviVector-class spotters, Planet
  via press), loss claims with confirmation status, tanker/AEW/airborne-command-post fleet size,
  patrol releases (NORAD, Japan Joint Staff, Nordic QRA), demonstrated launch geometry from strike
  reporting. Verify ICAO designators for the live board at `doc8643.com/aircraft/<CODE>` and add them
  to `references/ADSB-TYPES.md`.
- **Mobile land leg:** divisions/brigades with garrison towns, the announced patrol pattern (the
  MoD/TASS template sentence), exercise scale, test launches (closure boxes), forward deployments
  (construction imagery from FAS/ACW/Janes), production and inventory claims (single-side, graded).
- **Sea leg:** as `MAPS-RESEARCH-PLAYBOOK.md`.
- **Monitoring ecosystem:** the adversary-side alert channels (for Russia: the Ukrainian Air Force
  and the activist monitors), the subject's official and milblogger lanes, the exile press, the
  imagery lane; verify every handle with `scripts/verify_channels.js` and order `osint.channels` so
  the first 16 are the enabled set.
- **Collector plan:** RSS feeds verified with a fetch (many sites have no feed); Bluesky handles
  confirmed to exist; ADS-B sectors at fixed public locations with real receiver coverage (dense
  along NATO borders, sparse inside the subject); NAVAREA/HYDRO codes for the closure boxes that
  matter; NOTAM locations only if the operator has FAA API credentials.
- **Theatre configs:** cite every base, factor and point with a `LG-<CC>-Lnn` / `-Ann` reference
  in `references/countries/<slug>.md`; keep the sea theatres' `CD-<CC>-nn` scheme.
