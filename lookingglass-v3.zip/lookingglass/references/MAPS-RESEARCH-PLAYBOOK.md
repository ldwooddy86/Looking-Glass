# Research playbook

The engine is stable; the facts are not. This is what to re-check, where it actually lives, and
which sources waste the budget.

---

## Re-check before every build

For each class:

- [ ] **Hull count and status** — commissioned, launched, fitting out, in refit, sunk, retired.
- [ ] **Base assignment** — fleets move boats (Imperator Aleksandr III went to the Pacific in
      2024; Borei-As keep arriving).
- [ ] **Missile** — type, range, whether it is actually deployed or just tested.
- [ ] **Most recent test launch** — date, sea area, what was notified.
- [ ] **Most recent published detection or port visit** — who published it and where.
- [ ] **Adversary basing changes** — a new P-8 detachment or an access agreement changes the
      `pressure` field.
- [ ] **Anything the last edition marked "expected"** — did it happen?

For the theatre:

- [ ] **Patrol-rate estimates** — the at-sea counts are the softest numbers on the map.
- [ ] **New yards, tunnels or bases** — INS Varsha, the Huludao halls, Berbera.
- [ ] **Arms-control status** — New START expired February 2026; the ceilings that shaped several
      of these forces no longer apply.

---

## Sources that carry weight

**Annual authorities** — the spine of the country briefs.
- *Bulletin of the Atomic Scientists* / FAS **Nuclear Notebook**, one country per issue. The
  single best source for hull counts, missile status, warhead estimates and patrol practice.
  (`Russian nuclear weapons, 2026`; `Indian nuclear weapons, 2026`; `Chinese nuclear weapons, 2026`.)
- **DoD China Military Power Report** (annual, December).
- **IISS Military Balance** and its shipbuilding analyses (*Boomtime at Bohai*).
- **SIPRI Yearbook** for stockpile figures and spending.
- **ONI** publications and testimony, when they surface.

**Naval trade press** — the fastest accurate reporting on hulls.
- *Naval News* (launches, imagery reads, annual fleet reviews), *USNI News* (US Navy, Japanese
  Joint Staff releases), *TWZ/The War Zone*, *Janes*.

**Imagery analysis** — CSIS *Beyond Parallel* (DPRK), FAS Strategic Security Blog, *38 North*,
CSIS *Hidden Reach*, AMTI, H I Sutton's work, Planet/Maxar/Vantor-derived analyses in the trade
press.

**Government primary** — Japan Joint Staff releases (published detections and transits), ROK JCS,
Taiwan MND daily counts, NAVAREA navigational warnings (they announce launch boxes),
Norwegian and Barents-region official statements.

**Regional specialists** — *The Barents Observer* (Kola, Arctic, Norway's MPA policy),
*russianforces.org* (Russian strategic forces, exercise reconstruction), CMSI/Naval War College
reports (China maritime), *War on the Rocks* and CIMSEC for doctrine.

---

## Sources to treat as leads, not findings

- Anonymous-official claims in a single outlet, until a second outlet with its own sourcing
  confirms.
- Substack and commentary aggregators, however plausible — cite them as a lead and label them
  ("single commentary source" in the Israel theatre's July 2026 Tiran report).
- Denied reports (Berbera). Keep them, mark the denial, weight them at or near zero.
- Outlier hull counts. Press claims of "≈32 Chinese nuclear boats" count launched hulls and new
  classes; the Notebook and IISS numbers are the ones to use, with the outlier noted.
- State media on its own capabilities — useful for *intent* and for what the state wants seen,
  not for performance.

---

## Fetching, in this environment

- `WebSearch` returns links, not content. Budget one search per question, then fetch.
- `WebFetch` on the trade press and think-tank sites generally works.
- **Wikipedia is cache-only** for the category and list pages — fetch the specific article
  (`/wiki/Dolphin-class_submarine` works; `/wiki/Category:Borei-class_submarines` does not).
- Some publishers return 403 (`tandfonline`) or are disallowed by robots (`bloomberg`). Reach the
  same content through the summarising outlet, or through the think tank's own copy.
- Provenance prompts can time out on a first fetch; a second attempt on the same URL usually
  succeeds, and a search result that already carries the URL primes it.
- Fetch prompts should ask for **structured extraction** ("list every boat with name, fleet, base,
  commissioning date, status"), not summaries. The map needs fields.

---

## Coordinates

Base and facility coordinates come from public references — Wikipedia infoboxes, GlobalSecurity,
NTI country profiles, naval-encyclopedia. Verify two ways when a base sits inside an inlet
(Gadzhiyevo, Bangor, Sinpo, Rybachiy): a coordinate that lands on the wrong side of a spit
produces a plausible-looking map with a wrong egress.

**Never** derive a coordinate from imagery analysis of an operational site beyond what the public
reference already names, and never map anything at a resolution finer than the sources support.

---

## Inferred geometry — the one place to be very careful

Some launch positions are not reported, only implied. China's 6 July 2026 SLBM shot was described
as "from the South China Sea, over northern Luzon, ~7,300 km, to a box between Nauru and Tonga" —
enough to back-project a great circle and get 20–21°N, 115–118°E.

That is legitimate, and it is in the map. It is labelled **(inferred)** on the marker, described
as "an inference from stated geometry, not a reported coordinate" in the factor note, and given a
170 nm radius circle rather than a point. Do all four of those things or do not do it at all.

The back-projection, for reuse:

```python
import math
R = 6371.0
def to_xyz(lat, lon):
    la, lo = math.radians(lat), math.radians(lon)
    return (math.cos(la)*math.cos(lo), math.cos(la)*math.sin(lo), math.sin(la))
def gc_extend(A, B, km):        # point km beyond A, on the great circle from B through A
    a, b = to_xyz(*A), to_xyz(*B)
    dot = sum(i*j for i, j in zip(a, b))
    t = [b[i] - dot*a[i] for i in range(3)]
    n = math.sqrt(sum(i*i for i in t)); t = [-i/n for i in t]
    ang = km / R
    p = [a[i]*math.cos(ang) + t[i]*math.sin(ang) for i in range(3)]
    n = math.sqrt(sum(i*i for i in p)); p = [i/n for i in p]
    return math.degrees(math.asin(p[2])), math.degrees(math.atan2(p[1], p[0]))
```

Feed it the overflight point and the impact box, walk the distance back, and check the total range
matches what was reported.

---

## Editions

Stamp `meta.compiled` and `meta.edition` on every build, and put what changed in the delivery
message. A structural prior is not a snapshot of anything, but the *evidence* is dated, and a
reader six months from now needs to know which facts the map was built on.
