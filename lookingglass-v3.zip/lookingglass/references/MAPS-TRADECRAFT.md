# LOOKING GLASS map tradecraft (Countdown) — choosing weights honestly

The model is arithmetic. The analysis is in which factors you include, how hard you push them,
and how loudly you say what you do not know. This file is the part that keeps the map honest.

---

## 1. The question, exactly

> **Conditional on a boat of this class being at sea, where is it?**

Not "where is the boat" (unknowable). Not "where will the boat be" (a forecast this cannot make).
Not "how many boats are out" (an assumption you declare). The conditional is the whole product,
and every piece of prose must respect it.

The corollary: a boat alongside contributes nothing to the surface. That is why North Korea's
map has an at-sea count of 0.15 and a note saying the honest baseline has often been zero. The
map is still useful — it says where a boat *would* go — but the number on the tile is a premise.

---

## 2. The four doctrinal archetypes

Decide which one applies **before** you tune anything. Getting this wrong produces a map that is
precise and wrong.

### Bastion
*Russia (both fleets), China, India, and — for different reasons — North Korea.*

The boat stays in protected home water under its own navy's umbrella, because the missile's range
means it does not have to leave and the acoustic disadvantage means it should not. Signature
factors: a `zones` bastion polygon, a `hubs` own-umbrella, a `line_exposure` at the barrier the
adversary listens on, a `pressure` field for adversary maritime patrol, and an `envelope` at the
edge of the doctrinal range. The prior comes out tight — tens of thousands of square miles — and
that tightness is a real finding about the force's design, not about your model.

The trap: **making it tighter than the evidence.** Bastion doctrine tells you the *shape*, not
the box. Give the outer basin real weight; a 094 is not glued to the Paracels.

### Open ocean
*The United States, and by the same logic the UK and France.*

There is no bastion. Trident covers the target set from anywhere in the ocean and the design goal
is unpredictability. The prior is an **exclusion map**: what the boat avoids (shelves, confined
seas, shipping lanes, the escorted egress, water where adversary collection has been reported)
rather than where it goes. The 50 % region comes out at hundreds of thousands or millions of
square miles.

**That is the correct answer and you must say so in the BLUF.** A tight US SSBN prior means a
factor is asserting something the evidence does not support. The value of the map is the
exclusion, the launch water, and the honest scale of the uncertainty.

### Coastal
*North Korea.*

The limit is the hull, not the doctrine. Romeo-derived boats are slow, loud and short-legged; the
crews have never demonstrated a long patrol. Model it with a short `decay_nm`, a tight
`envelope`, a strong own-cover `hubs` term at small scale, and a heavy adversary `pressure`
field. The prior collapses onto a coastal box — which is the finding.

Keep the capability scenario (a nuclear hull) as a **switch**, not a baseline.

### Undeclared
*Israel.*

The state neither confirms nor denies. Model **where the flotilla operates**; never assert what
it carries. Range circles drawn from reported missile performance are labelled as reported. The
triad tab presents external estimates as external estimates, in `notes_html`, in as many words.

---

## 3. Evidence classes, and what each is worth

| evidence | weight it earns | how to use it |
|---|---|---|
| **Basing** (imagery, official) | structural — it sets the sources | `bases` + `sources` shares |
| **Missile range** | structural — it sets the envelope | `envelope.wall_nm` |
| **Bathymetry** | structural, external | `depth_suitability` |
| **Declared doctrine** (bastion, NFU, patrol practice) | strong zone weights | `zones` |
| **Demonstrated launch geometry** (notified tests, NAVAREA warnings) | *modest* bump, 0.3–0.5 | a `points` entry |
| **Published detections** (Japan Joint Staff, ROK JCS, MND) | small bump, 0.2–0.35 | a `points` entry |
| **Publicised port visits** | very small, 0.1–0.2 | a `points` entry — signalling, not patrol |
| **Adversary ASW basing** | a real, continuous penalty | `pressure` |
| **Adversary collection episodes** (survey ships, intel ships) | small negative | a `points` entry with negative `amp` |
| **Single-source or denied reports** | ≤0.1, and labelled in the note | a `points` entry, graded in the text |

**Launch water is not patrol water.** Every one of these maps has a demonstrated launch point,
and on every one of them it earns a bump of 0.3–0.5 and no more. Crews shoot where the range
safety and the notification allow; they patrol where they are safe. Conflating the two is the
single easiest way to produce a confident, wrong map.

**Detections are where the boat was caught, not where it lives.** A published contact tells you
the class uses that gap — which is a *route* fact, and the flow layer already carries routes.
Give it a small bump and let the routing do the work.

---

## 4. Positive and negative factors

- `hubs` (own umbrella) and `points` with positive `amp` **attract**. Use them for protection the
  boat's own navy provides and for water the record shows the class uses.
- `pressure` (adversary ASW) and `points` with negative `amp` **repel**. Use them for capability
  that exists continuously (basing) and for episodes that have been reported.
- `line_exposure` does both: a penalty for *sitting on* the barrier, and a beyond-factor for
  crossing it. This is the right tool for the Fish Hook, the Bear Island and GIUK lines, the Kuril
  chain, the first island chain.
- `proximity` over a chokepoint set is usually **negative for nuclear boats** (they transit, they
  do not loiter) and **positive for conventional boats** (barrier patrol is their job).

Prefer an exclusion zone to bending a real factor. If mass leaks into the Baltic, add a
`zones` penalty for the Baltic; do not shorten the decay constant until it goes away.

---

## 5. Calibration checks that catch real errors

Run `maps_test_model.js` and argue with these five numbers:

1. **50 % area vs archetype.** Bastion: 10⁴–10⁵ nm². Open ocean: 10⁵–10⁶ nm². Coastal: 10³–10⁴ nm².
   Outside the band, something is wrong.
2. **T+12h near the base, T+48h at the operating area.** At 10 kt, 48 h is 480 nm. If the T+48h
   50 % region is still tiny, the destination prior is over-concentrated; if it already covers
   the theatre, the routing is not binding.
3. **On-station fraction.** A 60-day patrol 300 nm from port should be >0.9 on station. A 7-day
   patrol 100 nm out should be lower. If a long-patrol class reads 0.5, the decay is too long for
   the patrol length.
4. **Top region sanity.** Is it the strongest evidence or the biggest polygon? Re-cut regions
   first, then re-tune.
5. **"Elsewhere in frame".** Over ~10 % means the region set has a hole; the mass table is the
   map's tabular twin and it must account for the surface.

---

## 6. Posture and scenarios

**Posture** is a dial the reader turns: guarded → elevated → high → severe. It should change
*emphasis*, not shape — forward-deployment weights, bastion concentration, at-sea counts. If
switching to HIGH produces a different map rather than a sharper one, you have put a scenario in
the posture.

**Scenarios** are contingent facts that change the shape: a new class quiet enough to leave the
bastion, a surge through a gap, a season of ice, a base opening, a missile entering service. Each
one is off by default, with a note saying what it would take to justify turning it on.

Never use a scenario to smuggle in a claim. "Type 096 scenario" is legitimate because the DoD says
the boat is coming; "boats are armed at sea" would not be, because nobody can confirm it.

---

## 7. Writing the prose

- **BLUF first, caveat immediately after.** The `bluf_warn_html` is not boilerplate: it is the
  sentence that stops a reader treating the map as a track.
- **State confidence per class, separately from the likelihood.** "A tight prior at MODERATE
  confidence" and "a diffuse prior at LOW confidence" are different claims.
- **Name the largest judgment call.** Every theatre has one — the SSK fleet split for China, the
  Arabian Sea share for India, the at-sea counts everywhere, the whole nuclear premise for Israel.
  Say which it is, in the class judgment or the method text.
- **List what would move the map.** `movers_html` should be actionable: which observation, which
  factor it would change, which direction.
- **List the limits.** Cell size, seasonal effects you did not model, sensors that are not public,
  water outside the frame.

---

## 7b. Land and air theatres (v3)

The sea archetypes have land and air cousins.

- **Positional district (land).** A mobile ICBM division's prior is its garrison's road network
  under cover within the announced patrol radius: terrain suitability rewards covered road
  corridors, penalises open ground and towns; the envelope soft-walls the routed distance at the
  doctrinal march; `deployed` is the exercised fraction at each posture; an exercise scenario
  lengthens the envelope and can swap source shares. Brigade-level dual-capable forces get the same
  treatment with a wider envelope. Do not model a belligerent's wartime deployment areas.
- **Sanctuary stand-off (air).** A bomber force's prior is own and international airspace within
  the unrefuelled radius of the bases sorties *start from* (staging bases for strike sorties, the
  main base for patrols and transits), bumped by demonstrated launch water and patrol lanes;
  adversary airspace is a near-exclusion; tanker support enters through the posture modifier; an
  Arctic-dispersal scenario swaps the source shares. The 50 % region will be large — a 23-hour
  sortie is mostly transit — and the prose must say so.
- **Forward battalion (land).** A partner-territory deployment (an Oreshnik battalion) is a short
  envelope around a site whose existence is public; keep it a class of its own so the reader can
  switch it off.

Calibration for land and air: the 50 % region at the default posture should sit inside the
announced doctrine (patrol radius; unrefuelled radius) with no mass in adversary territory or
airspace; if a garrison or base carries more than half the class, say why (regiment counts, sortie
origins) in the judgment text.

## 8. Things this skill will not do

- Produce, imply or predict a position, track, patrol box, field position, route or alert state for any boat, launcher or aircraft.
- Model where a country's *warheads* are, or infer custody, mating or alert status.
- Use non-public sourcing, or attempt to defeat anyone's operational security.
- Assert a nuclear capability for a state that has not declared one.
- Present a single-source or denied report as a finding.

If a request needs one of those, decline that piece and deliver the rest of the map.
