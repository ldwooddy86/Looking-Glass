---
name: lookingglass
description: "LOOKING GLASS — the unified nuclear-forces watch. Merges DalesOracle (all-source OSINT posture monitor, IC tradecraft, protective layer, hardened Chrome MV3 extension) and Countdown (Bayesian operating-area heatmaps) for any nuclear power: Sub Watch, Air Watch (bombers, dual-capable fighters, tankers, airborne command posts, AEW/ISR, public-ADS-B live board), Launcher Watch (road-mobile ICBM/IRBM/SRBM garrisons, dispersal doctrine, land-leg I&W), a Triad Map tab with sea, land and air heatmaps, and a local read-only collector with working connectors (Telegram user + bot, Discord bot, Bluesky, Mastodon, Reddit, YouTube, RSS, ADS-B, NOTAM/NAVWARN) whose Claude agent triages posts, photos and video into a feed, gallery and digest. Use when the user says LOOKING GLASS, DalesOracle or Countdown; wants a nuclear-forces, triad, bomber, mobile-launcher or submarine monitor or heatmap for a country; or wants OSINT channels, Telegram or Discord pulled through their own accounts. Russia is the flagship."
license: "For Dale Wooddy / Top Shelf Logic internal use."
---

# LOOKING GLASS — the unified nuclear-forces watch

One platform, three legs, one rail. LOOKING GLASS fuses **DalesOracle's** all-source posture
monitor (BLUF / Key Judgments, capability matrix, I&W, ACH, protective layer, verified Telegram
lanes, public-ADS-B Track Watch, the hardened MV3 extension) with **Countdown's** heatmap engine
(a Bayesian structural prior over where a deployed unit *would* be), and adds the two legs the
sea-only tools never had — the **air leg** (strike and support aircraft) and the **mobile land
leg** (road-mobile launchers) — plus a **collector** that reads OSINT channels, social media,
Telegram and Discord through the operator's own accounts and lets a Claude agent triage the
posts, photos and video into a feed, a gallery and a watch digest.

The name is the mission: a looking glass shows what the public record reflects, never what is
hidden. The rail is absolute and enforced in code: **nothing this skill produces is a position, a
track, a patrol box, a field position, a route, an alert state or a target.** Quiet is unseen,
not absent. Estimates carry uncertainty. Feeds are unverified. Public reporting only.

## What ships

- `assets/extension/` — the dashboard engine (v3): 21 tabs in five groups — Assessment (BLUF,
  Capability Matrix, Forces, I&W·ACH, Intent), Watch (Movement, Track Watch, **Air Watch**,
  **Launcher Watch**, Sub Watch, **Triad Map**, **Feed**, **Media**), Protective (Terror Threat,
  Soft Targets, Infrastructure, Threat Geography), Sources (State Media, Social, Collection,
  Sources). One codebase, two modes: the self-contained preview and the installed extension.
- `assets/maps/engine/` — the heatmap engine generalised to sea, land and air domains.
- `data/theatres/` — ten theatre configs: the eight Countdown sea theatres (Russia ×2, China,
  India, US ×2, Israel, North Korea) plus `russia-land` and `russia-air`.
- `assets/extension/data.js` — the flagship **Russia** dataset (15 SEP 2026): every block filled,
  40 Telegram handles verified, 17 RSS feeds verified, four theatres embedded.
- `collector/` — the Python collector (connectors, triage/vision/digest agent, loopback API,
  exports, offline tests) and `watchlists/russia.json`.
- `references/` — SCHEMA, MAPS-SCHEMA, TRADECRAFT, MAPS-TRADECRAFT, RESEARCH-PLAYBOOK (both),
  AIRCRAFT, LAUNCHERS, CONNECTORS, ADSB-TYPES, MAPS-GEODATA and `countries/` briefs.
- `scripts/` — scaffold, verify, validate, build, package, render-check for both halves.

## The rails — never weaken these

1. **Never a position.** No unit, launcher, aircraft, boat or warhead location — real-time,
   recent or predicted. Heatmaps are structural priors conditional on deployment; the validators
   grep every config and every dashboard block for position claims and fail on them.
2. **Never targeting.** No targeting, strike-planning or force-defeat vocabulary anywhere;
   the protective layer is written for defenders only (no facilities, methods, timings, maps).
3. **Deployed counts are assumptions and say so.** `bluf_warn_html`, the leg status blocks and
   the I&W `unseen` rows carry the honesty explicitly. A blind fraction is the honest product.
4. **Reads only, own accounts, loopback only.** The extension reads public previews and public
   ADS-B; the collector reads through the operator's own sessions, never posts, joins or scrapes
   behind another login, binds to 127.0.0.1 with a token, keeps everything local, and its agent is
   told in its system prompt never to assert positions. Secrets never enter `data.js`.
5. **Every factor and every number cites its evidence.** Country-brief reference IDs
   (`CD-XX-nn`, `LG-XX-Lnn`, `LG-XX-Ann`) on the maps; `src` fields beside every claim on the
   dashboard; two figures where sources diverge.
6. **Single-side war reporting is graded as such.** Adversary intelligence claims are B2 once
   imagery confirms them and C3 until then; official statements are A1 for fact-of-statement only.
7. **Undeclared arsenals stay undeclared; the security posture never regresses.**

## Build procedure

Work in this order. The failure mode is a frozen snapshot — never skip the refresh.

### 1. Scope
Confirm or state: the **country / force**; which **legs** apply (`--sub` for nuclear-submarine
operators; `--air` for any bomber or dual-capable air force; `--launcher` for road-mobile
launcher forces; `--maps` when theatres exist or will be built; `--collector` when the operator
wants the local collector); whether the protective layer and the escalation model are in scope
(default yes for a full build); whether the extension is wanted (default yes).

### 2. Research on the build date (required)
Follow `references/RESEARCH-PLAYBOOK.md` §1–§7 and `MAPS-RESEARCH-PLAYBOOK.md`: FAS/Bulletin
Nuclear Notebook, russianforces.org-class status notes, IISS, SIPRI; per-leg sweeps (basing counts
from imagery, loss and production claims with confirmation status, patrol releases, test shots
and closure boxes, forward-deployment construction, the announced patrol pattern); the monitoring
ecosystem (adversary-side alert channels, official and milblogger lanes, exile press, imagery
lane); the collector plan (feeds that actually resolve, handles that exist, sectors with real
receiver coverage). Keep a research log of facts + URLs + dates. Verify every perishable by search;
dual-source anything load-bearing; date-stamp to the source edition; if unsure, omit.

### 3. Scaffold and populate `data.js`
```bash
node scripts/scaffold_data.js --country Russia --adjective Russian --subject "Russian Armed Forces" \
  --slug russia --flag "🇷🇺" --protective --escalation --sub --air --launcher --maps --collector \
  > assets/extension/data.js
```
Fill every block per `references/SCHEMA.md` to the depth of the Russia build (≈280 KB): posture
with `range` and `mover`; ≥6 Key Judgments with ICD-203 bands, separate confidence, grade, basis
and `whatWouldChange`; matrix ≥10 domains; forces with `alt` figures and a search-verified
leadership board; I&W ≥16 with the invisible rows `unseen`; ACH with real inconsistent cells;
Sub/Air/Launcher Watch each with a fleet board (two counts), basing, observables by tier, a leg
I&W board with `unseen` rows, doctrine, timeline and a native-language scanner dictionary; the
Air Watch `live` board with Doc-8643-verified designators; `triadMaps` listing one theatre per
leg; `collector.sources` as the verified bench; the protective layer in the defensive idiom.
Order `osint.channels` so the first 16 are the enabled set (the worker's cap).

### 4. Theatre configs (maps)
Write `references/countries/<slug>.md` reference IDs first, then `data/theatres/<slug>-land.json`
and `<slug>-air.json` per `references/MAPS-SCHEMA.md` (domain, classes with `deployed`,
`cell_cost`, `terrain_suitability`, `sources_scenarios`, envelope and points factors, regions,
text, triad). Keep sea theatres from Countdown as they are; rebrand only.
```bash
export LG_GEODATA=~/geodata LG_BUILD=build/maps LG_DIST=dist/maps     # Natural Earth 10 m via scripts/maps_fetch_geodata.sh
bash scripts/maps_build_all.sh russia-north russia-pacific russia-land russia-air
```
Each theatre runs validate → prep_geo → validate --grid → test_model → build and writes
`dist/maps/<id>.html`, `<id>.artifact.html` and `dist/maps/ext/<id>.html` (+ `.data.js`,
`engine.js`). Read `maps_test_model.js`'s region table: mass must sit inside the doctrine
(patrol radius, unrefuelled radius, bastion) with none in adversary territory or airspace.

### 5. Verify the live and collector layers
```bash
node scripts/verify_channels.js [handle …]        # t.me/s public streams, freshness, subscriber counts
curl -sI <feed-url>                               # every RSS feed must return XML
```
Verify ICAO designators at `doc8643.com/aircraft/<CODE>` and record them in `ADSB-TYPES.md`.
Only verified handles ship `enabled:true`; dead projects stay listed and disabled with the reason.

### 6. Red-team, then validate (required)
`TRADECRAFT.md` §6 and §9. Then:
```bash
node scripts/validate_data.js --strict            # schema, ICD/Admiralty coherence, ACH/Track parity, rails, secrets, no-TODO
node scripts/maps_validate_config.js data/theatres/<id>.json --grid build/maps/<id>/grid.json
```
ERRORs mean the product would ship wrong, broken or irresponsible. Fix them; review warnings.

### 7. Build, package, render-check
```bash
python scripts/build_preview.py --out-dir OUT --maps-dir dist/maps --artifact   # self-contained preview (+ Artifact fragment)
python scripts/package_extension.py --out-dir OUT --maps-dir dist/maps/ext       # <slug>-monitor-extension.zip
node scripts/render_check.js OUT/<slug>-lookingglass-preview.html --ext --shots SHOTS
node scripts/maps_render_check.js dist/maps/<id>.html --shots SHOTS --all-classes
```
Both render checks must report 0 console errors, every mount populated, the embedded map frame
rendered, hostile markup neutralised, and no horizontal overflow at phone width. Look at the
screenshots.

### 8. Collector
```bash
cd collector && python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
python -m lg_collector init --from-data ../assets/extension/data.js     # config.toml + watchlist + token
python -m lg_collector login telegram && python -m lg_collector test && python -m lg_collector run
python tests/test_offline.py                                            # 8 offline tests must pass
```
`references/CONNECTORS.md` is the operator's guide: lanes, credentials, rails, the
triage → vision → digest agent workflow, and what "working connectors" means (the registry has
no Telegram/Discord connector; the collector's own are the connectors).

### 9. Deliver
Preview HTML first (and its Artifact fragment when the session can publish), then the extension
zip, then the collector notes. Restate the rails in one breath; name the judgment calls (posture
level and range, leading hypothesis, what stayed `unseen`, how the air prior weights sortie origins,
why a lane is disabled). Keep the postamble short.

## How the heatmaps work

For class *c* and cell *i*: `prior_c(i) = suitability_c(i) · Π_k f_k,c(i) · exp(−d_b(i)/λ_c)`,
with `d_b` the routed distance (16-neighbour Dijkstra on a class-costed raster: bathymetry at sea,
road corridors and cover on land, airspace class in the air), mixed over bases by `sources`
shares (or `sources_scenarios` while a scenario is on), normalised to the class's `deployed` count
at the chosen posture, then routed back along transit flow for the time-since-sortie slider. HDR
contours enclose 50/80/95 % of the mass. Factor types: `depth`/`terrain`, `zones`, `hubs`,
`points`, `line_exposure`, `pressure`, `proximity`, `envelope`; parameters may be constants,
posture-scaled `{mod, base, gain}`, scenario-switched `{default, scenario, value}` or both.

## Architecture (why the pieces exist)

- `dashboard.html/.css/.js` — the dual-mode UI; leg tabs render from `airWatch`, `launcherWatch`,
  `subWatch`; Triad Map lazily loads `dist/maps/ext/<id>.html` in the extension or the embedded
  `window.LG_MAPS` base64 pages in the preview, and posts live ADS-B hits (`lg-live`) into air
  theatres; Feed/Media/Digest render collector items text-only through `sanitize.js`.
- `background.js` — MV3 worker: alarms; allowlisted GET-only fetch of `t.me/s` previews,
  `opendata.adsb.fi` (track sector + `air:` sector) and the loopback collector (optional host
  permission granted on click; `x-lg-token` never returned to the page); backoff; capped caches.
- `assets/maps/engine/` — `model.js` (DOMAIN, cost tables, routing, HDR), `app.js` (per-domain
  vocabulary, generic `GEO.layers`, sighting/exercise/closure markers, live overlay, resize guard),
  `style.css`; `scripts/maps_prep_geo.py` rasterises Natural Earth per domain.
- `collector/lg_collector/` — `connectors/` (telegram_user, telegram_bot, discord_bot, social,
  technical), `triage.py` (keyword pre-triage + Claude JSON agent), `media.py` (EXIF-stripped
  thumbnails, dHash dedupe, ffmpeg frames), `store.py` (SQLite), `server.py` (loopback API,
  CORS, token), `export.py`, `cli.py`.

## Security posture — never regress

Permissions stay `storage` + `alarms`; hosts stay `t.me`, `opendata.adsb.fi`, `api.anthropic.com`
plus the **optional** loopback origin; CSP stays `script-src 'self'` with `img/media/connect-src`
widened only to `http://127.0.0.1:*` / `http://localhost:*`; every remote string is text-only;
the worker is GET-only, cookie-less, no-referrer, allowlisted after redirects; storage is local;
synthesis and triage run only with the operator's own key on the operator's click or machine.
`package_extension.py` refuses a manifest that loosens any of this.

## Guardrails

Help freely with force posture, capability, readiness, doctrine, warning, heatmap priors and
defensive protective assessment. Decline — and keep delivering the rest — anything that would
present real-time or predicted unit, launcher, aircraft, boat or warhead locations; produce
targeting, strike or force-defeat products; defeat OPSEC; write facility vulnerabilities, methods
or target maps; log into, post to or interact with accounts; scrape private data; deanonymise or
track individuals; or present unverified feed or collector claims as fact.
