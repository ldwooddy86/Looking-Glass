#!/usr/bin/env bash
# maps_build_all.sh — run the full LOOKING GLASS map pipeline for one or more theatres.
# Usage: scripts/maps_build_all.sh [theatre-id ...]        (default: every config in data/theatres/)
# Env: LG_GEODATA (Natural Earth dir), LG_BUILD (build dir, default build/maps), LG_DIST (default dist/maps)
# Steps per theatre: validate → prep_geo → validate --grid → test_model → build
set -uo pipefail
cd "$(dirname "$0")/.."
BUILD="${LG_BUILD:-build/maps}"; DIST="${LG_DIST:-dist/maps}"
IDS=("$@")
if [ ${#IDS[@]} -eq 0 ]; then for f in data/theatres/*.json; do IDS+=("$(basename "$f" .json)"); done; fi
FAIL=0
for id in "${IDS[@]}"; do
  CFG="data/theatres/$id.json"
  echo "=============== $id"
  node scripts/maps_validate_config.js "$CFG" || { FAIL=1; continue; }
  python3 scripts/maps_prep_geo.py --config "$CFG" --out "$BUILD/$id" || { FAIL=1; continue; }
  node scripts/maps_validate_config.js "$CFG" --grid "$BUILD/$id/grid.json" || { FAIL=1; continue; }
  node scripts/maps_test_model.js "$CFG" --build "$BUILD/$id" || { FAIL=1; continue; }
  python3 scripts/maps_build.py --config "$CFG" --build "$BUILD/$id" --out "$DIST" || FAIL=1
done
echo "=============== maps_build_all done (exit $FAIL)"
exit $FAIL
