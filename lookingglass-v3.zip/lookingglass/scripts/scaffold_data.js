#!/usr/bin/env node
/* scaffold_data.js — emit a complete, correctly-shaped LOOKING GLASS v3 data.js skeleton
   for a NEW country so a build starts from the contract, not from another
   country's content. Every enum is valid; every content field is a TODO the
   validator refuses to ship. Fill it from the research playbook.
   Usage:
     node scripts/scaffold_data.js --country "Iran" --adjective Iranian \
       --subject "IRGC + Artesh" --slug iran --flag "🇮🇷" [--protective] [--escalation] [--sub] [--air] [--launcher] [--maps] [--collector] > assets/extension/data.js
   --sub adds the optional Sub Watch block (nuclear-submarine force, basing, sea-leg I&W,
   undersea-surveillance ledger, civil-maritime fusion) — only for a subject that operates
   nuclear-powered submarines.
   --air adds Air Watch (nuclear strike & support aircraft: bombers, dual-capable fighters,
   tankers, airborne C2 / relay, AEW, ISR — with a live public-ADS-B board for the subject's
   transponding types). --launcher adds Launcher Watch (road-mobile TELs: order of battle,
   garrisons, dispersal doctrine, land-leg I&W). --maps adds the Triad Map block listing the
   theatre configs in data/theatres/. --collector adds the collection plan the local collector
   is generated from (Telegram user+bot, Discord bot, Bluesky, Mastodon, Reddit, YouTube, RSS,
   ADS-B, NOTAM / NAVWARN). */
"use strict";
const a = { country: "Country", adjective: "National", subject: "Armed Forces", slug: "country", flag: "🏳️", protective: false, escalation: false, sub: false, air: false, launcher: false, maps: false, collector: false };
const argv = process.argv.slice(2);
for (let i = 0; i < argv.length; i++) {
  const k = argv[i];
  if (k === "--protective") a.protective = true;
  else if (k === "--escalation") a.escalation = true;
  else if (k === "--sub") a.sub = true;
  else if (k === "--air") a.air = true;
  else if (k === "--launcher") a.launcher = true;
  else if (k === "--maps") a.maps = true;
  else if (k === "--collector") a.collector = true;
  else if (k.startsWith("--")) a[k.slice(2)] = argv[++i];
}
const today = new Date();
const MON = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const compiled = `${String(today.getUTCDate()).padStart(2, "0")} ${MON[today.getUTCMonth()]} ${today.getUTCFullYear()}`;
const asOf = `${String(today.getUTCDate()).padStart(2, "0")}0900Z ${MON[today.getUTCMonth()]} ${today.getUTCFullYear()}`;
const T = (s) => `TODO: ${s}`;

const D = {
  meta: { version: 2, country: a.country, adjective: a.adjective, subject: a.subject, flag: a.flag, slug: a.slug, brand: "LOOKING GLASS", line: `${a.subject} Nuclear Forces & Posture Monitor`, tagline: `Open-source all-source watch on ${a.adjective} nuclear forces, military capability, readiness & intent`, compiled, edition: `${today.getUTCFullYear()}.${String(today.getUTCMonth() + 1).padStart(2, "0")}`, previousCompiled: "" },
  posture: { level: "elevated", range: ["guarded", "high"], headline: T("1-2 sentence synthesis of the current posture with the load-bearing numbers"), body: T("paragraph: trajectory, the two or three threads that complicate the read, what OSINT sees with a lag and what it cannot see"), mover: T("the observation that would move the level up or down") },
  product: {
    handling: "UNCLASSIFIED // OPEN SOURCE // OSINT synthesis — not a government assessment",
    line: `Strategic Warning — ${a.adjective} Military Posture`, asOf, horizon: "12-month rolling",
    scopeNote: T("scope and analytic line of departure"),
    estimativeKey: [{ term: "Almost no chance / remote", band: "01-05%" }, { term: "Very unlikely / highly improbable", band: "05-20%" }, { term: "Unlikely / improbable", band: "20-45%" }, { term: "Roughly even chance", band: "45-55%" }, { term: "Likely / probable", band: "55-80%" }, { term: "Very likely / highly probable", band: "80-95%" }, { term: "Almost certain(ly)", band: "95-99%" }],
    confidenceDef: "Analytic confidence (Low / Moderate / High) is stated SEPARATELY from probability. Probability is how likely the judgment is true; confidence is how good the evidence is — source reliability, corroboration across independent collection, and the size of the relevant gaps.",
    bluf: T("BLUF paragraph with ICD-203 bands and the confidence ceiling named"),
    keyJudgments: [1, 2, 3, 4].map(n => ({ id: `KJ-${n}`, text: T(`key judgment ${n}`), prob: "Likely (55-80%)", confidence: "Moderate", grade: "B2", basis: T("sources / editions"), whatWouldChange: T("what would move it") })),
    changes: [{ date: compiled, kind: "new", text: T("first edition — what this build establishes as baseline") }],
  },
  matrix: {
    updated: compiled, note: T("how to read the matrix; where the gaps are"),
    intCols: [{ key: "osint", label: "OSINT", full: "Open-source: state & social media, defense press, ship/flight tracking, procurement notices" }, { key: "geoint", label: "GEOINT", full: "Commercial satellite imagery via institutes and analysts" }, { key: "sigint", label: "SIGINT", full: "Publicly-reported signals/ELINT; allied ISR; ADS-B/AIS as open technical collection" }, { key: "humint", label: "HUMINT", full: "Publicly-reported human, defector, official & diplomatic sourcing" }, { key: "masint", label: "MASINT", full: "Test telemetry, seismic/acoustic, radiological signatures via public monitoring" }],
    levels: [{ key: "guarded", label: "Guarded" }, { key: "elevated", label: "Elevated" }, { key: "high", label: "High" }, { key: "severe", label: "Severe" }],
    collectionPosture: T("strongest coverage vs critical gaps"),
    domains: ["Ground forces", "Naval forces", "Air & air defence", "Missile / rocket forces", "Nuclear / strategic", "Space & counterspace", "Cyber, EW & IO", "Gray-zone & paramilitary", "Leadership, command & reliability", "Allied collection & response posture"].map((d, i) => ({ id: `CM-${String(i + 1).padStart(2, "0")}`, domain: d, pri: 3, level: "elevated", trend: "flat", conf: "Moderate", finding: T(`finding for ${d}`), primary: "OSINT", src: T("source"), ints: { osint: "partial", geoint: "partial", sigint: "partial", humint: "partial", masint: "na" } })),
  },
  forces: {
    updated: compiled, note: T("estimates note — two figures where sources diverge"),
    totals: [{ label: "Total active personnel", val: T("≈ n"), note: T("IISS Military Balance edition"), alt: T("second estimate") }, { label: "Official defense budget", val: T("local currency (≈ USD)"), note: T("year, source"), alt: T("SIPRI real-spend estimate") }],
    branches: [{ branch: "Army", personnel: T("≈ n"), pct: 50, detail: T("structure") }, { branch: "Navy", personnel: T("≈ n"), pct: 20, detail: T("structure") }, { branch: "Air Force", personnel: T("≈ n"), pct: 20, detail: T("structure") }, { branch: "Other", personnel: T("≈ n"), pct: 10, detail: T("structure") }],
    systems: { ground: [T("system")], air: [T("system")], naval: [T("system")], missile: [T("system")], strategic: [], enabling: [T("system")] },
    leadership: [{ post: "Commander-in-chief / CMC chair", name: T("name"), since: T("date"), status: "confirmed", note: T("note"), src: T("verified on build date via …") }, { post: "Defence minister", name: T("name"), since: T("date"), status: "confirmed", note: "", src: T("src") }, { post: "Chief of general staff", name: T("name"), since: T("date"), status: "confirmed", note: "", src: T("src") }],
  },
  indicators: [{ cat: T("category"), level: "elevated", title: T("title"), body: T("body"), src: T("src") }],
  doctrine: [T("doctrinal tenet")], doctrineNote: T("doctrine note"),
  events: [{ date: compiled, iso: today.toISOString().slice(0, 10), hot: false, title: T("newest event"), body: T("what happened, why it matters"), src: T("src") }],
  iwBoard: {
    note: "Each indicator is an OBSERVABLE whose appearance would precede or accompany a rise in conflict risk. 'Threshold' is what would trip it; 'observed' is the current read; 'crit' is the consequence weight; sourcing is Admiralty-graded. Near-invisible indicators are marked UNSEEN and counted in the blind fraction — quiet there is not clear.",
    scaleLegend: [{ key: "normal", label: "Normal", body: "At/below routine baseline." }, { key: "note", label: "Note", body: "Marginally above baseline; logged for pattern-of-life." }, { key: "elevated", label: "Elevated", body: "Indicator partially present; watch closely." }, { key: "warning", label: "Warning", body: "Threshold met / strong positive indication." }],
    indicators: ["Major joint exercises", "Amphibious / lift mobilisation", "Reserve call-up", "Missile-force generation", "Warhead custody / mating", "Naval surge", "Air-activity surge", "Cyber pre-positioning"].map((d, i) => ({ id: `I-${String(i + 1).padStart(2, "0")}`, domain: d, threshold: T("threshold"), observed: i === 4 ? "unseen" : "normal", crit: 4, conf: "Moderate", grade: i === 4 ? "F6 (gap)" : "B2", read: T("current read"), src: T("src") })),
  },
  ach: {
    question: T("the analytic question the board answers"), method: "Cells: C = consistent, I = inconsistent, N = neutral. Ranked by least reliability- and diagnosticity-weighted inconsistency.",
    hypotheses: [{ id: "H1", label: T("hypothesis"), desc: T("desc") }, { id: "H2", label: T("hypothesis"), desc: T("desc") }, { id: "H3", label: T("hypothesis"), desc: T("desc") }],
    evidence: [1, 2, 3, 4, 5, 6].map(n => ({ id: `E${n}`, text: T(`evidence ${n}`), grade: "B2", scores: { H1: "C", H2: n % 2 ? "I" : "N", H3: n % 3 ? "N" : "I" }, diag: n % 2 === 1, src: T("src") })),
    conclusion: T("blend and residual; which gap decides between survivors"),
  },
  keyAssumptions: [{ id: "KA-1", text: T("assumption"), risk: T("risk"), ifWrong: T("consequence") }],
  collectionGaps: [{ rank: 1, gap: T("gap"), detail: T("detail"), mitigation: T("mitigation") }],
  movementWatch: {
    intro: T("intro"),
    tiers: [{ tier: "t1", label: "Announced / high-visibility", vis: "seen when it happens", note: T("note") }, { tier: "t2", label: "Operational / observable with lag", vis: "imagery- & tracking-dependent", note: T("note") }, { tier: "t3", label: "Near-invisible / disciplined", vis: "should essentially never surface", note: T("note") }],
    signatures: [{ id: "MV-01", tier: "t1", sig: T("signature"), iw: "I-01", feed: T("feed"), blind: false, note: T("note") }, { id: "MV-02", tier: "t3", sig: T("signature"), iw: "I-05", feed: "-", blind: true, note: T("note") }],
    scanner: { note: T("scanner note"), dictionary: [{ cat: "Mobilization / call-up", tone: "red", terms: ["mobilization", T("native term (romanised)")] }, { cat: "Blockade / quarantine", tone: "alert", terms: ["blockade", "quarantine"] }, { cat: "Rhetoric (noisy)", tone: "watch", terms: [T("term")] }] },
    note: T("closing note"),
  },
  trackWatch: {
    intro: T("intro — which allied ISR / transponding types matter"), note: "Three honesty rules: (1) ADS-B only sees transponding aircraft a community receiver hears — absence is uninformative. (2) It reads correlation, never intent. (3) These are public tracks watched openly by thousands of hobbyists — public OSINT, not a classified location.",
    types: [{ key: "p8", type: "P-8A Poseidon", nick: "ASW / maritime ISR", tempo: "frequent", role: T("role"), bases: T("bases"), src: T("src") }, { key: "rc135", type: "RC-135", nick: "SIGINT", tempo: "frequent", role: T("role"), bases: T("bases"), src: T("src") }, { key: "hale", type: "RQ-4 / MQ-4C", nick: "HALE ISR", tempo: "rare", crit: true, role: T("role"), bases: T("bases"), src: T("src") }],
    sector: { lat: 0, lon: 0, dist: 140, label: T("sector label"), why: T("why this fixed public location") },
    links: [{ label: "adsb.fi military globe", href: "https://globe.adsb.fi/?largeMode=2&filterMilitary" }],
    match: { p8: { types: ["P8"], regs: [], hex: [] }, rc135: { types: ["R135"], regs: [], hex: [] }, hale: { types: ["Q4"], regs: [], hex: [] } },
    alert: { alert: 2, red: 3 }, alertRule: T("tripwire in words"),
  },
  osint: {
    signalChain: [{ t: "HOURS 0", layer: T("layer"), what: T("what"), src: T("src") }], signalChainNote: T("note"),
    channels: [{ handle: "examplehandle", label: T("label"), lane: "aggregator", note: "Unverified — confirm t.me/s/<handle> resolves before enabling.", enabled: false, verified: false }],
    channelNote: T("note"), channelSuggestions: [T("suggestion")],
    directory: [{ group: T("group"), sub: T("sub"), items: [{ name: T("name"), handle: "example.org", note: T("note"), rel: "independent", src: "example.org" }] }],
  },
  stateMedia: { intro: T("intro"), framing: [{ k: "Fact-of-statement", v: T("v") }], outlets: [{ name: T("outlet"), native: "", grade: "B / 4", kind: T("kind"), control: T("control"), beat: T("beat") }], rss: [] },
  social: { intro: T("intro"), ethics: "Public communities and aggregate patterns only — no individual tracking, no profile-building, no deanonymization, no logins.", platforms: [{ name: T("platform"), native: "-", hot: false, control: T("control"), caught: T("caught"), access: T("access") }], method: [{ when: T("when"), what: T("what"), src: T("src"), limit: false }] },
  academia: { updated: compiled, headline: T("headline"), intro: T("intro"), framingNote: T("framing"), gradeNote: T("grade note"), stanceLegend: [{ key: "independent", label: "Independent", body: "Autonomous scholarship." }, { key: "mixed", label: "Mixed", body: "Government-funded or establishment-linked." }, { key: "state", label: "State-adjacent", body: "Party-/ministry-linked; read for declaratory intent." }], countries: [{ cc: "US", flag: "🇺🇸", name: "United States", stance: "independent", stanceNote: T("note"), institutions: [{ name: T("institute"), org: T("org"), url: "example.org", focus: T("focus"), grade: "A2" }] }] },
  sourceReliability: { legend: { reliability: "A completely reliable - B usually reliable - C fairly reliable - D not usually reliable - E unreliable - F cannot be judged", credibility: "1 confirmed by other sources - 2 probably true - 3 possibly true - 4 doubtful - 5 improbable - 6 cannot be judged" }, note: T("note"), entries: [{ source: T("source"), grade: "A2", role: T("role") }] },
  security: [
    { k: "L", h: "Least privilege", p: "Permissions are exactly storage + alarms. Host access is limited to t.me (public channel previews), opendata.adsb.fi (public military ADS-B) and optional-use api.anthropic.com. No tabs access, no <all_urls>, no scripting into pages." },
    { k: "C", h: "Locked Content-Security-Policy", p: "Extension pages run under script-src 'self' — no inline scripts, no remote code, no eval. Nothing loads from a CDN; system fonts only." },
    { k: "H", h: "Hostile-input handling", p: "Channel previews and any AI-returned text are parsed in a detached document, stripped by sanitize.js, length-capped, and inserted as TEXT ONLY. Remote content never touches innerHTML." },
    { k: "G", h: "Allowlisted, GET-only worker", p: "The service worker re-checks every request against a hard-coded host allowlist, sends no cookies, uses no-referrer, and never POSTs. No telemetry." },
    { k: "S", h: "Local-only storage", p: "Cache, settings and any API key stay in chrome.storage.local on your device. This hardens the extension but does not anonymize your network." },
    { k: "K", h: "Synthesis only on your click, with your key", p: "The optional synthesis call is made by the page, only when you click, only to api.anthropic.com, carrying sanitized public channel text and your own key." },
  ],
  sources: T(`baselines with editions/years — refreshed ${compiled}`),
};
if (a.escalation) D.escalation = { title: T("title"), horizon: "12-month rolling horizon", question: T("question"), bluf: T("bluf"), judgments: [{ id: "KJ-1", text: T("text"), conf: "Moderate", grade: "B2" }], driverGroups: [{ key: "A", label: "Structural / capability" }], drivers: [{ id: "A1", group: "A", name: T("driver"), dir: "↑", value: T("value"), lev: "high", conf: "Mod" }], scenarios: [{ id: "S1", name: T("scenario"), type: "Coercion", prob: "55-75%", tone: "watch", gate: T("gate") }], scenarioNote: T("note"), crossImpactNote: T("note"), net: { likely: T("likely"), dangerous: T("dangerous"), movers: T("movers") }, paperNote: "This is an open-source analytic estimate, not a prediction." };
if (a.protective) D.protective = {
  framingNote: "Protective-security layer in the CISA/NPSA idiom: threat levels, target CLASSES, sector exposure and where advisories apply — written for defenders. No facility-level vulnerabilities, methods, timings, coordinates or target maps appear here by design.",
  threat: { level: "moderate", updated: compiled, headline: T("headline"), body: T("body"), actors: [{ id: "A1", name: T("actor"), type: T("type"), intent: 3, capability: 2, reach: "domestic", trend: "flat", targets: T("target classes"), grade: "B2", note: T("note"), src: T("src") }], iw: [{ id: "T-01", indicator: T("indicator"), threshold: T("threshold"), observed: "normal", crit: 3, conf: "Moderate", grade: "B2", read: T("read"), src: T("src") }], incidents: [{ date: compiled, place: T("place"), kind: T("kind"), actor: T("actor"), casualties: T("casualties"), note: T("note"), src: T("src") }], note: T("note") },
  softTargets: { intro: T("intro"), classes: [{ id: "ST-01", class: T("class"), examples: T("generic examples"), precedent: 2, risk: "moderate", posture: "baseline", measures: [T("measure")], note: T("note"), src: T("src") }], note: T("note") },
  infrastructure: { intro: T("intro"), sectors: [{ id: "CI-01", sector: "Data centers & cloud", spotlight: true, exposure: "moderate", resilience: "moderate", vectors: [T("vector")], recent: T("recent"), measures: [T("measure")], src: T("src") }], dataCenters: { intro: T("intro"), vectors: [{ vector: T("vector"), likelihood: "moderate", impact: "high", measure: T("measure"), src: T("src") }], note: T("note") }, note: T("note") },
  geography: { intro: T("intro"), regions: [{ id: "G-01", region: T("region"), scope: "domestic", advisory: "moderate", drivers: [T("driver")], actors: ["A1"], trend: "flat", note: T("note"), src: T("src") }], note: T("note") },
};

if (a.sub) D.subWatch = {
  title: `${a.adjective} nuclear-submarine watch`, updated: compiled,
  framingNote: "Public reporting only. This tab tracks force structure, basing, exercises, tests, doctrine and the undersea-surveillance environment. It never shows, implies or predicts where a boat is: submarine positions, patrol areas and alert states are unobservable in open sources on every side, and quiet here is UNSEEN, not absent.",
  intro: T("what the tab watches and why the sea leg matters for this subject"),
  status: { level: "elevated", range: ["guarded", "high"], headline: T("headline"), body: T("body"), mover: T("what would move it") },
  fleet: [
    { id: "SB-01", cls: T("class"), role: "SSBN", nick: T("nickname"), hulls: T("count with uncertainty"), alt: T("second estimate"), status: "in-service", weapons: T("weapons"), base: T("base"), trend: "flat", conf: "Moderate", grade: "B2", note: T("note"), src: T("src") },
    { id: "SB-02", cls: T("class"), role: "SSN", hulls: T("count"), status: "in-service", weapons: T("weapons"), base: T("base"), trend: "flat", conf: "Moderate", grade: "B2", note: T("note"), src: T("src") },
    { id: "SB-03", cls: T("class"), role: "SSBN (next generation)", hulls: T("count"), status: "building", weapons: T("weapons"), base: T("base"), trend: "up", conf: "Low", grade: "C3", note: T("note"), src: T("src") }
  ],
  bases: [{ id: "BS-01", name: T("base"), role: T("role"), sees: T("what commercial imagery shows"), lastChange: T("date"), conf: "Moderate", src: T("src") }],
  observables: [{ id: "SO-01", signature: T("signature"), tier: "t2", iw: "SW-01", feed: T("feed"), cadence: T("cadence"), blind: false, read: T("read"), src: T("src") }],
  iw: [
    { id: "SW-01", domain: T("observable indicator"), threshold: T("threshold"), observed: "note", crit: 4, conf: "Moderate", grade: "B2", read: T("read"), src: T("src") },
    { id: "SW-02", domain: "SSBN alert state / boats at sea", threshold: T("threshold"), observed: "unseen", crit: 5, conf: "Low", grade: "F6 (gap)", read: T("read"), src: "structural" },
    { id: "SW-03", domain: "Warhead loading at the SSBN base", threshold: T("threshold"), observed: "unseen", crit: 5, conf: "Low", grade: "F6 (gap)", read: T("read"), src: "structural" },
    { id: "SW-04", domain: T("observable indicator"), threshold: T("threshold"), observed: "normal", crit: 3, conf: "Moderate", grade: "B2", read: T("read"), src: T("src") },
    { id: "SW-05", domain: T("observable indicator"), threshold: T("threshold"), observed: "note", crit: 3, conf: "Moderate", grade: "B2", read: T("read"), src: T("src") }
  ],
  environment: [
    { id: "UE-01", layer: "Allied fixed undersea arrays", side: "allied", known: T("what public reporting establishes"), unknown: T("what is classified"), effect: T("how it bends the board"), grade: "B3", src: T("src") },
    { id: "UE-02", layer: "Subject's own undersea sensor network", side: "prc", known: T("known"), unknown: T("unknown"), effect: T("effect"), grade: "C3", src: T("src") },
    { id: "UE-03", layer: "Acoustic signatures", side: "both", known: T("known"), unknown: T("unknown"), effect: T("effect"), grade: "B3", src: T("src") },
    { id: "UE-04", layer: "SLBM command, control and custody", side: "prc", known: T("known"), unknown: T("unknown"), effect: T("effect"), grade: "C3", src: T("src") }
  ],
  doctrine: [{ id: "SD-01", tenet: T("tenet"), basis: T("basis"), implication: T("implication"), src: T("src") }],
  civilMaritime: [{ id: "CV-01", element: T("element"), mechanism: T("mechanism"), observable: T("observable"), status: T("status"), tone: "watch", src: T("src") }],
  timeline: [{ date: compiled, hot: false, title: T("title"), body: T("body"), src: T("src") }],
  scanner: { note: T("scanner note"), dictionary: [{ cat: "Submarine / SLBM", tone: "alert", terms: ["submarine", "SSBN", "SLBM", T("native-language term (romanisation)")] }] },
  sources: T("sources for the tab"), note: T("closing note")
};

if (a.air) D.airWatch = {
  title: `${a.adjective} nuclear strike & support aircraft watch`, updated: compiled,
  framingNote: "Public reporting only. This tab tracks the strike and support fleets — bombers, dual-capable fighters, tankers, airborne command posts and relay, AEW and ISR — their basing, pattern of life, doctrine and the air-leg indicators open sources can see. It never produces targeting, strike planning or force-defeat detail. Public ADS-B broadcasts, where a type transponds, are what community receivers heard, at coarse resolution: correlation, never intent.",
  intro: T("why the air leg matters for this subject, and which types actually show on public ADS-B"),
  status: { level: "elevated", range: ["guarded", "high"], headline: T("headline"), body: T("body"), mover: T("what would move it") },
  fleet: [
    { id: "AF-01", type: T("bomber type"), role: "strike", nick: T("NATO name"), airframes: T("count with uncertainty"), alt: T("second estimate"), status: "in-service", weapons: T("weapons"), bases: T("bases"), units: T("regiments / squadrons"), icao: [], transponds: "never", trend: "flat", conf: "Moderate", grade: "B2", note: T("note"), src: T("src") },
    { id: "AF-02", type: T("tanker type"), role: "tanker", airframes: T("count"), status: "in-service", weapons: "—", bases: T("bases"), units: T("units"), icao: [T("designator")], transponds: "often", trend: "flat", conf: "Moderate", grade: "B2", note: T("note"), src: T("src") },
    { id: "AF-03", type: T("airborne command post / relay type"), role: "c2", airframes: T("count"), status: "in-service", weapons: "—", bases: T("bases"), units: T("units"), icao: [T("designator")], transponds: "rarely", trend: "flat", conf: "Low", grade: "C3", note: T("note"), src: T("src") }
  ],
  bases: [{ id: "AB-01", name: T("base"), role: T("role"), sees: T("what commercial imagery / public notices show"), lastChange: T("date"), conf: "Moderate", src: T("src") }],
  observables: [{ id: "AO-01", signature: T("signature"), tier: "t2", iw: "AW-01", feed: T("feed"), cadence: T("cadence"), blind: false, read: T("read"), src: T("src") }],
  iw: [
    { id: "AW-01", domain: T("observable indicator (e.g. bomber dispersal to forward fields)"), threshold: T("threshold"), observed: "note", crit: 4, conf: "Moderate", grade: "B2", read: T("read"), src: T("src") },
    { id: "AW-02", domain: "Bombers generated / weapons loaded", threshold: T("threshold"), observed: "unseen", crit: 5, conf: "Low", grade: "F6 (gap)", read: T("read"), src: "structural" },
    { id: "AW-03", domain: "Airborne command-post continuous airborne alert", threshold: T("threshold"), observed: "unseen", crit: 5, conf: "Low", grade: "F6 (gap)", read: T("read"), src: "structural" },
    { id: "AW-04", domain: T("observable indicator"), threshold: T("threshold"), observed: "normal", crit: 3, conf: "Moderate", grade: "B2", read: T("read"), src: T("src") },
    { id: "AW-05", domain: T("observable indicator"), threshold: T("threshold"), observed: "note", crit: 3, conf: "Moderate", grade: "B2", read: T("read"), src: T("src") }
  ],
  doctrine: [{ id: "AD-01", tenet: T("tenet"), basis: T("basis"), implication: T("implication"), src: T("src") }],
  timeline: [{ date: compiled, hot: false, title: T("title"), body: T("body"), src: T("src") }],
  scanner: { note: T("scanner note"), dictionary: [{ cat: "Strategic aviation", tone: "alert", terms: ["bomber", "strategic aviation", T("native term (romanisation)")] }] },
  live: {
    intro: T("which of the subject's own strike/support types transpond, and why the board mostly sees tankers, AEW and command posts"),
    note: "Three honesty rules: (1) ADS-B only sees transponding aircraft a community receiver hears — bombers fly dark, so absence is uninformative (F6). (2) It reads correlation, never intent. (3) These are public broadcasts watched openly by thousands of hobbyists — public OSINT, not a classified location. Positions are rounded to a tenth of a degree by design.",
    types: [{ key: "tanker", type: T("tanker type"), nick: "aerial refuelling", tempo: "frequent", role: T("role"), bases: T("bases"), src: T("src") }, { key: "c2", type: T("airborne command post"), nick: "NC3", tempo: "rare", crit: true, role: T("role"), bases: T("bases"), src: T("src") }],
    sector: { lat: 0, lon: 0, dist: 200, label: T("sector label"), why: T("why this fixed public location") },
    links: [{ label: "adsb.fi military globe", href: "https://globe.adsb.fi/?largeMode=2&filterMilitary" }],
    match: { tanker: { types: [T("designator")], regs: [], hex: [] }, c2: { types: [T("designator")], regs: [], hex: [] } },
    alert: { alert: 1, red: 2 }, alertRule: T("tripwire in words")
  },
  sources: T("sources for the tab"), note: T("closing note")
};

if (a.launcher) D.launcherWatch = {
  title: `${a.adjective} road-mobile launcher watch`, updated: compiled,
  framingNote: "Public reporting only. This tab tracks road-mobile launcher forces — systems, chassis, garrisons as towns and regions, dispersal doctrine, pattern of life and the land-leg indicators open sources can see. It never shows, implies or predicts where a launcher is: field positions, routes and alert states are unobservable in open sources, and quiet here is UNSEEN, not absent. The Triad Map's land theatre draws a structural prior over dispersal areas, never a position.",
  intro: T("why the mobile leg matters for this subject and what open sources actually see of it"),
  status: { level: "elevated", range: ["guarded", "high"], headline: T("headline"), body: T("body"), mover: T("what would move it") },
  fleet: [
    { id: "LF-01", system: T("mobile ICBM system"), role: "ICBM", nick: T("NATO name"), launchers: T("count with uncertainty"), alt: T("second estimate"), status: "in-service", chassis: T("TEL chassis"), warheads: T("warheads per missile / total"), range: T("range"), units: T("divisions / brigades"), trend: "flat", conf: "Moderate", grade: "B2", note: T("note"), src: T("src") },
    { id: "LF-02", system: T("dual-capable SRBM/GLCM system"), role: "dual-capable", launchers: T("count"), status: "in-service", chassis: T("chassis"), warheads: T("warheads"), range: T("range"), units: T("brigades"), trend: "flat", conf: "Moderate", grade: "B2", note: T("note"), src: T("src") }
  ],
  garrisons: [{ id: "LG-01", name: T("garrison town / region"), formation: T("formation · system"), sees: T("what commercial imagery shows of the garrison and its positional area"), lastChange: T("date"), conf: "Moderate", src: T("src") }],
  dispersal: { pattern: T("how the force disperses: positional areas, patrol radius, prepared field positions, cadence, cover"), inputs: [{ k: "Patrol radius", v: T("value"), src: T("src") }, { k: "Positional area", v: T("value"), src: T("src") }, { k: "Field-deployment cadence", v: T("value"), src: T("src") }], note: T("note") },
  observables: [{ id: "LO-01", signature: T("signature"), tier: "t1", iw: "LW-01", feed: T("feed"), cadence: T("cadence"), blind: false, read: T("read"), src: T("src") }],
  iw: [
    { id: "LW-01", domain: T("observable indicator (e.g. announced regiments on combat patrol)"), threshold: T("threshold"), observed: "note", crit: 4, conf: "Moderate", grade: "B2", read: T("read"), src: T("src") },
    { id: "LW-02", domain: "Warheads mated / dispersal ordered", threshold: T("threshold"), observed: "unseen", crit: 5, conf: "Low", grade: "F6 (gap)", read: T("read"), src: "structural" },
    { id: "LW-03", domain: "Field positions occupied", threshold: T("threshold"), observed: "unseen", crit: 5, conf: "Low", grade: "F6 (gap)", read: T("read"), src: "structural" },
    { id: "LW-04", domain: T("observable indicator"), threshold: T("threshold"), observed: "normal", crit: 3, conf: "Moderate", grade: "B2", read: T("read"), src: T("src") },
    { id: "LW-05", domain: T("observable indicator"), threshold: T("threshold"), observed: "note", crit: 3, conf: "Moderate", grade: "B2", read: T("read"), src: T("src") }
  ],
  doctrine: [{ id: "LD-01", tenet: T("tenet"), basis: T("basis"), implication: T("implication"), src: T("src") }],
  timeline: [{ date: compiled, hot: false, title: T("title"), body: T("body"), src: T("src") }],
  scanner: { note: T("scanner note"), dictionary: [{ cat: "Mobile launchers", tone: "alert", terms: ["TEL", "launcher", "combat patrol", T("native term (romanisation)")] }] },
  sources: T("sources for the tab"), note: T("closing note")
};

if (a.maps) D.triadMaps = {
  intro: T("what the embedded theatres model and how to read them together"),
  framingNote: "Each map is a STRUCTURAL PRIOR — where public basing, doctrine, geography, demonstrated launch geometry and adversary reach say a deployed unit of a class would be, conditional on its being deployed at all. Deployed counts are posture assumptions. Nothing on these maps is a position, a track, a patrol box or an alert state.",
  theatres: [{ id: `${a.slug}-north`, leg: "sea", label: T("theatre label"), summary: T("one-line reading at the default posture"), edition: T("Edition") }],
  note: T("note")
};

if (a.collector) D.collector = {
  framingNote: "The local collector reads through YOUR OWN accounts — a Telegram user session and/or bot, a Discord bot on servers you invite it to, Bluesky, Mastodon, Reddit, YouTube, RSS, public ADS-B and NOTAM / navigational warnings. It only reads: it never posts, never joins, never scrapes behind someone else's login, and it keeps items and media on your machine, served on the loopback interface only. Everything it carries is unverified OSINT; triage labels are machine suggestions.",
  endpoint: "http://127.0.0.1:8787",
  sources: [
    { kind: "telegram", handle: "examplehandle", label: T("label"), lane: "aggregator", enabled: false, note: "Unverified — confirm t.me/s/<handle> or your session can read it before enabling." },
    { kind: "discord", id: "000000000000000000", label: T("server label"), lane: "community", enabled: false, note: "Numeric server id; the bot must be invited with read-message-history." },
    { kind: "bluesky", handle: "example.bsky.social", label: T("label"), lane: "analyst", enabled: false },
    { kind: "rss", url: "https://example.org/feed.xml", label: T("label"), lane: "wire", enabled: false }
  ],
  note: T("note")
};

const header = `/* ============================================================
   data.js — LOOKING GLASS v3 baseline OSINT dataset (${a.country})
   ------------------------------------------------------------
   Scaffolded ${compiled}. Every TODO must be replaced with sourced
   content (see references/RESEARCH-PLAYBOOK.md); the validator refuses
   to build while any TODO remains. Keep every KEY NAME and SHAPE — see
   references/SCHEMA.md. Everything here must be PUBLIC REPORTING.
   ============================================================ */
window.ORACLE_DATA = `;
process.stdout.write(header + JSON.stringify(D, null, 2) + ";\n");
