#!/usr/bin/env python3
"""
package_extension.py — package the LOOKING GLASS MV3 extension into a loadable
.zip, stamped with the target country from data.js.

It rewrites manifest.json name/description from data.js.meta so the installed
extension self-identifies per country, WITHOUT touching the shared engine
(dashboard.*, background.js, sanitize.js, popup.*). It also refuses to package
a manifest whose security posture has regressed (extra permissions, extra
hosts, a loosened CSP).

Usage:
    python scripts/package_extension.py [--src assets/extension] [--out-dir OUT]
"""
import argparse, json, os, re, subprocess, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

INCLUDE = ["manifest.json", "background.js", "sanitize.js", "data.js",
           "dashboard.html", "dashboard.css", "dashboard.js",
           "popup.html", "popup.css", "popup.js", "README.md"]
INCLUDE_DIRS = ["icons"]

ALLOWED_PERMISSIONS = {"storage", "alarms"}
ALLOWED_HOSTS = {"https://t.me/*", "https://opendata.adsb.fi/*", "https://api.anthropic.com/*"}
# LOOKING GLASS: the local collector lives on the loopback interface only. It is an OPTIONAL host
# permission (granted by the user from Settings → Connect) and nothing else may appear there.
ALLOWED_OPTIONAL_HOSTS = {"http://127.0.0.1/*", "http://localhost/*"}
CSP_ALLOWED_HTTP = {"http://127.0.0.1:*", "http://localhost:*"}


def read(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()


def load_meta(src):
    data_path = os.path.join(src, "data.js")
    js = ("const fs=require('fs');const vm=require('vm');const sb={window:{},self:{}};vm.createContext(sb);"
          "vm.runInContext(fs.readFileSync(process.argv[1],'utf8'),sb,{timeout:5000});"
          "const d=sb.window.ORACLE_DATA||{};process.stdout.write(JSON.stringify({meta:d.meta||{},level:(d.posture||{}).level||''}));")
    out = subprocess.run(["node", "-e", js, data_path], capture_output=True, text=True, timeout=20)
    if out.returncode != 0:
        print("ERROR: could not evaluate data.js:", out.stderr.strip(), file=sys.stderr)
        sys.exit(2)
    j = json.loads(out.stdout)
    return j.get("meta", {}), j.get("level", "")


def load_theatres(src):
    data_path = os.path.join(src, "data.js")
    js = ("const fs=require('fs');const vm=require('vm');const sb={window:{},self:{}};vm.createContext(sb);"
          "vm.runInContext(fs.readFileSync(process.argv[1],'utf8'),sb,{timeout:5000});"
          "const d=sb.window.ORACLE_DATA||{};process.stdout.write(JSON.stringify(((d.triadMaps||{}).theatres||[]).map(t=>t.id)));")
    out = subprocess.run(["node", "-e", js, data_path], capture_output=True, text=True, timeout=20)
    if out.returncode != 0:
        return []
    return [t for t in json.loads(out.stdout or "[]") if re.match(r"^[a-z0-9-]+$", str(t))]


def check_security(manifest):
    problems = []
    if manifest.get("manifest_version") != 3:
        problems.append("manifest_version must be 3")
    extra_perm = set(manifest.get("permissions", [])) - ALLOWED_PERMISSIONS
    if extra_perm:
        problems.append(f"permissions beyond storage+alarms: {sorted(extra_perm)}")
    if manifest.get("optional_permissions"):
        problems.append("optional_permissions must be empty")
    extra_hosts = set(manifest.get("host_permissions", [])) - ALLOWED_HOSTS
    if extra_hosts:
        problems.append(f"host_permissions beyond the allowlist: {sorted(extra_hosts)}")
    extra_opt = set(manifest.get("optional_host_permissions", [])) - ALLOWED_OPTIONAL_HOSTS
    if extra_opt:
        problems.append(f"optional_host_permissions beyond loopback: {sorted(extra_opt)}")
    csp = (manifest.get("content_security_policy") or {}).get("extension_pages", "")
    if "script-src 'self'" not in csp or "unsafe-eval" in csp or "script-src 'self' 'unsafe-inline'" in csp:
        problems.append("CSP must keep script-src 'self' with no unsafe-eval / inline scripts")
    for m in re.findall(r"http://[^\s;]+", csp):
        if m not in CSP_ALLOWED_HTTP:
            problems.append(f"CSP allows a non-loopback http source: {m}")
    if re.search(r"script-src[^;]*http", csp):
        problems.append("CSP script-src must not allow any http(s) source")
    if manifest.get("content_scripts"):
        problems.append("no content_scripts allowed (no scripting into pages)")
    return problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=os.path.join(ROOT, "assets", "extension"))
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "build"))
    ap.add_argument("--maps-dir", default=os.path.join(ROOT, "dist", "maps", "ext"), help="extension-mode map pages from maps_build.py (dist/maps/ext)")
    ap.add_argument("--no-maps", action="store_true")
    args = ap.parse_args()
    src = args.src

    meta, posture = load_meta(src)
    slug = (meta.get("slug") or "country").lower()
    brand = meta.get("brand") or "LOOKING GLASS"
    line = meta.get("line") or "Nuclear Forces & Military Posture Monitor"
    country = meta.get("country") or ""

    manifest = json.loads(read(os.path.join(src, "manifest.json")))
    problems = check_security(manifest)
    if problems:
        print("ERROR: security posture regression in manifest.json:", file=sys.stderr)
        for p in problems:
            print("  - " + p, file=sys.stderr)
        return 1
    manifest["name"] = f"{brand} — {line}".strip(" —")
    manifest["description"] = (
        f"{brand} — an all-source OSINT monitor on {country or 'a country'}'s nuclear forces and military posture: "
        "force structure, readiness, doctrine, intent and threat with IC-grade tradecraft (BLUF/Key Judgments, I&W, ACH, source grading); "
        "Air Watch, Launcher Watch, Sub Watch, embedded triad likelihood maps, public channel lanes, public-ADS-B boards and an optional loopback "
        "link to your own read-only collector. Public reporting only — no positions, no targeting."
    )
    manifest["action"]["default_title"] = brand
    manifest_str = json.dumps(manifest, indent=2, ensure_ascii=False)

    os.makedirs(args.out_dir, exist_ok=True)
    top = f"{slug}-monitor"
    zip_path = os.path.join(args.out_dir, f"{slug}-monitor-extension.zip")
    written = []
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for name in INCLUDE:
            p = os.path.join(src, name)
            if not os.path.exists(p):
                if name in ("manifest.json", "background.js", "sanitize.js", "data.js", "dashboard.html", "dashboard.css", "dashboard.js"):
                    print(f"ERROR: required file missing: {name}", file=sys.stderr)
                    return 1
                continue
            arc = f"{top}/{name}"
            if name == "manifest.json":
                z.writestr(arc, manifest_str)
            else:
                z.write(p, arc)
            written.append(arc)
        for d in INCLUDE_DIRS:
            dp = os.path.join(src, d)
            if not os.path.isdir(dp):
                continue
            for fn in sorted(os.listdir(dp)):
                fp = os.path.join(dp, fn)
                if os.path.isfile(fp):
                    arc = f"{top}/{d}/{fn}"
                    z.write(fp, arc)
                    written.append(arc)
        # Triad Map theatres (extension-mode pages: external scripts only, so the CSP holds)
        theatres = [] if args.no_maps else load_theatres(src)
        if theatres:
            missing = []
            for tid in theatres:
                page = os.path.join(args.maps_dir, tid + ".html"); data = os.path.join(args.maps_dir, tid + ".data.js")
                if not (os.path.exists(page) and os.path.exists(data)):
                    missing.append(tid); continue
                for fp, arc in ((page, f"{top}/maps/{tid}.html"), (data, f"{top}/maps/{tid}.data.js")):
                    z.write(fp, arc); written.append(arc)
            eng = os.path.join(args.maps_dir, "engine.js")
            if os.path.exists(eng):
                z.write(eng, f"{top}/maps/engine.js"); written.append(f"{top}/maps/engine.js")
            else:
                missing.append("engine.js")
            if missing:
                print("ERROR: Triad Map theatres missing from " + args.maps_dir + ": " + ", ".join(missing) + " (run maps_build_all.sh, or --no-maps)", file=sys.stderr)
                return 1

    print(f"Packaged: {zip_path}")
    print(f"  top-level folder: {top}/")
    print(f"  name: {manifest['name']}  posture: {posture}")
    print(f"  files: {len(written)}")
    print("  load via chrome://extensions -> Developer mode -> Load unpacked (after unzip)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
