#!/usr/bin/env node
/* maps_test_model.js — run the map engine headless for a theatre and print the analytic readout.
   Usage: node scripts/maps_test_model.js data/theatres/<theatre>.json [--build build/maps/<id>] [--json]
                                          [--posture <level>] [--scenario a,b] [--off factorId,factorId]
   Prints per class: normalisation, 50/80/95 % HDR areas, on-station fraction, top regions, T+12h/T+48h checks.
   --posture / --scenario / --off probe a non-default context (each run gets a fresh ctx — the engine caches
   ctx.pm, so never reuse one ctx object across postures). Fails (exit 1) if a surface does not normalise or a
   class produces no reachable mass. */
const fs = require('fs'), path = require('path');
const args = process.argv.slice(2); const file = args.find(a => !a.startsWith('--')); const asJson = args.includes('--json');
const opt = k => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : null; };
const cfg = JSON.parse(fs.readFileSync(file, 'utf8'));
const bdir = opt('--build') || path.join('build', 'maps', cfg.meta.id);
globalThis.GRID = JSON.parse(fs.readFileSync(path.join(bdir, 'grid.json'), 'utf8')); globalThis.CFG = cfg;
let t0 = Date.now(); require(path.join(__dirname, '..', 'assets', 'maps', 'engine', 'model.js')); const M = globalThis.MODEL;
const posture = opt('--posture') || cfg.meta.posture_default;
const scenarios = {}; (opt('--scenario') || '').split(',').filter(Boolean).forEach(s => scenarios[s] = true);
const enabled = {}; (opt('--off') || '').split(',').filter(Boolean).forEach(f => enabled[f] = false);
const mkCtx = extra => Object.assign({ posture, scenarios: Object.assign({}, scenarios), enabled: Object.assign({}, enabled), hours: null }, extra || {});
const out = { id: cfg.meta.id, domain: M.DOMAIN, posture, scenarios: Object.keys(scenarios), off: Object.keys(enabled), init_ms: Date.now() - t0, passable_cells: M.seaCount, classes: {} }; let fail = false;
for (const cls of Object.keys(cfg.classes)) {
  t0 = Date.now(); const ctx = mkCtx(); const s = M.classSurface(cls, ctx); let sum = 0; for (let i = 0; i < s.length; i++) sum += s[i]; const h = M.hdr(s); const rows = M.regionMass(s);
  const rec = { sum: +sum.toFixed(4), ms: Date.now() - t0, hdr50: Math.round(h.areas[0.5]), hdr80: Math.round(h.areas[0.8]), hdr95: Math.round(h.areas[0.95]), on_station: +(M.transitSplit(cls, ctx) || 0).toFixed(2), top: rows.slice(0, 8).map(r => [r.name, +(100 * r.mass).toFixed(1)]), t12_hdr50: 0, t48_hdr50: 0 };
  for (const hrs of [12, 48]) { const c2 = mkCtx({ hours: hrs }); const s2 = M.classSurface(cls, c2); rec[`t${hrs}_hdr50`] = Math.round(M.hdr(s2).areas[0.5]); }
  if (!(Math.abs(sum - 1) < 1e-6)) { fail = true; rec.error = 'surface does not normalise'; } if (!h.areas[0.5]) { fail = true; rec.error = 'no mass'; }
  out.classes[cls] = rec;
  if (!asJson) { console.log(`\n${cls} (sum=${rec.sum}, ${rec.ms} ms) HDR nm²: 50% ${rec.hdr50} · 80% ${rec.hdr80} · 95% ${rec.hdr95} · on-station ${rec.on_station} · T+12h 50% ${rec.t12_hdr50} · T+48h 50% ${rec.t48_hdr50}${rec.error ? ' · ERROR ' + rec.error : ''}`); for (const [n, m] of rec.top) console.log(`   ${String(m).padStart(5)} %  ${n}`); }
}
t0 = Date.now(); const cs = M.combinedSurface(mkCtx()); out.combined_ms = Date.now() - t0; out.contour_segments_50 = M.contours(M.hdr(cs).dens, M.hdr(cs).levels[0.5]).length;
if (asJson) console.log(JSON.stringify(out, null, 1)); else console.log(`\n[${M.DOMAIN}] posture ${posture}${Object.keys(scenarios).length ? ' · scenarios ' + Object.keys(scenarios).join(',') : ''} · combined ${out.combined_ms} ms · 50 % contour segments ${out.contour_segments_50} · init ${out.init_ms} ms · passable cells ${out.passable_cells}`);
process.exit(fail ? 1 : 0);
