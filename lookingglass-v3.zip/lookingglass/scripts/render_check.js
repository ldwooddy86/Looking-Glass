#!/usr/bin/env node
/* render_check.js — open a built preview in headless Chromium, click every
   visible tab, assert each section mounted content, and fail on any console
   error. Optionally screenshot every tab.
   Usage: node scripts/render_check.js <preview.html> [--shots DIR] [--ext]
     --ext  also run an EXTENSION-MODE pass with a fake chrome.* API (cached
            lanes + a fake ADS-B feed) to exercise the live layers offline. */
const path = require("path");
const fs = require("fs");
let chromium;
try { ({ chromium } = require("playwright")); } catch (e) { console.error("playwright not installed (npm i playwright)"); process.exit(3); }

const args = process.argv.slice(2);
const file = args[0];
if (!file) { console.error("usage: render_check.js <preview.html> [--shots DIR] [--ext]"); process.exit(3); }
const shotsIdx = args.indexOf("--shots");
const shots = shotsIdx !== -1 ? args[shotsIdx + 1] : null;
const doExt = args.indexOf("--ext") !== -1;

const TABS = [
  ["tp-bluf", "productMount"], ["tp-matrix", "matrixMount"], ["tp-forces", "forcesMount"], ["tp-iw", "iwMount"],
  ["tp-escalation", "escMount"], ["tp-movement", "movementMount"], ["tp-track", "trackMount"],
  ["tp-air", "airMount"], ["tp-launcher", "launcherMount"], ["tp-sub", "subMount"], ["tp-maps", "mapsMount"],
  ["tp-feed", "feedMount"], ["tp-gallery", "galleryMount"],
  ["tp-terror", "terrorMount"], ["tp-soft", "softMount"], ["tp-infra", "infraMount"], ["tp-geo", "geoMount"],
  ["tp-media", "mediaMount"], ["tp-social", "socialMount"], ["tp-collection", "lanesMount"], ["tp-sources", "reliabilityMount"],
];

// A minimal fake of the chrome.* surface the dashboard uses, with canned cache content.
const FAKE_CHROME = `
(function(){
  var store = {};
  var tg_cache = {
    fakelane: { ok:true, ts: Date.now()-120000, html: '<div class="tgme_widget_message"><div class="tgme_widget_message_text">Reports of mobilization and reserve call-up near the coast; 动员 orders and a blockade drill announced. <script>alert(1)</script></div><time datetime="' + new Date(Date.now()-3600000).toISOString() + '">1h</time></div><div class="tgme_widget_message"><div class="tgme_widget_message_text">Second post: barge marshalling seen, amphibious loading.</div><time datetime="' + new Date(Date.now()-7200000).toISOString() + '">2h</time></div>' },
    otherlane: { ok:true, ts: Date.now()-60000, html: '<div class="tgme_widget_message"><div class="tgme_widget_message_text">mobilization chatter repeated here too</div><time datetime="' + new Date(Date.now()-1800000).toISOString() + '">30m</time></div>' },
    deadlane: { ok:false, error:'HTTP 404', ts: Date.now()-60000 }
  };
  function firstTypes(){ try { var t=(window.ORACLE_DATA.trackWatch||{}).types||[]; return t.map(function(x){return x.key;}); } catch(e){ return []; } }
  function airTypes(){ try { var t=((window.ORACLE_DATA.airWatch||{}).live||{}).types||[]; return t.map(function(x){return "air:"+x.key;}); } catch(e){ return []; } }
  var col_cache = { ok:true, ts: Date.now()-90000, summary:{ items: 2, media: 1, version: "test", sources: [{kind:"telegram", id:"x", ok:true},{kind:"discord", id:"y", ok:false}] },
    items:[ { id:"i1", ts: Math.floor(Date.now()/1000)-600, source:{kind:"telegram", id:"fakelane", label:"Fake lane", lane:"aggregator"}, author:"someone", text:"Tu-95MS pair took off from Engels — <img src=x onerror=alert(1)> unverified claim", url:"https://t.me/fakelane/1", lang:"en", leg:"air", kind:"sortie", entities:{aircraft:["Tu-95MS"], bases:["Engels"]}, triage:{relevance:0.9, grade:"C3", summary_en:"Claimed bomber take-off; single lane.", reason:"vocabulary match", claims:[]}, media:["m1"] },
            { id:"i2", ts: Math.floor(Date.now()/1000)-3600, source:{kind:"rss", id:"https://example.org/feed", label:"Example wire", lane:"wire"}, text:"Yars regiments on combat patrol in the Ivanovo region, ministry says", url:"https://example.org/a", leg:"land", kind:"exercise", entities:{launchers:["Yars"], units:["54th Guards Missile Division"]}, triage:{relevance:0.6, grade:"B2", summary_en:"Announced patrol.", reason:"official statement"} } ],
    media:[ { id:"m1", item_id:"i1", kind:"photo", thumb:"/media/thumb/m1.jpg", w:640, h:480, phash:"abc", dups:1, source:{kind:"telegram", id:"fakelane", label:"Fake lane"}, ts: Math.floor(Date.now()/1000)-600, triage:{what:"Four-engine turboprop on an apron", aircraft:["Tu-95MS (suggested)"], claimed_place:"Engels-2", consistency:"Apron layout plausible; date unverifiable"}, url:"https://t.me/fakelane/1" } ],
    digest:{ ts: Math.floor(Date.now()/1000)-300, text:"UNVERIFIED digest. Lead 1: claimed Tu-95 pair. Not seen: any NOTAM." } };
  window.__fakeChromeMessages = [];
  window.chrome = {
    runtime: {
      id: "fakeextid", lastError: null,
      sendMessage: function(msg, cb){
        window.__fakeChromeMessages.push(msg && msg.type);
        if (msg.type === "getCache") {
          var keys = firstTypes(); var ac = [];
          if (keys[0]) ac.push({ cls:keys[0], hex:"abc123", r:"AE1234", flight:"TEST01", t:"P8", alt:31000, gs:420, lat:24.1, lon:119.9, airborne:true });
          if (keys[1]) ac.push({ cls:keys[1], hex:"abc124", r:"AE5678", flight:"TEST02", t:"R135", alt:"ground", gs:5, lat:26.3, lon:127.7, airborne:false });
          if (keys[2]) ac.push({ cls:keys[2], hex:"abc125", r:"AE9999", flight:"TEST03", t:"Q4", alt:52000, gs:330, lat:20.5, lon:125.0, airborne:true });
          var pol = {}; keys.forEach(function(k,i){ pol[k] = { days7: i===0?6:1, lastSeen: Date.now()-3600000 }; });
          var ak = airTypes(); if (ak[0]) ac.push({ cls:ak[0], hex:"abd001", r:"RF-94261", flight:"", t:"IL76", alt:29000, gs:410, lat:55.9, lon:38.1, airborne:true }); if (ak[1]) ac.push({ cls:ak[1], hex:"abd002", r:"RF-93643", flight:"", t:"IL76", alt:"ground", gs:0, lat:54.6, lon:39.6, airborne:false });
          ak.forEach(function(k,i){ pol[k] = { days7: i===0?2:0, lastSeen: Date.now()-7200000 }; });
          cb({ tg_cache: tg_cache, tg_health: { deadlane: { fails: 3 } }, tg_last_run: Date.now()-60000,
               col_cache: col_cache, col_last_run: Date.now()-90000, collector: { endpoint: "http://127.0.0.1:8787", enabled: true },
               flt_cache: { ok:true, ac: ac, ts: Date.now(), total: 900 }, flt_last_run: Date.now(),
               flt_track: { events: [ { ts: Date.now()-300000, kind:"appeared", cls:keys[0]||"x", hex:"abc123", r:"AE1234", lat:24.1, lon:119.9 } ] },
               flt_pol: pol, sec_cache: { ok:true, total: 120, mil: 3, ac: [{cls:keys[0]||"x"}] } });
        } else if (cb) cb({ ok:true });
      }
    },
    storage: { local: {
      get: function(keys, cb){ var out={}; (Array.isArray(keys)?keys:[keys]).forEach(function(k){ if (k in store) out[k]=store[k]; }); cb(out); },
      set: function(obj, cb){ Object.keys(obj).forEach(function(k){ store[k]=obj[k]; }); if (cb) cb(); },
      remove: function(keys, cb){ (Array.isArray(keys)?keys:[keys]).forEach(function(k){ delete store[k]; }); if (cb) cb(); }
    } },
    tabs: { create: function(){} }
  };
})();`;

(async () => {
  const browser = await chromium.launch();
  let exitCode = 0;
  async function pass(label, initScript) {
    const page = await browser.newPage({ viewport: { width: 1360, height: 1700 } });
    const errors = [];
    page.on("console", m => { if (m.type() === "error") { const t = m.text(); if (initScript && /Failed to load resource/.test(t)) return; errors.push(t); } });
    page.on("pageerror", e => errors.push("PAGEERROR: " + e.message));
    if (initScript) await page.addInitScript(initScript);
    await page.addInitScript(() => { window.__alertFired = false; window.alert = () => { window.__alertFired = true; }; });
    // Force extension mode past the PREVIEW_MODE flag the builder injects.
    if (initScript) await page.addInitScript(() => { Object.defineProperty(window, "PREVIEW_MODE", { get() { return false; }, set() {}, configurable: true }); });
    await page.goto("file://" + path.resolve(file), { waitUntil: "load" });
    await page.waitForTimeout(700);
    const report = {};
    for (const [tab, mount] of TABS) {
      const hidden = await page.$eval(`[data-tab="${tab}"]`, el => el.hidden).catch(() => true);
      if (hidden) { report[tab] = "hidden"; continue; }
      await page.click(`[data-tab="${tab}"]`);
      await page.waitForTimeout(120);
      const len = await page.$eval("#" + mount, el => el.textContent.trim().length).catch(() => -1);
      report[tab] = len;
      if (len <= 0) { errors.push("EMPTY MOUNT: " + tab + "/" + mount); }
      if (shots) { fs.mkdirSync(shots, { recursive: true }); await page.screenshot({ path: path.join(shots, `${label}-${tab}.png`), fullPage: true }); }
    }
    const brand = await page.$eval("#brandName", e => e.textContent).catch(() => "");
    const gauge = await page.$eval("#gaugeFlag", e => e.textContent).catch(() => "");
    const kj = await page.$$eval(".kj", els => els.length).catch(() => 0);
    const mx = await page.$$eval(".tmx-table tr", els => els.length).catch(() => 0);
    const iw = await page.$$eval(".iw-table tr", els => els.length).catch(() => 0);
    const ach = await page.$$eval(".ach-cell", els => els.length).catch(() => 0);
    const mode = await page.$eval("#modePill", e => e.textContent).catch(() => "");
    let extra = "";
    const subOn = await page.$eval('[data-tab="tp-sub"]', el => !el.hidden).catch(() => false);
    if (subOn) {
      const swCards = await page.$$eval(".sw-card", els => els.length).catch(() => 0);
      const swEnv = await page.$$eval(".sw-env tr", els => els.length).catch(() => 0);
      const swDict = await page.$$eval("#subScannerMount .kw-chip", els => els.length).catch(() => 0);
      extra += ` | subWatch: classes=${swCards} ledgerRows=${Math.max(0, swEnv - 1)} scannerTerms=${swDict}`;
      if (!swCards) errors.push("SUB: order-of-battle board rendered no class cards");
      if (!swDict) errors.push("SUB: undersea-language scanner rendered no dictionary");
    }
    const airOn = await page.$eval('[data-tab="tp-air"]', el => !el.hidden).catch(() => false);
    if (airOn) { const awCards = await page.$$eval(".aw-fleet .sw-card", els => els.length).catch(() => 0); const awLive = await page.$$eval("#airLiveMount .fleet-card", els => els.length).catch(() => 0); const awDict = await page.$$eval("#airScannerMount .kw-chip", els => els.length).catch(() => 0); extra += ` | airWatch: fleet=${awCards} liveTypes=${awLive} scannerTerms=${awDict}`; if (!awCards) errors.push("AIR: order-of-battle rendered no cards"); if (!awDict) errors.push("AIR: scanner rendered no dictionary"); }
    const lwOn = await page.$eval('[data-tab="tp-launcher"]', el => !el.hidden).catch(() => false);
    if (lwOn) { const lwCards = await page.$$eval(".lw-fleet .sw-card", els => els.length).catch(() => 0); const lwDict = await page.$$eval("#launcherScannerMount .kw-chip", els => els.length).catch(() => 0); extra += ` | launcherWatch: fleet=${lwCards} scannerTerms=${lwDict}`; if (!lwCards) errors.push("LAUNCHER: order-of-battle rendered no cards"); if (!lwDict) errors.push("LAUNCHER: scanner rendered no dictionary"); }
    const mapsOn = await page.$eval('[data-tab="tp-maps"]', el => !el.hidden).catch(() => false);
    if (mapsOn) { await page.click('[data-tab="tp-maps"]'); await page.waitForTimeout(5000); const tiles = await page.$$eval(".map-tile", els => els.length).catch(() => 0); const frames = await page.$$eval("iframe.map-frame", els => els.length).catch(() => 0); const frameOk = await page.evaluate(() => { const f = document.querySelector("iframe.map-frame"); try { return !!(f && f.contentDocument && f.contentDocument.querySelector("#heat")); } catch (e) { return false; } }); extra += ` | triadMap: tiles=${tiles} frames=${frames} frameRendered=${frameOk}`; if (!tiles) errors.push("MAPS: no theatre tiles"); if (frames && !frameOk && !initScript) errors.push("MAPS: embedded map frame did not render a heat canvas"); }
    if (initScript) {
      const feedOn = await page.$eval('[data-tab="tp-feed"]', el => !el.hidden).catch(() => false);
      if (feedOn) { const items = await page.$$eval(".feed-item", els => els.length).catch(() => 0); const gal = await page.$$eval(".gal-card", els => els.length).catch(() => 0); const feedNeutral = await page.evaluate(() => !window.__alertFired && document.querySelectorAll("#feedMount .feed-text img, #feedMount .feed-text script").length === 0 && document.body.textContent.indexOf("unverified claim") !== -1); const airBanner = await page.$eval("#airLiveMount .ab-label", e => e.textContent).catch(() => ""); extra += ` | feed items=${items} media=${gal} hostileFeedTextOnly=${feedNeutral} airBanner=${JSON.stringify(airBanner)}`; if (!items) errors.push("FEED: no items rendered from the canned collector cache"); if (!gal) errors.push("MEDIA: no gallery cards rendered"); if (!feedNeutral) errors.push("FEED: hostile markup in an item was not rendered as text"); }
      const hits = await page.$$eval(".mv-hit", els => els.length).catch(() => 0);
      const corr = await page.$$eval(".mv-corr-row", els => els.length).catch(() => 0);
      const banner = await page.$eval(".ab-label", e => e.textContent).catch(() => "");
      const lanes = await page.$$eval(".lane", els => els.length).catch(() => 0);
      const injected = await page.evaluate(() => document.querySelectorAll("script").length);
      const neutralized = await page.evaluate(() => document.body.textContent.indexOf("alert(1)") !== -1 && !window.__alertFired);
      const expectedScripts = fs.readFileSync(path.resolve(file), "utf8").match(/<script[\s>]/g).length;
      extra += ` | scanner hits: ${hits} corroborated terms: ${corr} track banner: ${JSON.stringify(banner)} lanes: ${lanes} script-tags: ${injected}/${expectedScripts} hostile-markup-neutralized: ${neutralized}`;
      if (!hits) errors.push("EXT: scanner produced no hits on the canned lanes");
      if (!/ALERT|RED/.test(banner)) errors.push("EXT: track banner did not escalate on a crit sortie (" + banner + ")");
      if (injected !== expectedScripts) errors.push("EXT: unexpected script element count " + injected + " (expected " + expectedScripts + ") — remote markup may have been inserted as HTML");
      if (!neutralized) errors.push("EXT: hostile markup in a lane was not neutralized");
    }
    console.log(`[${label}] mode=${mode} brand=${JSON.stringify(brand)} gauge=${JSON.stringify(gauge)} KJ=${kj} matrixRows=${mx} iwRows=${iw} achCells=${ach}${extra}`);
    console.log(`[${label}] mounts: ${JSON.stringify(report)}`);
    console.log(`[${label}] CONSOLE ERRORS: ${errors.length}`);
    errors.slice(0, 20).forEach(e => console.log("  ! " + e));
    if (errors.length) exitCode = 2;
    await page.close();
  }
  await pass("preview", null);
  if (doExt) await pass("ext", FAKE_CHROME);
  await browser.close();
  process.exit(exitCode);
})();
