#!/usr/bin/env python3
"""
maps_build.py — assemble one LOOKING GLASS map theatre (sea, land or air) into HTML.

Usage:
    python scripts/maps_build.py --config data/theatres/<theatre>.json [--build build/maps/<id>] [--out dist/maps]

Requires maps_prep_geo.py to have produced <build>/grid.json and geo.json.
Writes:
    <out>/<id>.html            full standalone document (download / offline / embedded into the dashboard preview)
    <out>/<id>.artifact.html   fragment without doctype/html/head/body (for the Artifact tool)
    <out>/ext/<id>.html        extension-mode page: NO inline scripts (MV3 CSP script-src 'self'),
    <out>/ext/<id>.data.js     loads <id>.data.js (GRID/CFG/GEO) and the shared engine.js
    <out>/ext/engine.js        model.js + app.js concatenated (written once per run)
All CSS/JS/data are inlined in the standalone; no external requests; system fonts only.
"""
import argparse, html, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ENGINE = os.path.join(ROOT, "assets", "maps", "engine")

DOMAIN_TEXT = {
    "sea": dict(line="Sea-leg operating-area likelihood", unit="boat", units="boats", deployed="at sea", areas="named sea areas", h1="Where a <span class=\"amb\">{adj} submarine</span> is most likely to be once it leaves port",
                tagline="Bayesian operating-area prior · per hull class · time since sortie · every weight traceable to a reference", ctl_time="Time since sortie", ctl_posture="Sea-leg posture", sortie="sortie",
                bluf_warn="Conditional on being at sea. Whether any boat is out, armed or on alert is not observable — the at-sea counts are posture assumptions.",
                rail="Nothing on this page is a position, track, patrol box or alert state; the surface is what public structure implies about an at-sea boat's likely water.",
                routing="16-neighbour sea-distance field, multiple-flow-direction transit", basemap="Natural Earth 10 m coastline & isobaths (200 · 2,000 · 4,000 m)", tile_onst="On station", table_note="The map's tabular twin: the same surface summed over analyst-drawn sea-area polygons. E[boats] multiplies the share by the assumed at-sea count.",
                bases_label="Home ports &amp; yards", asw_label="Adversary MPA / ASW basing", hubs_label="Own sensor / support hubs", events_label="Detections · launches · visits · surveys", chokes_label="Chokepoints", lines_label="Surveillance &amp; barrier lines", labels_label="Sea &amp; place labels", zones_label="Doctrine &amp; mission polygons"),
    "land": dict(line="Land-leg dispersal-area likelihood", unit="launcher", units="launchers", deployed="in the field", areas="named dispersal areas", h1="Where a <span class=\"amb\">{adj} road-mobile launcher</span> is most likely to be once it leaves garrison",
                 tagline="Bayesian dispersal-area prior · per launcher class · time since leaving garrison · every weight traceable to a reference", ctl_time="Time since leaving garrison", ctl_posture="Land-leg posture", sortie="leaving garrison",
                 bluf_warn="Conditional on a launcher being in the field. Whether any regiment has dispersed, whether warheads are mated and whether crews are on alert is not observable — the in-the-field counts are posture assumptions.",
                 rail="Nothing on this page is a position, track, field-position or alert state; the surface is what public basing, road structure, cover and declared doctrine imply about a dispersed launcher's likely ground.",
                 routing="16-neighbour road-cost distance field, multiple-flow-direction dispersal routing", basemap="Natural Earth 10 m land, lakes, rivers, roads and urban areas; cover from analyst polygons", tile_onst="In field positions", table_note="The map's tabular twin: the same surface summed over analyst-drawn dispersal-area polygons. E[launchers] multiplies the share by the assumed in-the-field count.",
                 bases_label="Garrisons &amp; depots", asw_label="Adversary ISR / strike reach", hubs_label="Support &amp; technical bases", events_label="Reported exercises · sightings · closures", chokes_label="River crossings &amp; chokepoints", lines_label="Rail &amp; surveillance lines", labels_label="Region &amp; place labels", zones_label="Positional areas &amp; exclusions"),
    "air": dict(line="Air-leg sortie-area likelihood", unit="aircraft", units="aircraft", deployed="airborne", areas="named airspace areas", h1="Where a <span class=\"amb\">{adj} strike or support aircraft</span> is most likely to be once it is airborne",
                tagline="Bayesian sortie-area prior · per aircraft class · time since take-off · every weight traceable to a reference", ctl_time="Time since take-off", ctl_posture="Air-leg posture", sortie="take-off",
                bluf_warn="Conditional on an aircraft being airborne. Whether any bomber is generated, loaded or on alert is not observable — the airborne counts are posture assumptions; public ADS-B broadcasts, where drawn, are what community receivers heard, not a track.",
                rail="Nothing on this page is a target, a track or an alert state; the surface is what public basing, range, declared training areas, demonstrated launch geometry and adversary air defence imply about an airborne aircraft's likely airspace.",
                routing="16-neighbour airspace-cost distance field, multiple-flow-direction routing", basemap="Natural Earth 10 m land & admin-0 boundaries; airspace classes from the theatre config", tile_onst="On station / orbit", table_note="The map's tabular twin: the same surface summed over analyst-drawn airspace polygons. E[aircraft] multiplies the share by the assumed airborne count.",
                bases_label="Air bases &amp; dispersal fields", asw_label="Adversary air defence / interceptor basing", hubs_label="Tanker &amp; support hubs", events_label="Launch boxes · intercepts · closures", chokes_label="Corridors &amp; gateways", lines_label="ADIZ &amp; radar lines", labels_label="Sea, land &amp; place labels", zones_label="Training areas &amp; exclusions"),
}


def esc_script(s):
    return s.replace("</", "<\\/")


def render(cfg, gridj, geoj, css, model, app, mode):
    meta, text, grid = cfg["meta"], cfg.get("text", {}), cfg["grid"]
    domain = grid.get("domain", "sea")
    T = dict(DOMAIN_TEXT.get(domain, DOMAIN_TEXT["sea"]))
    T.update(cfg.get("vocab_text", {}))
    adj = meta.get("adjective", "")
    title = meta.get("title") or f"{adj} {T['line']}"
    brand = meta.get("brand", "LOOKING GLASS")
    sig = """<svg class="sig" viewBox="0 0 26 26" aria-hidden="true"><circle cx="13" cy="13" r="11.5" fill="none" stroke="#FFB454" stroke-width="1.4"/><circle cx="13" cy="13" r="6.5" fill="none" stroke="#FFB454" stroke-width="1.1" opacity=".7"/><circle cx="13" cy="13" r="2" fill="#FFB454"/><path d="M13 1.5v4M13 20.5v4M1.5 13h4M20.5 13h4" stroke="#FFB454" stroke-width="1.2"/></svg>"""
    banner = text.get("banner", "Unclassified // open source // structural prior derived from public reporting — not a track, not a detection, not a position")
    pills = "".join(f'<span class="pill {p.get("tone","")}">{html.escape(p["text"])}</span>' for p in meta.get("pills", [{"text": f"Edition {meta.get('edition','')} · compiled {meta.get('compiled','')}", "tone": "amber"}]))
    lead = text.get("lead_html", "")
    h1 = text.get("h1_html", T["h1"].format(adj=html.escape(adj)))
    tagline = text.get("tagline", T["tagline"])
    bluf = text.get("bluf_html", "")
    bluf_warn = text.get("bluf_warn_html", T["bluf_warn"])
    method = text.get("method_html", ""); structural = text.get("structural_html", ""); movers = text.get("movers_html", ""); limits = text.get("limits_html", ""); sources = text.get("sources_html", "")
    triad = cfg.get("triad", {})
    modelled = {"sea": "sea", "land": "land", "air": "air"}[domain]
    def leg_cls(l):
        return "modelled" if (l.get("leg", "").lower().startswith(modelled)) else ""
    triad_rows = "".join(f'<tr class="{leg_cls(l)}"><td class="leg {leg_cls(l)}">{html.escape(l.get("leg",""))}</td><td>{l.get("systems_html","")}</td><td>{l.get("warheads_html","")}</td><td>{l.get("posture_html","")}<div class="refs">{html.escape(" · ".join(l.get("refs",[])))}</div></td></tr>' for l in triad.get("legs", []))
    layer_menu = f"""
      <label><input type="checkbox" data-layer="contours"><span class="mk" style="border-top:2px solid #FFB454;height:0"></span>HDR contours 50 / 80 / 95 %</label>
      <label><input type="checkbox" data-layer="bases"><span class="mk" style="background:#FFB454"></span>{T['bases_label']}</label>
      <label><input type="checkbox" data-layer="chokes"><span class="mk" style="border:1.5px solid #C9D3E3;border-radius:50%"></span>{T['chokes_label']}</label>
      <label><input type="checkbox" data-layer="lines"><span class="mk" style="border-top:2px dashed #9B8CFF;height:0"></span>{T['lines_label']}</label>
      <label><input type="checkbox" data-layer="hubs"><span class="mk" style="background:#FFB454;transform:rotate(45deg);width:9px;height:9px"></span>{T['hubs_label']}</label>
      <label><input type="checkbox" data-layer="asw"><span class="mk" style="width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:11px solid #7CC5A0"></span>{T['asw_label']}</label>
      <label><input type="checkbox" data-layer="events"><span class="mk" style="border:1.5px solid #FF5B47;transform:rotate(45deg);width:9px;height:9px"></span>{T['events_label']}</label>
      <label><input type="checkbox" data-layer="zones"><span class="mk" style="border:1px dashed #C97F1E"></span>{T['zones_label']}</label>
      <label><input type="checkbox" data-layer="labels"><span class="mk" style="border-bottom:1px solid #4A6188;height:0"></span>{T['labels_label']}</label>
      <label><input type="checkbox" data-layer="graticule"><span class="mk" style="border:1px solid #1C2C48"></span>Graticule</label>"""
    if domain == "air":
        layer_menu += """
      <label><input type="checkbox" data-layer="live"><span class="mk" style="width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:11px solid #7CC5A0"></span>Live public ADS-B (dashboard-fed, coarse)</label>"""
    units_cap = T["units"].capitalize()
    body = f"""
<a class="skip" href="#viewport">Skip to map</a>
<div class="cls">{html.escape(banner)}</div>
<header class="cmd"><div class="wrap cmd-inner">
  <div class="brandmark">{sig}<div><div class="t1">{html.escape(brand)} · {html.escape(meta.get('line', T['line']))}</div><div class="t2">{html.escape(title)}</div></div></div>
  {pills}
</div></header>
<section class="wrap mast">
  <div><h1>{h1}</h1><div class="mast-tag">{html.escape(tagline)}</div><p class="lead">{lead}</p></div>
  <aside class="bluf"><div class="k">BLUF</div><p>{bluf}</p><p class="warn">{bluf_warn}</p></aside>
</section>
<div class="controls"><div class="wrap controls-inner">
  <div class="ctl"><span class="lbl">Class</span><div class="seg" id="clsseg" role="group" aria-label="Class"></div></div>
  <div class="ctl"><span class="lbl">{T['ctl_time']}</span><input type="range" id="tslider" min="0" max="9" step="1" value="9" aria-label="Hours since {T['sortie']}"><span class="val" id="tval">Average</span></div>
  <div class="ctl"><span class="lbl">{T['ctl_posture']}</span><select class="sel" id="posture" aria-label="Posture level"></select></div>
  <div class="ctl-scen" id="scenarios"></div>
  <div class="layers" style="margin-left:auto"><button class="btn" id="layerbtn" aria-haspopup="true">Layers ▾</button><div class="menu" id="layermenu" hidden>{layer_menu}</div></div>
</div></div>
<main class="wrap main">
  <section class="mapcard" aria-label="Likelihood map">
    <div class="viewport" id="viewport" tabindex="0">
      <div class="world" id="world"><svg id="base" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"></svg><canvas id="heat" aria-label="Probability heat surface"></canvas><svg id="overlay" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Map overlays"></svg></div>
      <div class="maptools"><button id="zin" title="Zoom in" aria-label="Zoom in">+</button><button id="zout" title="Zoom out" aria-label="Zoom out">−</button><button id="zhome" title="Reset view" aria-label="Reset view">⌂</button><button id="zfocus" title="Zoom to focus" aria-label="Zoom to focus">◎</button></div>
      <div class="busy" id="busy">Computing surface</div>
    </div>
    <div class="legend" aria-live="polite">
      <div class="lg-a"><div class="t">Likelihood · <span id="legend-cls"></span> · posture <b id="legend-post"></b></div><div class="ramp"></div><div class="ticks"><span>outside 95 %</span><span>80 %</span><span>50 %</span><span>densest</span></div><div class="n">Colour = highest-density-region centrality on a single amber hue — not a probability value; hover any cell for the number.</div><div class="live" id="legend-live" hidden></div></div>
      <div class="lg-b"><div class="row"><span class="ln" style="border-color:#FFB454"></span><span>50 % highest-density region</span></div><div class="row l80"><span class="ln" style="border-color:#FFB454"></span><span>80 % region</span></div><div class="row l95"><span class="ln" style="border-color:#FFB454"></span><span>95 % region</span></div><div class="row"><span class="sym" id="legend-sw" style="border-radius:2px"></span><span>contour colour follows the class</span></div></div>
    </div>
    <div class="mapfoot"><span><b>Projection</b> {html.escape(grid.get('projection', {}).get('type', 'mercator'))}</span><span><b>Grid</b> <span id="stat-cells"></span></span><span><b>Base map</b> {T['basemap']}</span><span><b>Routing</b> {T['routing']}</span><span><b>Drag</b> to pan · <b>wheel</b> to zoom · <b>hover</b> for the factor breakdown</span></div>
  </section>
  <aside class="rail">
    <div class="tabs" role="tablist"><button role="tab" aria-selected="true" data-panel="p-read">Readout</button><button role="tab" aria-selected="false" data-panel="p-vars">Variables</button><button role="tab" aria-selected="false" data-panel="p-triad">Triad</button><button role="tab" aria-selected="false" data-panel="p-method">Method</button></div>
    <section class="panel" id="p-read" role="tabpanel">
      <div class="card"><h3>Expected disposition</h3>
        <div class="tiles"><div class="tile"><div class="k">{units_cap} {T['deployed']} (assumed)</div><div class="v" id="t-boats">–</div><div class="n" id="t-boats-n"></div></div><div class="tile"><div class="k">50 % region</div><div class="v" id="t-50">–</div><div class="n" id="t-50-n"></div></div><div class="tile"><div class="k">80 % region</div><div class="v" id="t-80">–</div><div class="n" id="t-80-n"></div></div><div class="tile"><div class="k">{T['tile_onst']}</div><div class="v" id="t-onst">–</div><div class="n" id="t-onst-n"></div></div></div>
        <div id="judg"></div></div>
      <div class="card"><h3>Where the mass is — {T['areas']}</h3>
        <table class="rt" id="regions"><thead><tr><th>Region</th><th></th><th style="text-align:right">Mass</th><th class="boats" style="text-align:right">E[{T['units']}]</th></tr></thead><tbody></tbody></table>
        <p id="regions-foot" style="margin-top:8px;font-family:var(--mono);font-size:10.5px;color:var(--faint)"></p>
        <p style="margin-top:8px;font-size:12px">{T['table_note']}</p></div>
    </section>
    <section class="panel" id="p-vars" role="tabpanel" hidden>
      <div class="card"><h3>Spatial factors — toggle to see what each variable does</h3><p>Every factor multiplies the prior at each passable cell. Unchecking one removes it from the product and recomputes the surface. Chips name the references the factor is built from; <span class="chip ext">EXTERNAL CONSTANT</span> marks an input the country brief does not carry.</p><div id="vars"></div></div>
      <div class="card"><h3>Structural inputs (not toggleable)</h3>{structural}</div>
    </section>
    <section class="panel" id="p-triad" role="tabpanel" hidden>
      <div class="card"><h3>Triad context — where this leg sits</h3><p class="pap">{triad.get('summary_html', '')}</p>
        <table class="triad"><thead><tr><th>Leg</th><th>Delivery systems</th><th>Warheads (est.)</th><th>Posture · notes</th></tr></thead><tbody>{triad_rows}</tbody></table>
        <p style="margin-top:10px">{triad.get('notes_html', '')}</p></div>
    </section>
    <section class="panel" id="p-method" role="tabpanel" hidden>
      <div class="card"><h3>What this is — and is not</h3>{method}
        <h4>What would move this map</h4><p>{movers}</p>
        <h4>Limits</h4><p>{limits}</p>
        <h4>Sources</h4>{sources}</div>
    </section>
  </aside>
</main>
<footer class="wrap foot"><b>Handling</b> {html.escape(meta.get('handling', 'UNCLASSIFIED // OPEN SOURCE // OSINT synthesis — not a government assessment'))}. <b>Rail</b> {html.escape(text.get('rail', T['rail']))} {html.escape(meta.get('edition', ''))} · compiled {html.escape(meta.get('compiled', ''))}.</footer>
<div class="tip" id="tip" hidden></div>
<div class="cls bottom">{html.escape(text.get('banner_bottom', 'Unclassified // open source // structural prior — refresh with every edition; recompute, never extrapolate'))}</div>
"""
    head = f"""<title>{html.escape(title)}</title>
<meta name="description" content="{html.escape(meta.get('description', 'Structural prior over where ' + adj + ' ' + T['units'] + ' operate once ' + T['deployed']))}">
<style>
{css}
</style>"""
    data_js = f"window.GRID = {gridj};\nwindow.CFG = {json.dumps(cfg, separators=(',', ':'))};\nwindow.GEO = {geoj};\n"
    if mode == "ext":
        scripts = f"""<script src="{meta['id']}.data.js"></script>
<script src="engine.js"></script>"""
    else:
        scripts = f"""<script>
{esc_script(data_js)}</script>
<script>
{esc_script(model)}
</script>
<script>
{esc_script(app)}
</script>"""
    fragment = head + "\n" + body + "\n" + scripts
    full = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
{head}
</head>
<body>
{body}
{scripts}
</body>
</html>"""
    return full, fragment, data_js


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--build", default=None)
    ap.add_argument("--out", default=os.path.join("dist", "maps"))
    args = ap.parse_args()
    cfg = json.load(open(args.config))
    meta = cfg["meta"]
    bdir = args.build or os.path.join("build", "maps", meta["id"])
    gridj = open(os.path.join(bdir, "grid.json")).read()
    geoj = open(os.path.join(bdir, "geo.json")).read()
    css = open(os.path.join(ENGINE, "style.css")).read()
    model = open(os.path.join(ENGINE, "model.js")).read()
    app = open(os.path.join(ENGINE, "app.js")).read()
    os.makedirs(args.out, exist_ok=True); os.makedirs(os.path.join(args.out, "ext"), exist_ok=True)

    full, fragment, data_js = render(cfg, gridj, geoj, css, model, app, "standalone")
    fp_full = os.path.join(args.out, f"{meta['id']}.html"); fp_frag = os.path.join(args.out, f"{meta['id']}.artifact.html")
    open(fp_full, "w").write(full); open(fp_frag, "w").write(fragment)
    ext_full, _, _ = render(cfg, gridj, geoj, css, model, app, "ext")
    open(os.path.join(args.out, "ext", f"{meta['id']}.html"), "w").write(ext_full)
    open(os.path.join(args.out, "ext", f"{meta['id']}.data.js"), "w").write(data_js)
    open(os.path.join(args.out, "ext", "engine.js"), "w").write(model + "\n" + app)
    print(f"[build] {fp_full} ({len(full)//1024} KB) · {fp_frag} · ext/{meta['id']}.html (+ .data.js, engine.js)")


if __name__ == "__main__":
    main()
