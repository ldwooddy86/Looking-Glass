#!/usr/bin/env python3
"""
build_preview.py — inline the LOOKING GLASS extension into ONE self-contained
HTML file that renders inline (PREVIEW_MODE) with zero external asset calls.

It is the SAME markup/logic the extension uses, flipped to preview mode, so the
dashboard and the installable extension never drift. The Triad Map theatres listed
in data.js.triadMaps are embedded as base64 (window.LG_MAPS) from --maps-dir
(default dist/maps, i.e. the standalone pages maps_build.py produced), so the
preview carries the heatmaps too. Pass --no-maps to skip embedding.

Usage:
    python scripts/build_preview.py [--src assets/extension] [--out-dir OUT] [--name FILE.html]
                                    [--maps-dir dist/maps] [--no-maps] [--artifact]
    --artifact also writes <name>.artifact.html: the same page as a fragment (no doctype /
    html / head / body) for the Artifact tool.

Exit code 1 if any local asset reference survived inlining (the file would then
try to load something from disk/network) — that count must be 0.
"""
import argparse, base64, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def read(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()


def load_meta(src):
    """Evaluate data.js with node (robust) and fall back to a regex on the meta block."""
    data_path = os.path.join(src, "data.js")
    try:
        js = ("const fs=require('fs');const vm=require('vm');const sb={window:{},self:{}};vm.createContext(sb);"
              "vm.runInContext(fs.readFileSync(process.argv[1],'utf8'),sb,{timeout:5000});"
              "const d=sb.window.ORACLE_DATA||{};process.stdout.write(JSON.stringify({meta:d.meta||{},level:(d.posture||{}).level||''}));")
        out = subprocess.run(["node", "-e", js, data_path], capture_output=True, text=True, timeout=20)
        if out.returncode == 0 and out.stdout.strip():
            j = json.loads(out.stdout)
            return j.get("meta", {}), j.get("level", "")
    except Exception:
        pass
    return _regex_meta(data_path)


def load_theatres(src):
    """ids of the theatres data.js.triadMaps lists (empty when the block is absent)."""
    data_path = os.path.join(src, "data.js")
    js = ("const fs=require('fs');const vm=require('vm');const sb={window:{},self:{}};vm.createContext(sb);"
          "vm.runInContext(fs.readFileSync(process.argv[1],'utf8'),sb,{timeout:5000});"
          "const d=sb.window.ORACLE_DATA||{};process.stdout.write(JSON.stringify(((d.triadMaps||{}).theatres||[]).map(t=>t.id)));")
    try:
        out = subprocess.run(["node", "-e", js, data_path], capture_output=True, text=True, timeout=20)
        if out.returncode == 0 and out.stdout.strip():
            return [t for t in json.loads(out.stdout) if re.match(r"^[a-z0-9-]+$", str(t))]
    except Exception:
        pass
    return []


def _regex_meta(data_path):
    datajs = read(data_path)
    block = re.search(r"meta\s*:\s*\{(.*?)\}", datajs, re.S)
    body = block.group(1) if block else datajs

    def field(key, default=""):
        m = re.search(r"\b" + re.escape(key) + r"\s*:\s*\"([^\"]*)\"", body)
        return m.group(1) if m else default

    meta = {k: field(k) for k in ("country", "subject", "slug", "brand", "line", "compiled", "edition")}
    lvl = re.search(r"level\s*:\s*\"([^\"]*)\"", datajs)
    return meta, (lvl.group(1) if lvl else "")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=os.path.join(ROOT, "assets", "extension"))
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "build"))
    ap.add_argument("--name", default=None, help="override the output filename")
    ap.add_argument("--maps-dir", default=os.path.join(ROOT, "dist", "maps"), help="where maps_build.py wrote <id>.html (standalone pages)")
    ap.add_argument("--no-maps", action="store_true", help="do not embed the Triad Map theatres")
    ap.add_argument("--artifact", action="store_true", help="also write an Artifact-tool fragment")
    args = ap.parse_args()
    src = args.src

    html_doc = read(os.path.join(src, "dashboard.html"))
    css = read(os.path.join(src, "dashboard.css"))
    data_js = read(os.path.join(src, "data.js"))
    sanitize_js = read(os.path.join(src, "sanitize.js"))
    dashboard_js = read(os.path.join(src, "dashboard.js"))
    meta, level = load_meta(src)
    slug = re.sub(r"[^a-z0-9-]", "", (meta.get("slug") or "country").lower()) or "country"

    # 0) Triad Map theatres → window.LG_MAPS (base64 of each standalone map page)
    maps_js = ""
    theatres = [] if args.no_maps else load_theatres(src)
    embedded, missing = [], []
    if theatres:
        parts = []
        for tid in theatres:
            fp = os.path.join(args.maps_dir, tid + ".html")
            if not os.path.exists(fp):
                missing.append(tid); continue
            b64 = base64.b64encode(open(fp, "rb").read()).decode("ascii")
            parts.append(json.dumps(tid) + ":" + json.dumps(b64))
            embedded.append(tid)
        maps_js = "<script>window.LG_MAPS = {" + ",".join(parts) + "};</script>\n"
        if missing:
            print("ERROR: theatres listed in data.js.triadMaps have no built map page in " + args.maps_dir + ": " + ", ".join(missing) + " (run maps_build_all.sh, or --no-maps)", file=sys.stderr)

    # 1) inline CSS
    html_doc, n_css = re.subn(r'<link[^>]*rel="stylesheet"[^>]*href="dashboard\.css"[^>]*/?>',
                              lambda m: "<style>\n" + css + "\n</style>", html_doc)
    # 2) inline JS (PREVIEW_MODE flag first so the renderer runs baseline-only)
    def script_block(js):
        return "<script>\n" + js.replace("</script", "<\\/script") + "\n</script>"
    html_doc = html_doc.replace('<script src="data.js"></script>', "<script>window.PREVIEW_MODE = true;</script>\n" + maps_js + script_block(data_js))
    html_doc = html_doc.replace('<script src="sanitize.js"></script>', script_block(sanitize_js))
    html_doc = html_doc.replace('<script src="dashboard.js"></script>', script_block(dashboard_js))
    # 3) title + a build stamp comment
    title = f"{meta.get('brand') or 'LOOKING GLASS'} — {meta.get('line') or 'Nuclear Forces & Military Posture Monitor'} ({meta.get('compiled') or ''})"
    html_doc = re.sub(r"<title>.*?</title>", "<title>" + title.replace("&", "&amp;").replace("<", "&lt;") + "</title>", html_doc, count=1, flags=re.S)
    html_doc = html_doc.replace("<head>", f"<head>\n<!-- LOOKING GLASS v3 preview build · {slug} · compiled {meta.get('compiled','')} · posture {level} · maps {','.join(embedded) or 'none'} -->", 1)

    # 4) safety: no leftover local refs (src/href not http(s)/data/#/mailto)
    leftovers = [l for l in re.findall(r'(?:src|href)="(?!https?:|data:|#|mailto:)([^"]+)"', html_doc) if l.strip()]
    if n_css != 1:
        leftovers.append("dashboard.css (stylesheet link not replaced)")
    if leftovers:
        print("ERROR: leftover local references not inlined:", leftovers, file=sys.stderr)

    os.makedirs(args.out_dir, exist_ok=True)
    out_name = args.name or f"{slug}-lookingglass-preview.html"
    out_path = os.path.join(args.out_dir, out_name)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html_doc)
    if args.artifact:
        # fragment: everything between <head>…</head> content and the body content, no wrapper tags
        head_inner = re.search(r"<head>(.*?)</head>", html_doc, re.S).group(1)
        body_inner = re.search(r"<body>(.*?)</body>", html_doc, re.S).group(1)
        head_inner = re.sub(r"<meta[^>]*>\s*", "", head_inner)   # the Artifact skeleton supplies charset/viewport
        frag_path = os.path.join(args.out_dir, re.sub(r"\.html$", "", out_name) + ".artifact.html")
        with open(frag_path, "w", encoding="utf-8") as f:
            f.write(head_inner.strip() + "\n" + body_inner)
        print(f"Artifact fragment: {frag_path}")

    ext_calls = len(re.findall(r"https?://", html_doc))
    print(f"Built: {out_path}")
    print(f"  brand={meta.get('brand')!r} country={meta.get('country')!r} line={meta.get('line')!r} compiled={meta.get('compiled')!r} posture={level!r}")
    print(f"  size={os.path.getsize(out_path)} bytes · maps embedded: {', '.join(embedded) or 'none'}")
    print(f"  https references in file: {ext_calls} (outbound links / allowlisted feeds only; no asset loads)")
    print(f"  leftover local asset refs: {len(leftovers)} (must be 0)")
    return 0 if not (leftovers or missing) else 1


if __name__ == "__main__":
    sys.exit(main())
