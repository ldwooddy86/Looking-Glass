#!/usr/bin/env node
/* render_check.js — open a built theatre in headless Chromium, capture screenshots, fail on console errors.
   Usage: node scripts/render_check.js dist/maps/<id>.html [--shots out/] [--all-classes]
   Needs playwright (npm i -g playwright) and a Chromium; set PLAYWRIGHT_CHROMIUM to an executable if needed. */
const path = require('path'), fs = require('fs');
const args = process.argv.slice(2); const file = args.find(a => !a.startsWith('--')); const shots = args.indexOf('--shots') >= 0 ? args[args.indexOf('--shots') + 1] : 'out'; const allClasses = args.includes('--all-classes');
if (!file) { console.error('usage: render_check.js dist/maps/<id>.html'); process.exit(2); }
fs.mkdirSync(shots, { recursive: true });
(async () => {
  const { chromium } = require('playwright');
  const exe = process.env.PLAYWRIGHT_CHROMIUM; const launch = exe ? { executablePath: exe, args: ['--no-sandbox'] } : { args: ['--no-sandbox'] };
  const browser = await chromium.launch(launch).catch(() => chromium.launch());
  const page = await browser.newPage({ viewport: { width: 1500, height: 1000 } });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file://' + path.resolve(file)); await page.waitForTimeout(3500);
  const id = path.basename(file, '.html');
  await page.evaluate(() => window.scrollTo(0, 420)); await page.waitForTimeout(400);
  await page.screenshot({ path: path.join(shots, `${id}.png`) });
  const stats = await page.evaluate(() => ({ boats: document.querySelector('#t-boats').textContent, hdr50: document.querySelector('#t-50').textContent, top: [...document.querySelectorAll('#regions tbody tr')].slice(0, 3).map(tr => tr.textContent.replace(/\s+/g, ' ').trim()) }));
  if (allClasses) { const btns = await page.$$('#clsseg button'); for (const b of btns) { const c = await b.getAttribute('data-cls'); await b.click(); await page.waitForTimeout(3000); await page.screenshot({ path: path.join(shots, `${id}.${c}.png`), clip: { x: 0, y: 100, width: 910, height: 900 } }); } }
  // mobile overflow check
  await page.setViewportSize({ width: 390, height: 844 }); await page.waitForTimeout(600); const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
  await browser.close();
  console.log(JSON.stringify({ file, errors, stats, mobile_horizontal_overflow: overflow }, null, 1));
  process.exit(errors.length || overflow ? 1 : 0);
})();
