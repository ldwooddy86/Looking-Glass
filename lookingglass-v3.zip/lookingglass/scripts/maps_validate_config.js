#!/usr/bin/env node
/* maps_validate_config.js — schema, geometry and honesty-rail checks for a LOOKING GLASS map theatre config
   (sea, land or air). Usage: node scripts/maps_validate_config.js data/theatres/<theatre>.json [--grid build/maps/<id>/grid.json] [--strict]
   Exit 1 on errors; warnings exit 0 unless --strict. */
const fs = require('fs');
const args = process.argv.slice(2);
const file = args.find(a => !a.startsWith('--'));
const strict = args.includes('--strict');
const gridArg = args.indexOf('--grid') >= 0 ? args[args.indexOf('--grid') + 1] : null;
if (!file) { console.error('usage: maps_validate_config.js <config.json> [--grid grid.json] [--strict]'); process.exit(2); }
const cfg = JSON.parse(fs.readFileSync(file, 'utf8'));
const errors = [], warns = [];
const E = m => errors.push(m), Wn = m => warns.push(m);
const isNum = v => typeof v === 'number' && isFinite(v);
const inBox = (lon, lat) => lon >= cfg.grid.lon0 && lon <= cfg.grid.lon1 && lat >= cfg.grid.lat0 && lat <= cfg.grid.lat1;
const domain = (cfg.grid && cfg.grid.domain) || 'sea';
const UNITS = { sea: 'boat', land: 'launcher', air: 'aircraft' };

// meta / grid
for (const k of ['id', 'country', 'adjective', 'compiled', 'posture_default']) if (!cfg.meta || cfg.meta[k] == null) E(`meta.${k} missing`);
if (!cfg.grid) E('grid missing'); else {
  const g = cfg.grid; if (!['sea', 'land', 'air'].includes(domain)) E('grid.domain must be sea|land|air'); if (!(g.lon0 < g.lon1 && g.lat0 < g.lat1)) E('grid bbox invalid'); if (!(g.step >= 0.05 && g.step <= 0.5)) E('grid.step must be 0.05–0.5'); const pt = (g.projection || {}).type || 'mercator'; if (!['mercator', 'lcc'].includes(pt)) E('grid.projection.type must be mercator or lcc');
  if (pt === 'mercator' && g.lat1 > 72) Wn('Mercator above 72°N distorts badly — consider projection lcc');
  const cells = Math.round((g.lon1 - g.lon0) / g.step) * Math.round((g.lat1 - g.lat0) / g.step); if (cells > 130000) Wn(`grid has ${cells} cells — builds will be slow in the browser; raise step`); if (cells < 4000) Wn('grid very small — lower step for detail');
  for (const seg of (g.force_open || []).concat(g.force_block || [])) if (!(Array.isArray(seg) && seg.length >= 4 && seg.slice(0, 4).every(isNum))) E('grid.force_open / force_block entries must be [lon,lat,lon,lat]');
  if (domain === 'land') { if (!(g.confine_iso || []).length) Wn('land theatre without grid.confine_iso — launchers will be allowed to route across borders'); for (const k of (g.cover_polygons || [])) if (!(cfg.polygons || {})[k]) E(`grid.cover_polygons names unknown polygon ${k}`); if (!(g.cover_polygons || []).length && !g.cover_geojson) Wn('land theatre without cover polygons — the "under cover" classes will be empty and the terrain factor cannot reward concealment'); }
  if (domain === 'air') { if (!(g.own_iso || []).length) Wn('air theatre without grid.own_iso — own airspace class will be empty'); }
}
// postures
const levels = (cfg.postures && cfg.postures.levels) || []; if (!levels.length) E('postures.levels missing'); if (cfg.meta && !levels.includes(cfg.meta.posture_default)) E('meta.posture_default not in postures.levels');
// bases
if (!cfg.bases || !Object.keys(cfg.bases).length) E('bases missing'); else for (const k in cfg.bases) { const b = cfg.bases[k]; if (!isNum(b.lon) || !isNum(b.lat)) E(`base ${k}: lon/lat`); else if (!inBox(b.lon, b.lat)) E(`base ${k} outside grid bbox`); if (!b.name) E(`base ${k}: name`); if (b.kind && !['port', 'yard', 'garrison', 'airbase', 'depot', 'site'].includes(b.kind)) Wn(`base ${k}: unknown kind ${b.kind}`); }
// scenario bookkeeping (declared before the class loop, which may reference scenarios)
const usedScenarios = new Set();
// classes
const suitKey = cfg.terrain_suitability ? 'terrain_suitability' : 'depth_suitability';
if (!cfg.classes || !Object.keys(cfg.classes).length) E('classes missing'); else for (const c in cfg.classes) { const C = cfg.classes[c]; for (const k of ['label', 'speed_kts', 'decay_nm', 'sources', 'colour']) if (C[k] == null) E(`class ${c}: ${k} missing`);
  if (C.hulls == null && C.inventory == null) E(`class ${c}: hulls (or inventory) missing`);
  const dep = C.deployed || C.at_sea; if (!dep) E(`class ${c}: deployed (or at_sea) missing`); else for (const l of levels) if (!isNum(dep[l])) E(`class ${c}: deployed.${l} missing`);
  const checkShares = (map, label) => { let s = 0; for (const b in map) { if (!cfg.bases[b]) E(`class ${c}: ${label} base ${b} unknown`); if (!isNum(map[b]) || map[b] < 0) E(`class ${c}: ${label} share for ${b} must be a non-negative number`); else s += map[b]; } if (Math.abs(s - 1) > 0.02) E(`class ${c}: ${label} shares sum to ${s.toFixed(2)}, not 1`); };
  if (C.sources) checkShares(C.sources, 'source');
  for (const sid in (C.sources_scenarios || {})) { if (!(cfg.scenarios || {})[sid]) E(`class ${c}: sources_scenarios names unknown scenario ${sid}`); usedScenarios.add(sid); checkShares(C.sources_scenarios[sid], `scenario ${sid} source`); }
  if (C.colour && !/^#[0-9a-fA-F]{6}$/.test(C.colour)) E(`class ${c}: colour must be #rrggbb`);
  if (C.cell_cost && !(Array.isArray(C.cell_cost) && C.cell_cost.length === 8 && C.cell_cost.every(v => isNum(v) && v > 0))) E(`class ${c}: cell_cost must be 8 positive numbers`);
  if (C.maintenance_transit) { const m = C.maintenance_transit; if (!cfg.bases[m.from] || !cfg.bases[m.to]) E(`class ${c}: maintenance_transit bases unknown`); if (m.weight && m.weight > 0.15) Wn(`class ${c}: maintenance_transit weight ${m.weight} is high`); }
  if (!C.judgment || !C.judgment.confidence) Wn(`class ${c}: no judgment/confidence text — the readout will fall back to a generic line`);
  if (!cfg[suitKey] || !cfg[suitKey][c] || cfg[suitKey][c].length !== 8) E(`${suitKey}.${c} must have 8 values`); }
// factors
const ids = new Set(); const TYPES = ['depth', 'terrain', 'zones', 'hubs', 'points', 'line_exposure', 'pressure', 'proximity', 'envelope'];
function scanScen(v) { if (v && typeof v === 'object') { if (v.scenario) usedScenarios.add(v.scenario); for (const k in v) scanScen(v[k]); } }
if (!Array.isArray(cfg.factors) || !cfg.factors.length) E('factors missing'); else for (const F of cfg.factors) { if (!F.id) { E('factor without id'); continue; } if (ids.has(F.id)) E(`duplicate factor id ${F.id}`); ids.add(F.id); if (!TYPES.includes(F.type)) E(`factor ${F.id}: unknown type ${F.type}`); if (!F.label) E(`factor ${F.id}: label`); if (!F.external && !(F.refs && F.refs.length)) E(`factor ${F.id}: refs missing (every factor cites its references or is marked external)`); if (!F.note) Wn(`factor ${F.id}: no note`);
  scanScen(F);
  if (F.classes) for (const c of F.classes) if (!cfg.classes[c]) E(`factor ${F.id}: unknown class ${c}`);
  if (F.type === 'zones') for (const z of (F.zones || [])) if (!cfg.polygons || !cfg.polygons[z.polygon]) E(`factor ${F.id}: polygon ${z.polygon} unknown`);
  if (F.type === 'hubs') for (const s of (F.sets || [])) if (!cfg.point_sets || !cfg.point_sets[s.set]) E(`factor ${F.id}: set ${s.set} unknown`);
  if (F.type === 'points') for (const p of (F.points || [])) if (!cfg.points || !cfg.points[p.point]) E(`factor ${F.id}: point ${p.point} unknown`);
  if (F.type === 'line_exposure') { if (F.inside_polygon && !(cfg.polygons || {})[F.inside_polygon]) E(`factor ${F.id}: inside_polygon unknown`); if (F.line && !(cfg.lines || {})[F.line]) E(`factor ${F.id}: line unknown`); }
  if (F.type === 'pressure' || F.type === 'proximity') if (!cfg.point_sets || !cfg.point_sets[F.set]) E(`factor ${F.id}: set ${F.set} unknown`);
  if (F.type === 'pressure' && F.shield && !(cfg.polygons || {})[F.shield.polygon]) E(`factor ${F.id}: shield polygon unknown`); }
for (const c in (cfg.classes || {})) scanScen(cfg.classes[c]);
for (const id in (cfg.scenarios || {})) if (!usedScenarios.has(id)) E(`scenario ${id} is declared but no factor or class parameter references it — it would render as a dead checkbox`);
if (domain === 'sea' && !cfg.factors.some(F => F.type === 'depth')) Wn('no depth factor — bathymetry will not shape the prior');
if (domain !== 'sea' && !cfg.factors.some(F => F.type === 'terrain' || F.type === 'depth')) Wn('no terrain factor — the raster classes will not shape the prior');
// geometry containers
for (const k in (cfg.polygons || {})) { const p = cfg.polygons[k]; if (!Array.isArray(p.pts) || p.pts.length < 3) E(`polygon ${k}: pts`); else for (const pt of p.pts) if (!inBox(pt[0], pt[1])) Wn(`polygon ${k}: vertex outside bbox (${pt})`); }
for (const k in (cfg.lines || {})) { const l = cfg.lines[k]; if (!Array.isArray(l.pts) || l.pts.length < 2) E(`line ${k}: pts`); }
const KINDS = ['detection', 'survey', 'launch', 'visit', 'sighting', 'exercise', 'closure', 'other'];
for (const k in (cfg.points || {})) { const p = cfg.points[k]; if (!isNum(p.lon) || !isNum(p.lat)) E(`point ${k}: lon/lat`); else if (!inBox(p.lon, p.lat)) Wn(`point ${k} outside bbox`); if (!p.kind) Wn(`point ${k}: kind missing (${KINDS.join('|')})`); else if (!KINDS.includes(p.kind)) Wn(`point ${k}: unknown kind ${p.kind}`);
  if (p.kind === 'sighting' && !/claim|report|unverified|single|graded|alleg/i.test(String(p.note || '') + ' ' + String(p.label || ''))) E(`point ${k}: a 'sighting' must be labelled as a reported / unverified claim in its note (grade the source in place)`); }
for (const k in (cfg.point_sets || {})) { const s = cfg.point_sets[k]; if (!Array.isArray(s.pts) || !s.pts.length) E(`point_set ${k}: pts`); else for (const p of s.pts) { const lon = p.lon ?? p[0], lat = p.lat ?? p[1]; if (!isNum(lon) || !isNum(lat)) E(`point_set ${k}: bad point`); else if (!inBox(lon, lat)) Wn(`point_set ${k}: point outside bbox (${p.name || lon + ',' + lat})`); } }
const rids = new Set(); for (const r of (cfg.regions || [])) { if (!r.id || !r.name) E('region without id/name'); if (rids.has(r.id)) E(`duplicate region ${r.id}`); rids.add(r.id); if (!Array.isArray(r.pts) || r.pts.length < 3) E(`region ${r.id}: pts`); }
if (!(cfg.regions || []).length) Wn('no regions — the mass table will be empty');
// triad — the modelled leg must be present
const legWord = { sea: /^sea/i, land: /^land/i, air: /^air/i }[domain];
if (!cfg.triad || !(cfg.triad.legs || []).length) Wn('triad block missing — the Triad tab will be empty'); else if (!cfg.triad.legs.some(l => legWord.test(l.leg || ''))) E(`triad.legs must include a ${domain[0].toUpperCase() + domain.slice(1)} leg (the one this map models)`);
// honesty rails — vocabulary scan
const textBlob = JSON.stringify(cfg.text || {}) + JSON.stringify(cfg.triad || {}) + JSON.stringify(Object.values(cfg.classes || {}).map(c => c.judgment || {})) + JSON.stringify(Object.values(cfg.points || {}).map(p => p.note || '')) + JSON.stringify((cfg.factors || []).map(f => f.note || ''));
const RAILS = [/currently (at|located|positioned|deployed at)/i, /real-?time (position|track)/i, /\b(is|are) (now )?on station (at|off|near) (the )?[A-Z]/, /we (have )?tracked/i, /live track/i, /present position/i, /\b(launcher|TEL|regiment|bomber|boat)s? (is|are|was|were) (spotted|located|sitting|parked|hiding) (at|in|near) \d/i, /\btarget(ing)? (solution|package|coordinates)\b/i, /\bstrike (plan|package)\b/i];
for (const bad of RAILS) if (bad.test(textBlob)) E(`honesty rail: text contains a position / targeting claim (${bad})`);
if (!/assum|not observable|unobservable|cannot be seen|unseen/i.test((cfg.text || {}).bluf_warn_html || '')) E(`text.bluf_warn_html must state that ${UNITS[domain]} deployed status is an assumption / not observable`);
for (const c in (cfg.classes || {})) { const j = (cfg.classes[c].judgment || {}).text || ''; const bad = j.match(/\{(\w+)\}/g) || []; for (const b of bad) if (!['{a50k}', '{a80k}', '{a95k}', '{top1}', '{top1pct}', '{top2}', '{top2pct}', '{n}', '{hulls}', '{on_pct}', '{box}'].includes(b)) E(`class ${c}: unknown judgment placeholder ${b}`); }
// grid-level checks: bases must resolve to a passable cell
if (gridArg && fs.existsSync(gridArg)) { const G = JSON.parse(fs.readFileSync(gridArg, 'utf8')); const N = G.nc * G.nr; const ras = new Uint8Array(N); let p = 0; for (const [v, n] of G.rle) { ras.fill(v, p, p + n); p += n; }
  if ((G.domain || 'sea') !== domain) E(`grid.json domain ${G.domain} does not match config domain ${domain} — re-run maps_prep_geo.py`);
  const used = new Set(); for (const c in (cfg.classes || {})) { for (const b in (cfg.classes[c].sources || {})) used.add(b); const m = cfg.classes[c].maintenance_transit; if (m) { used.add(m.from); used.add(m.to); } }
  for (const k in cfg.bases) { if (!used.has(k)) continue; const b = cfg.bases[k]; const c0 = Math.floor((b.lon - G.lon0) / G.step), r0 = Math.floor((b.lat - G.lat0) / G.step); let ok = false; for (let dr = -8; dr <= 8 && !ok; dr++) for (let dc = -8; dc <= 8; dc++) { const r = r0 + dr, c = c0 + dc; if (r < 0 || r >= G.nr || c < 0 || c >= G.nc) continue; if (ras[r * G.nc + c] !== 255) { ok = true; break; } } if (!ok) E(`base ${k}: no passable cell within 8 cells — fix coordinates, add a grid.force_open channel, or widen grid.confine_iso`); }
  let passable = 0; for (let i = 0; i < N; i++) if (ras[i] !== 255) passable++; if (passable < 500) E(`only ${passable} passable cells in the raster — check confine_iso / bbox`); }
for (const w of warns) console.log('  WARN  ' + w); for (const e of errors) console.log('  ERROR ' + e);
console.log(`[validate] ${file} (${domain}): ${errors.length} errors, ${warns.length} warnings`);
process.exit(errors.length || (strict && warns.length) ? 1 : 0);
