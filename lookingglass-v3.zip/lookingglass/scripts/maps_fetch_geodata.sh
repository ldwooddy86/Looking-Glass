#!/usr/bin/env bash
# maps_fetch_geodata.sh — download the Natural Earth 10 m GeoJSON layers the LOOKING GLASS map
# engine needs (public domain). Sea theatres use land + bathymetry; land theatres add lakes,
# rivers, roads and urban areas; air theatres add admin-0 countries and boundary lines.
# Usage: scripts/maps_fetch_geodata.sh [target-dir]   (default: ./geodata or $LG_GEODATA)
# ~120 MB total; skipped when a file already exists. Source: github.com/nvkelso/natural-earth-vector.
set -euo pipefail
DIR="${1:-${LG_GEODATA:-${COUNTDOWN_GEODATA:-geodata}}}"
mkdir -p "$DIR"
BASE="https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson"
SEA="ne_10m_land ne_10m_minor_islands ne_10m_bathymetry_L_0 ne_10m_bathymetry_K_200 ne_10m_bathymetry_J_1000 ne_10m_bathymetry_I_2000 ne_10m_bathymetry_H_3000 ne_10m_bathymetry_G_4000 ne_10m_bathymetry_F_5000 ne_10m_bathymetry_E_6000 ne_10m_bathymetry_D_7000 ne_10m_bathymetry_C_8000 ne_10m_bathymetry_B_9000 ne_10m_bathymetry_A_10000"
LAND="ne_10m_lakes ne_10m_rivers_lake_centerlines ne_10m_roads ne_10m_urban_areas"
AIR="ne_10m_admin_0_countries ne_10m_admin_0_boundary_lines_land"
for L in $SEA $LAND $AIR; do
  if [ -s "$DIR/$L.geojson" ]; then echo "have $L"; continue; fi
  echo "fetching $L"
  curl -sS -L --retry 3 --max-time 600 -o "$DIR/$L.geojson" "$BASE/$L.geojson" || { echo "failed $L (try the 50m layer or the naciscdn.org zip)"; exit 1; }
done
echo "geodata ready in $DIR"
