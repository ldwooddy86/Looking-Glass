#!/usr/bin/env python3
"""
package_skill.py — zip this skill folder into a re-importable bundle.

Usage:
    python scripts/package_skill.py [--out-dir OUT] [--name lookingglass-v3.skill] [--zip]

Excludes build outputs, caches, virtualenvs, collector data and OS cruft. The archive's
top-level folder is `lookingglass/` so it imports as the `lookingglass` skill. `--zip` also
writes a plain `.zip` twin of the same archive for hosts that reject the `.skill` extension.
The script refuses to write inside the skill root (a nested archive would grow without bound).
"""
import argparse, os, shutil, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SKILL = "lookingglass"
EXCLUDE_DIRS = {"build", "dist", "node_modules", "__pycache__", ".git", ".DS_Store", ".venv", "venv", ".pytest_cache", "data_dir", "exports"}
EXCLUDE_EXT = {".pyc", ".log", ".session", ".session-journal", ".sqlite", ".db"}
EXCLUDE_FILES = {"config.toml"}   # the operator's credentials never travel with the skill


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default=os.path.join(os.path.dirname(ROOT), "dist"))
    ap.add_argument("--name", default=f"{SKILL}-v3.skill")
    ap.add_argument("--zip", action="store_true", help="also write a .zip twin")
    args = ap.parse_args()
    out_dir = os.path.abspath(args.out_dir)
    if out_dir.startswith(os.path.abspath(ROOT) + os.sep) or out_dir == os.path.abspath(ROOT):
        sys.exit("refusing to write inside the skill root — pick an --out-dir outside it")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, args.name)
    n = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for dirpath, dirnames, filenames in os.walk(ROOT):
            dirnames[:] = [d for d in sorted(dirnames) if d not in EXCLUDE_DIRS]
            for fn in sorted(filenames):
                if os.path.splitext(fn)[1] in EXCLUDE_EXT or fn in EXCLUDE_DIRS or fn in EXCLUDE_FILES:
                    continue
                full = os.path.join(dirpath, fn)
                arc = os.path.join(SKILL, os.path.relpath(full, ROOT))
                z.write(full, arc)
                n += 1
    print(f"Packaged {n} files -> {out} ({os.path.getsize(out)} bytes)")
    if args.zip:
        twin = os.path.splitext(out)[0] + ".zip"
        shutil.copyfile(out, twin)
        print(f"Twin -> {twin}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
