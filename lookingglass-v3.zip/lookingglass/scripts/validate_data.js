#!/usr/bin/env node
/* ============================================================
   validate_data.js — pre-build validator for LOOKING GLASS v3 data.js (DalesOracle v2 contract + LG blocks)
   ------------------------------------------------------------
   Executes assets/extension/data.js in a sandbox, reads
   window.ORACLE_DATA, and checks it against the analytic contract in
   references/SCHEMA.md and the rails in references/TRADECRAFT.md.
   It catches the mistakes that silently ship a WRONG, incoherent or
   irresponsible product:
     • Key Judgments without ICD-203 confidence / probability vocabulary,
       or High confidence on weak sourcing
     • matrix domains with bad enums or missing per-INT coverage, or
       High confidence on a mostly-blind domain
     • forces totals with no second estimate (false precision)
     • a leadership board with bad statuses; events out of order
     • an I&W board with bad enums, or invisible indicators marked normal
     • ACH scores pointing at a hypothesis that doesn't exist; a board
       with no disconfirming evidence
     • Track Watch matcher / type-key mismatches, malformed designators,
       sector out of range, unreachable tripwires
     • channels left ENABLED while unverified (honesty rail)
     • the protective layer missing its defensive framing, referencing
       unknown actors, or carrying operational vocabulary (coordinates,
       addresses, methods, timing, "weak point") — hard ERROR
     • the optional Sub Watch block missing its public-OSINT framing,
       carrying live/current-position vocabulary or coordinates for a
       boat (hard ERROR), bad status/side enums, no `unseen` sea-leg
       indicator, or a ledger row that does not say what is classified
     • TODO/placeholder text anywhere; stale compiled date; duplicate ids
     • (LOOKING GLASS) the optional Air Watch block: framing, ≥3 fleet
       entries with roles, live board matcher/type parity and designators,
       ≥5 air-leg indicators with an `unseen` row, no targeting vocabulary
     • (LOOKING GLASS) the optional Launcher Watch block: framing, ≥2
       launcher classes, garrisons named as towns/regions, ≥5 indicators
       with an `unseen` row, the no-positions rail (coordinates, live /
       current position or field-position claims → hard ERROR)
     • (LOOKING GLASS) triadMaps theatres exist as configs, legs are
       sea|land|air; collector sources have valid kinds/handles, the
       endpoint is loopback-only, and NO secret (token, api key, bot
       token, phone number) is embedded in data.js

   Usage:
     node scripts/validate_data.js [--src assets/extension] [--strict] [--json]
   Exit code: 1 if any ERROR (or any WARN under --strict), 2 on load failure, else 0.
   Run it — and fix every ERROR — before build_preview.py.
   ============================================================ */
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const HERE = __dirname;
const ROOT = path.dirname(HERE);

function parseArgs() {
  const a = { src: path.join(ROOT, "assets", "extension"), strict: false, json: false };
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "--src") a.src = argv[++i];
    else if (argv[i] === "--strict") a.strict = true;
    else if (argv[i] === "--json") a.json = true;
  }
  return a;
}

const ENUM = {
  posture: ["stable", "guarded", "elevated", "high", "severe"],
  observed: ["normal", "note", "elevated", "warning", "unseen"],
  coverage: ["strong", "partial", "gap", "na"],
  trend: ["up", "flat", "down"],
  conf: ["High", "Moderate", "Low"],
  lane: ["propaganda", "official", "wire", "milblogger", "independent", "analyst", "community", "aggregator", "custom"],
  tempo: ["neardaily", "frequent", "rare"],
  cell: ["C", "I", "N"],
  tone: ["watch", "alert", "red"],
  lev: ["vhigh", "high", "med", "low"],
  stance: ["independent", "mixed", "state"],
  leadStatus: ["confirmed", "acting", "vacant", "purged", "unknown"],
  threat: ["low", "moderate", "substantial", "severe", "critical"],
  ppost: ["baseline", "heightened", "reinforced"],
  exposure: ["low", "moderate", "high", "critical"],
  resilience: ["weak", "moderate", "strong"],
  changeKind: ["up", "down", "new", "watch", "resolved"],
  reach: ["domestic", "regional", "global"],
  scope: ["domestic", "overseas"],
};
const INT_KEYS = ["osint", "geoint", "sigint", "humint", "masint"];
const HANDLE_RE = /^[a-zA-Z0-9_]{3,64}$/;
const ICAO_RE = /^[A-Z0-9]{2,5}$/; // ICAO designators are 2-4; 5 allows documented feed variants (e.g. WC135)
const ICD_TERMS = /(almost no chance|remote|very unlikely|highly improbable|unlikely|improbable|roughly even|even chance|likely|probable|very likely|highly probable|almost certain|\d{1,2}\s*[-–]\s*\d{1,3}\s*%|\d{1,3}\s*%|fact|assessment)/i;
// Protective-layer rails: operational vocabulary that has no place in a defensive product.
const PROT_BANNED = [
  { re: /\b-?\d{1,2}\.\d{3,}\s*,?\s*-?\d{1,3}\.\d{3,}\b/, why: "looks like a coordinate pair" },
  { re: /\b\d{1,5}\s+(?:[A-Z][a-z]+\s){0,3}(?:street|st\.|road|rd\.|avenue|ave\.|boulevard|blvd|lane|lu|jie|dadao)\b/i, why: "looks like a street address" },
  { re: /\b(how to (?:make|build|breach|bypass|defeat|evade)|bypass(?:ing)? (?:security|the guards?|screening)|guard (?:rotation|shift|change)|shift change|blind spot|weak(?:est)? point|entry point|access route|attack plan|best time to|timing window|recipe|detonat|improvised explosive|ied\b|firing position|kill zone|casualty maximi[sz]|maximi[sz]e (?:casualties|deaths))/i, why: "operational / attack-enabling vocabulary" },
];
const TODO_RE = /\b(TODO|TBD|FIXME|XXX|lorem ipsum|placeholder)\b/i;

const errors = [];
const warns = [];
function err(p, m) { errors.push(p + " — " + m); }
function warn(p, m) { warns.push(p + " — " + m); }
function isNum(v) { return typeof v === "number" && isFinite(v); }
function isStr(v) { return typeof v === "string" && v.trim().length > 0; }
function arr(v) { return Array.isArray(v) ? v : []; }
function admLetter(g) { const m = String(g || "").toUpperCase().match(/[A-F]/); return m ? m[0] : null; }
function admCred(g) { const m = String(g || "").match(/[A-F]\s*([1-6])/i); return m ? parseInt(m[1], 10) : null; }
function inEnum(list, v) { return list.indexOf(v) !== -1; }
function reqEnum(at, field, list, v) { if (!inEnum(list, v)) err(at, field + " must be one of " + list.join("|") + "; got " + JSON.stringify(v)); }
function warnEnum(at, field, list, v) { if (v != null && !inEnum(list, v)) warn(at, field + " must be one of " + list.join("|") + "; got " + JSON.stringify(v)); }
function uniqueIds(at, list, key) { const seen = {}; arr(list).forEach((x, i) => { const id = x && x[key]; if (!id) return; if (seen[id]) err(at + "[" + i + "]", "duplicate id " + JSON.stringify(id)); seen[id] = 1; }); }

function loadData(src) {
  const file = path.join(src, "data.js");
  const code = fs.readFileSync(file, "utf8");
  const sandbox = { window: {}, self: {}, console: console };
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox, { filename: "data.js", timeout: 5000 });
  return { D: sandbox.window.ORACLE_DATA, raw: code };
}

/* ---------- checks ---------- */
function checkMeta(D) {
  const m = D.meta; if (!m) { err("meta", "missing"); return; }
  if (m.version !== 2) warn("meta.version", "expected 2 (v2 schema); got " + JSON.stringify(m.version));
  if (!isStr(m.country)) err("meta.country", "required");
  if (!isStr(m.subject)) err("meta.subject", "required (the force, e.g. 'People's Liberation Army')");
  if (!isStr(m.slug)) err("meta.slug", "required (drives output filenames)");
  else if (!/^[a-z0-9-]+$/.test(m.slug)) err("meta.slug", "must be kebab-case [a-z0-9-]; got " + JSON.stringify(m.slug));
  if (!isStr(m.compiled)) err("meta.compiled", "compiled date required");
  else { const t = Date.parse(m.compiled); if (isNaN(t)) warn("meta.compiled", "not a parseable date: " + m.compiled); else if ((Date.now() - t) > 120 * 864e5) warn("meta.compiled", "baseline looks stale (" + m.compiled + ", >120 days) — refresh before shipping"); }
  if (!isStr(m.flag)) warn("meta.flag", "no flag emoji");
  if (!isStr(m.brand) || !isStr(m.line)) warn("meta", "brand/line drive the extension name — set both");
}
function checkPosture(D) {
  const p = D.posture; if (!p) { err("posture", "missing"); return; }
  reqEnum("posture", "level", ENUM.posture, p.level);
  if (!isStr(p.headline)) err("posture.headline", "required");
  if (!isStr(p.body)) warn("posture.body", "empty");
  if (p.range != null) {
    if (!Array.isArray(p.range) || p.range.length !== 2 || !inEnum(ENUM.posture, p.range[0]) || !inEnum(ENUM.posture, p.range[1])) err("posture.range", "must be [levelLo, levelHi] using the posture enum");
    else { const i = ENUM.posture.indexOf(p.level), lo = ENUM.posture.indexOf(p.range[0]), hi = ENUM.posture.indexOf(p.range[1]); if (i < Math.min(lo, hi) || i > Math.max(lo, hi)) err("posture.range", "level " + p.level + " lies outside its own uncertainty range " + JSON.stringify(p.range)); }
  } else warn("posture.range", "no uncertainty range on the gauge (estimates carry uncertainty — consider one)");
  if (!isStr(p.mover)) warn("posture.mover", "say what observation would move the level");
}
function checkProduct(D) {
  const p = D.product; if (!p) { err("product", "missing (BLUF + Key Judgments)"); return; }
  if (!isStr(p.bluf)) err("product.bluf", "required");
  if (!isStr(p.asOf)) warn("product.asOf", "no as-of stamp");
  const kj = arr(p.keyJudgments);
  if (kj.length < 4) err("product.keyJudgments", "need >=4 Key Judgments; got " + kj.length);
  uniqueIds("product.keyJudgments", kj, "id");
  kj.forEach((k, i) => {
    const at = "product.keyJudgments[" + i + "]" + (k && k.id ? " (" + k.id + ")" : "");
    if (!k) { err(at, "null"); return; }
    if (!isStr(k.text)) err(at, "no text");
    reqEnum(at, "confidence", ENUM.conf, k.confidence);
    if (!isStr(k.prob)) warn(at, "no probability band"); else if (!ICD_TERMS.test(k.prob)) warn(at, "prob should use ICD-203 vocabulary or a % band; got " + JSON.stringify(k.prob));
    if (!isStr(k.grade) || !admLetter(k.grade)) warn(at, "no Admiralty grade (e.g. A2)");
    else { const L = admLetter(k.grade), C = admCred(k.grade); if (k.confidence === "High" && (["D", "E", "F"].indexOf(L) !== -1 || (C && C >= 4))) err(at, "High confidence on " + k.grade + "-graded basis — confidence must fit the sourcing (TRADECRAFT §1)"); }
    if (!isStr(k.basis)) warn(at, "no basis/source");
    if (!isStr(k.whatWouldChange)) warn(at, "no whatWouldChange — say what observation would move the judgment");
  });
  if (!arr(p.estimativeKey).length) warn("product.estimativeKey", "no ICD-203 probability yardstick");
  if (!isStr(p.confidenceDef)) warn("product.confidenceDef", "no confidence definition");
  const ch = arr(p.changes);
  if (!ch.length) warn("product.changes", "no 'what changed since last edition' strip — a monitor should say what moved");
  ch.forEach((c, i) => { if (!c || !isStr(c.text)) err("product.changes[" + i + "]", "needs text"); else warnEnum("product.changes[" + i + "]", "kind", ENUM.changeKind, c.kind); });
}
function checkMatrix(D) {
  const mx = D.matrix; if (!mx) { err("matrix", "missing"); return; }
  const cols = arr(mx.intCols).map(c => c && c.key);
  if (INT_KEYS.some(k => cols.indexOf(k) === -1)) warn("matrix.intCols", "expected the five INT keys " + INT_KEYS.join("|") + "; got " + JSON.stringify(cols));
  const dom = arr(mx.domains);
  if (dom.length < 6) err("matrix.domains", "need >=6 domains for a credible fused picture; got " + dom.length);
  else if (dom.length < 8) warn("matrix.domains", "only " + dom.length + " domains (minimum viable is 8)");
  uniqueIds("matrix.domains", dom, "id");
  dom.forEach((d, i) => {
    const at = "matrix.domains[" + i + "]" + (d && d.id ? " (" + d.id + ")" : "");
    if (!d) { err(at, "null"); return; }
    if (!isStr(d.domain)) err(at, "no domain name");
    reqEnum(at, "level", ENUM.posture, d.level);
    reqEnum(at, "trend", ENUM.trend, d.trend);
    if (!(Number.isInteger(d.pri) && d.pri >= 1 && d.pri <= 5)) warn(at, "pri should be an integer 1..5");
    if (!isStr(d.finding)) warn(at, "no finding");
    warnEnum(at, "conf", ENUM.conf, d.conf);
    const ints = d.ints || {}; let gaps = 0, known = 0;
    INT_KEYS.forEach(k => {
      if (ints[k] == null) warn(at, "ints." + k + " missing (renders as n/a)");
      else if (!inEnum(ENUM.coverage, ints[k])) err(at, "ints." + k + " must be strong|partial|gap|na; got " + JSON.stringify(ints[k]));
      else if (ints[k] !== "na") { known++; if (ints[k] === "gap") gaps++; }
    });
    if (known && gaps / known >= 0.6 && d.conf === "High") warn(at, "High confidence on a domain whose coverage is mostly gap (" + gaps + "/" + known + ")");
  });
}
function checkForces(D) {
  const f = D.forces; if (!f) { err("forces", "missing"); return; }
  const tot = arr(f.totals);
  if (!tot.length) err("forces.totals", "empty");
  if (tot.length && !tot.some(t => t && isStr(t.alt))) warn("forces.totals", "no total carries an `alt` second estimate — show the spread (SIPRI vs official, IISS vs DoD)");
  const br = arr(f.branches); if (!br.length) err("forces.branches", "empty");
  let sum = 0, haveP = 0;
  br.forEach((b, i) => { if (b && isNum(b.pct)) { sum += b.pct; haveP++; if (b.pct < 0 || b.pct > 100) warn("forces.branches[" + i + "]", "pct out of 0..100: " + b.pct); } });
  if (haveP && (sum < 85 || sum > 115)) warn("forces.branches", "pct values sum to " + sum + " (expected ~100)");
  const sys = f.systems || {};
  const groups = ["ground", "air", "naval", "missile", "strategic", "enabling"].filter(g => arr(sys[g]).length);
  if (groups.length < 2) warn("forces.systems", "fewer than 2 non-empty systems groups");
  const lead = arr(f.leadership);
  if (!lead.length) warn("forces.leadership", "no command-chain board — the most perishable facts should be tracked explicitly");
  lead.forEach((r, i) => { const at = "forces.leadership[" + i + "]"; if (!r || !isStr(r.post)) err(at, "needs post"); else { reqEnum(at, "status", ENUM.leadStatus, r.status); if (!isStr(r.src)) warn(at + " (" + r.post + ")", "no src — leadership rows must be search-verified per build"); } });
}
function checkEvents(D) {
  const ev = arr(D.events); if (!ev.length) { warn("events", "no timeline"); return; }
  let last = null;
  ev.forEach((e, i) => {
    const at = "events[" + i + "]";
    if (!e || !isStr(e.title)) { err(at, "needs title"); return; }
    if (e.iso) { const t = Date.parse(e.iso); if (isNaN(t)) warn(at, "iso not parseable: " + e.iso); else { if (last != null && t > last) warn(at, "events should be newest-first (iso " + e.iso + " is later than the row above)"); last = t; } }
  });
}
function checkIw(D) {
  const iw = D.iwBoard; if (!iw) { err("iwBoard", "missing"); return; }
  const ind = arr(iw.indicators);
  if (ind.length < 6) err("iwBoard.indicators", "need >=6 I&W indicators; got " + ind.length);
  else if (ind.length < 8) warn("iwBoard.indicators", "only " + ind.length + " (minimum viable is 8)");
  uniqueIds("iwBoard.indicators", ind, "id");
  let unseen = 0;
  ind.forEach((r, i) => {
    const at = "iwBoard.indicators[" + i + "]" + (r && r.id ? " (" + r.id + ")" : "");
    if (!r) { err(at, "null"); return; }
    reqEnum(at, "observed", ENUM.observed, r.observed);
    if (r.observed === "unseen") unseen++;
    if (!(Number.isInteger(r.crit) && r.crit >= 1 && r.crit <= 5)) err(at, "crit must be an integer 1..5; got " + JSON.stringify(r.crit));
    if (!isStr(r.threshold)) warn(at, "no threshold");
    if (!isStr(r.grade)) warn(at, "no Admiralty grade");
    warnEnum(at, "conf", ENUM.conf, r.conf);
    const gapGrade = /F\s*6|\bgap\b/i.test(String(r.grade || "") + " " + String(r.src || ""));
    if (gapGrade && r.observed === "normal") warn(at, "graded as a collection gap but observed=normal — mark it 'unseen' so quiet is not read as clear");
  });
  if (ind.length && unseen === 0) warn("iwBoard.indicators", "no indicator marked 'unseen' — every real board has near-invisible rows; the blind fraction will read 0%");
}
function checkAch(D) {
  const a = D.ach; if (!a) { err("ach", "missing"); return; }
  const hyps = arr(a.hypotheses); const ids = hyps.map(h => h && h.id).filter(Boolean);
  if (hyps.length < 2) err("ach.hypotheses", "need >=2; got " + hyps.length);
  else if (hyps.length < 3 || hyps.length > 5) warn("ach.hypotheses", hyps.length + " hypotheses (3-4 is the usual range)");
  uniqueIds("ach.hypotheses", hyps, "id");
  const ev = arr(a.evidence);
  if (ev.length < 6) err("ach.evidence", "need >=6 evidence rows; got " + ev.length);
  uniqueIds("ach.evidence", ev, "id");
  let incTotal = 0, diagCount = 0; const covered = {}; const incPerHyp = {};
  ev.forEach((e, i) => {
    const at = "ach.evidence[" + i + "]" + (e && e.id ? " (" + e.id + ")" : "");
    if (!e) { err(at, "null"); return; }
    if (!isStr(e.text)) err(at, "no text");
    if (!isStr(e.grade)) warn(at, "no Admiralty grade (drives the reliability weight in the ranking)");
    if (e.diag) diagCount++;
    if (!e.scores) { err(at, "no scores object"); return; }
    Object.keys(e.scores).forEach(k => {
      if (ids.indexOf(k) === -1) err(at, "scores a hypothesis id '" + k + "' that is not in ach.hypotheses (" + ids.join(",") + ") — the cell is silently dropped");
      if (!inEnum(ENUM.cell, e.scores[k])) err(at, "score " + k + " must be C|I|N; got " + JSON.stringify(e.scores[k]));
      if (e.scores[k] === "I") { incTotal++; incPerHyp[k] = (incPerHyp[k] || 0) + 1; }
      covered[k] = true;
    });
    ids.forEach(h => { if (!(h in e.scores)) warn(at, "no score for " + h + " (incomplete matrix; treated neutral)"); });
  });
  ids.forEach(h => { if (!covered[h]) warn("ach.hypotheses (" + h + ")", "no evidence scores this hypothesis"); });
  if (ev.length && incTotal === 0) warn("ach.evidence", "ZERO inconsistent (I) scores — an ACH with no disconfirming evidence is confirmation-seeking, not ACH");
  if (ev.length && diagCount === 0) warn("ach.evidence", "no rows flagged diag:true — diagnostic (discriminating) evidence is what does the analytic work");
  const noInc = ids.filter(h => !incPerHyp[h]);
  if (ids.length >= 3 && noInc.length >= 2) warn("ach.evidence", "hypotheses " + noInc.join(", ") + " have no disconfirming cell at all — the board does not discriminate between them");
  if (!isStr(a.conclusion)) warn("ach.conclusion", "no conclusion");
}
function checkAnnex(D) {
  if (!arr(D.keyAssumptions).length) warn("keyAssumptions", "no Key Assumptions Check (KAC strengthens the product)");
  if (!arr(D.collectionGaps).length) warn("collectionGaps", "no prioritized collection gaps");
}
function checkEscalation(D) {
  const e = D.escalation; if (!e) return;
  arr(e.scenarios).forEach((s, i) => { if (s) warnEnum("escalation.scenarios[" + i + "]", "tone", ENUM.tone, s.tone); });
  arr(e.drivers).forEach((d, i) => { if (d) warnEnum("escalation.drivers[" + i + "]", "lev", ENUM.lev, d.lev); });
}
function checkMovement(D) {
  const mv = D.movementWatch; if (!mv) { warn("movementWatch", "missing (Movement tab + language scanner unpopulated)"); return; }
  arr(mv.signatures).forEach((s, i) => { if (s && s.tier && ["t1", "t2", "t3"].indexOf(s.tier) === -1) warn("movementWatch.signatures[" + i + "]", "tier must be t1|t2|t3; got " + JSON.stringify(s.tier)); });
  const dict = mv.scanner && arr(mv.scanner.dictionary);
  if (!dict || !dict.length) warn("movementWatch.scanner.dictionary", "empty — the live scanner has no vocabulary to match");
  else {
    let terms = 0, nonAscii = 0;
    dict.forEach((c, i) => {
      if (c) warnEnum("movementWatch.scanner.dictionary[" + i + "]", "tone", ENUM.tone, c.tone);
      if (!c || !arr(c.terms).length) warn("movementWatch.scanner.dictionary[" + i + "]", "category has no terms");
      arr(c && c.terms).forEach(t => { terms++; if (/[^\x00-\x7F]/.test(String(t))) nonAscii++; });
    });
    if (terms < 20) warn("movementWatch.scanner.dictionary", "only " + terms + " terms — a thin dictionary catches little");
    if (!nonAscii) warn("movementWatch.scanner.dictionary", "no native-language (non-ASCII) terms — the scanner will miss the subject's own vocabulary unless the language is English");
  }
}
function checkTrackWatch(D) {
  const tw = D.trackWatch; if (!tw) { err("trackWatch", "missing"); return; }
  const types = arr(tw.types); if (!types.length) { err("trackWatch.types", "empty"); return; }
  const typeKeys = [];
  types.forEach((t, i) => {
    const at = "trackWatch.types[" + i + "]" + (t && t.key ? " (" + t.key + ")" : "");
    if (!t || !isStr(t.key)) { err(at, "no key"); return; }
    typeKeys.push(t.key);
    warnEnum(at, "tempo", ENUM.tempo, t.tempo);
    if (!isStr(t.type)) warn(at, "no display type");
    if ("crit" in t && typeof t.crit !== "boolean") warn(at, "crit should be boolean");
  });
  uniqueIds("trackWatch.types", types, "key");
  const match = tw.match || {}; const matchKeys = Object.keys(match);
  if (!matchKeys.length) err("trackWatch.match", "empty — the worker will classify nothing");
  const missing = typeKeys.filter(k => matchKeys.indexOf(k) === -1), extra = matchKeys.filter(k => typeKeys.indexOf(k) === -1);
  if (missing.length) err("trackWatch.match", "no matcher for type key(s): " + missing.join(", ") + " — those cards can NEVER light up");
  if (extra.length) err("trackWatch.match", "matcher key(s) with no matching type: " + extra.join(", ") + " — a typo here silently breaks the feed");
  matchKeys.forEach(k => {
    const m = match[k] || {};
    if (!arr(m.types).length && !arr(m.regs).length && !arr(m.hex).length) warn("trackWatch.match." + k, "empty matcher (no types/regs/hex) — never matches");
    arr(m.types).forEach(code => { if (!ICAO_RE.test(String(code))) warn("trackWatch.match." + k, "designator " + JSON.stringify(code) + " is not 2-5 upper-case alphanumerics — see references/ADSB-TYPES.md"); });
    arr(m.hex).forEach(h => { if (!/^[0-9a-f]{6}$/i.test(String(h))) warn("trackWatch.match." + k, "hex " + JSON.stringify(h) + " is not a 6-digit Mode-S address"); });
  });
  const s = tw.sector;
  if (!s) err("trackWatch.sector", "missing");
  else {
    if (!(isNum(s.lat) && s.lat >= -90 && s.lat <= 90)) err("trackWatch.sector.lat", "must be a number in -90..90; got " + JSON.stringify(s.lat));
    if (!(isNum(s.lon) && s.lon >= -180 && s.lon <= 180)) err("trackWatch.sector.lon", "must be a number in -180..180; got " + JSON.stringify(s.lon));
    const dist = s.dist != null ? s.dist : s.radiusNm;
    if (!(isNum(dist) && dist >= 1 && dist <= 250)) err("trackWatch.sector.dist", "must be a number in 1..250 nm; got " + JSON.stringify(dist));
    if (!isStr(s.label) || !isStr(s.why)) warn("trackWatch.sector", "label and why should explain the fixed public location");
  }
  if (tw.alert) {
    const al = tw.alert;
    if (!(Number.isInteger(al.red) && Number.isInteger(al.alert) && al.red > al.alert && al.alert >= 1)) warn("trackWatch.alert", "expected integers with red > alert >= 1; got " + JSON.stringify(al));
    else if (al.red > types.length) err("trackWatch.alert", "red=" + al.red + " exceeds the " + types.length + " watched types — RED could never trip by count");
  }
  if (!isStr(tw.alertRule)) warn("trackWatch.alertRule", "describe the tripwire in words");
  arr(tw.links).forEach((l, i) => { if (!l || !/^https:\/\//.test(String(l.href || ""))) warn("trackWatch.links[" + i + "]", "href must be https"); });
}
function checkOsint(D) {
  const o = D.osint; if (!o) { warn("osint", "missing (Collection tab unpopulated)"); return; }
  const seen = {};
  arr(o.channels).forEach((c, i) => {
    const at = "osint.channels[" + i + "]" + (c && c.handle ? " (@" + c.handle + ")" : "");
    if (!c) { err(at, "null"); return; }
    const h = String(c.handle || "").replace(/^@/, "");
    if (!HANDLE_RE.test(h)) err(at, "invalid Telegram handle (must match [a-z0-9_]{3,64}); got " + JSON.stringify(c.handle));
    if (seen[h.toLowerCase()]) err(at, "duplicate handle"); seen[h.toLowerCase()] = 1;
    warnEnum(at, "lane", ENUM.lane, c.lane);
    const effectivelyEnabled = c.enabled !== false;
    if (effectivelyEnabled && c.verified !== true) err(at, "ENABLED but not verified:true — honesty rail: only ship verified public handles enabled (set enabled:false until the t.me/s/ preview is confirmed)");
    if (c.verified === true && !isStr(c.verifiedOn)) warn(at, "verified without verifiedOn date — record when the t.me/s/ preview was confirmed");
  });
}
function checkSourcesAndSecurity(D) {
  const sr = D.sourceReliability;
  if (!sr || !arr(sr.entries).length) warn("sourceReliability.entries", "no NATO-Admiralty source annex");
  else arr(sr.entries).forEach((e, i) => { if (e && !isStr(e.grade)) warn("sourceReliability.entries[" + i + "]", "no grade"); });
  const sec = arr(D.security);
  if (sec.length < 5) err("security", "need the >=5 security-model items (least-privilege, CSP, hostile-input, allowlist, local-storage); got " + sec.length);
  sec.forEach((s, i) => { if (!s || !isStr(s.k) || !isStr(s.h) || !isStr(s.p)) warn("security[" + i + "]", "each item needs k, h, p"); });
  if (!isStr(D.sources)) err("sources", "footer sources string is required (every build must cite its baselines)");
  else if (!/20\d\d/.test(D.sources)) warn("sources", "name source editions/years in the footer");
  const ac = D.academia;
  if (ac) arr(ac.countries).forEach((c, i) => { if (c) warnEnum("academia.countries[" + i + "]", "stance", ENUM.stance, c.stance); });
}
function scanBanned(at, value) {
  if (value == null) return;
  if (typeof value === "string") { PROT_BANNED.forEach(b => { if (b.re.test(value)) err(at, "protective-layer rail: " + b.why + " in " + JSON.stringify(value.slice(0, 80)) + (value.length > 80 ? "…" : "")); }); return; }
  if (Array.isArray(value)) { value.forEach((v, i) => scanBanned(at + "[" + i + "]", v)); return; }
  if (typeof value === "object") Object.keys(value).forEach(k => scanBanned(at + "." + k, value[k]));
}
function checkProtective(D) {
  const p = D.protective; if (!p) return;
  if (!isStr(p.framingNote)) err("protective.framingNote", "required — the defensive-framing statement (TRADECRAFT §8)");
  scanBanned("protective", p);
  const actorIds = {};
  const t = p.threat;
  if (t) {
    reqEnum("protective.threat", "level", ENUM.threat, t.level);
    if (!isStr(t.headline)) warn("protective.threat.headline", "empty");
    const actors = arr(t.actors); if (!actors.length) warn("protective.threat.actors", "no actor board");
    uniqueIds("protective.threat.actors", actors, "id");
    actors.forEach((a, i) => {
      const at = "protective.threat.actors[" + i + "]" + (a && a.id ? " (" + a.id + ")" : "");
      if (!a || !isStr(a.name)) { err(at, "needs name"); return; }
      if (a.id) actorIds[a.id] = 1;
      if (!(Number.isInteger(a.intent) && a.intent >= 1 && a.intent <= 5)) err(at, "intent must be integer 1..5");
      if (!(Number.isInteger(a.capability) && a.capability >= 1 && a.capability <= 5)) err(at, "capability must be integer 1..5");
      warnEnum(at, "reach", ENUM.reach, a.reach); warnEnum(at, "trend", ENUM.trend, a.trend);
      if (!isStr(a.grade)) warn(at, "no Admiralty grade");
    });
    const iw = arr(t.iw);
    if (!iw.length) warn("protective.threat.iw", "no attack-warning indicators");
    uniqueIds("protective.threat.iw", iw, "id");
    iw.forEach((r, i) => { const at = "protective.threat.iw[" + i + "]"; if (!r) { err(at, "null"); return; } reqEnum(at, "observed", ENUM.observed, r.observed); if (!(Number.isInteger(r.crit) && r.crit >= 1 && r.crit <= 5)) err(at, "crit must be integer 1..5"); });
    if (!arr(t.incidents).length) warn("protective.threat.incidents", "no incident timeline");
  } else warn("protective.threat", "missing (Terror Threat tab hidden)");
  const s = p.softTargets;
  if (s) {
    const cls = arr(s.classes); if (!cls.length) warn("protective.softTargets.classes", "empty");
    uniqueIds("protective.softTargets.classes", cls, "id");
    cls.forEach((c, i) => { const at = "protective.softTargets.classes[" + i + "]"; if (!c || !isStr(c.class)) { err(at, "needs class"); return; } reqEnum(at, "risk", ENUM.exposure, c.risk); reqEnum(at, "posture", ENUM.ppost, c.posture); if (!(Number.isInteger(c.precedent) && c.precedent >= 0 && c.precedent <= 5)) err(at, "precedent must be integer 0..5"); if (!arr(c.measures).length) warn(at, "no protective measures listed"); });
  } else warn("protective.softTargets", "missing (Soft Targets tab hidden)");
  const f = p.infrastructure;
  if (f) {
    const secs = arr(f.sectors); if (!secs.length) warn("protective.infrastructure.sectors", "empty");
    uniqueIds("protective.infrastructure.sectors", secs, "id");
    secs.forEach((x, i) => { const at = "protective.infrastructure.sectors[" + i + "]"; if (!x || !isStr(x.sector)) { err(at, "needs sector"); return; } reqEnum(at, "exposure", ENUM.exposure, x.exposure); warnEnum(at, "resilience", ENUM.resilience, x.resilience); });
    if (!secs.some(x => x && x.spotlight)) warn("protective.infrastructure.sectors", "no sector spotlighted (data centers are usually the spotlight)");
    if (!f.dataCenters || !arr(f.dataCenters.vectors).length) warn("protective.infrastructure.dataCenters", "no data-center vector table");
    else arr(f.dataCenters.vectors).forEach((v, i) => { const at = "protective.infrastructure.dataCenters.vectors[" + i + "]"; if (!v || !isStr(v.vector)) { err(at, "needs vector"); return; } reqEnum(at, "likelihood", ENUM.exposure, v.likelihood); reqEnum(at, "impact", ENUM.exposure, v.impact); if (!isStr(v.measure)) warn(at, "no protective measure"); });
  } else warn("protective.infrastructure", "missing (Infrastructure tab hidden)");
  const g = p.geography;
  if (g) {
    const regs = arr(g.regions); if (!regs.length) warn("protective.geography.regions", "empty");
    uniqueIds("protective.geography.regions", regs, "id");
    regs.forEach((r, i) => { const at = "protective.geography.regions[" + i + "]"; if (!r || !isStr(r.region)) { err(at, "needs region"); return; } reqEnum(at, "advisory", ENUM.threat, r.advisory); warnEnum(at, "scope", ENUM.scope, r.scope); warnEnum(at, "trend", ENUM.trend, r.trend); arr(r.actors).forEach(id => { if (!actorIds[id]) err(at, "references actor id " + JSON.stringify(id) + " that is not on the actor board"); }); });
  } else warn("protective.geography", "missing (Threat Geography tab hidden)");
}
/* ---------- Sub Watch (optional block) ----------
   Rails: the tab is an order-of-battle / basing / I&W / undersea-environment product.
   It must never carry a live or predicted position, track, patrol box or coordinate
   for a boat — that vocabulary is a hard ERROR unless the sentence is denying it. */
const SUB_STATUS = ["in-service", "building", "fitting-out", "trials", "unknown", "retired"];
const SUB_SIDE = ["allied", "subject", "prc", "both"]; // "prc" kept for the v2.1 China build; new builds use "subject"
const SUB_POS_RE = [
  { re: /\b-?\d{1,2}\.\d{3,}\s*,?\s*-?\d{1,3}\.\d{3,}\b/, why: "looks like a coordinate pair" },
  { re: /\b(?:real-?time|live|current|present|latest|last known|now)\s+(?:position|location|track|whereabouts|patrol box|patrol area)s?\b/i, why: "live/current-position vocabulary" },
  { re: /\b(?:is|are|was|were)\s+(?:currently|now|presently)\s+(?:at|off|near|in|inside|outside|transiting|patrolling|loitering|on station)\b/i, why: "present-tense unit-location claim" },
  { re: /\b(?:tracked|located|spotted|detected)\s+(?:at|to)\s+\d{1,2}\s*°/i, why: "tracked-to-coordinates claim" },
];
const SUB_NEG_RE = /\b(?:not|never|no|none|cannot|can't|unobservable|invisible|unseen|does not|do not|rather than|instead of|without|absence|neither|nor|not shown|not observable|is not|are not)\b/i;
function scanSubPositions(at, value) {
  if (value == null) return;
  if (typeof value === "string") {
    SUB_POS_RE.forEach(b => {
      const m = value.match(b.re); if (!m) return;
      const ctx = value.slice(Math.max(0, m.index - 90), m.index + m[0].length + 90);
      if (SUB_NEG_RE.test(ctx)) return; // a sentence that denies a position is the honesty rail, not a breach
      err(at, "sub-watch rail: " + b.why + " in " + JSON.stringify(value.slice(0, 90)) + (value.length > 90 ? "…" : ""));
    });
    return;
  }
  if (Array.isArray(value)) { value.forEach((v, i) => scanSubPositions(at + "[" + i + "]", v)); return; }
  if (typeof value === "object") Object.keys(value).forEach(k => scanSubPositions(at + "." + k, value[k]));
}
function checkSubWatch(D) {
  const sw = D.subWatch; if (!sw) return;
  if (!isStr(sw.framingNote)) err("subWatch.framingNote", "required — the public-OSINT / no-positions framing statement rendered at the top of the tab");
  if (!isStr(sw.updated)) warn("subWatch.updated", "no assessed-on date");
  scanSubPositions("subWatch", sw);
  const st = sw.status;
  if (!st) warn("subWatch.status", "no sea-leg posture meter");
  else {
    reqEnum("subWatch.status", "level", ENUM.posture, st.level);
    if (st.range != null) {
      if (!Array.isArray(st.range) || st.range.length !== 2 || !inEnum(ENUM.posture, st.range[0]) || !inEnum(ENUM.posture, st.range[1])) err("subWatch.status.range", "must be [levelLo, levelHi] using the posture enum");
      else { const i = ENUM.posture.indexOf(st.level), lo = ENUM.posture.indexOf(st.range[0]), hi = ENUM.posture.indexOf(st.range[1]); if (i < Math.min(lo, hi) || i > Math.max(lo, hi)) err("subWatch.status.range", "level " + st.level + " lies outside its own range " + JSON.stringify(st.range)); }
    } else warn("subWatch.status.range", "no uncertainty range on the sea-leg meter");
    if (!isStr(st.headline)) warn("subWatch.status.headline", "empty");
    if (!isStr(st.mover)) warn("subWatch.status.mover", "say what observation would move the sea-leg level");
  }
  const fleet = arr(sw.fleet);
  if (fleet.length < 3) err("subWatch.fleet", "need >=3 classes on the order-of-battle board; got " + fleet.length);
  uniqueIds("subWatch.fleet", fleet, "id");
  if (fleet.length && !fleet.some(b => b && isStr(b.alt))) warn("subWatch.fleet", "no class carries an `alt` second estimate — hull counts are contested; show the spread");
  fleet.forEach((b, i) => {
    const at = "subWatch.fleet[" + i + "]" + (b && b.id ? " (" + b.id + ")" : "");
    if (!b || !isStr(b.cls)) { err(at, "needs cls (class name)"); return; }
    if (!isStr(b.hulls)) err(at, "needs hulls (a count with its uncertainty, e.g. '6 (2 × 094 + 4 × 094A)')");
    reqEnum(at, "status", SUB_STATUS, b.status);
    warnEnum(at, "trend", ENUM.trend, b.trend); warnEnum(at, "conf", ENUM.conf, b.conf);
    if (!isStr(b.grade) || !admLetter(b.grade)) warn(at, "no Admiralty grade");
    if (!isStr(b.src)) warn(at, "no src");
  });
  const bases = arr(sw.bases);
  if (!bases.length) warn("subWatch.bases", "no basing / industrial-base board");
  uniqueIds("subWatch.bases", bases, "id");
  bases.forEach((b, i) => { const at = "subWatch.bases[" + i + "]"; if (!b || !isStr(b.name)) err(at, "needs name"); else { if (!isStr(b.sees)) warn(at + " (" + b.name + ")", "say what OSINT sees there"); warnEnum(at, "conf", ENUM.conf, b.conf); } });
  const obs = arr(sw.observables);
  if (!obs.length) warn("subWatch.observables", "no pattern-of-life observables table");
  uniqueIds("subWatch.observables", obs, "id");
  obs.forEach((o, i) => { if (o && o.tier && ["t1", "t2", "t3"].indexOf(o.tier) === -1) warn("subWatch.observables[" + i + "]", "tier must be t1|t2|t3; got " + JSON.stringify(o.tier)); });
  const iw = arr(sw.iw);
  if (iw.length < 5) err("subWatch.iw", "need >=5 sea-leg I&W indicators; got " + iw.length);
  uniqueIds("subWatch.iw", iw, "id");
  let unseen = 0;
  iw.forEach((r, i) => {
    const at = "subWatch.iw[" + i + "]" + (r && r.id ? " (" + r.id + ")" : "");
    if (!r) { err(at, "null"); return; }
    reqEnum(at, "observed", ENUM.observed, r.observed); if (r.observed === "unseen") unseen++;
    if (!(Number.isInteger(r.crit) && r.crit >= 1 && r.crit <= 5)) err(at, "crit must be an integer 1..5");
    if (!isStr(r.threshold)) warn(at, "no threshold"); if (!isStr(r.grade)) warn(at, "no Admiralty grade"); warnEnum(at, "conf", ENUM.conf, r.conf);
    const gapGrade = /F\s*6|\bgap\b/i.test(String(r.grade || "") + " " + String(r.src || ""));
    if (gapGrade && r.observed === "normal") warn(at, "graded as a collection gap but observed=normal — mark it 'unseen'");
  });
  if (iw.length && unseen === 0) err("subWatch.iw", "no sea-leg indicator marked 'unseen' — submarine alert state and warhead loading are near-invisible by definition; a board that reads them as normal is dishonest");
  const env = arr(sw.environment);
  if (env.length < 4) warn("subWatch.environment", "fewer than 4 rows in the undersea-surveillance ledger (allied arrays, PRC sensor net, acoustic signatures, C2 are the minimum)");
  uniqueIds("subWatch.environment", env, "id");
  env.forEach((e, i) => { const at = "subWatch.environment[" + i + "]" + (e && e.id ? " (" + e.id + ")" : ""); if (!e || !isStr(e.layer)) { err(at, "needs layer"); return; } reqEnum(at, "side", SUB_SIDE, e.side); if (!isStr(e.known) || !isStr(e.unknown)) warn(at, "each ledger row should state both what is public (known) and what is classified/unobservable (unknown)"); if (!isStr(e.grade)) warn(at, "no Admiralty grade"); });
  uniqueIds("subWatch.doctrine", arr(sw.doctrine), "id");
  const civ = arr(sw.civilMaritime);
  if (!civ.length) warn("subWatch.civilMaritime", "no civil–military maritime fusion board");
  uniqueIds("subWatch.civilMaritime", civ, "id");
  civ.forEach((c, i) => { if (c) warnEnum("subWatch.civilMaritime[" + i + "]", "tone", ENUM.tone, c.tone); });
  const tl = arr(sw.timeline); let last = null;
  tl.forEach((e, i) => { const at = "subWatch.timeline[" + i + "]"; if (!e || !isStr(e.title)) { err(at, "needs title"); return; } if (e.iso) { const t = Date.parse(e.iso); if (isNaN(t)) warn(at, "iso not parseable"); else { if (last != null && t > last) warn(at, "timeline should be newest-first"); last = t; } } });
  const dict = sw.scanner && arr(sw.scanner.dictionary);
  if (!dict || !dict.length) warn("subWatch.scanner.dictionary", "empty — the undersea-language scanner has nothing to match");
  else {
    let terms = 0, nonAscii = 0;
    dict.forEach((c, i) => { if (c) warnEnum("subWatch.scanner.dictionary[" + i + "]", "tone", ENUM.tone, c.tone); if (!c || !arr(c.terms).length) warn("subWatch.scanner.dictionary[" + i + "]", "category has no terms"); arr(c && c.terms).forEach(t => { terms++; if (/[^\x00-\x7F]/.test(String(t))) nonAscii++; }); });
    if (terms < 15) warn("subWatch.scanner.dictionary", "only " + terms + " terms — thin");
    if (!nonAscii) warn("subWatch.scanner.dictionary", "no native-language terms — the scanner will miss the subject's own vocabulary");
  }
  if (!isStr(sw.sources)) warn("subWatch.sources", "name the tab's sources");
}
/* ---------- LOOKING GLASS blocks ---------- */
const AIR_ROLES = ["strike", "dual-capable", "tanker", "c2", "relay", "aew", "isr", "support", "transport"];
const LAUNCHER_ROLES = ["ICBM", "IRBM", "MRBM", "SRBM", "GLCM", "HGV", "dual-capable", "SAM", "other"];
const AIR_BANNED = [
  { re: /\btarget(ing)? (package|solution|coordinates|list)\b/i, why: "targeting vocabulary" },
  { re: /\bstrike (plan|package|route)\b/i, why: "strike-planning vocabulary" },
  { re: /\b(how|best way) to (defeat|evade|penetrate|jam)\b/i, why: "force-defeat vocabulary" },
];
function scanRail(at, value, rails, negRe) {
  if (value == null) return;
  if (typeof value === "string") {
    rails.forEach(b => { const m = value.match(b.re); if (!m) return; const ctx = value.slice(Math.max(0, m.index - 90), m.index + m[0].length + 90); if (negRe && negRe.test(ctx)) return; err(at, "rail: " + b.why + " in " + JSON.stringify(value.slice(0, 90)) + (value.length > 90 ? "…" : "")); });
    return;
  }
  if (Array.isArray(value)) { value.forEach((v, i) => scanRail(at + "[" + i + "]", v, rails, negRe)); return; }
  if (typeof value === "object") Object.keys(value).forEach(k => scanRail(at + "." + k, value[k], rails, negRe));
}
function checkLegCommon(at, blk, opts) {
  if (!isStr(blk.framingNote)) err(at + ".framingNote", "required — the public-OSINT / no-positions framing statement rendered at the top of the tab");
  if (!isStr(blk.updated)) warn(at + ".updated", "no assessed-on date");
  const st = blk.status;
  if (!st) warn(at + ".status", "no leg posture meter");
  else {
    reqEnum(at + ".status", "level", ENUM.posture, st.level);
    if (st.range != null) { if (!Array.isArray(st.range) || st.range.length !== 2 || !inEnum(ENUM.posture, st.range[0]) || !inEnum(ENUM.posture, st.range[1])) err(at + ".status.range", "must be [levelLo, levelHi]"); else { const i = ENUM.posture.indexOf(st.level), lo = ENUM.posture.indexOf(st.range[0]), hi = ENUM.posture.indexOf(st.range[1]); if (i < Math.min(lo, hi) || i > Math.max(lo, hi)) err(at + ".status.range", "level lies outside its own range"); } }
    else warn(at + ".status.range", "no uncertainty range");
    if (!isStr(st.mover)) warn(at + ".status.mover", "say what observation would move the level");
  }
  const fleet = arr(blk.fleet);
  if (fleet.length < opts.minFleet) err(at + ".fleet", "need >=" + opts.minFleet + " entries on the order-of-battle board; got " + fleet.length);
  uniqueIds(at + ".fleet", fleet, "id");
  if (fleet.length && !fleet.some(b => b && isStr(b.alt))) warn(at + ".fleet", "no entry carries an `alt` second estimate — counts are contested; show the spread");
  fleet.forEach((b, i) => {
    const a = at + ".fleet[" + i + "]" + (b && b.id ? " (" + b.id + ")" : "");
    if (!b || !isStr(b[opts.nameKey])) { err(a, "needs " + opts.nameKey); return; }
    if (!isStr(b[opts.countKey])) err(a, "needs " + opts.countKey + " (a count with its uncertainty)");
    if (!inEnum(opts.roles, b.role)) warn(a, "role should be one of " + opts.roles.join("|") + "; got " + JSON.stringify(b.role));
    reqEnum(a, "status", opts.statuses, b.status);
    warnEnum(a, "trend", ENUM.trend, b.trend); warnEnum(a, "conf", ENUM.conf, b.conf);
    if (!isStr(b.grade) || !admLetter(b.grade)) warn(a, "no Admiralty grade");
    if (!isStr(b.src)) warn(a, "no src");
  });
  const obs = arr(blk.observables); uniqueIds(at + ".observables", obs, "id");
  if (!obs.length) warn(at + ".observables", "no pattern-of-life observables table");
  obs.forEach((o, i) => { if (o && o.tier && ["t1", "t2", "t3"].indexOf(o.tier) === -1) warn(at + ".observables[" + i + "]", "tier must be t1|t2|t3"); });
  const iw = arr(blk.iw);
  if (iw.length < 5) err(at + ".iw", "need >=5 leg indicators; got " + iw.length);
  uniqueIds(at + ".iw", iw, "id");
  let unseen = 0;
  iw.forEach((r, i) => { const a = at + ".iw[" + i + "]" + (r && r.id ? " (" + r.id + ")" : ""); if (!r) { err(a, "null"); return; } reqEnum(a, "observed", ENUM.observed, r.observed); if (r.observed === "unseen") unseen++; if (!(Number.isInteger(r.crit) && r.crit >= 1 && r.crit <= 5)) err(a, "crit must be an integer 1..5"); if (!isStr(r.threshold)) warn(a, "no threshold"); if (!isStr(r.grade)) warn(a, "no Admiralty grade"); warnEnum(a, "conf", ENUM.conf, r.conf); });
  if (iw.length && unseen === 0) err(at + ".iw", "no indicator marked 'unseen' — " + opts.unseenWhy);
  uniqueIds(at + ".doctrine", arr(blk.doctrine), "id");
  const tl = arr(blk.timeline); let last = null;
  tl.forEach((e, i) => { const a = at + ".timeline[" + i + "]"; if (!e || !isStr(e.title)) { err(a, "needs title"); return; } if (e.iso) { const t = Date.parse(e.iso); if (isNaN(t)) warn(a, "iso not parseable"); else { if (last != null && t > last) warn(a, "timeline should be newest-first"); last = t; } } });
  const dict = blk.scanner && arr(blk.scanner.dictionary);
  if (!dict || !dict.length) warn(at + ".scanner.dictionary", "empty — the scanner has nothing to match");
  else { let terms = 0, nonAscii = 0; dict.forEach((c, i) => { if (c) warnEnum(at + ".scanner.dictionary[" + i + "]", "tone", ENUM.tone, c.tone); if (!c || !arr(c.terms).length) warn(at + ".scanner.dictionary[" + i + "]", "category has no terms"); arr(c && c.terms).forEach(t => { terms++; if (/[^\x00-\x7F]/.test(String(t))) nonAscii++; }); }); if (terms < 15) warn(at + ".scanner.dictionary", "only " + terms + " terms — thin"); if (!nonAscii) warn(at + ".scanner.dictionary", "no native-language terms — the scanner will miss the subject's own vocabulary"); }
  if (!isStr(blk.sources)) warn(at + ".sources", "name the tab's sources");
}
function checkLiveBoard(at, tw) {
  const types = arr(tw.types); if (!types.length) { err(at + ".types", "empty"); return; }
  const typeKeys = [];
  types.forEach((t, i) => { const a = at + ".types[" + i + "]"; if (!t || !isStr(t.key)) { err(a, "no key"); return; } if (/^air:/.test(t.key)) err(a, "keys must not carry the air: prefix — the page adds it"); typeKeys.push(t.key); warnEnum(a, "tempo", ENUM.tempo, t.tempo); if (!isStr(t.type)) warn(a, "no display type"); });
  uniqueIds(at + ".types", types, "key");
  const match = tw.match || {}; const matchKeys = Object.keys(match);
  const missing = typeKeys.filter(k => matchKeys.indexOf(k) === -1), extra = matchKeys.filter(k => typeKeys.indexOf(k) === -1);
  if (missing.length) err(at + ".match", "no matcher for type key(s): " + missing.join(", "));
  if (extra.length) err(at + ".match", "matcher key(s) with no matching type: " + extra.join(", "));
  matchKeys.forEach(k => { const m = match[k] || {}; if (!arr(m.types).length && !arr(m.regs).length && !arr(m.hex).length) warn(at + ".match." + k, "empty matcher"); arr(m.types).forEach(code => { if (!ICAO_RE.test(String(code))) warn(at + ".match." + k, "designator " + JSON.stringify(code) + " is not 2-5 upper-case alphanumerics"); }); arr(m.hex).forEach(h => { if (!/^[0-9a-f]{6}$/i.test(String(h))) warn(at + ".match." + k, "hex " + JSON.stringify(h) + " is not a 6-digit Mode-S address"); }); });
  const s = tw.sector;
  if (s) { if (!(isNum(s.lat) && s.lat >= -90 && s.lat <= 90)) err(at + ".sector.lat", "out of range"); if (!(isNum(s.lon) && s.lon >= -180 && s.lon <= 180)) err(at + ".sector.lon", "out of range"); const dist = s.dist != null ? s.dist : s.radiusNm; if (!(isNum(dist) && dist >= 1 && dist <= 250)) err(at + ".sector.dist", "must be 1..250 nm"); }
  if (tw.alert) { const al = tw.alert; if (!(Number.isInteger(al.red) && Number.isInteger(al.alert) && al.red > al.alert && al.alert >= 1)) warn(at + ".alert", "expected integers with red > alert >= 1"); else if (al.red > types.length) err(at + ".alert", "red=" + al.red + " exceeds the " + types.length + " watched types"); }
  if (!isStr(tw.alertRule)) warn(at + ".alertRule", "describe the tripwire in words");
  if (!isStr(tw.note)) warn(at + ".note", "state the honesty rules (absence is uninformative; correlation not intent; public broadcasts)");
}
function checkAirWatch(D) {
  const aw = D.airWatch; if (!aw) return;
  checkLegCommon("airWatch", aw, { minFleet: 3, nameKey: "type", countKey: "airframes", roles: AIR_ROLES, statuses: ["in-service", "building", "modernising", "storage", "trials", "unknown", "retired"], unseenWhy: "bomber generation, weapons loading and alert status are near-invisible by definition" });
  scanRail("airWatch", aw, AIR_BANNED, /\b(not|never|no|cannot|does not|do not|is not|are not|rather than|instead of)\b/i);
  arr(aw.fleet).forEach((b, i) => { const a = "airWatch.fleet[" + i + "]"; if (!b) return; arr(b.icao).forEach(code => { if (!ICAO_RE.test(String(code))) warn(a, "icao " + JSON.stringify(code) + " is not a 2-5 char designator"); }); if (b.transponds != null && ["never", "rarely", "often", "mode-s-only", "unknown"].indexOf(b.transponds) === -1) warn(a, "transponds should be never|rarely|often|mode-s-only|unknown"); });
  const bases = arr(aw.bases); uniqueIds("airWatch.bases", bases, "id");
  if (!bases.length) warn("airWatch.bases", "no basing board");
  bases.forEach((b, i) => { const a = "airWatch.bases[" + i + "]"; if (!b || !isStr(b.name)) err(a, "needs name"); else { if (!isStr(b.sees)) warn(a + " (" + b.name + ")", "say what OSINT sees there"); warnEnum(a, "conf", ENUM.conf, b.conf); } });
  if (aw.live) checkLiveBoard("airWatch.live", aw.live); else warn("airWatch.live", "no live board — the subject's transponding support types (tankers, AEW, airborne C2, transports) are usually the only workable live signal");
}
const LAUNCHER_POS_RE = [
  { re: /\b-?\d{1,2}\.\d{3,}\s*,?\s*-?\d{1,3}\.\d{3,}\b/, why: "looks like a coordinate pair" },
  { re: /\b(?:real-?time|live|current|present|latest|last known|now)\s+(?:position|location|track|whereabouts|field position|firing position|launch position)s?\b/i, why: "live/current-position vocabulary" },
  { re: /\b(?:is|are|was|were)\s+(?:currently|now|presently)\s+(?:at|in|near|hiding|parked|dispersed to|sitting|deployed at)\b/i, why: "present-tense launcher-location claim" },
  { re: /\b(?:tracked|located|spotted|geolocated)\s+(?:at|to)\s+\d{1,2}\s*°/i, why: "tracked-to-coordinates claim" },
  { re: /\b(?:field|firing|launch)\s+positions?\s+(?:at|near|in)\s+[A-Z][a-z]+\s+(?:forest|woods|junction|km)/, why: "named field-position claim" },
];
const LAUNCHER_NEG_RE = /\b(?:not|never|no|none|cannot|can't|unobservable|invisible|unseen|does not|do not|rather than|instead of|without|absence|neither|nor|not shown|not observable|is not|are not|never shown|never drawn)\b/i;
function checkLauncherWatch(D) {
  const lw = D.launcherWatch; if (!lw) return;
  checkLegCommon("launcherWatch", lw, { minFleet: 2, nameKey: "system", countKey: "launchers", roles: LAUNCHER_ROLES, statuses: ["in-service", "building", "modernising", "storage", "trials", "unknown", "retired"], unseenWhy: "warhead mating, dispersal orders and alert states are near-invisible by definition; a board that reads them as normal is dishonest" });
  scanRail("launcherWatch", lw, LAUNCHER_POS_RE, LAUNCHER_NEG_RE);
  scanRail("launcherWatch", lw, AIR_BANNED, /\b(not|never|no|cannot|does not|do not|is not|are not|rather than|instead of)\b/i);
  const g = arr(lw.garrisons); uniqueIds("launcherWatch.garrisons", g, "id");
  if (!g.length) warn("launcherWatch.garrisons", "no garrisons board");
  g.forEach((b, i) => { const a = "launcherWatch.garrisons[" + i + "]"; if (!b || !isStr(b.name)) err(a, "needs name (a town / region, never a field position)"); else { if (!isStr(b.formation)) warn(a + " (" + b.name + ")", "name the formation and systems"); if (!isStr(b.sees)) warn(a + " (" + b.name + ")", "say what OSINT sees there"); warnEnum(a, "conf", ENUM.conf, b.conf); } });
  const d = lw.dispersal;
  if (!d || (!isStr(d.pattern) && !arr(d.inputs).length)) warn("launcherWatch.dispersal", "no dispersal-doctrine block — the land-leg map's structural inputs should be stated here");
  else arr(d.inputs).forEach((r, i) => { if (!r || !isStr(r.k) || !isStr(r.v)) warn("launcherWatch.dispersal.inputs[" + i + "]", "each input needs k and v"); });
}
function checkTriadMaps(D, src) {
  const tm = D.triadMaps; if (!tm) return;
  const th = arr(tm.theatres);
  if (!th.length) { err("triadMaps.theatres", "empty — omit the block or list theatres"); return; }
  if (!isStr(tm.framingNote)) err("triadMaps.framingNote", "required — the structural-prior / no-positions framing statement");
  uniqueIds("triadMaps.theatres", th, "id");
  const legs = {};
  th.forEach((t, i) => {
    const a = "triadMaps.theatres[" + i + "]" + (t && t.id ? " (" + t.id + ")" : "");
    if (!t || !isStr(t.id)) { err(a, "needs id"); return; }
    if (!/^[a-z0-9-]+$/.test(t.id)) err(a, "id must be kebab-case (it is a file name)");
    if (["sea", "land", "air"].indexOf(t.leg) === -1) err(a, "leg must be sea|land|air");
    legs[t.leg] = 1;
    if (!isStr(t.label)) warn(a, "no label");
    if (!isStr(t.summary)) warn(a, "no one-line summary (what the map says at the default posture)");
    const cfgPath = path.join(ROOT, "data", "theatres", t.id + ".json");
    if (!fs.existsSync(cfgPath)) err(a, "no theatre config at data/theatres/" + t.id + ".json");
    else { try { const c = JSON.parse(fs.readFileSync(cfgPath, "utf8")); const dom = (c.grid && c.grid.domain) || "sea"; if (dom !== t.leg) err(a, "leg " + t.leg + " does not match the config's grid.domain " + dom); if (c.meta && c.meta.edition && t.edition && c.meta.edition !== t.edition) warn(a, "edition " + t.edition + " differs from the config's " + c.meta.edition); } catch (e) { err(a, "theatre config not valid JSON"); } }
  });
  if (D.subWatch && !legs.sea) warn("triadMaps", "Sub Watch present but no sea theatre listed");
  if (D.launcherWatch && !legs.land) warn("triadMaps", "Launcher Watch present but no land theatre listed");
  if (D.airWatch && !legs.air) warn("triadMaps", "Air Watch present but no air theatre listed");
}
const SOURCE_KINDS = ["telegram", "telegram-bot", "discord", "bluesky", "mastodon", "reddit", "youtube", "rss", "x", "adsb", "notam", "navwarn", "web"];
const SECRET_RE = [
  { re: /\b\d{6,10}:[A-Za-z0-9_-]{30,}\b/, why: "looks like a Telegram bot token" },
  { re: /\bsk-ant-[A-Za-z0-9_-]{20,}/, why: "looks like an Anthropic API key" },
  { re: /\b[MN][A-Za-z\d]{23,}\.[\w-]{6}\.[\w-]{27,}\b/, why: "looks like a Discord bot token" },
  { re: /\bapi_hash\s*[:=]\s*["'][0-9a-f]{32}["']/i, why: "looks like a Telegram api_hash" },
  { re: /\+\d{9,15}\b/, why: "looks like a phone number" },
  { re: /\bAAAA[A-Za-z0-9%]{60,}/, why: "looks like an X bearer token" },
];
function checkCollector(D, raw) {
  const c = D.collector; if (!c) return;
  if (!isStr(c.framingNote)) err("collector.framingNote", "required — read-only, own accounts, loopback-only, unverified framing");
  if (c.endpoint != null && !/^https?:\/\/(127\.0\.0\.1|localhost)(:\d{2,5})?$/i.test(String(c.endpoint))) err("collector.endpoint", "must be a loopback endpoint (http://127.0.0.1:<port> or http://localhost:<port>); got " + JSON.stringify(c.endpoint));
  const srcs = arr(c.sources); if (!srcs.length) warn("collector.sources", "no collection plan — gen_collector_config.py will emit an empty config");
  const seen = {};
  srcs.forEach((s, i) => {
    const a = "collector.sources[" + i + "]";
    if (!s) { err(a, "null"); return; }
    if (SOURCE_KINDS.indexOf(s.kind) === -1) err(a, "kind must be one of " + SOURCE_KINDS.join("|") + "; got " + JSON.stringify(s.kind));
    const id = String(s.handle || s.id || s.url || "");
    if (!id) err(a, "needs handle / id / url");
    const key = s.kind + ":" + id.toLowerCase(); if (seen[key]) err(a, "duplicate source " + key); seen[key] = 1;
    if (s.kind === "telegram" && !HANDLE_RE.test(id.replace(/^@/, ""))) err(a, "telegram handle must match [a-z0-9_]{3,64}");
    if (s.kind === "discord" && !/^\d{15,22}(\/\d{15,22})?$/.test(id)) err(a, "discord source must be a numeric server id or server/channel id pair (snowflakes), never a token or invite");
    if (s.kind === "bluesky" && !/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(id)) warn(a, "bluesky handle should be a full handle like name.bsky.social");
    if (s.kind === "mastodon" && !/^@?[a-z0-9_.-]+@[a-z0-9.-]+\.[a-z]{2,}$/i.test(id)) warn(a, "mastodon account should be user@instance");
    if (s.kind === "reddit" && !/^r\/[A-Za-z0-9_]{2,30}$/.test(id)) warn(a, "reddit source should be r/<subreddit>");
    if (s.kind === "youtube" && !/^(UC[A-Za-z0-9_-]{20,24}|@[A-Za-z0-9_.-]{3,40})$/.test(id)) warn(a, "youtube source should be a channel id (UC…) or @handle");
    if ((s.kind === "rss" || s.kind === "web") && !/^https:\/\//.test(id)) err(a, "rss/web url must be https");
    if (s.kind === "x" && s.enabled !== false) warn(a, "X source enabled — the X connector is disabled by default (paid API); leave enabled:false unless a bearer token is configured");
    warnEnum(a, "lane", ENUM.lane, s.lane);
    if (!isStr(s.label)) warn(a, "no label");
  });
  SECRET_RE.forEach(b => { if (b.re.test(raw)) err("data.js", "SECRET in shipped content: " + b.why + " — secrets belong in collector/config.toml, never in data.js"); });
}
function checkPlaceholders(raw) {
  // Scan string literals only (not comments) for TODO-style placeholders.
  const noComments = raw.replace(/\/\*[\s\S]*?\*\//g, "").replace(/(^|[^:\\])\/\/[^\n]*/g, "$1");
  const strings = noComments.match(/"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'/g) || [];
  let n = 0; strings.forEach(s => { if (TODO_RE.test(s)) { n++; if (n <= 5) err("data.js", "placeholder text in shipped content: " + s.slice(0, 80)); } });
  if (n > 5) err("data.js", (n - 5) + " more placeholder strings");
}

function main() {
  const args = parseArgs();
  let loaded;
  try { loaded = loadData(args.src); }
  catch (e) { console.error("FATAL: could not evaluate data.js — " + (e && e.message)); process.exit(2); }
  const D = loaded.D;
  if (!D || typeof D !== "object") { console.error("FATAL: window.ORACLE_DATA not found or not an object in data.js"); process.exit(2); }
  checkMeta(D); checkPosture(D); checkProduct(D); checkMatrix(D); checkForces(D); checkEvents(D);
  checkIw(D); checkAch(D); checkAnnex(D); checkEscalation(D); checkMovement(D);
  checkTrackWatch(D); checkOsint(D); checkSourcesAndSecurity(D); checkProtective(D); checkSubWatch(D);
  checkAirWatch(D); checkLauncherWatch(D); checkTriadMaps(D, args.src); checkCollector(D, loaded.raw); checkPlaceholders(loaded.raw);

  const country = (D.meta && D.meta.country) || "?";
  const compiled = (D.meta && D.meta.compiled) || "?";
  if (args.json) { console.log(JSON.stringify({ country, compiled, errors, warnings: warns }, null, 2)); }
  else {
    console.log("LOOKING GLASS v3 data validation — " + country + " (compiled " + compiled + ")");
    console.log("  " + errors.length + " error(s), " + warns.length + " warning(s)\n");
    if (errors.length) { console.log("ERRORS (must fix before build):"); errors.forEach(e => console.log("  ✗ " + e)); console.log(""); }
    if (warns.length) { console.log("WARNINGS (review):"); warns.forEach(w => console.log("  ! " + w)); console.log(""); }
    if (!errors.length && !warns.length) console.log("✓ clean — the analytic contract is satisfied.");
  }
  const fail = errors.length > 0 || (args.strict && warns.length > 0);
  process.exit(fail ? 1 : 0);
}
main();
