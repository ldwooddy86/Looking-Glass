#!/usr/bin/env node
/* verify_channels.js — check every osint.channels handle in data.js against
   its PUBLIC preview page (https://t.me/s/<handle>) and report whether a real
   post stream exists, how many posts are visible and how fresh the newest is.
   It never logs in, sends no cookies, and reads only public pages.
   It does NOT edit data.js — set `verified:true` + `verifiedOn` by hand once
   you have seen the result (a human stays in the loop on the honesty rail).
   Usage: node scripts/verify_channels.js [--src assets/extension] [handle …] */
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const ROOT = path.dirname(__dirname);
const argv = process.argv.slice(2);
let src = path.join(ROOT, "assets", "extension");
const extra = [];
for (let i = 0; i < argv.length; i++) { if (argv[i] === "--src") src = argv[++i]; else extra.push(argv[i]); }

function loadHandles() {
  const code = fs.readFileSync(path.join(src, "data.js"), "utf8");
  const sb = { window: {}, self: {} }; vm.createContext(sb); vm.runInContext(code, sb, { timeout: 5000 });
  const D = sb.window.ORACLE_DATA || {};
  return ((D.osint && D.osint.channels) || []).map(c => ({ handle: String(c.handle || "").replace(/^@/, ""), enabled: c.enabled !== false, verified: c.verified === true, verifiedOn: c.verifiedOn || "" }));
}
async function check(handle) {
  if (!/^[a-zA-Z0-9_]{3,64}$/.test(handle)) return { handle, ok: false, why: "invalid handle" };
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch("https://t.me/s/" + handle, { redirect: "follow", credentials: "omit", referrerPolicy: "no-referrer", signal: ctl.signal });
    clearTimeout(t);
    if (!r.ok) return { handle, ok: false, why: "HTTP " + r.status };
    const html = await r.text();
    const posts = (html.match(/tgme_widget_message_text/g) || []).length;
    if (!posts && html.indexOf("tgme_widget_message") === -1) return { handle, ok: false, why: "no public post stream (contact page / private)" };
    const dates = [...html.matchAll(/<time[^>]*datetime="([^"]+)"/g)].map(m => Date.parse(m[1])).filter(x => !isNaN(x));
    const newest = dates.length ? Math.max(...dates) : null;
    const title = ((html.match(/<meta property="og:title" content="([^"]*)"/) || [])[1] || "").replace(/&amp;/g, "&").replace(/&quot;/g, "\"").replace(/&#39;/g, "'");
    const subs = (html.match(/(\d[\d\s.,]*[KM]?)\s*subscribers/) || [])[1] || "";
    return { handle, ok: true, posts, newest, title, subs: subs.trim(), stale: newest ? (Date.now() - newest) > 30 * 864e5 : true };
  } catch (e) { clearTimeout(t); return { handle, ok: false, why: e && e.message }; }
}
(async () => {
  const list = extra.length ? extra.map(h => ({ handle: h.replace(/^@/, ""), enabled: true, verified: false })) : loadHandles();
  if (!list.length) { console.log("no channels to check"); return; }
  let bad = 0;
  for (const c of list) {
    const r = await check(c.handle);
    const flag = c.enabled && !c.verified ? "  ✗ ENABLED-BUT-UNVERIFIED" : "";
    if (r.ok) console.log(`@${r.handle}: OK · ${r.posts} posts · newest ${r.newest ? new Date(r.newest).toISOString().slice(0, 10) : "?"}${r.stale ? " (STALE >30d)" : ""} · ${r.subs || "?"} subs · "${r.title}"${flag}`);
    else { bad++; console.log(`@${r.handle}: FAIL — ${r.why}${flag}`); }
  }
  console.log(`\n${list.length - bad} resolve with a public stream, ${bad} do not. Record verifiedOn as ${new Date().toISOString().slice(0, 10)} for the ones you enable.`);
})();
