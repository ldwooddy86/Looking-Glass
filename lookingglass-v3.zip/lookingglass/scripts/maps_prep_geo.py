#!/usr/bin/env python3
"""
maps_prep_geo.py — build the embedded geodata for one LOOKING GLASS map theatre (sea, land or air).

Usage:
    python scripts/maps_prep_geo.py --config data/theatres/<theatre>.json [--geodata <dir>] [--out build/maps/<id>]

Reads config.grid (bbox, step, projection, domain, force_open …), rasterises Natural Earth 10 m
layers onto the lat/lon grid (cell-centre sampling), projects the base map to SVG paths (Mercator
or Lambert conformal conic), and writes:
    <out>/grid.json   grid spec + RLE class raster (255 = impassable) + class names + domain
    <out>/geo.json    projection constants + SVG base-map layers (generic `layers[]`, plus the
                      legacy sea keys land/shelf/deep/abyss so older pages still render)

Domains
    sea   classes = bathymetry bands (0:<200 m … 7:>6000 m); 255 = land. COUNTDOWN heritage.
    land  classes = movement/terrain: 0 road corridor (open) · 1 road corridor (under cover) ·
          2 open terrain off-road · 3 covered terrain off-road · 4 urban · 5–7 reserved;
          255 = water, or outside `grid.confine_iso` territory. Cover comes from analyst polygons
          (`grid.cover_polygons` naming keys of config.polygons) and/or an optional GeoJSON file
          (`grid.cover_geojson`). Roads from ne_10m_roads buffered by `grid.road_buffer_km` (8).
    air   classes = airspace: 0 own (`grid.own_iso`) · 1 allied (`grid.allied_iso`) ·
          2 neutral / international · 3 adversary (`grid.adversary_iso`); nothing impassable.

Natural Earth GeoJSON files are read from --geodata (default $LG_GEODATA, $COUNTDOWN_GEODATA or
./geodata); run scripts/maps_fetch_geodata.sh first.
"""
import argparse, json, math, os, sys, time
import numpy as np
try:
    from shapely.geometry import shape, box, Point, MultiPolygon, Polygon, LineString, MultiLineString
    from shapely.ops import unary_union
    from shapely import prepared
except ImportError:
    sys.exit("shapely is required: pip install shapely --break-system-packages")

LEVELS = [("L_0", 0), ("K_200", 200), ("J_1000", 1000), ("I_2000", 2000), ("H_3000", 3000), ("G_4000", 4000), ("F_5000", 5000), ("E_6000", 6000), ("D_7000", 7000), ("C_8000", 8000), ("B_9000", 9000), ("A_10000", 10000)]
CLASS_OF = {0: 0, 200: 1, 1000: 2, 2000: 3, 3000: 4, 4000: 5, 5000: 6, 6000: 7, 7000: 7, 8000: 7, 9000: 7, 10000: 7}
SEA_CLASSES = ["0-200 m", "200-1000 m", "1000-2000 m", "2000-3000 m", "3000-4000 m", "4000-5000 m", "5000-6000 m", ">6000 m"]
LAND_CLASSES = ["road corridor · open", "road corridor · under cover", "open terrain · off-road", "covered terrain · off-road", "urban", "reserved", "reserved", "reserved"]
AIR_CLASSES = ["own airspace", "allied airspace", "neutral / international", "adversary airspace", "reserved", "reserved", "reserved", "reserved"]
D2R = math.pi / 180


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--geodata", default=os.environ.get("LG_GEODATA", os.environ.get("COUNTDOWN_GEODATA", "geodata")))
    ap.add_argument("--out", default=None)
    ap.add_argument("--width", type=float, default=1000.0)
    args = ap.parse_args()
    cfg = json.load(open(args.config))
    grid = cfg["grid"]
    domain = grid.get("domain", "sea")
    if domain not in ("sea", "land", "air"):
        sys.exit(f"grid.domain must be sea|land|air, got {domain!r}")
    out = args.out or os.path.join("build", "maps", cfg["meta"]["id"])
    os.makedirs(out, exist_ok=True)
    t0 = time.time()

    LON0, LON1, LAT0, LAT1 = grid["lon0"], grid["lon1"], grid["lat0"], grid["lat1"]
    STEP = grid.get("step", 0.2)
    NC = int(round((LON1 - LON0) / STEP)); NR = int(round((LAT1 - LAT0) / STEP))
    print(f"[prep] {cfg['meta']['id']} ({domain}): grid {NC} x {NR} = {NC*NR} cells at {STEP}°")
    BBOX = box(LON0 - 1, LAT0 - 1, LON1 + 1, LAT1 + 1)

    def load(name, props=False):
        fp = os.path.join(args.geodata, name + ".geojson")
        if not os.path.exists(fp):
            sys.exit(f"missing {fp} — run scripts/maps_fetch_geodata.sh")
        gj = json.load(open(fp)); feats = []
        for ft in gj["features"]:
            try:
                g = shape(ft["geometry"])
            except Exception:
                continue
            if g.is_empty or not g.intersects(BBOX):
                continue
            g = g.intersection(BBOX)
            if g.is_empty:
                continue
            feats.append((g, ft.get("properties", {})) if props else g)
        return feats

    def valid(u):
        if u is not None and not u.is_valid:
            u = u.buffer(0)
        return u

    def cell_lat(r): return LAT0 + (r + 0.5) * STEP
    def cell_lon(c): return LON0 + (c + 0.5) * STEP

    def mask_of(geom):
        """boolean NR×NC mask of cell centres inside geom (None → all False)."""
        m = np.zeros((NR, NC), dtype=bool)
        if geom is None or geom.is_empty:
            return m
        pg = prepared.prep(geom)
        for r in range(NR):
            la = cell_lat(r)
            for c in range(NC):
                if pg.contains(Point(cell_lon(c), la)):
                    m[r, c] = True
        return m

    def iso_of(p):
        return str(p.get("ISO_A3") if p.get("ISO_A3") not in (None, "-99") else p.get("ADM0_A3", "")).upper()

    countries = None
    def country_union(codes):
        nonlocal countries
        if not codes:
            return None
        if countries is None:
            countries = load("ne_10m_admin_0_countries", props=True)
        want = set(x.upper() for x in codes)
        gs = [g for g, p in countries if iso_of(p) in want or str(p.get("ADM0_A3", "")).upper() in want or str(p.get("SOV_A3", "")).upper() in want]
        return valid(unary_union(gs)) if gs else None

    land = valid(unary_union(load("ne_10m_land") + load("ne_10m_minor_islands")))
    layers = []      # generic base-map layers, drawn in order
    legacy = {}      # sea heritage keys
    print(f"[prep] land loaded {time.time()-t0:.1f}s")

    if domain == "sea":
        bathy = {}
        for code, depth in LEVELS:
            feats = load("ne_10m_bathymetry_" + code)
            bathy[depth] = valid(unary_union(feats)) if feats else None
        land_p = prepared.prep(land)
        bathy_p = {d: (prepared.prep(g) if g is not None else None) for d, g in bathy.items()}
        klass = np.zeros((NR, NC), dtype=np.uint8); blocked = np.zeros((NR, NC), dtype=bool)
        for r in range(NR):
            la = cell_lat(r)
            for c in range(NC):
                p = Point(cell_lon(c), la)
                if land_p.contains(p):
                    blocked[r, c] = True; continue
                dc = 0
                for code, depth in LEVELS[1:]:
                    bp = bathy_p[depth]
                    if bp is not None and bp.contains(p):
                        dc = CLASS_OF[depth]
                    else:
                        break
                klass[r, c] = dc
        class_names = SEA_CLASSES
        credits = "Coastline & isobaths: Natural Earth 10 m (200 · 2,000 · 4,000 m)"
    elif domain == "land":
        lakes = valid(unary_union(load("ne_10m_lakes"))) if True else None
        urban = valid(unary_union(load("ne_10m_urban_areas")))
        roads = load("ne_10m_roads")
        rivers = load("ne_10m_rivers_lake_centerlines")
        road_buf_km = float(grid.get("road_buffer_km", 8.0))
        # buffer roads in degrees (approx. at the frame's mid-latitude)
        midlat = (LAT0 + LAT1) / 2
        dlon = road_buf_km / (111.32 * max(0.2, math.cos(midlat * D2R))); dlat = road_buf_km / 110.57
        road_zone = valid(unary_union([g.buffer(max(dlon, dlat)) for g in roads])) if roads else None
        cover_geoms = []
        for key in grid.get("cover_polygons", []):
            pg = (cfg.get("polygons") or {}).get(key)
            if pg:
                cover_geoms.append(Polygon(pg["pts"]))
        if grid.get("cover_geojson"):
            fp = grid["cover_geojson"] if os.path.isabs(grid["cover_geojson"]) else os.path.join(os.path.dirname(args.config), grid["cover_geojson"])
            gj = json.load(open(fp))
            for ft in gj.get("features", []):
                try:
                    g = shape(ft["geometry"]).intersection(BBOX)
                    if not g.is_empty:
                        cover_geoms.append(g)
                except Exception:
                    pass
        cover = valid(unary_union(cover_geoms)) if cover_geoms else None
        confine = country_union(grid.get("confine_iso", []))
        m_land = mask_of(land); m_lake = mask_of(lakes); m_urb = mask_of(urban); m_road = mask_of(road_zone); m_cov = mask_of(cover)
        m_conf = mask_of(confine) if confine is not None else np.ones((NR, NC), dtype=bool)
        blocked = (~m_land) | m_lake | (~m_conf)
        klass = np.full((NR, NC), 2, dtype=np.uint8)          # open terrain off-road
        klass[m_cov] = 3                                         # covered off-road
        klass[m_road & ~m_cov] = 0                               # road corridor open
        klass[m_road & m_cov] = 1                                # road corridor under cover
        klass[m_urb] = 4                                         # urban
        class_names = LAND_CLASSES
        credits = "Base map: Natural Earth 10 m land, lakes, rivers, roads, urban areas; cover = analyst polygons"
        print(f"[prep] land raster: road-corridor cells {int((klass==0).sum()+(klass==1).sum())} · cover {int(m_cov.sum())} · urban {int(m_urb.sum())} · blocked {int(blocked.sum())}")
    else:  # air
        own = country_union(grid.get("own_iso", [])); ally = country_union(grid.get("allied_iso", [])); adv = country_union(grid.get("adversary_iso", []))
        klass = np.full((NR, NC), 2, dtype=np.uint8)
        if ally is not None: klass[mask_of(ally)] = 1
        if adv is not None: klass[mask_of(adv)] = 3
        if own is not None: klass[mask_of(own)] = 0
        blocked = np.zeros((NR, NC), dtype=bool)
        class_names = AIR_CLASSES
        credits = "Base map: Natural Earth 10 m land & admin-0 boundaries; airspace classes from the theatre config"
    print(f"[prep] raster {time.time()-t0:.1f}s · impassable cells {int(blocked.sum())}")

    # force-open channels (cell-centre sampling can close narrow water / mountain passes)
    for seg in grid.get("force_open", []):
        a, b, c_, d = seg[:4]
        n = 60
        for i in range(n + 1):
            t = i / n
            lo = a + (c_ - a) * t; la = b + (d - b) * t
            cc = int((lo - LON0) / STEP); rr = int((la - LAT0) / STEP)
            if 0 <= rr < NR and 0 <= cc < NC:
                blocked[rr, cc] = False
    # force-blocked cells (e.g. an enclosed basin the routing must not use)
    for seg in grid.get("force_block", []):
        a, b, c_, d = seg[:4]
        n = 60
        for i in range(n + 1):
            t = i / n
            lo = a + (c_ - a) * t; la = b + (d - b) * t
            cc = int((lo - LON0) / STEP); rr = int((la - LAT0) / STEP)
            if 0 <= rr < NR and 0 <= cc < NC:
                blocked[rr, cc] = True

    raster = klass.copy(); raster[blocked] = 255
    flat = raster.flatten(); rle = []; prev = int(flat[0]); cnt = 1
    for v in flat[1:]:
        v = int(v)
        if v == prev and cnt < 65535:
            cnt += 1
        else:
            rle.append([prev, cnt]); prev = v; cnt = 1
    rle.append([prev, cnt])
    json.dump({"lon0": LON0, "lon1": LON1, "lat0": LAT0, "lat1": LAT1, "step": STEP, "nc": NC, "nr": NR, "domain": domain,
               "classes": class_names, "rle": rle},
              open(os.path.join(out, "grid.json"), "w"), separators=(",", ":"))

    # ---- projection ----------------------------------------------------------------------
    pj = grid.get("projection", {"type": "mercator"})
    ptype = pj.get("type", "mercator")
    if ptype == "lcc":
        lat1 = pj.get("lat1", LAT0 + (LAT1 - LAT0) / 6); lat2 = pj.get("lat2", LAT1 - (LAT1 - LAT0) / 6)
        lat_o = pj.get("lat0", (LAT0 + LAT1) / 2); lon_o = pj.get("lon0", (LON0 + LON1) / 2)
        p1, p2, p0 = lat1 * D2R, lat2 * D2R, lat_o * D2R
        n = math.log(math.cos(p1) / math.cos(p2)) / math.log(math.tan(math.pi / 4 + p2 / 2) / math.tan(math.pi / 4 + p1 / 2)) if abs(lat1 - lat2) > 1e-6 else math.sin(p1)
        F = math.cos(p1) * math.tan(math.pi / 4 + p1 / 2) ** n / n
        rho0 = F / math.tan(math.pi / 4 + p0 / 2) ** n
        def raw(lon, lat):
            phi = max(-89.0, min(89.0, lat)) * D2R
            rho = F / math.tan(math.pi / 4 + phi / 2) ** n
            th = n * (lon - lon_o) * D2R
            return rho * math.sin(th), rho0 - rho * math.cos(th)
        proj_consts = {"type": "lcc", "lon0": lon_o, "lat1": lat1, "lat2": lat2, "lat0": lat_o, "n": n, "F": F, "rho0": rho0}
    else:
        def raw(lon, lat):
            la = max(-85.0, min(85.0, lat))
            return lon, math.log(math.tan(math.pi / 4 + la * D2R / 2)) / D2R
        proj_consts = {"type": "mercator"}
    samples = []
    for i in range(201):
        t = i / 200
        samples += [raw(LON0 + (LON1 - LON0) * t, LAT0), raw(LON0 + (LON1 - LON0) * t, LAT1), raw(LON0, LAT0 + (LAT1 - LAT0) * t), raw(LON1, LAT0 + (LAT1 - LAT0) * t)]
    minX = min(s[0] for s in samples); maxX = max(s[0] for s in samples); minY = min(s[1] for s in samples); maxY = max(s[1] for s in samples)
    W = args.width; S = W / (maxX - minX); Hh = (maxY - minY) * S
    proj_consts.update({"minX": minX, "maxY": maxY, "S": S})

    def proj(lon, lat):
        X, Y = raw(lon, lat)
        return (X - minX) * S, (maxY - Y) * S

    def ring_to_path(coords, close=True):
        parts = []; last = None
        for lon, lat in coords:
            x, y = proj(lon, lat); x = round(x, 1); y = round(y, 1)
            if last is not None and abs(x - last[0]) < 0.35 and abs(y - last[1]) < 0.35:
                continue
            parts.append(("M" if not parts else "L") + f"{x:g},{y:g}"); last = (x, y)
        if close:
            return "".join(parts) + "Z" if len(parts) >= 3 else ""
        return "".join(parts) if len(parts) >= 2 else ""

    def geom_to_path(g, tol):
        if g is None or g.is_empty:
            return ""
        g = g.simplify(tol, preserve_topology=True)
        polys = [g] if isinstance(g, Polygon) else (list(g.geoms) if isinstance(g, MultiPolygon) else [p for p in getattr(g, "geoms", []) if isinstance(p, Polygon)])
        d = []
        for p in polys:
            if p.area < 1e-5:
                continue
            d.append(ring_to_path(p.exterior.coords))
            for it in p.interiors:
                d.append(ring_to_path(it.coords))
        return "".join(d)

    def lines_to_path(geoms, tol):
        d = []
        for g in geoms:
            if g is None or g.is_empty:
                continue
            g = g.simplify(tol, preserve_topology=True)
            parts = [g] if isinstance(g, LineString) else (list(g.geoms) if isinstance(g, MultiLineString) else [p for p in getattr(g, "geoms", []) if isinstance(p, LineString)])
            for ln in parts:
                d.append(ring_to_path(ln.coords, close=False))
        return "".join(d)

    clip = box(LON0, LAT0, LON1, LAT1)
    tol = STEP * 0.06
    land_path = geom_to_path(land.intersection(clip), tol)
    if domain == "sea":
        legacy = {"land": land_path,
                  "shelf": geom_to_path(bathy[200].intersection(clip) if bathy[200] is not None else None, tol * 2.5),
                  "deep": geom_to_path(bathy[2000].intersection(clip) if bathy[2000] is not None else None, tol * 3),
                  "abyss": geom_to_path(bathy[4000].intersection(clip) if bathy[4000] is not None else None, tol * 4)}
        layers = [{"id": "shelf", "d": legacy["shelf"], "fill": "var(--shelf)", "stroke": "#1E3354", "width": .6},
                  {"id": "deep", "d": legacy["deep"], "fill": "var(--deep)", "stroke": "#152744", "width": .6},
                  {"id": "abyss", "d": legacy["abyss"], "fill": "var(--abyss)"},
                  {"id": "land", "d": land_path, "fill": "var(--landfill)", "stroke": "var(--coast)", "width": .7, "group": "land"}]
    elif domain == "land":
        bnd = load("ne_10m_admin_0_boundary_lines_land")
        layers = [{"id": "land", "d": land_path, "fill": "var(--landfill-dry)", "stroke": "var(--coast)", "width": .7, "group": "land"},
                  {"id": "cover", "d": geom_to_path(cover.intersection(clip) if cover is not None else None, tol * 2), "fill": "var(--cover)", "opacity": .55},
                  {"id": "urban", "d": geom_to_path(urban.intersection(clip) if urban is not None else None, tol * 2), "fill": "var(--urban)", "opacity": .8},
                  {"id": "lakes", "d": geom_to_path(lakes.intersection(clip) if lakes is not None else None, tol * 2), "fill": "var(--sea)", "stroke": "var(--coast)", "width": .5},
                  {"id": "rivers", "d": lines_to_path([g.intersection(clip) for g in rivers], tol * 2), "fill": "none", "stroke": "var(--river)", "width": .5, "opacity": .7},
                  {"id": "roads", "d": lines_to_path([g.intersection(clip) for g in roads], tol * 1.5), "fill": "none", "stroke": "var(--road)", "width": .6, "opacity": .45},
                  {"id": "borders", "d": lines_to_path([g.intersection(clip) for g in bnd], tol * 2), "fill": "none", "stroke": "var(--border)", "width": .8, "dash": "5 3", "opacity": .8}]
        if confine is not None:
            layers.insert(1, {"id": "territory", "d": geom_to_path(confine.intersection(clip), tol * 2), "fill": "var(--territory)", "opacity": .35})
    else:
        bnd = load("ne_10m_admin_0_boundary_lines_land")
        layers = [{"id": "land", "d": land_path, "fill": "var(--landfill)", "stroke": "var(--coast)", "width": .7, "group": "land"},
                  {"id": "own", "d": geom_to_path(own.intersection(clip) if own is not None else None, tol * 2), "fill": "var(--territory)", "opacity": .35},
                  {"id": "allied", "d": geom_to_path(ally.intersection(clip) if ally is not None else None, tol * 2), "fill": "var(--allied)", "opacity": .25},
                  {"id": "adversary", "d": geom_to_path(adv.intersection(clip) if adv is not None else None, tol * 2), "fill": "var(--adversary)", "opacity": .22},
                  {"id": "borders", "d": lines_to_path([g.intersection(clip) for g in bnd], tol * 2), "fill": "none", "stroke": "var(--border)", "width": .8, "dash": "5 3", "opacity": .8}]
        legacy = {"land": land_path}
    geo = {"W": W, "H": Hh, "proj": proj_consts, "domain": domain, "credits": credits, "layers": layers}
    geo.update(legacy)
    json.dump(geo, open(os.path.join(out, "geo.json"), "w"))
    kb = sum(len(l.get("d", "")) for l in layers) // 1024
    print(f"[prep] done {time.time()-t0:.1f}s · canvas {W:.0f}x{Hh:.0f} · base-map paths {kb} KB · projection {ptype}")


if __name__ == "__main__":
    main()
