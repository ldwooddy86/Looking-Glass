/* ============================================================
   dashboard.js — LOOKING GLASS v3 renderer (country-agnostic)
   ------------------------------------------------------------
   The DalesOracle v2 engine plus the LOOKING GLASS layers:
     Air Watch      — nuclear strike & support aircraft (bombers, dual-capable
                      fighters, tankers, airborne C2/relay, AEW, ISR): order of
                      battle, basing, pattern-of-life, air-leg I&W, a live
                      public-ADS-B board for the SUBJECT's transponding types,
                      an air-language scanner.
     Launcher Watch — road-mobile launchers (ICBM/IRBM/MRBM/SRBM TELs): order of
                      battle, garrisons, dispersal doctrine, land-leg I&W, a
                      launcher-language scanner. Never a position.
     Triad Map      — the COUNTDOWN likelihood heatmaps (sea · land · air
                      theatres) embedded as self-contained map pages.
     Feed · Media   — items, photos and video pulled by the local LOOKING GLASS
                      collector (Telegram user + bot, Discord bot, Bluesky,
                      Mastodon, Reddit, YouTube, RSS, ADS-B, NOTAM/NAVWARN) with
                      machine-suggested triage, read over loopback only.
   Renders every tab from window.ORACLE_DATA in two modes:
     "extension" — chrome.* present. Live channel lanes, the scanners,
       Track Watch / Air Watch pattern-of-life, the collector feed and the
       optional synthesis layer read the worker's cache.
     "preview"   — plain file / artifact. Full sourced baseline; the live
       layers explain that feeds need the installed build; the maps are
       embedded (window.LG_MAPS, base64) by build_preview.py.
   Security invariants:
     • ALL untrusted text (channel HTML, collector items, AI text) is
       sanitized by OracleSanitize and inserted via textContent / text
       nodes. Remote content never touches innerHTML. No eval, no remote
       code, no inline handlers — CSP script-src 'self'.
     • Outbound links are rendered only for https URLs that pass
       OracleSanitize.safeHttpsUrl; collector media only for URLs under
       the accepted LOOPBACK endpoint (OracleSanitize.safeLocalUrl).
   ============================================================ */
(function () {
  "use strict";
  var D = window.ORACLE_DATA || {};
  var S = window.OracleSanitize;
  var IS_EXT = !!(typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id && chrome.storage && chrome.storage.local);
  var PREVIEW = (typeof window.PREVIEW_MODE !== "undefined" && window.PREVIEW_MODE) || !IS_EXT;
  var LEVELS = { stable: 6, guarded: 28, elevated: 50, high: 72, severe: 94 };
  var LEVEL_ORDER = ["stable", "guarded", "elevated", "high", "severe"];
  var THREAT_ORDER = ["low", "moderate", "substantial", "severe", "critical"];
  var TEMPO_RATE = { neardaily: 1.0, frequent: 0.4, rare: 0.07 }; // expected sightings / day
  var DEFAULT_MODEL = "claude-sonnet-4-6";
  var AIR_PREFIX = "air:";                       // Air Watch live keys are namespaced in the shared ADS-B cache
  var DEFAULT_COLLECTOR = "http://127.0.0.1:8787";
  var ENGINE_NAME = "LOOKING GLASS v3.0";
  var lastLive = null;                           // most recent flt_cache (for the map live overlay)
  var mapFrames = {};                            // theatre id → iframe (Triad Map tab)

  /* ---------- tiny DOM helpers ---------- */
  function el(tag, cls, txt) { var n = document.createElement(tag); if (cls) n.className = cls; if (txt != null) n.textContent = String(txt); return n; }
  function byId(id) { return document.getElementById(id); }
  function clear(n) { while (n && n.firstChild) n.removeChild(n.firstChild); }
  function tn(s) { return document.createTextNode(String(s == null ? "" : s)); }
  function extLink(href, cls, label) {
    var safe = S && S.safeHttpsUrl(href);
    if (!safe) return el("span", cls, label);
    var a = document.createElement("a"); a.className = cls || ""; a.textContent = String(label); a.href = safe; a.target = "_blank"; a.rel = "noopener noreferrer"; return a;
  }
  function levelClass(lvl) {
    var k = String(lvl || "").toLowerCase();
    if (k === "high" || k === "severe" || k === "warning") return k;
    if (k === "guarded" || k === "stable" || k === "watch" || k === "normal") return "guarded";
    return "elevated";
  }
  function dots(n, max) { n = Math.max(0, Math.min(max || 5, n || 0)); var s = ""; for (var i = 0; i < (max || 5); i++) s += i < n ? "●" : "○"; return s; }
  function fmtAgo(ts) { if (!ts) return "—"; var s = Math.max(0, Math.floor((Date.now() - ts) / 1000)); if (s < 60) return s + "s"; var m = Math.floor(s / 60); if (m < 60) return m + "m"; var h = Math.floor(m / 60); if (h < 24) return h + "h"; return Math.floor(h / 24) + "d"; }
  function has(v) { return v != null && String(v).trim().length > 0; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function kvRow(cls, k, v) { var r = el("div", cls); r.appendChild(el("b", null, k)); r.appendChild(tn(v)); return r; }
  // Row filter for big tables: a text input that hides non-matching <tr>s (header row kept).
  function makeFilter(table, placeholder) {
    var inp = el("input", "filter"); inp.type = "search"; inp.placeholder = placeholder || "Filter rows…"; inp.setAttribute("aria-label", placeholder || "Filter rows");
    inp.addEventListener("input", function () {
      var q = inp.value.trim().toLowerCase();
      var rows = table.querySelectorAll("tr");
      for (var i = 1; i < rows.length; i++) {
        var hit = !q || rows[i].textContent.toLowerCase().indexOf(q) !== -1;
        rows[i].classList.toggle("hidden-row", !hit);
      }
    });
    return inp;
  }
  function chipFor(prefix, value, extraCls) { return el("span", prefix + " " + prefix + "-" + String(value || "").toLowerCase() + (extraCls ? " " + extraCls : ""), String(value || "").toUpperCase()); }

  /* ---------- identity / masthead / footer ---------- */
  function renderIdentity() {
    var m = D.meta || {};
    byId("brandName").textContent = m.brand || "LOOKING GLASS";
    byId("brandEyebrow").textContent = "OSINT · " + (m.country || "Military") + " Watch";
    document.title = (m.brand || "LOOKING GLASS") + " — " + (m.line || "Nuclear Forces & Military Posture Monitor");
    var pill = byId("modePill"); pill.textContent = PREVIEW ? "PREVIEW" : "LIVE"; pill.className = "mode-pill " + (PREVIEW ? "preview" : "live");
    var t = byId("mastTitle"); clear(t);
    t.appendChild(el("span", null, (m.country || "") + " ")); t.appendChild(el("span", "amb", m.subject || m.line || "Military Posture"));
    byId("mastLede").textContent = (D.posture && D.posture.headline) || "";
    byId("mastTag").textContent = (m.tagline ? m.tagline + " · " : "") + "Compiled " + (m.compiled || "") + (m.edition ? " · Edition " + m.edition : "");
    var pr = byId("postureRead"); clear(pr);
    pr.appendChild(el("strong", null, (D.posture ? String(D.posture.level || "").toUpperCase() : "") + " — "));
    pr.appendChild(tn((D.posture && D.posture.body) || ""));
    var mv = byId("postureMover");
    if (D.posture && has(D.posture.mover)) { clear(mv); mv.appendChild(el("b", null, "What would move it: ")); mv.appendChild(tn(D.posture.mover)); mv.hidden = false; } else mv.hidden = true;
    byId("footAbout").textContent = "An open-source intelligence synthesis of " + (m.country || "the target country") + "'s nuclear forces and military posture" + (D.protective ? " and the protective-security picture around it" : "") + ". Value is in currency and synthesis, not access to secrets. Real-time unit, launcher and warhead locations, munitions depth and alert states are not observable in open sources and are not shown; the Triad Map draws structural priors, never tracks.";
    byId("footSources").textContent = D.sources || "";
  }
  function setGauge() {
    var p = D.posture || {};
    var k = String(p.level || "elevated").toLowerCase(); if (!(k in LEVELS)) k = "elevated";
    var mk = byId("gaugeMarker"), fl = byId("gaugeFlag");
    mk.style.left = LEVELS[k] + "%"; fl.textContent = k.toUpperCase();
    fl.style.background = (k === "high" || k === "severe") ? "var(--alert)" : (k === "stable" || k === "guarded") ? "var(--calm)" : "var(--amber)";
    mk.querySelector(".stem").style.background = fl.style.background;
    var rg = byId("gaugeRange");
    if (Array.isArray(p.range) && p.range.length === 2 && (p.range[0] in LEVELS) && (p.range[1] in LEVELS)) {
      var lo = LEVELS[p.range[0]], hi = LEVELS[p.range[1]]; if (lo > hi) { var t = lo; lo = hi; hi = t; }
      rg.style.left = Math.max(0, lo - 4) + "%"; rg.style.width = Math.max(4, hi - lo + 8) + "%"; rg.hidden = false;
      rg.title = "Uncertainty range: " + p.range[0] + " – " + p.range[1];
    } else rg.hidden = true;
  }

  /* ---------- BLUF / product ---------- */
  function renderProduct() {
    var p = D.product; if (!p) return;
    var mount = byId("productMount"); clear(mount);
    var wrap = el("div", "product");
    wrap.appendChild(el("div", "prod-handling", p.handling || ""));
    var head = el("div", "prod-head");
    head.appendChild(el("div", "prod-title", p.line || "Strategic Warning"));
    var asof = el("div", "prod-asof"); asof.appendChild(el("span", "k", "As of")); asof.appendChild(el("span", "v", p.asOf || "")); if (has(p.horizon)) { asof.appendChild(tn("  ")); asof.appendChild(el("span", "k", "Horizon")); asof.appendChild(el("span", "v", p.horizon)); }
    head.appendChild(asof); wrap.appendChild(head);
    if (has(p.scopeNote)) wrap.appendChild(el("div", "prod-scope", p.scopeNote));
    if (has(p.bluf)) { var b = el("div", "bluf"); b.appendChild(el("span", "bluf-tag", "BLUF")); b.appendChild(tn(p.bluf)); wrap.appendChild(b); }
    // changes since last edition
    var ch = arr(p.changes);
    if (ch.length) {
      var box = el("div", "changes"); var chh = el("div", "changes-head");
      chh.appendChild(el("div", "mini-h", "What changed"));
      chh.appendChild(el("span", "changes-prev", (D.meta && D.meta.previousCompiled) ? "since " + D.meta.previousCompiled : "since the previous edition"));
      box.appendChild(chh);
      ch.forEach(function (c) {
        var row = el("div", "change ch-" + String(c.kind || "watch").toLowerCase());
        row.appendChild(el("span", "change-date", c.date || ""));
        row.appendChild(el("span", "change-kind", c.kind || "watch"));
        row.appendChild(el("span", "change-text", c.text || ""));
        box.appendChild(row);
      });
      wrap.appendChild(box);
    }
    var kjs = arr(p.keyJudgments);
    if (kjs.length) {
      var kjw = el("div", "kj-wrap"); var kh = el("div", "kj-head");
      kh.appendChild(el("div", "mini-h", "Key judgments")); kh.appendChild(el("div", "kj-hint", "ICD-203 · probability and confidence stated separately · Admiralty-graded basis")); kjw.appendChild(kh);
      var list = el("div", "kj-list");
      kjs.forEach(function (kj) {
        var c = el("div", "kj"); var top = el("div", "kj-top"); top.appendChild(el("span", "kj-id", kj.id || ""));
        var chips = el("div", "kj-chips");
        if (has(kj.prob)) chips.appendChild(el("span", "kj-chip prob", kj.prob));
        if (has(kj.confidence)) chips.appendChild(el("span", "kj-chip conf-" + String(kj.confidence).toLowerCase(), "Conf: " + kj.confidence));
        if (has(kj.grade)) chips.appendChild(el("span", "kj-chip grade", kj.grade));
        top.appendChild(chips); c.appendChild(top);
        c.appendChild(el("div", "kj-text", kj.text || ""));
        if (has(kj.basis)) c.appendChild(el("div", "kj-basis", "Basis: " + kj.basis));
        if (has(kj.whatWouldChange)) { var w = el("div", "kj-change"); w.appendChild(el("b", null, "Would change it")); w.appendChild(tn(kj.whatWouldChange)); c.appendChild(w); }
        list.appendChild(c);
      });
      kjw.appendChild(list);
      if (arr(p.estimativeKey).length) {
        var det = el("details", "prob-key"); det.appendChild(el("summary", null, "Estimative-probability yardstick (ICD-203)"));
        var grid = el("div", "prob-grid");
        p.estimativeKey.forEach(function (r) { var row = el("div", "prob-row"); row.appendChild(el("span", "prob-term", r.term)); row.appendChild(el("span", "prob-band", r.band)); grid.appendChild(row); });
        det.appendChild(grid);
        if (has(p.confidenceDef)) det.appendChild(el("div", "prob-conf", p.confidenceDef));
        kjw.appendChild(det);
      }
      wrap.appendChild(kjw);
    }
    mount.appendChild(wrap);
  }

  /* ---------- capability / threat matrix ---------- */
  function covGlyph(v) { var map = { strong: "●", partial: "◐", gap: "○", na: "·" }; var s = el("span", "tmx-cov tmx-cov-" + (v || "na"), map[v] || "·"); s.title = v || "n/a"; return s; }
  function renderMatrix() {
    var mx = D.matrix; if (!mx) return;
    var mount = byId("matrixMount"); clear(mount);
    mount.appendChild(el("div", "tmx-lead", "All-source fusion · " + (mx.updated || "")));
    if (has(mx.note)) mount.appendChild(el("p", "posture-read", mx.note));
    var leg = el("div", "tmx-legend");
    var r1 = el("div", "tmx-leg-row"); arr(mx.levels).forEach(function (l) { var g = el("div", "tmx-leg"); g.appendChild(el("span", "tmx-chip tmx-" + l.key, l.label)); r1.appendChild(g); }); leg.appendChild(r1);
    var r2 = el("div", "tmx-leg-row"); [["strong", "seen well"], ["partial", "partial"], ["gap", "blind spot"], ["na", "n/a"]].forEach(function (c) { var g = el("div", "tmx-leg"); g.appendChild(covGlyph(c[0])); g.appendChild(el("span", "tmx-leg-t", c[1])); r2.appendChild(g); }); leg.appendChild(r2);
    mount.appendChild(leg);
    var sc = el("div", "tmx-scroll"); var t = el("table", "tmx-table");
    var thead = el("tr"); ["ID", "Domain", "Pri", "Level", "Trend", "Conf", "Lead", "Finding"].forEach(function (h) { thead.appendChild(el("th", null, h)); });
    arr(mx.intCols).forEach(function (c) { var th = el("th", "tmx-int-h", c.label); th.title = c.full || ""; thead.appendChild(th); });
    t.appendChild(thead);
    var trend = { up: "▲", flat: "▬", down: "▼" };
    arr(mx.domains).forEach(function (d) {
      var tr = el("tr", d.level === "high" ? "tmx-r-high" : d.level === "severe" ? "tmx-r-severe" : "");
      tr.appendChild(el("td", "tmx-id", d.id));
      tr.appendChild(el("td", "tmx-dom", d.domain));
      var pc = el("td", "tmx-cons"); pc.appendChild(el("span", "cons-dots", dots(d.pri, 5))); pc.title = "Priority " + (d.pri || 0) + "/5"; tr.appendChild(pc);
      var lc = el("td"); lc.appendChild(el("span", "tmx-chip tmx-" + (d.level || "guarded"), String(d.level || "").toUpperCase())); tr.appendChild(lc);
      var tdT = el("td", "tmx-trend tmx-tr-" + (d.trend || "flat"), trend[d.trend] || "▬"); tdT.title = "trend " + (d.trend || "flat"); tr.appendChild(tdT);
      tr.appendChild(el("td", "tmx-conf", d.conf || ""));
      tr.appendChild(el("td", "tmx-prim", d.primary || "—"));
      var fc = el("td", "tmx-find"); fc.appendChild(tn(d.finding || "")); if (has(d.lastChange)) fc.appendChild(el("span", "tmx-src", "Last change: " + d.lastChange)); if (has(d.src)) fc.appendChild(el("span", "tmx-src", d.src)); tr.appendChild(fc);
      arr(mx.intCols).forEach(function (c) { var td = el("td", "tmx-covcell"); td.appendChild(covGlyph(d.ints ? d.ints[c.key] : "na")); tr.appendChild(td); });
      t.appendChild(tr);
    });
    mount.appendChild(makeFilter(t, "Filter domains…"));
    sc.appendChild(t); mount.appendChild(sc);
    if (has(mx.collectionPosture)) { var cp = el("div", "tmx-collect"); cp.appendChild(el("span", "tmx-collect-tag", "Collection")); cp.appendChild(tn(mx.collectionPosture)); mount.appendChild(cp); }
  }

  /* ---------- forces / order of battle / command chain ---------- */
  function renderForces() {
    var f = D.forces; if (!f) return;
    var mount = byId("forcesMount"); clear(mount);
    var cols = el("div", "cols");
    var left = el("div"); var tbl = el("table", "nums");
    arr(f.totals).forEach(function (r) {
      var tr = el("tr");
      var lbl = el("td", "lbl"); lbl.appendChild(tn(r.label)); if (has(r.note)) lbl.appendChild(el("small", null, r.note)); tr.appendChild(lbl);
      var val = el("td", "val"); val.appendChild(tn(r.val)); if (has(r.alt)) val.appendChild(el("span", "alt", "vs " + r.alt)); tr.appendChild(val);
      tbl.appendChild(tr);
    });
    left.appendChild(tbl);
    if (has(f.note)) left.appendChild(el("div", "note", f.note));
    cols.appendChild(left);
    var right = el("div", "disp");
    arr(f.branches).forEach(function (b) {
      var row = el("div", "disp-row"); var hd = el("div", "disp-head"); hd.appendChild(el("span", "leg", b.branch)); hd.appendChild(el("span", "wh", b.personnel)); row.appendChild(hd);
      var bar = el("div", "disp-bar"); var fill = el("div", "disp-fill"); fill.style.width = Math.max(3, Math.min(100, b.pct || 0)) + "%"; bar.appendChild(fill); row.appendChild(bar);
      if (has(b.detail)) row.appendChild(el("small", null, b.detail));
      right.appendChild(row);
    });
    cols.appendChild(right); mount.appendChild(cols);
    var sys = f.systems || {};
    var order = [["ground", "Ground"], ["air", "Air"], ["naval", "Naval"], ["missile", "Missile / rocket"], ["strategic", "Strategic / nuclear"], ["enabling", "Enabling (space · cyber · ISR)"]];
    var grid = el("div", "sysgrid");
    order.forEach(function (o) {
      var a = arr(sys[o[0]]); if (!a.length) return;
      var col = el("div", "syscol" + (o[0] === "strategic" || o[0] === "enabling" ? " exotic" : "")); col.appendChild(el("h4", null, o[1]));
      var ul = el("ul"); a.forEach(function (x) { ul.appendChild(el("li", null, x)); }); col.appendChild(ul); grid.appendChild(col);
    });
    mount.appendChild(grid);
    // leadership / command chain
    var lm = byId("leadershipMount"); clear(lm); var lead = arr(f.leadership);
    if (!lead.length) { byId("leadershipBlock").hidden = true; }
    else {
      byId("leadershipBlock").hidden = false;
      lm.appendChild(el("p", "posture-read", "The command chain as open sources can see it on the build date. Status: confirmed · acting · vacant · purged · unknown. These are the most perishable facts in the product — every row is search-verified per build and sourced."));
      var g = el("div", "lead-grid"); var hd = el("div", "lead-row head"); ["Post", "Holder", "Since", "Status", "Note"].forEach(function (h) { hd.appendChild(el("span", null, h)); }); g.appendChild(hd);
      lead.forEach(function (r) {
        var st = String(r.status || "unknown").toLowerCase();
        var row = el("div", "lead-row st-" + st);
        row.appendChild(el("span", "lead-post", r.post || ""));
        row.appendChild(el("span", "lead-name", r.name || "—"));
        row.appendChild(el("span", "lead-since", r.since || ""));
        row.appendChild(el("span", "lead-status", st));
        var note = el("span", "lead-note"); note.appendChild(tn(r.note || "")); if (has(r.src)) note.appendChild(el("div", "src", r.src)); row.appendChild(note);
        g.appendChild(row);
      });
      lm.appendChild(g);
    }
  }
  function renderIndicators() {
    var mount = byId("indicatorsMount"); clear(mount);
    arr(D.indicators).forEach(function (i) {
      var c = el("div", "card"); var top = el("div", "card-top"); top.appendChild(el("span", "cat", i.cat || "")); top.appendChild(el("span", "chip " + levelClass(i.level), String(i.level || "").toUpperCase())); c.appendChild(top);
      c.appendChild(el("h3", null, i.title || "")); c.appendChild(el("p", null, i.body || "")); if (has(i.src)) c.appendChild(el("div", "src", i.src)); mount.appendChild(c);
    });
  }
  function renderDoctrine() {
    var mount = byId("doctrineMount"); clear(mount);
    var ol = el("ol"); arr(D.doctrine).forEach(function (d) { ol.appendChild(el("li", null, d)); }); mount.appendChild(ol);
    if (has(D.doctrineNote)) mount.appendChild(el("div", "note", D.doctrineNote));
  }
  function renderEvents() {
    var mount = byId("eventsMount"); clear(mount);
    arr(D.events).forEach(function (e) {
      var it = el("div", "tl-item" + (e.hot ? " hot" : ""));
      it.appendChild(el("div", "tl-date", e.date || "")); it.appendChild(el("h4", null, e.title || "")); it.appendChild(el("p", null, e.body || "")); if (has(e.src)) it.appendChild(el("div", "tl-src", e.src)); mount.appendChild(it);
    });
  }

  /* ---------- I&W watchboard (shared builder for the protective layer) ---------- */
  var OBS_W = { normal: 0, note: 0.33, elevated: 0.66, warning: 1 };
  function iwMeters(rows) {
    var wsum = 0, tot = 0, blind = 0, all = 0;
    rows.forEach(function (r) { var w = r.crit || 1; all += w; if (r.observed === "unseen") { blind += w; return; } tot += w; wsum += w * (OBS_W[r.observed] != null ? OBS_W[r.observed] : 0.5); });
    var pct = tot ? Math.round((wsum / tot) * 100) : 0;
    var band = pct >= 66 ? "red" : pct >= 40 ? "alert" : pct >= 20 ? "watch" : "quiet";
    var blindPct = all ? Math.round((blind / all) * 100) : 0;
    var wrap = el("div", "iw-meters");
    var meter = el("div", "iw-meter"); var fill = el("div", "iw-meter-fill iw-fill-" + band); fill.style.width = pct + "%"; meter.appendChild(fill);
    meter.appendChild(el("div", "iw-meter-lbl", "Warning posture (observable rows): " + pct + "% · " + band.toUpperCase())); wrap.appendChild(meter);
    var bm = el("div", "iw-meter iw-blind"); var bf = el("div", "iw-meter-fill"); bf.style.width = blindPct + "%"; bm.appendChild(bf);
    bm.appendChild(el("div", "iw-meter-lbl", "Blind fraction: " + blindPct + "% of consequence unseen")); bm.title = "Crit-weighted share of the board marked UNSEEN — quiet there is not clear."; wrap.appendChild(bm);
    return wrap;
  }
  function iwTable(rows, opts) {
    opts = opts || {};
    var sc = el("div", "iw-scroll"); var t = el("table", "iw-table");
    var th = el("tr"); ["ID", opts.domainLabel || "Domain", "Threshold", "Observed", "Crit", "Conf", "Grade", "Read", "Src"].forEach(function (h) { th.appendChild(el("th", null, h)); }); t.appendChild(th);
    rows.forEach(function (r) {
      var ob = String(r.observed || "normal").toLowerCase();
      var tr = el("tr", ob === "warning" ? "iw-r-warning" : ob === "elevated" ? "iw-r-elevated" : ob === "unseen" ? "iw-r-unseen" : "");
      tr.appendChild(el("td", "iw-id", r.id));
      tr.appendChild(el("td", "iw-dom", r.domain || r.indicator || ""));
      tr.appendChild(el("td", "iw-thr", r.threshold || ""));
      var oc = el("td"); oc.appendChild(el("span", "iw-chip iw-" + ob, ob.toUpperCase())); tr.appendChild(oc);
      var cc = el("td"); cc.appendChild(el("span", "crit-dots", dots(r.crit, 5))); cc.title = "Consequence weight " + (r.crit || 0) + "/5"; tr.appendChild(cc);
      tr.appendChild(el("td", "iw-conf", r.conf || ""));
      tr.appendChild(el("td", "iw-grade", r.grade || ""));
      tr.appendChild(el("td", "iw-read", r.read || ""));
      tr.appendChild(el("td", "iw-src", r.src || ""));
      t.appendChild(tr);
    });
    sc.appendChild(t);
    return { scroll: sc, table: t };
  }
  function renderIw() {
    var iw = D.iwBoard; if (!iw) return;
    var mount = byId("iwMount"); clear(mount);
    var rows = arr(iw.indicators);
    mount.appendChild(iwMeters(rows));
    var lg = el("div", "iw-legend");
    arr(iw.scaleLegend).forEach(function (s) { var g = el("div", "iw-leg"); g.appendChild(el("span", "iw-leg-dot iw-" + s.key)); g.appendChild(el("span", null, s.label + " — " + s.body)); lg.appendChild(g); });
    var gu = el("div", "iw-leg"); gu.appendChild(el("span", "iw-leg-dot iw-unseen")); gu.appendChild(el("span", null, "Unseen — a collection gap; excluded from the meter, counted in the blind fraction.")); lg.appendChild(gu);
    mount.appendChild(lg);
    var t = iwTable(rows); mount.appendChild(makeFilter(t.table, "Filter indicators…")); mount.appendChild(t.scroll);
    if (has(iw.note)) mount.appendChild(el("div", "note", iw.note));
  }

  /* ---------- ACH ---------- */
  function admWeight(grade) { var letter = String(grade || "").toUpperCase().replace(/[^A-F]/g, "").charAt(0); var map = { A: 1.0, B: 0.8, C: 0.6, D: 0.4, E: 0.2, F: 0.5 }; return map[letter] != null ? map[letter] : 0.5; }
  function evWeight(e) { return admWeight(e.grade) * (e.diag ? 1.6 : 0.8); }
  function renderAch() {
    var a = D.ach; if (!a) return;
    var mount = byId("achMount"); clear(mount);
    mount.appendChild(el("p", "posture-read", a.question || ""));
    if (has(a.method)) mount.appendChild(el("div", "note", a.method));
    var sc = el("div", "ach-scroll"); var t = el("table", "ach-table");
    var th = el("tr"); th.appendChild(el("th", null, "Evidence")); th.appendChild(el("th", null, "Grade"));
    arr(a.hypotheses).forEach(function (h) { var x = el("th", "ach-hcol"); x.appendChild(el("span", "ach-hid", h.id)); x.appendChild(el("span", "ach-hlab", h.label)); x.title = h.desc || ""; th.appendChild(x); }); t.appendChild(th);
    arr(a.evidence).forEach(function (e) {
      var tr = el("tr", e.diag ? "ach-diag" : "");
      var et = el("td", "ach-etext"); et.appendChild(el("span", "ach-eid", (e.id || "") + " ")); et.appendChild(tn(e.text || "")); if (e.diag) et.appendChild(el("span", "ach-diag-tag", "diagnostic")); if (has(e.src)) et.appendChild(el("span", "ach-src", e.src)); tr.appendChild(et);
      tr.appendChild(el("td", "ach-grade", e.grade || ""));
      arr(a.hypotheses).forEach(function (h) { var v = e.scores ? e.scores[h.id] : "N"; tr.appendChild(el("td", "ach-cell ach-" + (v || "N"), v || "N")); });
      t.appendChild(tr);
    });
    sc.appendChild(t); mount.appendChild(sc);
    var scoreWrap = el("div", "ach-score");
    scoreWrap.appendChild(el("div", "ach-score-head", "Ranked by LEAST reliability- and diagnosticity-weighted inconsistency (Heuer). Each row's Admiralty letter sets a source-reliability weight (A 1.0 · B 0.8 · C 0.6 · D 0.4 · E 0.2); diagnostic rows count ×2. The most tenable hypothesis is the one the reliable, discriminating evidence fails to contradict — not the one with the most ticks. Weighted score shown with the raw count in parentheses."));
    var grid = el("div", "ach-score-grid");
    var scores = arr(a.hypotheses).map(function (h) {
      var inc = 0, con = 0, winc = 0, wcon = 0;
      arr(a.evidence).forEach(function (e) { var v = e.scores ? e.scores[h.id] : "N", w = evWeight(e); if (v === "I") { inc++; winc += w; } else if (v === "C") { con++; wcon += w; } });
      return { h: h, inc: inc, con: con, winc: winc, wcon: wcon };
    });
    var minWinc = Math.min.apply(null, scores.map(function (s) { return s.winc; }).concat([Infinity]));
    var maxWinc = Math.max.apply(null, scores.map(function (s) { return s.winc; }).concat([0.001]));
    var maxWcon = Math.max.apply(null, scores.map(function (s) { return s.wcon; }).concat([0.001]));
    scores.forEach(function (s) {
      var isLead = (s.winc - minWinc) < 1e-9;
      var card = el("div", "ach-score-card" + (isLead ? " lead" : ""));
      var top = el("div", "ach-sc-top"); top.appendChild(el("span", "ach-sc-id", s.h.id)); top.appendChild(el("span", "ach-sc-lab", s.h.label)); card.appendChild(top);
      var bars = el("div", "ach-sc-bars");
      [["Wtd. inconsist.", "sc-i", s.winc, s.inc, maxWinc], ["Wtd. consist.", "sc-c", s.wcon, s.con, maxWcon]].forEach(function (b) {
        var r = el("div", "ach-scbar"); r.appendChild(el("span", "ach-scbar-l", b[0]));
        var trk = el("span", "ach-scbar-track"); var fl = el("span", "ach-scbar-fill " + b[1]); fl.style.width = Math.min(100, (b[2] / b[4]) * 100) + "%"; trk.appendChild(fl); r.appendChild(trk);
        r.appendChild(el("span", "ach-scbar-n", b[2].toFixed(1) + " (" + b[3] + ")")); bars.appendChild(r);
      });
      card.appendChild(bars);
      card.appendChild(el("div", "ach-sc-rank " + (isLead ? "rank-most" : "rank-tenable"), isLead ? "Most tenable — least weighted disconfirmation" : "Less tenable"));
      grid.appendChild(card);
    });
    scoreWrap.appendChild(grid); mount.appendChild(scoreWrap);
    if (has(a.conclusion)) { var conc = el("div", "ach-conc"); conc.appendChild(el("span", "ach-conc-tag", "Conclusion")); conc.appendChild(tn(a.conclusion)); mount.appendChild(conc); }
  }

  /* ---------- annex: key assumptions + collection gaps ---------- */
  function renderAnnex() {
    var mount = byId("annexMount"); clear(mount);
    var grid = el("div", "annex-grid");
    var kaCol = el("div"); kaCol.appendChild(el("div", "mini-h", "Key assumptions check"));
    arr(D.keyAssumptions).forEach(function (k) {
      var b = el("div", "ka"); var top = el("div", "ka-top"); top.appendChild(el("span", "ka-id", k.id)); top.appendChild(el("span", "ka-text", k.text)); b.appendChild(top);
      if (has(k.risk)) { var r = el("div", "ka-risk"); r.appendChild(el("span", "ka-lbl", "Risk: ")); r.appendChild(tn(k.risk)); b.appendChild(r); }
      if (has(k.ifWrong)) { var w = el("div", "ka-risk"); w.appendChild(el("span", "ka-lbl", "If wrong: ")); w.appendChild(tn(k.ifWrong)); b.appendChild(w); }
      kaCol.appendChild(b);
    });
    grid.appendChild(kaCol);
    var gpCol = el("div"); gpCol.appendChild(el("div", "mini-h", "Collection gaps (by consequence)"));
    arr(D.collectionGaps).forEach(function (g) {
      var b = el("div", "gap"); var top = el("div", "gap-top"); top.appendChild(el("span", "gap-rank", "#" + g.rank)); top.appendChild(el("span", "gap-name", g.gap)); b.appendChild(top);
      if (has(g.detail)) b.appendChild(el("div", "gap-detail", g.detail));
      if (has(g.mitigation)) b.appendChild(el("div", "gap-mit", "Mitigation: " + g.mitigation));
      gpCol.appendChild(b);
    });
    grid.appendChild(gpCol); mount.appendChild(grid);
  }

  /* ---------- intent / escalation (optional tab) ---------- */
  function renderEscalation() {
    var e = D.escalation; var mount = byId("escMount"); clear(mount);
    if (!e) { hideTab("tp-escalation"); return; }
    mount.appendChild(el("div", "esc-lead", e.horizon || ""));
    mount.appendChild(el("div", "focus-q", e.question || e.title || ""));
    if (has(e.bluf)) { var b = el("div", "bluf"); b.appendChild(el("span", "bluf-tag", "BLUF")); b.appendChild(tn(e.bluf)); mount.appendChild(b); }
    if (arr(e.judgments).length) {
      var hyp = el("div", "hyp"); hyp.style.marginTop = "18px";
      e.judgments.forEach(function (j) { var i = el("div", "hyp-i wide"); var top = el("div", "hyp-top"); if (has(j.conf)) top.appendChild(el("span", "conf c2", "Conf: " + j.conf)); i.appendChild(top); i.appendChild(el("h4", null, j.id)); i.appendChild(el("p", null, j.text)); if (has(j.grade)) i.appendChild(el("div", "hyp-src", "Grade: " + j.grade)); hyp.appendChild(i); });
      mount.appendChild(hyp);
    }
    if (arr(e.drivers).length) {
      mount.appendChild(el("div", "mini-h", "Drivers"));
      var sc = el("div", "iw-scroll"); var t = el("table", "iw-table esc-drivers");
      var th = el("tr"); ["ID", "Driver", "Dir", "Current value", "Leverage", "Conf"].forEach(function (h) { th.appendChild(el("th", null, h)); }); t.appendChild(th);
      var groups = {}; arr(e.driverGroups).forEach(function (g) { groups[g.key] = g.label; });
      var lastG = null;
      e.drivers.forEach(function (d) {
        if (d.group !== lastG) { var gr = el("tr", "esc-grp"); var td = el("td"); td.colSpan = 6; td.textContent = groups[d.group] || d.group; gr.appendChild(td); t.appendChild(gr); lastG = d.group; }
        var tr = el("tr");
        tr.appendChild(el("td", "iw-id", d.id)); tr.appendChild(el("td", "iw-dom", d.name)); tr.appendChild(el("td", "esc-dir", d.dir || "")); tr.appendChild(el("td", "esc-val", d.value || ""));
        var lc = el("td"); lc.appendChild(el("span", "lev-tag lev-" + (d.lev || "med"), d.lev || "med")); tr.appendChild(lc);
        tr.appendChild(el("td", "iw-conf", d.conf || "")); t.appendChild(tr);
      });
      sc.appendChild(t); mount.appendChild(sc);
    }
    if (arr(e.scenarios).length) {
      mount.appendChild(el("div", "mini-h", "Scenarios")); var grid = el("div", "esc-scen");
      e.scenarios.forEach(function (s) {
        var card = el("div", "esc-scard esc-" + (s.tone || "watch"));
        var top = el("div", "esc-sc-top"); top.appendChild(el("span", "esc-sid", s.id)); top.appendChild(el("span", "esc-prob esc-prob-" + (s.tone || "watch"), s.prob || "")); card.appendChild(top);
        card.appendChild(el("div", "esc-sname", s.name || "")); card.appendChild(el("div", "esc-stype", s.type || ""));
        if (has(s.gate)) card.appendChild(el("div", "esc-sgate", "Gate: " + s.gate)); grid.appendChild(card);
      });
      mount.appendChild(grid);
      if (has(e.scenarioNote)) mount.appendChild(el("div", "esc-paper", e.scenarioNote));
    }
    if (has(e.crossImpactNote)) { var ci = el("div", "esc-cross"); ci.appendChild(el("span", "esc-cross-tag", "Cross-impact")); ci.appendChild(tn(e.crossImpactNote)); mount.appendChild(ci); }
    if (e.net) {
      var net = el("div", "esc-net"); net.style.marginTop = "16px";
      [["likely", "Most likely", "esc-net-likely"], ["dangerous", "Most dangerous", "esc-net-danger"], ["movers", "What moves it", "esc-net-movers"]].forEach(function (n) {
        if (!has(e.net[n[0]])) return; var it = el("div", "esc-net-item " + n[2]); it.appendChild(el("div", "esc-net-lbl", n[1])); it.appendChild(el("div", "esc-net-body", e.net[n[0]])); net.appendChild(it);
      });
      mount.appendChild(net);
    }
    if (has(e.paperNote)) mount.appendChild(el("div", "esc-paper", e.paperNote));
  }

  /* ---------- movement watchboard + live scanner ---------- */
  function renderMovement() {
    var mv = D.movementWatch; var mount = byId("movementMount"); clear(mount);
    if (!mv) { mount.appendChild(el("div", "note", "No movement watchboard configured for this build.")); return; }
    if (has(mv.intro)) mount.appendChild(el("p", "posture-read", mv.intro));
    if (arr(mv.tiers).length) { var tg = el("div", "mv-tiers"); mv.tiers.forEach(function (t) { var c = el("div", "mv-tier " + t.tier); c.appendChild(el("span", "t", t.tier)); c.appendChild(el("span", "lbl", t.label)); c.appendChild(el("span", "vis", t.vis)); c.appendChild(el("p", null, t.note)); tg.appendChild(c); }); mount.appendChild(tg); }
    if (arr(mv.signatures).length) {
      var sc = el("div", "iw-scroll"); sc.style.marginTop = "16px"; var t = el("table", "iw-table");
      var th = el("tr"); ["ID", "Tier", "Signature", "→ I&W", "Feed", "Read"].forEach(function (h) { th.appendChild(el("th", null, h)); }); t.appendChild(th);
      mv.signatures.forEach(function (s) {
        var tr = el("tr", s.blind ? "iw-r-warning" : "");
        tr.appendChild(el("td", "iw-id", s.id));
        var tier = s.tier || "t3"; var tc = el("td"); tc.appendChild(el("span", "mv-tierchip " + tier, tier.toUpperCase())); tr.appendChild(tc);
        tr.appendChild(el("td", "iw-dom", s.sig)); tr.appendChild(el("td", "iw-conf", s.iw || "")); tr.appendChild(el("td", "iw-thr", s.feed || ""));
        var rc = el("td", "iw-read"); if (s.blind) rc.appendChild(el("span", "mv-blind", "NEAR-BLIND · ")); rc.appendChild(tn(s.note || "")); tr.appendChild(rc);
        t.appendChild(tr);
      });
      sc.appendChild(t); mount.appendChild(sc);
    }
    if (has(mv.note)) mount.appendChild(el("div", "note", mv.note));
  }
  // "动员 (dongyuan)" -> ["动员","dongyuan"]; "no-fly / no-sail zone" -> both halves.
  function scanTerms(term) {
    var out = [];
    String(term || "").split("/").forEach(function (part) {
      var paren = part.match(/\(([^)]*)\)/);
      var outside = part.replace(/\([^)]*\)/g, " ").replace(/[，,]/g, " ").trim();
      if (outside.length >= 2) out.push(outside);
      if (paren && paren[1].trim().length >= 2) out.push(paren[1].trim());
    });
    return out.filter(function (t, i) { return out.indexOf(t) === i; });
  }
  // Text nodes + spans only — never innerHTML (input is already sanitized).
  function appendHighlighted(container, text, subterms) {
    text = String(text); var lower = text.toLowerCase();
    var terms = (subterms || []).map(function (s) { return String(s).toLowerCase(); }).filter(function (s) { return s.length >= 2; });
    var i = 0, guard = 0;
    while (i < text.length && guard++ < 4000) {
      var bestPos = -1, bestLen = 0;
      terms.forEach(function (t) { var p = lower.indexOf(t, i); if (p !== -1 && (bestPos === -1 || p < bestPos)) { bestPos = p; bestLen = t.length; } });
      if (bestPos === -1) break;
      if (bestPos > i) container.appendChild(tn(text.slice(i, bestPos)));
      container.appendChild(el("span", "kwhit", text.slice(bestPos, bestPos + bestLen)));
      i = bestPos + bestLen;
    }
    if (i < text.length) container.appendChild(tn(text.slice(i)));
  }
  function laneMeta(handle) { var m = null; arr(D.osint && D.osint.channels).forEach(function (c) { if (S && S.handle(c.handle) === handle) m = c; }); return m; }
  function scanLanes(cache, dictionary) {
    var toneRank = { red: 0, alert: 1, watch: 2 }; var hits = [];
    Object.keys(cache || {}).forEach(function (handle) {
      var res = cache[handle]; if (!res || !res.ok || !res.html) return;
      var meta = laneMeta(handle); var lane = (meta && meta.lane) || "custom";
      parseTelegram(res.html).forEach(function (p) {
        var text = p.text || ""; if (!text) return; var lower = text.toLowerCase();
        arr(dictionary).forEach(function (cat) {
          var matched = [];
          arr(cat.terms).forEach(function (term) { scanTerms(term).forEach(function (sub) { if (lower.indexOf(sub.toLowerCase()) !== -1 && matched.indexOf(sub) === -1) matched.push(sub); }); });
          if (matched.length) hits.push({ cat: cat.cat, tone: cat.tone || "watch", handle: handle, lane: lane, label: (meta && meta.label) || "@" + handle, when: p.date || "", text: text, matched: matched });
        });
      });
    });
    hits.sort(function (a, b) { return (toneRank[a.tone] == null ? 3 : toneRank[a.tone]) - (toneRank[b.tone] == null ? 3 : toneRank[b.tone]); });
    return hits.slice(0, 80);
  }
  // Cross-lane corroboration: same term seen in how many distinct lanes / lane classes.
  function corroborate(hits) {
    var by = {};
    hits.forEach(function (h) { h.matched.forEach(function (term) { var k = term.toLowerCase(); if (!by[k]) by[k] = { term: term, tone: h.tone, handles: {}, lanes: {} }; by[k].handles[h.handle] = 1; by[k].lanes[h.lane] = 1; }); });
    return Object.keys(by).map(function (k) { var r = by[k]; return { term: r.term, tone: r.tone, lanes: Object.keys(r.handles).length, classes: Object.keys(r.lanes).length }; })
      .filter(function (r) { return r.lanes >= 2; }).sort(function (a, b) { return b.classes - a.classes || b.lanes - a.lanes; }).slice(0, 12);
  }
  // One scanner engine, two dictionaries: the Movement tab scans movement-language, the
  // optional Sub Watch tab scans undersea-language. Both read the same cached lanes.
  function scannerPanel(opts) {
    var sc = opts.sc, mount = opts.mount, cache = opts.cache, kind = opts.kind || "movement-language";
    if (!mount) return; clear(mount);
    var dot = byId(opts.dotId); if (dot) dot.hidden = true;
    if (!sc) return;
    if (has(sc.note)) mount.appendChild(el("p", "posture-read", sc.note));
    var scannable = !PREVIEW && cache && Object.keys(cache).length;
    var hits = scannable ? scanLanes(cache, sc.dictionary || []) : [];
    if (hits.length) {
      var reds = hits.filter(function (h) { return h.tone === "red"; }).length;
      if (dot) { dot.hidden = false; var tabEl = byId(opts.tabId); if (tabEl) tabEl.classList.toggle("tab-red", reds > 0); }
      var sum = el("div", "mv-hits-sum");
      sum.appendChild(el("b", null, hits.length + " " + kind + " hit" + (hits.length === 1 ? "" : "s") + (reds ? " · " + reds + " red-tier" : "")));
      sum.appendChild(tn(" in the cached lanes — VOCABULARY matches, not confirmed events. Each is a lead to corroborate; a red-tier hit warrants immediate cross-checking against a second, independent source."));
      mount.appendChild(sum);
      var corr = corroborate(hits);
      if (corr.length) {
        mount.appendChild(el("div", "mini-h", "Cross-lane corroboration (same term in ≥2 lanes)"));
        var cw = el("div", "mv-corr");
        corr.forEach(function (c) { var row = el("div", "mv-corr-row" + (c.classes >= 2 ? " strong" : "")); row.appendChild(el("span", "mv-corr-term", c.term)); row.appendChild(el("span", "mv-corr-n", c.lanes + " lanes · " + c.classes + " lane class" + (c.classes === 1 ? "" : "es"))); cw.appendChild(row); });
        mount.appendChild(cw);
      }
      var wrap = el("div", "mv-hits");
      hits.forEach(function (h) {
        var box = el("div", "mv-hit" + (h.tone === "red" ? " red" : h.tone === "watch" ? " grey" : ""));
        var top = el("div", "mv-hit-top"); top.appendChild(el("span", "mv-hit-cat", h.cat)); top.appendChild(el("span", "mv-hit-ch", "@" + h.handle + " · " + h.lane)); if (h.when) top.appendChild(el("span", "mv-hit-when", h.when)); box.appendChild(top);
        var body = el("div", "mv-hit-text"); appendHighlighted(body, h.text, h.matched); box.appendChild(body);
        box.appendChild(el("div", "mv-hit-terms", "matched: " + h.matched.join(", "))); wrap.appendChild(box);
      });
      mount.appendChild(wrap);
    } else {
      var empty = el("div", "mv-hits-empty");
      empty.textContent = PREVIEW
        ? "Live scanning runs in the installed extension: it matches the vocabulary below across every cached channel lane (native-language and romanised forms), highlights the term in context, flags the hit by tier and shows cross-lane corroboration. In this preview no lanes are cached, so the scanner shows the dictionary only."
        : scannable ? "No " + kind + " hits in the current cached lanes. A quiet scanner is a statement about VISIBILITY, never about reality — the channels that would carry a real move are the ones disciplined enough never to post it."
          : "No channel lanes are cached yet. Enable verified public handles in Settings, then Refresh — the scanner runs across whatever the worker has cached.";
      mount.appendChild(empty);
    }
    if (arr(sc.dictionary).length) {
      mount.appendChild(el("div", "mini-h", "Dictionary — the vocabulary scanned"));
      var dict = el("div", "mv-dict");
      sc.dictionary.forEach(function (cat) {
        var c = el("div", "mv-cat"); var top = el("div", "mv-cat-top"); top.appendChild(el("span", "mv-cat-name", cat.cat)); top.appendChild(el("span", "mv-cat-tone " + (cat.tone || ""), cat.tone || "")); c.appendChild(top);
        var terms = el("div", "mv-terms"); arr(cat.terms).forEach(function (kw) { terms.appendChild(el("span", "kw-chip", kw)); }); c.appendChild(terms); dict.appendChild(c);
      });
      mount.appendChild(dict);
    }
  }
  function renderScanner(cache) {
    scannerPanel({ sc: D.movementWatch && D.movementWatch.scanner, mount: byId("scannerMount"), cache: cache, dotId: "movementTabDot", tabId: "tab-movement", kind: "movement-language" });
  }
  function renderSubScanner(cache) {
    var sw = D.subWatch; var block = byId("subScanBlock");
    if (!sw || !sw.scanner) { if (block) block.hidden = true; return; }
    if (block) block.hidden = false;
    scannerPanel({ sc: sw.scanner, mount: byId("subScannerMount"), cache: cache, dotId: "subTabDot", tabId: "tab-sub", kind: "undersea-language" });
  }

  /* ---------- Sub Watch (optional tab): nuclear-submarine force, basing, sea-leg I&W,
     the undersea-surveillance environment and civil-maritime fusion.
     Honesty rails: public reporting only; never a position, track or patrol box —
     the validator refuses live-position vocabulary in this block. ---------- */
  var TREND_GLYPH = { up: "▲ up", flat: "▬ flat", down: "▼ down" };
  function swChip(base, value) { var v = String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, "-"); return el("span", base + " " + base + "-" + v, String(value || "").replace(/-/g, " ").toUpperCase()); }
  function renderSubWatch() {
    var sw = D.subWatch; var mount = byId("subMount"); if (!mount) return; clear(mount);
    if (!sw) { hideTab("tp-sub"); return; }
    if (has(sw.framingNote)) { var fr = el("div", "pt-frame sw-frame"); fr.appendChild(el("b", null, "Public OSINT · no positions")); fr.appendChild(tn(sw.framingNote)); mount.appendChild(fr); }
    if (has(sw.intro)) mount.appendChild(el("p", "posture-read", sw.intro));
    // sea-leg posture meter (posture enum, optional uncertainty range)
    var st = sw.status;
    if (st) {
      var lvl = String(st.level || "elevated").toLowerCase(); if (LEVEL_ORDER.indexOf(lvl) === -1) lvl = "elevated";
      var lo = -1, hi = -1;
      if (Array.isArray(st.range) && st.range.length === 2) { lo = LEVEL_ORDER.indexOf(st.range[0]); hi = LEVEL_ORDER.indexOf(st.range[1]); if (lo > hi) { var t0 = lo; lo = hi; hi = t0; } }
      var meter = el("div", "threat-meter sw-meter"); var head = el("div", "tm-head");
      head.appendChild(el("div", "tm-level sw-level-" + lvl, "SEA-LEG POSTURE: " + lvl.toUpperCase()));
      head.appendChild(el("div", "tm-updated", (sw.updated ? "Assessed " + sw.updated : "") + (lo >= 0 ? " · range " + st.range[0] + "–" + st.range[1] : ""))); meter.appendChild(head);
      var steps = el("div", "tm-steps");
      LEVEL_ORDER.forEach(function (k, i) { steps.appendChild(el("div", "tm-step sw-" + k + (k === lvl ? " on" : "") + (lo >= 0 && i >= lo && i <= hi && k !== lvl ? " in-range" : ""), k)); });
      meter.appendChild(steps);
      if (has(st.headline)) meter.appendChild(el("div", "tm-headline", st.headline));
      if (has(st.body)) meter.appendChild(el("div", "tm-body", st.body));
      if (has(st.mover)) { var mv = el("div", "tm-body sw-mover"); mv.appendChild(el("b", null, "What would move it: ")); mv.appendChild(tn(st.mover)); meter.appendChild(mv); }
      mount.appendChild(meter);
    }
    // order of battle — one card per class, two estimates where sources diverge
    var fleet = arr(sw.fleet);
    if (fleet.length) {
      mount.appendChild(el("div", "mini-h", "Nuclear-powered order of battle — a second estimate beside every count where sources diverge"));
      var grid = el("div", "fleet-grid sw-fleet");
      fleet.forEach(function (b) {
        var status = String(b.status || "unknown").toLowerCase().replace(/[^a-z0-9]+/g, "-");
        var card = el("div", "fleet-card sw-card sws-" + status);
        var top = el("div", "fleet-card-top"); var l = el("div"); var tt = el("div", "fc-type"); tt.appendChild(tn(b.cls || "")); if (has(b.role)) tt.appendChild(el("span", "sw-role", b.role)); l.appendChild(tt); if (has(b.nick)) l.appendChild(el("div", "fc-nick", b.nick)); top.appendChild(l);
        top.appendChild(el("span", "fc-status sw-status sws-" + status, String(b.status || "unknown").replace(/-/g, " ").toUpperCase())); card.appendChild(top);
        var hull = el("div", "sw-hulls"); hull.appendChild(el("span", "sw-hulls-n", b.hulls || "—")); if (has(b.alt)) hull.appendChild(el("span", "alt", "vs " + b.alt)); card.appendChild(hull);
        var meta = el("div", "fc-meta");
        [["Weapons", b.weapons], ["Base", b.base], ["Trend", TREND_GLYPH[b.trend] || b.trend], ["Conf", has(b.conf) ? b.conf + (has(b.grade) ? " · " + b.grade : "") : b.grade]].forEach(function (r) {
          if (!has(r[1])) return; var row = el("div", "fc-meta-row"); row.appendChild(el("span", "k", r[0])); row.appendChild(el("span", "v", r[1])); meta.appendChild(row);
        });
        card.appendChild(meta);
        if (has(b.note)) card.appendChild(el("div", "fc-role sw-note", b.note));
        if (has(b.src)) card.appendChild(el("div", "src", b.src));
        grid.appendChild(card);
      });
      mount.appendChild(grid);
    }
    // basing & industrial base
    var bases = arr(sw.bases);
    if (bases.length) {
      mount.appendChild(el("div", "mini-h", "Basing & industrial base — what commercial imagery can and cannot see"));
      var bg = el("div", "lead-grid sw-bases"); var bh = el("div", "lead-row sw-base-row head");
      ["Site", "Role", "What OSINT sees", "Last change", "Conf"].forEach(function (h) { bh.appendChild(el("span", null, h)); }); bg.appendChild(bh);
      bases.forEach(function (b) {
        var row = el("div", "lead-row sw-base-row");
        row.appendChild(el("span", "lead-post", b.name || "")); row.appendChild(el("span", "lead-note", b.role || ""));
        var s = el("span", "lead-note"); s.appendChild(tn(b.sees || "")); if (has(b.src)) s.appendChild(el("div", "src", b.src)); row.appendChild(s);
        row.appendChild(el("span", "lead-since", b.lastChange || "")); row.appendChild(el("span", "iw-conf", b.conf || ""));
        bg.appendChild(row);
      });
      mount.appendChild(bg);
    }
    // pattern-of-life observables
    var obs = arr(sw.observables);
    if (obs.length) {
      mount.appendChild(el("div", "mini-h", "Pattern-of-life observables — what a sea-leg move would look like in open sources, and how visible each is"));
      var osc = el("div", "iw-scroll"); var ot = el("table", "iw-table");
      var oth = el("tr"); ["ID", "Tier", "Signature", "→ I&W", "Feed", "Cadence", "Read"].forEach(function (h) { oth.appendChild(el("th", null, h)); }); ot.appendChild(oth);
      obs.forEach(function (o) {
        var tr = el("tr", o.blind ? "iw-r-warning" : "");
        tr.appendChild(el("td", "iw-id", o.id)); var tier = o.tier || "t3"; var tc = el("td"); tc.appendChild(el("span", "mv-tierchip " + tier, tier.toUpperCase())); tr.appendChild(tc);
        tr.appendChild(el("td", "iw-dom", o.signature || "")); tr.appendChild(el("td", "iw-conf", o.iw || "")); tr.appendChild(el("td", "iw-thr", o.feed || "")); tr.appendChild(el("td", "iw-conf", o.cadence || ""));
        var rc = el("td", "iw-read"); if (o.blind) rc.appendChild(el("span", "mv-blind", "NEAR-BLIND · ")); rc.appendChild(tn(o.read || "")); if (has(o.src)) rc.appendChild(el("div", "src", o.src)); tr.appendChild(rc);
        ot.appendChild(tr);
      });
      osc.appendChild(ot); mount.appendChild(osc);
    }
    // sea-leg I&W (shared builder: warning meter + blind fraction)
    var iw = arr(sw.iw);
    if (iw.length) {
      mount.appendChild(el("div", "mini-h", "Sea-leg indications & warning — the meter reads only what can be seen; the blind fraction is the rest"));
      mount.appendChild(iwMeters(iw));
      var it = iwTable(iw); mount.appendChild(makeFilter(it.table, "Filter sea-leg indicators…")); mount.appendChild(it.scroll);
    }
    // undersea-surveillance environment — the classified-factor ledger
    var env = arr(sw.environment);
    if (env.length) {
      mount.appendChild(el("div", "mini-h", "Undersea-surveillance environment — the classified-factor ledger (what is public, what is not, and how it bends this board)"));
      var esc = el("div", "iw-scroll"); var et = el("table", "iw-table sw-env");
      var eth = el("tr"); ["ID", "Layer", "Side", "Known (public reporting)", "Unknown (classified / unobservable)", "Effect on this board", "Grade"].forEach(function (h) { eth.appendChild(el("th", null, h)); }); et.appendChild(eth);
      env.forEach(function (e) {
        var tr = el("tr");
        tr.appendChild(el("td", "iw-id", e.id)); tr.appendChild(el("td", "iw-dom", e.layer || ""));
        var sc = el("td"); sc.appendChild(swChip("sw-side", e.side || "both")); tr.appendChild(sc);
        var kc = el("td", "sw-known"); kc.appendChild(tn(e.known || "")); if (has(e.src)) kc.appendChild(el("div", "src", e.src)); tr.appendChild(kc);
        tr.appendChild(el("td", "sw-unknown", e.unknown || "")); tr.appendChild(el("td", "sw-effect", e.effect || "")); tr.appendChild(el("td", "iw-grade", e.grade || ""));
        et.appendChild(tr);
      });
      mount.appendChild(makeFilter(et, "Filter the ledger…")); esc.appendChild(et); mount.appendChild(esc);
    }
    // naval doctrine
    var doc = arr(sw.doctrine);
    if (doc.length) {
      mount.appendChild(el("div", "mini-h", "Doctrine — how the PLAN says it will use and protect the boats"));
      var dg = el("div", "sw-doc");
      doc.forEach(function (d) {
        var c = el("div", "sw-doc-card"); var tt = el("div", "sw-doc-tenet"); tt.appendChild(el("span", "actor-id", d.id || "")); tt.appendChild(tn(d.tenet || "")); c.appendChild(tt);
        if (has(d.basis)) c.appendChild(kvRow("sw-doc-row", "Basis", d.basis));
        if (has(d.implication)) c.appendChild(kvRow("sw-doc-row", "Implication", d.implication));
        if (has(d.src)) c.appendChild(el("div", "src", d.src)); dg.appendChild(c);
      });
      mount.appendChild(dg);
    }
    // civil–military maritime fusion
    var civ = arr(sw.civilMaritime);
    if (civ.length) {
      mount.appendChild(el("div", "mini-h", "Civil–military maritime fusion — commercial hulls, survey ships and militia in the undersea picture"));
      var csc = el("div", "iw-scroll"); var ct = el("table", "iw-table");
      var cth = el("tr"); ["ID", "Element", "Mechanism", "Observable", "Status", "Tone"].forEach(function (h) { cth.appendChild(el("th", null, h)); }); ct.appendChild(cth);
      civ.forEach(function (c) {
        var tr = el("tr", c.tone === "red" ? "iw-r-warning" : c.tone === "alert" ? "iw-r-elevated" : "");
        tr.appendChild(el("td", "iw-id", c.id)); tr.appendChild(el("td", "iw-dom", c.element || "")); tr.appendChild(el("td", "iw-thr", c.mechanism || "")); tr.appendChild(el("td", "iw-thr", c.observable || ""));
        var stc = el("td", "iw-read"); stc.appendChild(tn(c.status || "")); if (has(c.src)) stc.appendChild(el("div", "src", c.src)); tr.appendChild(stc);
        var tc = el("td"); tc.appendChild(el("span", "mv-cat-tone " + (c.tone || "watch"), c.tone || "watch")); tr.appendChild(tc);
        ct.appendChild(tr);
      });
      csc.appendChild(ct); mount.appendChild(csc);
    }
    // sea-leg timeline
    var tl = arr(sw.timeline);
    if (tl.length) {
      mount.appendChild(el("div", "mini-h", "Sea-leg timeline — public reporting, newest first"));
      var tw = el("div", "tl");
      tl.forEach(function (e) { var itx = el("div", "tl-item" + (e.hot ? " hot" : "")); itx.appendChild(el("div", "tl-date", e.date || "")); itx.appendChild(el("h4", null, e.title || "")); itx.appendChild(el("p", null, e.body || "")); if (has(e.src)) itx.appendChild(el("div", "tl-src", e.src)); tw.appendChild(itx); });
      mount.appendChild(tw);
    }
    if (has(sw.sources)) mount.appendChild(el("div", "src sw-sources", "Sources for this tab: " + sw.sources));
    if (has(sw.note)) mount.appendChild(el("div", "note", sw.note));
  }

  /* ---------- shared builders for the leg watches (Air Watch · Launcher Watch) ----------
     Each leg tab is an order-of-battle / basing / pattern-of-life / I&W / doctrine / timeline
     product with the same honesty rails as Sub Watch: public reporting only, never a position,
     track or alert state; near-invisible rows stay `unseen`. */
  function legStatusMeter(st, updated, label, cls) {
    var lvl = String(st.level || "elevated").toLowerCase(); if (LEVEL_ORDER.indexOf(lvl) === -1) lvl = "elevated";
    var lo = -1, hi = -1;
    if (Array.isArray(st.range) && st.range.length === 2) { lo = LEVEL_ORDER.indexOf(st.range[0]); hi = LEVEL_ORDER.indexOf(st.range[1]); if (lo > hi) { var t0 = lo; lo = hi; hi = t0; } }
    var meter = el("div", "threat-meter sw-meter " + (cls || "")); var head = el("div", "tm-head");
    head.appendChild(el("div", "tm-level sw-level-" + lvl, label + ": " + lvl.toUpperCase()));
    head.appendChild(el("div", "tm-updated", (updated ? "Assessed " + updated : "") + (lo >= 0 ? " · range " + st.range[0] + "–" + st.range[1] : ""))); meter.appendChild(head);
    var steps = el("div", "tm-steps");
    LEVEL_ORDER.forEach(function (k, i) { steps.appendChild(el("div", "tm-step sw-" + k + (k === lvl ? " on" : "") + (lo >= 0 && i >= lo && i <= hi && k !== lvl ? " in-range" : ""), k)); });
    meter.appendChild(steps);
    if (has(st.headline)) meter.appendChild(el("div", "tm-headline", st.headline));
    if (has(st.body)) meter.appendChild(el("div", "tm-body", st.body));
    if (has(st.mover)) { var mv = el("div", "tm-body sw-mover"); mv.appendChild(el("b", null, "What would move it: ")); mv.appendChild(tn(st.mover)); meter.appendChild(mv); }
    return meter;
  }
  function legFrame(mount, note, tag) { if (!has(note)) return; var fr = el("div", "pt-frame sw-frame"); fr.appendChild(el("b", null, tag || "Public OSINT · no positions")); fr.appendChild(tn(note)); mount.appendChild(fr); }
  function legObservables(mount, obs, title) {
    if (!obs.length) return;
    mount.appendChild(el("div", "mini-h", title));
    var osc = el("div", "iw-scroll"); var ot = el("table", "iw-table");
    var oth = el("tr"); ["ID", "Tier", "Signature", "→ I&W", "Feed", "Cadence", "Read"].forEach(function (h) { oth.appendChild(el("th", null, h)); }); ot.appendChild(oth);
    obs.forEach(function (o) {
      var tr = el("tr", o.blind ? "iw-r-warning" : "");
      tr.appendChild(el("td", "iw-id", o.id)); var tier = o.tier || "t3"; var tc = el("td"); tc.appendChild(el("span", "mv-tierchip " + tier, tier.toUpperCase())); tr.appendChild(tc);
      tr.appendChild(el("td", "iw-dom", o.signature || "")); tr.appendChild(el("td", "iw-conf", o.iw || "")); tr.appendChild(el("td", "iw-thr", o.feed || "")); tr.appendChild(el("td", "iw-conf", o.cadence || ""));
      var rc = el("td", "iw-read"); if (o.blind) rc.appendChild(el("span", "mv-blind", "NEAR-BLIND · ")); rc.appendChild(tn(o.read || "")); if (has(o.src)) rc.appendChild(el("div", "src", o.src)); tr.appendChild(rc);
      ot.appendChild(tr);
    });
    osc.appendChild(ot); mount.appendChild(osc);
  }
  function legIw(mount, iw, title, filterLabel) { if (!iw.length) return; mount.appendChild(el("div", "mini-h", title)); mount.appendChild(iwMeters(iw)); var it = iwTable(iw); mount.appendChild(makeFilter(it.table, filterLabel)); mount.appendChild(it.scroll); }
  function legDoctrine(mount, doc, title) {
    if (!doc.length) return; mount.appendChild(el("div", "mini-h", title)); var dg = el("div", "sw-doc");
    doc.forEach(function (d) { var c = el("div", "sw-doc-card"); var tt = el("div", "sw-doc-tenet"); tt.appendChild(el("span", "actor-id", d.id || "")); tt.appendChild(tn(d.tenet || "")); c.appendChild(tt); if (has(d.basis)) c.appendChild(kvRow("sw-doc-row", "Basis", d.basis)); if (has(d.implication)) c.appendChild(kvRow("sw-doc-row", "Implication", d.implication)); if (has(d.src)) c.appendChild(el("div", "src", d.src)); dg.appendChild(c); });
    mount.appendChild(dg);
  }
  function legTimeline(mount, tl, title) {
    if (!tl.length) return; mount.appendChild(el("div", "mini-h", title)); var tw = el("div", "tl");
    tl.forEach(function (e) { var itx = el("div", "tl-item" + (e.hot ? " hot" : "")); itx.appendChild(el("div", "tl-date", e.date || "")); itx.appendChild(el("h4", null, e.title || "")); itx.appendChild(el("p", null, e.body || "")); if (has(e.src)) itx.appendChild(el("div", "tl-src", e.src)); tw.appendChild(itx); });
    mount.appendChild(tw);
  }
  function legBases(mount, bases, title, headers, fields) {
    if (!bases.length) return; mount.appendChild(el("div", "mini-h", title));
    var bg = el("div", "lead-grid sw-bases"); var bh = el("div", "lead-row sw-base-row head");
    headers.forEach(function (h) { bh.appendChild(el("span", null, h)); }); bg.appendChild(bh);
    bases.forEach(function (b) {
      var row = el("div", "lead-row sw-base-row");
      fields.forEach(function (f, i) { var v = b[f]; var sp = el("span", i === 0 ? "lead-post" : (f === "conf" ? "iw-conf" : f === "lastChange" ? "lead-since" : "lead-note")); sp.appendChild(tn(v == null ? "" : String(v))); if (i === 2 && has(b.src)) sp.appendChild(el("div", "src", b.src)); row.appendChild(sp); });
      bg.appendChild(row);
    });
    mount.appendChild(bg);
  }
  function legCard(rows, b, statusKey) {
    var status = String(b[statusKey] || "unknown").toLowerCase().replace(/[^a-z0-9]+/g, "-");
    var card = el("div", "fleet-card sw-card sws-" + status);
    var top = el("div", "fleet-card-top"); var l = el("div"); var tt = el("div", "fc-type"); tt.appendChild(tn(b.type || b.system || b.cls || "")); if (has(b.role)) tt.appendChild(el("span", "sw-role", b.role)); l.appendChild(tt); if (has(b.nick)) l.appendChild(el("div", "fc-nick", b.nick)); top.appendChild(l);
    top.appendChild(el("span", "fc-status sw-status sws-" + status, String(b[statusKey] || "unknown").replace(/-/g, " ").toUpperCase())); card.appendChild(top);
    var hull = el("div", "sw-hulls"); hull.appendChild(el("span", "sw-hulls-n", b.count || b.airframes || b.launchers || b.hulls || "—")); if (has(b.alt)) hull.appendChild(el("span", "alt", "vs " + b.alt)); card.appendChild(hull);
    var meta = el("div", "fc-meta");
    rows.forEach(function (r) { var v = typeof r[1] === "function" ? r[1](b) : b[r[1]]; if (!has(v)) return; var row = el("div", "fc-meta-row"); row.appendChild(el("span", "k", r[0])); row.appendChild(el("span", "v", v)); meta.appendChild(row); });
    card.appendChild(meta);
    if (has(b.note)) card.appendChild(el("div", "fc-role sw-note", b.note));
    if (has(b.src)) card.appendChild(el("div", "src", b.src));
    return card;
  }

  /* ---------- Air Watch (optional tab): nuclear strike & support aircraft ---------- */
  function renderAirWatch() {
    var aw = D.airWatch; var mount = byId("airMount"); if (!mount) return; clear(mount);
    if (!aw) { hideTab("tp-air"); return; }
    legFrame(mount, aw.framingNote, "Public OSINT · no targeting");
    if (has(aw.intro)) mount.appendChild(el("p", "posture-read", aw.intro));
    if (aw.status) mount.appendChild(legStatusMeter(aw.status, aw.updated, "AIR-LEG POSTURE", "aw-meter"));
    var fleet = arr(aw.fleet);
    if (fleet.length) {
      mount.appendChild(el("div", "mini-h", "Strike & support order of battle — a second estimate beside every count where sources diverge"));
      var grid = el("div", "fleet-grid sw-fleet aw-fleet");
      fleet.forEach(function (b) {
        grid.appendChild(legCard([["Weapons", "weapons"], ["Bases", "bases"], ["Units", "units"], ["ADS-B", function (x) { return has(x.transponds) ? x.transponds + (arr(x.icao).length ? " · " + x.icao.join(", ") : "") : (arr(x.icao).length ? x.icao.join(", ") : ""); }], ["Trend", function (x) { return TREND_GLYPH[x.trend] || x.trend; }], ["Conf", function (x) { return has(x.conf) ? x.conf + (has(x.grade) ? " · " + x.grade : "") : x.grade; }]], b, "status"));
      });
      mount.appendChild(grid);
    }
    legBases(mount, arr(aw.bases), "Basing — main operating bases, forward and dispersal fields, tanker and C2 hubs, as commercial imagery and public notices see them", ["Base", "Role", "What OSINT sees", "Last change", "Conf"], ["name", "role", "sees", "lastChange", "conf"]);
    legObservables(mount, arr(aw.observables), "Pattern-of-life observables — what an air-leg move looks like in open sources, and how visible each is");
    legIw(mount, arr(aw.iw), "Air-leg indications & warning — the meter reads only what can be seen; the blind fraction is the rest", "Filter air-leg indicators…");
    legDoctrine(mount, arr(aw.doctrine), "Doctrine — how the air leg is meant to be used and preserved");
    legTimeline(mount, arr(aw.timeline), "Air-leg timeline — public reporting, newest first");
    if (has(aw.sources)) mount.appendChild(el("div", "src sw-sources", "Sources for this tab: " + aw.sources));
    if (has(aw.note)) mount.appendChild(el("div", "note", aw.note));
  }
  function renderAirScanner(cache) {
    var aw = D.airWatch; var block = byId("airScanBlock");
    if (!aw || !aw.scanner) { if (block) block.hidden = true; return; }
    if (block) block.hidden = false;
    scannerPanel({ sc: aw.scanner, mount: byId("airScannerMount"), cache: cache, dotId: "airTabDot", tabId: "tab-air", kind: "air-language" });
  }

  /* ---------- Launcher Watch (optional tab): road-mobile launchers (TELs) ---------- */
  function renderLauncherWatch() {
    var lw = D.launcherWatch; var mount = byId("launcherMount"); if (!mount) return; clear(mount);
    if (!lw) { hideTab("tp-launcher"); return; }
    legFrame(mount, lw.framingNote, "Public OSINT · no positions");
    if (has(lw.intro)) mount.appendChild(el("p", "posture-read", lw.intro));
    if (lw.status) mount.appendChild(legStatusMeter(lw.status, lw.updated, "MOBILE-LAUNCHER POSTURE", "lw-meter"));
    var fleet = arr(lw.fleet);
    if (fleet.length) {
      mount.appendChild(el("div", "mini-h", "Road-mobile launcher order of battle — a second estimate beside every count where sources diverge"));
      var grid = el("div", "fleet-grid sw-fleet lw-fleet");
      fleet.forEach(function (b) {
        grid.appendChild(legCard([["Chassis", "chassis"], ["Warheads", "warheads"], ["Range", "range"], ["Units", "units"], ["Trend", function (x) { return TREND_GLYPH[x.trend] || x.trend; }], ["Conf", function (x) { return has(x.conf) ? x.conf + (has(x.grade) ? " · " + x.grade : "") : x.grade; }]], b, "status"));
      });
      mount.appendChild(grid);
    }
    legBases(mount, arr(lw.garrisons), "Garrisons & positional areas — as open sources describe them (towns and regions, never field positions)", ["Garrison", "Formation · systems", "What OSINT sees", "Last change", "Conf"], ["name", "formation", "sees", "lastChange", "conf"]);
    var disp = lw.dispersal;
    if (disp && (has(disp.pattern) || arr(disp.inputs).length)) {
      mount.appendChild(el("div", "mini-h", "Dispersal doctrine — the structural inputs the land-leg map is built from"));
      var box = el("div", "lw-disp");
      if (has(disp.pattern)) box.appendChild(el("p", "posture-read", disp.pattern));
      arr(disp.inputs).forEach(function (r) { var row = el("div", "sw-doc-row lw-disp-row"); row.appendChild(el("b", null, r.k)); row.appendChild(tn(r.v)); if (has(r.src)) row.appendChild(el("span", "src", " · " + r.src)); box.appendChild(row); });
      if (has(disp.note)) box.appendChild(el("div", "note", disp.note));
      mount.appendChild(box);
    }
    legObservables(mount, arr(lw.observables), "Pattern-of-life observables — what a dispersal looks like in open sources, and how visible each is");
    legIw(mount, arr(lw.iw), "Land-leg (mobile) indications & warning — the meter reads only what can be seen; the blind fraction is the rest", "Filter launcher indicators…");
    legDoctrine(mount, arr(lw.doctrine), "Doctrine — survivability, alert states and how the mobile force is generated");
    legTimeline(mount, arr(lw.timeline), "Mobile-launcher timeline — public reporting, newest first");
    if (has(lw.sources)) mount.appendChild(el("div", "src sw-sources", "Sources for this tab: " + lw.sources));
    if (has(lw.note)) mount.appendChild(el("div", "note", lw.note));
  }
  function renderLauncherScanner(cache) {
    var lw = D.launcherWatch; var block = byId("launcherScanBlock");
    if (!lw || !lw.scanner) { if (block) block.hidden = true; return; }
    if (block) block.hidden = false;
    scannerPanel({ sc: lw.scanner, mount: byId("launcherScannerMount"), cache: cache, dotId: "launcherTabDot", tabId: "tab-launcher", kind: "launcher-language" });
  }

  /* ---------- Track Watch (shared banner/state builder also drives the Air Watch live board) ---------- */
  function trackState(live, tw, prefix) {
    tw = tw || D.trackWatch || {}; prefix = prefix || ""; var types = arr(tw.types); var total = types.length;
    var up = 0, present = 0, critUp = 0;
    types.forEach(function (ty) { var c = live && live[prefix + ty.key]; if (c && c.airborne) { up++; if (ty.crit) critUp++; } if (c && (c.airborne || c.ground)) present++; });
    var cfg = tw.alert || {};
    var redN = Math.min(total || 1, cfg.red || Math.max(3, Math.ceil(total * 0.6)));
    var alertN = Math.min(total || 1, cfg.alert || Math.max(2, Math.ceil(total * 0.34)));
    if (alertN >= redN) alertN = Math.max(1, redN - 1);
    var tone = (up >= redN || critUp >= 2) ? "red" : (up >= alertN || critUp >= 1) ? "alert" : present > 0 ? "watch" : "quiet";
    var label = tone === "red" ? "RED ALERT" : tone === "alert" ? "ALERT" : tone === "watch" ? "WATCH" : "QUIET";
    return { tone: tone, label: label, up: up, total: total, alertN: alertN, redN: redN };
  }
  // One live board, two blocks: Track Watch (the allied ISR mirror, D.trackWatch) and the Air Watch
  // live board (the SUBJECT's own transponding strike / support types, D.airWatch.live, keys namespaced
  // with AIR_PREFIX in the shared worker cache). Same ADS-B feed, same honesty rules.
  function renderLiveBoard(o) {
    var tw = o.block; var mount = byId(o.mountId); if (!tw || !mount) return; clear(mount);
    var prefix = o.prefix || ""; var live = o.live, track = o.track, sector = o.sector, pol = o.pol;
    if (has(tw.intro)) mount.appendChild(el("p", "posture-read", tw.intro));
    var st = trackState(live, tw, prefix);
    var banner = el("div", "alert-banner alert-" + st.tone);
    var abLeft = el("div", "ab-left"); abLeft.appendChild(el("div", "ab-label", st.label)); abLeft.appendChild(el("div", "ab-count", st.up + " / " + st.total + " watched types airborne · ALERT ≥" + st.alertN + " · RED ≥" + st.redN + " or 2 crit")); banner.appendChild(abLeft);
    var abMid = el("div", "ab-mid"); abMid.appendChild(el("div", "ab-when", PREVIEW ? "Illustrative — install for live" : "Live · public military ADS-B (adsb.fi open data)"));
    abMid.appendChild(el("div", "ab-body", tw.alertRule || "")); banner.appendChild(abMid);
    var chips = el("div", "ab-chips");
    arr(tw.types).forEach(function (ty) { var c = live && live[prefix + ty.key]; var on = c && c.airborne; var chip = el("div", "ab-chip" + (on ? " on" : "")); chip.appendChild(el("span", "abc-name", ty.type)); chip.appendChild(el("span", "abc-state", on ? "AIRBORNE" : (c && c.ground ? "ON GROUND" : "not seen"))); chips.appendChild(chip); });
    banner.appendChild(chips); mount.appendChild(banner);
    mount.appendChild(el("div", "alert-note", tw.note || ""));
    var grid = el("div", "fleet-grid");
    arr(tw.types).forEach(function (ty) {
      var c = live && live[prefix + ty.key];
      var status = c && c.airborne ? "airborne" : (c && c.ground ? "ground" : "none");
      var card = el("div", "fleet-card fc-" + status);
      var top = el("div", "fleet-card-top"); var l = el("div"); var tt = el("div", "fc-type"); tt.appendChild(tn(ty.type)); if (ty.crit) tt.appendChild(el("span", "crit-tag", "crit")); l.appendChild(tt); l.appendChild(el("div", "fc-nick", ty.nick || "")); top.appendChild(l);
      top.appendChild(el("span", "fc-status fcs-" + status, status === "airborne" ? "AIRBORNE" : status === "ground" ? "ON GROUND" : "not seen")); card.appendChild(top);
      card.appendChild(el("div", "fc-role", ty.role || ""));
      var meta = el("div", "fc-meta");
      var r1 = el("div", "fc-meta-row"); r1.appendChild(el("span", "k", "Tempo")); var v1 = el("span", "v"); v1.appendChild(el("span", "tempo-tag tempo-" + (ty.tempo || "frequent"), ty.tempo || "")); r1.appendChild(v1); meta.appendChild(r1);
      if (has(ty.bases)) { var r2 = el("div", "fc-meta-row"); r2.appendChild(el("span", "k", "Bases")); r2.appendChild(el("span", "v", ty.bases)); meta.appendChild(r2); }
      if (has(ty.note)) { var r3 = el("div", "fc-meta-row"); r3.appendChild(el("span", "k", "Note")); r3.appendChild(el("span", "v", ty.note)); meta.appendChild(r3); }
      card.appendChild(meta);
      // pattern-of-life: 7-day sightings vs expected tempo (extension only)
      var p = pol && pol[prefix + ty.key];
      if (!PREVIEW && p) {
        var exp = (TEMPO_RATE[ty.tempo] || 0.4) * 7; var ratio = exp ? (p.days7 || 0) / exp : 0;
        var pw = el("div", "fc-pol"); var lbl = el("div", "pol-lbl"); lbl.appendChild(el("span", null, "7-day pattern-of-life")); lbl.appendChild(el("span", null, (p.days7 || 0) + " active day" + ((p.days7 || 0) === 1 ? "" : "s") + " · expected ≈" + exp.toFixed(1) + (p.lastSeen ? " · last " + fmtAgo(p.lastSeen) + " ago" : ""))); pw.appendChild(lbl);
        var bar = el("div", "pol-bar"); var fill = el("div", "pol-fill" + (ratio >= 1.5 ? " high" : ratio <= 0.5 ? " low" : "")); fill.style.width = Math.min(100, ratio * 50) + "%"; bar.appendChild(fill); pw.appendChild(bar);
        card.appendChild(pw);
      }
      if (has(ty.src)) card.appendChild(el("div", "src", ty.src));
      grid.appendChild(card);
    });
    mount.appendChild(grid);
    if (tw.sector) {
      var s = tw.sector; var sec = el("div", "fleet-sector");
      var sh = el("div", "sector-head"); var shl = el("div"); shl.appendChild(el("span", "sector-eyebrow", "Live sector")); shl.appendChild(el("span", "sector-label", s.label || "")); sh.appendChild(shl);
      sh.appendChild(el("span", "sector-coord", s.lat + "°, " + s.lon + "° · " + s.dist + " nm")); sec.appendChild(sh);
      var stats = el("div", "sector-stats");
      var ok = sector && sector.ok; var total = ok ? sector.total : "—", mil = ok ? sector.mil : "—", hitsN = ok ? arr(sector.ac).filter(function (a) { return prefix ? String(a.cls || "").indexOf(prefix) === 0 : String(a.cls || "").indexOf(AIR_PREFIX) !== 0; }).length : "—";
      [["In view", total, false], ["Military-tagged", mil, false], ["Watched in sector", hitsN, ok && hitsN > 0]].forEach(function (x) { var t = el("div", "sector-tile" + (x[2] ? " hot" : "")); t.appendChild(el("div", "st-num", String(x[1]))); t.appendChild(el("div", "st-lbl", x[0])); stats.appendChild(t); });
      sec.appendChild(stats);
      if (has(s.why)) sec.appendChild(el("div", "sector-why", s.why));
      if (arr(tw.links).length) { var links = el("div", "sector-links"); tw.links.forEach(function (lk) { links.appendChild(extLink(lk.href, "sector-link", lk.label)); }); sec.appendChild(links); }
      mount.appendChild(sec);
    }
    var events = !PREVIEW && track ? arr(track.events).filter(function (ev) { var isAir = String(ev.cls || "").indexOf(AIR_PREFIX) === 0; return prefix ? isAir : !isAir; }) : [];
    if (events.length) {
      var act = el("div", "fleet-activity"); act.appendChild(el("div", "act-eyebrow", "Pattern-of-life log (appeared / went dark — coarse position, public feed)")); var doc = el("div", "act-events");
      events.slice(0, 14).forEach(function (ev) {
        var row = el("div", "act-ev");
        row.appendChild(el("span", "aev-time", fmtAgo(ev.ts)));
        row.appendChild(el("span", "aev-kind " + (ev.kind === "dark" ? "aek-dark" : "aek-appeared"), ev.kind === "dark" ? "WENT DARK" : "APPEARED"));
        row.appendChild(el("span", "aev-type", String(ev.cls || "").replace(AIR_PREFIX, "")));
        row.appendChild(el("span", "aev-id", ev.r || ev.flight || ev.hex || ""));
        row.appendChild(el("span", "aev-where", (typeof ev.lat === "number" ? ev.lat.toFixed(1) + ", " + ev.lon.toFixed(1) : "—")));
        doc.appendChild(row);
      });
      act.appendChild(doc); mount.appendChild(act);
    }
    var dot = byId(o.dotId); if (dot) { dot.hidden = st.tone === "quiet" || st.tone === "watch"; var tabEl = byId(o.tabId); if (tabEl) tabEl.classList.toggle("tab-red", st.tone === "red"); }
    return st;
  }
  function renderTrack(live, track, sector, pol) { renderLiveBoard({ block: D.trackWatch, mountId: "trackMount", dotId: "trackTabDot", tabId: "tab-track", prefix: "", live: live, track: track, sector: sector, pol: pol }); }
  function renderAirLive(live, track, sector, pol) {
    var aw = D.airWatch; var block = byId("airLiveBlock");
    if (!aw || !aw.live) { if (block) block.hidden = true; return; }
    block.hidden = false;
    renderLiveBoard({ block: aw.live, mountId: "airLiveMount", dotId: "airTabDot", tabId: "tab-air", prefix: AIR_PREFIX, live: live, track: track, sector: sector, pol: pol });
  }

  /* ---------- protective-intelligence layer ---------- */
  function framing(mount) {
    var p = D.protective; if (!p || !has(p.framingNote)) return;
    var f = el("div", "pt-frame"); f.appendChild(el("b", null, "Defensive framing")); f.appendChild(tn(p.framingNote)); mount.appendChild(f);
  }
  function renderTerror() {
    var t = D.protective && D.protective.threat; var mount = byId("terrorMount"); clear(mount);
    if (!t) { hideTab("tp-terror"); return; }
    framing(mount);
    var lvl = String(t.level || "moderate").toLowerCase();
    var meter = el("div", "threat-meter"); var head = el("div", "tm-head");
    head.appendChild(el("div", "tm-level", "THREAT LEVEL: " + lvl.toUpperCase())); head.appendChild(el("div", "tm-updated", t.updated ? "Assessed " + t.updated : "")); meter.appendChild(head);
    var steps = el("div", "tm-steps"); THREAT_ORDER.forEach(function (k) { steps.appendChild(el("div", "tm-step tm-" + k + (k === lvl ? " on" : ""), k)); }); meter.appendChild(steps);
    if (has(t.headline)) meter.appendChild(el("div", "tm-headline", t.headline));
    if (has(t.body)) meter.appendChild(el("div", "tm-body", t.body));
    mount.appendChild(meter);
    // actor board: intent × capability grid + cards
    var actors = arr(t.actors);
    if (actors.length) {
      mount.appendChild(el("div", "mini-h", "Actor board — intent × capability (1–5), reach, targets by class"));
      var wrap = el("div", "actor-wrap");
      var grid = el("div", "actor-grid"); grid.setAttribute("role", "img"); grid.setAttribute("aria-label", "Intent versus capability grid of threat actors");
      var cells = {}; actors.forEach(function (a) { var key = (a.intent || 1) + ":" + (a.capability || 1); (cells[key] = cells[key] || []).push(a.id || a.name); });
      for (var row = 5; row >= 1; row--) {
        if (row === 5) { /* first column axis label spans rows via first cell per row */ }
        var ax = el("div", "ag-axis y", row === 3 ? "intent →" : ""); grid.appendChild(ax);
        for (var col = 1; col <= 5; col++) {
          var cell = el("div", "ag-cell" + ((row + col) >= 8 ? " hi" : (row + col) >= 6 ? " mid" : ""));
          var k = row + ":" + col; if (cells[k]) { var d = el("span", "ag-dot" + (cells[k].length > 1 ? " multi" : ""), cells[k].join(", ")); d.title = "intent " + row + " · capability " + col; cell.appendChild(d); }
          grid.appendChild(cell);
        }
      }
      grid.appendChild(el("div", "ag-axis", "")); for (var c2 = 1; c2 <= 5; c2++) grid.appendChild(el("div", "ag-axis", c2 === 3 ? "capability →" : String(c2)));
      wrap.appendChild(grid);
      var list = el("div", "actor-list");
      actors.forEach(function (a) {
        var card = el("div", "actor-card"); var top = el("div", "actor-top"); var nm = el("span", "actor-name"); nm.appendChild(el("span", "actor-id", a.id || "")); nm.appendChild(tn(a.name || "")); top.appendChild(nm); top.appendChild(el("span", "actor-type", a.type || "")); card.appendChild(top);
        var sc = el("div", "actor-scores"); sc.appendChild(el("span", "score-pill", "intent " + dots(a.intent, 5))); sc.appendChild(el("span", "score-pill", "capability " + dots(a.capability, 5))); if (has(a.reach)) sc.appendChild(el("span", "score-pill reach-" + String(a.reach).toLowerCase(), a.reach)); if (has(a.trend)) sc.appendChild(el("span", "score-pill", "trend " + ({ up: "▲", flat: "▬", down: "▼" }[a.trend] || a.trend))); if (has(a.grade)) sc.appendChild(el("span", "score-pill", a.grade)); card.appendChild(sc);
        if (has(a.targets)) card.appendChild(kvRow("actor-targets", "Target classes", a.targets));
        if (has(a.note)) card.appendChild(el("div", "actor-note", a.note)); if (has(a.src)) card.appendChild(el("div", "src", a.src));
        list.appendChild(card);
      });
      wrap.appendChild(list); mount.appendChild(wrap);
    }
    var iw = arr(t.iw);
    if (iw.length) { mount.appendChild(el("div", "mini-h", "Attack-warning indicators")); mount.appendChild(iwMeters(iw)); var tb = iwTable(iw, { domainLabel: "Indicator" }); mount.appendChild(tb.scroll); }
    var inc = arr(t.incidents);
    if (inc.length) {
      mount.appendChild(el("div", "mini-h", "Incident timeline (public reporting)")); var tl = el("div", "tl");
      inc.forEach(function (e) { var it = el("div", "tl-item" + (e.hot ? " hot" : "")); it.appendChild(el("div", "tl-date", (e.date || "") + (e.place ? " · " + e.place : ""))); it.appendChild(el("h4", null, (e.kind || "") + (e.actor ? " — " + e.actor : ""))); it.appendChild(el("p", null, (e.casualties ? e.casualties + ". " : "") + (e.note || ""))); if (has(e.src)) it.appendChild(el("div", "tl-src", e.src)); tl.appendChild(it); });
      mount.appendChild(tl);
    }
    if (has(t.note)) mount.appendChild(el("div", "note", t.note));
  }
  function renderSoft() {
    var s = D.protective && D.protective.softTargets; var mount = byId("softMount"); clear(mount);
    if (!s) { hideTab("tp-soft"); return; }
    framing(mount);
    if (has(s.intro)) mount.appendChild(el("p", "posture-read", s.intro));
    var sc = el("div", "pt-scroll"); var t = el("table", "pt-table");
    var th = el("tr"); ["ID", "Target class", "Typical examples", "Precedent", "Risk", "Protective posture", "Protective measures", "Read"].forEach(function (h) { th.appendChild(el("th", null, h)); }); t.appendChild(th);
    arr(s.classes).forEach(function (c) {
      var tr = el("tr");
      tr.appendChild(el("td", "iw-id", c.id)); tr.appendChild(el("td", "pt-class", c.class)); tr.appendChild(el("td", "pt-ex", c.examples || ""));
      var pc = el("td"); pc.appendChild(el("span", "prec-dots", dots(c.precedent, 5))); pc.title = "Precedent " + (c.precedent || 0) + "/5"; tr.appendChild(pc);
      var rc = el("td"); rc.appendChild(chipFor("risk-chip risk", c.risk)); tr.appendChild(rc);
      var pp = el("td"); pp.appendChild(el("span", "posture-chip pp-" + String(c.posture || "baseline").toLowerCase(), c.posture || "baseline")); tr.appendChild(pp);
      var mc = el("td"); var ul = el("ul", "measures"); arr(c.measures).forEach(function (m) { ul.appendChild(el("li", null, m)); }); mc.appendChild(ul); tr.appendChild(mc);
      var nc = el("td", "pt-note"); nc.appendChild(tn(c.note || "")); if (has(c.src)) nc.appendChild(el("div", "src", c.src)); tr.appendChild(nc);
      t.appendChild(tr);
    });
    mount.appendChild(makeFilter(t, "Filter target classes…")); sc.appendChild(t); mount.appendChild(sc);
    if (has(s.note)) mount.appendChild(el("div", "note", s.note));
  }
  function renderInfra() {
    var f = D.protective && D.protective.infrastructure; var mount = byId("infraMount"); clear(mount);
    if (!f) { hideTab("tp-infra"); return; }
    framing(mount);
    if (has(f.intro)) mount.appendChild(el("p", "posture-read", f.intro));
    var sectors = arr(f.sectors).slice().sort(function (a, b) { return (b.spotlight ? 1 : 0) - (a.spotlight ? 1 : 0); });
    var grid = el("div", "infra-grid");
    sectors.forEach(function (s) {
      var card = el("div", "infra-card" + (s.spotlight ? " spotlight" : ""));
      var top = el("div", "infra-top"); var nm = el("div", "infra-name"); nm.appendChild(tn(s.sector)); if (s.spotlight) nm.appendChild(el("span", "infra-spot", "spotlight")); top.appendChild(nm);
      var chips = el("div", "infra-chips"); chips.appendChild(chipFor("exp-chip risk", s.exposure)); if (has(s.resilience)) chips.appendChild(el("span", "res-chip res-" + String(s.resilience).toLowerCase(), "resilience " + s.resilience)); top.appendChild(chips); card.appendChild(top);
      if (arr(s.vectors).length) card.appendChild(kvRow("infra-vectors", "Threat vectors", s.vectors.join(" · ")));
      if (has(s.recent)) card.appendChild(kvRow("infra-recent", "Recent", s.recent));
      if (arr(s.measures).length) { var ul = el("ul", "measures"); s.measures.forEach(function (m) { ul.appendChild(el("li", null, m)); }); card.appendChild(ul); }
      if (has(s.src)) card.appendChild(el("div", "src", s.src));
      grid.appendChild(card);
    });
    mount.appendChild(grid);
    var dc = f.dataCenters;
    if (dc) {
      var panel = el("div", "dc-panel"); var head = el("div", "dc-head"); head.appendChild(el("div", "dc-title", "Data centers — threat vectors & protective measures")); panel.appendChild(head);
      if (has(dc.intro)) panel.appendChild(el("div", "dc-intro", dc.intro));
      var sc = el("div", "pt-scroll"); var t = el("table", "pt-table dc-table");
      var th = el("tr"); ["Vector", "Likelihood", "Impact", "Protective measure", "Basis"].forEach(function (h) { th.appendChild(el("th", null, h)); }); t.appendChild(th);
      arr(dc.vectors).forEach(function (v) {
        var tr = el("tr"); tr.appendChild(el("td", "pt-class", v.vector));
        var lc = el("td"); lc.appendChild(chipFor("lk-chip risk", v.likelihood)); tr.appendChild(lc);
        var ic = el("td"); ic.appendChild(chipFor("lk-chip risk", v.impact)); tr.appendChild(ic);
        tr.appendChild(el("td", "pt-note", v.measure || "")); tr.appendChild(el("td", "iw-src", v.src || "")); t.appendChild(tr);
      });
      sc.appendChild(t); panel.appendChild(sc);
      if (has(dc.note)) panel.appendChild(el("div", "note", dc.note));
      mount.appendChild(panel);
    }
    if (has(f.note)) mount.appendChild(el("div", "note", f.note));
  }
  function renderGeo() {
    var g = D.protective && D.protective.geography; var mount = byId("geoMount"); clear(mount);
    if (!g) { hideTab("tp-geo"); return; }
    framing(mount);
    if (has(g.intro)) mount.appendChild(el("p", "posture-read", g.intro));
    var actorName = {}; arr(D.protective.threat && D.protective.threat.actors).forEach(function (a) { actorName[a.id] = a.name; });
    var regions = arr(g.regions).slice().sort(function (a, b) { return THREAT_ORDER.indexOf(String(b.advisory).toLowerCase()) - THREAT_ORDER.indexOf(String(a.advisory).toLowerCase()); });
    var list = el("div", "geo-list");
    regions.forEach(function (r) {
      var adv = String(r.advisory || "moderate").toLowerCase();
      var card = el("div", "geo-card adv-" + adv);
      var top = el("div", "geo-top"); var nm = el("div", "geo-name"); nm.appendChild(tn(r.region)); nm.appendChild(el("span", "geo-scope", r.scope || "")); top.appendChild(nm);
      var chips = el("div", "infra-chips"); chips.appendChild(chipFor("adv-chip risk", adv)); if (has(r.trend)) chips.appendChild(el("span", "score-pill", "trend " + ({ up: "▲", flat: "▬", down: "▼" }[r.trend] || r.trend))); top.appendChild(chips); card.appendChild(top);
      if (arr(r.drivers).length) card.appendChild(kvRow("geo-drivers", "Drivers", r.drivers.join(" · ")));
      if (arr(r.actors).length) card.appendChild(kvRow("geo-actors", "Actors", r.actors.map(function (id) { return actorName[id] ? actorName[id] + " (" + id + ")" : id; }).join(", ")));
      if (has(r.note)) card.appendChild(el("div", "geo-note", r.note)); if (has(r.src)) card.appendChild(el("div", "src", r.src));
      list.appendChild(card);
    });
    mount.appendChild(list);
    if (has(g.note)) mount.appendChild(el("div", "note", g.note));
  }

  /* ---------- state media / social ---------- */
  function renderMedia() {
    var sm = D.stateMedia; var mount = byId("mediaMount"); clear(mount);
    if (!sm) { hideTab("tp-media"); return; }
    if (has(sm.intro)) mount.appendChild(el("p", "posture-read", sm.intro));
    if (arr(sm.framing).length) { var fr = el("div", "rm-framing"); sm.framing.forEach(function (f) { var c = el("div", "rm-frame"); c.appendChild(el("span", "k", f.k)); c.appendChild(el("span", "v", f.v)); fr.appendChild(c); }); mount.appendChild(fr); }
    if (arr(sm.outlets).length) {
      var grid = el("div", "rm-outlets");
      sm.outlets.forEach(function (o) {
        var c = el("div", "rm-outlet"); var top = el("div", "rm-outlet-top"); top.appendChild(el("div", "rm-outlet-name", o.name)); if (has(o.grade)) top.appendChild(el("span", "rm-grade", o.grade)); c.appendChild(top);
        if (has(o.native)) c.appendChild(el("div", "rm-outlet-native", o.native)); if (has(o.kind)) c.appendChild(el("div", "rm-kind", o.kind));
        if (has(o.control)) { var ct = el("div", "rm-control"); ct.appendChild(tn("Control: ")); ct.appendChild(el("b", null, o.control)); c.appendChild(ct); }
        if (has(o.beat)) c.appendChild(el("div", "rm-beat", o.beat)); grid.appendChild(c);
      });
      mount.appendChild(grid);
    }
  }
  function renderSocial() {
    var so = D.social; var mount = byId("socialMount"); clear(mount);
    if (!so) { hideTab("tp-social"); return; }
    if (has(so.intro)) mount.appendChild(el("p", "posture-read", so.intro));
    if (has(so.ethics)) { var e = el("div", "rs-ethics"); e.appendChild(el("b", null, "Ethics rail — ")); e.appendChild(tn(so.ethics)); mount.appendChild(e); }
    if (arr(so.platforms).length) {
      var grid = el("div", "rs-platforms");
      so.platforms.forEach(function (p) {
        var c = el("div", "rs-platform " + (p.hot ? "hot" : "watch")); var top = el("div", "rs-p-top"); top.appendChild(el("span", "rs-p-name", p.name)); if (has(p.native) && p.native !== "-") top.appendChild(el("span", "rs-p-native", p.native)); c.appendChild(top);
        if (has(p.control)) { var r = el("div", "rs-p-row"); r.appendChild(el("span", "k", "Control")); r.appendChild(tn(p.control)); c.appendChild(r); }
        if (has(p.caught)) { var r2 = el("div", "rs-p-row"); r2.appendChild(el("span", "k", "Has caught")); r2.appendChild(tn(p.caught)); c.appendChild(r2); }
        if (has(p.access)) c.appendChild(el("div", "rs-p-value", p.access)); grid.appendChild(c);
      });
      mount.appendChild(grid);
    }
    if (arr(so.method).length) {
      mount.appendChild(el("div", "mini-h", "Method — what public monitoring has caught")); var m = el("div", "rs-method");
      so.method.forEach(function (cs) { var row = el("div", "rs-case" + (cs.limit ? " limit" : "")); row.appendChild(el("div", "rs-case-when", cs.when)); var w = el("div", "rs-case-what"); w.appendChild(tn(cs.what)); if (has(cs.src)) w.appendChild(el("span", "rs-case-src", "Source: " + cs.src)); row.appendChild(w); m.appendChild(row); });
      mount.appendChild(m);
    }
  }

  /* ---------- collection: lanes, synthesis, directory, chain ---------- */
  function parseTelegram(html) {
    var out = [];
    try {
      var doc = new DOMParser().parseFromString(html, "text/html"); // detached document: scripts never execute
      var nodes = doc.querySelectorAll(".tgme_widget_message");
      for (var i = nodes.length - 1; i >= 0 && out.length < 12; i--) {
        var n = nodes[i]; var textEl = n.querySelector(".tgme_widget_message_text"); var timeEl = n.querySelector("time");
        var raw = textEl ? textEl.textContent : ""; var clean = S ? S.text(raw, 600) : String(raw).slice(0, 600);
        if (!clean) continue;
        var iso = timeEl ? (timeEl.getAttribute("datetime") || "") : "";
        out.push({ text: clean, date: timeEl ? S.text(iso || timeEl.textContent, 40) : "", ts: iso ? Date.parse(iso) : NaN });
      }
    } catch (e) { /* never trust remote HTML */ }
    return out;
  }
  function renderLanes(cache, health) {
    var mount = byId("lanesMount"); clear(mount);
    var warn = el("div", "tg-warn"); warn.appendChild(el("b", null, "Unverified · ")); warn.appendChild(tn("Feed content is open-source chatter — state channels, milbloggers and aggregators routinely publish false or exaggerated claims, sometimes as deliberate information operations. Treat every post as a lead to corroborate, never as fact. Real-time unit locations and warhead custody are not observable and never appear here.")); mount.appendChild(warn);
    var channels = arr(D.osint && D.osint.channels);
    var lanes = el("div", "lanes");
    if (PREVIEW || !cache) {
      var empty = el("div", "lane-empty");
      var on = channels.filter(function (c) { return c.enabled !== false; });
      empty.textContent = "Live channel lanes run only in the installed extension (they use the extension's declared t.me host permission to read public t.me/s/<handle> previews). "
        + (on.length ? "Lanes enabled by default in this build: " + on.map(function (c) { return "@" + c.handle + (c.verified ? " (verified " + (c.verifiedOn || "") + ")" : " (unverified)"); }).join(", ") + ". " : "No default lanes are enabled for this country — add confirmed public handles in Settings. ")
        + "Enable and verify handles before trusting anything they carry.";
      lanes.appendChild(empty);
    } else {
      var handles = Object.keys(cache);
      if (!handles.length) { var e2 = el("div", "lane-empty"); e2.textContent = "No lanes cached yet — hit Refresh, or enable public handles in Settings."; lanes.appendChild(e2); }
      handles.forEach(function (h) { lanes.appendChild(renderLane(h, cache[h], health && health[h])); });
    }
    mount.appendChild(lanes);
    if (D.osint && has(D.osint.channelNote)) mount.appendChild(el("div", "note", D.osint.channelNote));
  }
  function renderLane(handle, res, hl) {
    var meta = laneMeta(handle); var lane = (meta && meta.lane) || "custom";
    var box = el("div", "lane lane-" + lane);
    var top = el("div", "lane-top"); top.appendChild(el("span", "h", (meta && meta.label) || "@" + handle)); top.appendChild(el("span", "src-tag " + lane, lane + (meta && meta.verified ? "" : " · unverified"))); box.appendChild(top);
    var body = el("div", "lane-body");
    if (!res || !res.ok) { var em = el("div", "lane-empty"); em.textContent = res && res.error ? "Feed error: " + S.text(res.error, 120) + (hl && hl.fails ? " (" + hl.fails + " consecutive)" : "") : "No data."; body.appendChild(em); }
    else {
      var posts = parseTelegram(res.html);
      var newest = posts.reduce(function (m, p) { return isNaN(p.ts) ? m : Math.max(m, p.ts); }, 0);
      var metaRow = el("div", "lane-meta"); metaRow.appendChild(el("span", null, posts.length + " posts parsed")); metaRow.appendChild(el("span", null, "fetched " + fmtAgo(res.ts) + " ago"));
      if (newest) { var age = Date.now() - newest; metaRow.appendChild(el("span", age > 3 * 864e5 ? "stale" : "", "newest post " + fmtAgo(newest) + " ago" + (age > 3 * 864e5 ? " · STALE" : ""))); }
      box.appendChild(metaRow);
      if (!posts.length) { var em2 = el("div", "lane-empty"); em2.textContent = "No public posts parsed."; body.appendChild(em2); }
      posts.slice(0, 8).forEach(function (p) { var post = el("div", "post"); if (p.date) post.appendChild(el("div", "pd", p.date)); post.appendChild(el("div", "pt", p.text)); body.appendChild(post); });
    }
    box.appendChild(body); return box;
  }
  // Optional synthesis with the user's OWN key (extension only). Input: sanitized public channel text. Output: text only.
  function renderSynthesis(cache) {
    var mount = byId("synthMount"); clear(mount);
    var panel = el("div", "synth-panel");
    panel.appendChild(el("div", "synth-note", "Optional. Sends the sanitized text of the cached PUBLIC lanes (plus scanner hits) to the Anthropic Messages API with your own key, and asks for an I&W-style read: leads, what corroborates them, what is NOT seen. Every line it returns is still unverified OSINT — a summary of chatter, never a fact. The key stays in this browser's extension storage and is sent only to api.anthropic.com. Nothing runs unless you click."));
    var actions = el("div", "synth-actions");
    var btn = el("button", "btn small", "Synthesize cached lanes"); btn.type = "button"; var status = el("span", "synth-status", PREVIEW ? "Preview — install the extension and add your key in Settings." : "Ready");
    actions.appendChild(btn); actions.appendChild(status); panel.appendChild(actions);
    var out = el("div", "synth-out"); out.hidden = true; panel.appendChild(out);
    btn.disabled = PREVIEW;
    btn.addEventListener("click", function () {
      if (PREVIEW) return;
      chrome.storage.local.get(["apiKey", "model"], function (cfg) {
        var key = S.apiKey(cfg && cfg.apiKey); var model = S.modelId(cfg && cfg.model) || DEFAULT_MODEL;
        if (!key) { status.textContent = "No API key set — add your own key in Settings."; return; }
        var corpus = buildCorpus(cache); if (!corpus.text) { status.textContent = "No cached lane text to synthesize — Refresh first."; return; }
        status.textContent = "Requesting synthesis (" + model + ")…"; btn.disabled = true;
        var system = "You are an open-source intelligence watch officer supporting a strategic-warning product on " + ((D.meta && D.meta.country) || "the subject country") + "'s military posture. INPUT: unverified public Telegram channel posts (aggregators, milbloggers, state-linked and independent lanes) and a list of movement-vocabulary hits. TASK: write a short I&W read in plain text: (1) up to six LEADS worth corroborating, each with the lane, the claim, why it matters to posture or movement, and a corroboration status (single-lane / multi-lane / contradicted); (2) what is NOT seen that would matter; (3) a one-line bottom line. RULES: label everything UNVERIFIED; never state or infer real-time unit, launcher or warhead locations; never produce targeting or operational detail; never present chatter as fact; note information-operations risk where a claim serves a lane's known bias. Max 350 words. Plain text only.";
        var body = { model: model, max_tokens: 900, system: system, messages: [{ role: "user", content: corpus.text }] };
        fetch("https://api.anthropic.com/v1/messages", { method: "POST", credentials: "omit", referrerPolicy: "no-referrer", headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" }, body: JSON.stringify(body) })
          .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, status: r.status, j: j }; }); })
          .then(function (res) {
            btn.disabled = false;
            if (!res.ok) { status.textContent = "API error " + res.status + (res.j && res.j.error && res.j.error.message ? ": " + S.text(res.j.error.message, 160) : ""); return; }
            var parts = (res.j && Array.isArray(res.j.content)) ? res.j.content.filter(function (c) { return c && c.type === "text"; }).map(function (c) { return c.text; }) : [];
            var text = S.text(parts.join("\n"), 6000);
            clear(out); out.appendChild(el("span", "synth-tag", "Unverified synthesis")); out.appendChild(tn(text || "(empty response)")); out.hidden = false;
            status.textContent = "Synthesized " + corpus.posts + " posts from " + corpus.lanes + " lanes · " + new Date().toISOString().slice(11, 16) + "Z";
          })
          .catch(function (err) { btn.disabled = false; status.textContent = "Request failed: " + S.text(err && err.message, 120); });
      });
    });
    mount.appendChild(panel);
  }
  function buildCorpus(cache) {
    var lines = [], posts = 0, lanes = 0;
    Object.keys(cache || {}).forEach(function (h) {
      var res = cache[h]; if (!res || !res.ok || !res.html) return; var meta = laneMeta(h); lanes++;
      lines.push("### @" + h + " [" + ((meta && meta.lane) || "custom") + (meta && meta.verified ? "" : ", unverified") + "]");
      parseTelegram(res.html).slice(0, 10).forEach(function (p) { posts++; lines.push("- (" + (p.date || "?") + ") " + S.text(p.text, 400)); });
    });
    var sc = D.movementWatch && D.movementWatch.scanner; var hits = sc ? scanLanes(cache, sc.dictionary || []) : [];
    if (hits.length) { lines.push("### movement-vocabulary hits"); hits.slice(0, 20).forEach(function (h) { lines.push("- [" + h.tone + "/" + h.cat + "] @" + h.handle + ": " + h.matched.join(", ")); }); }
    var text = lines.join("\n"); if (text.length > 24000) text = text.slice(0, 24000);
    return { text: text, posts: posts, lanes: lanes };
  }
  function renderDirectory() {
    var mount = byId("directoryMount"); clear(mount);
    var dir = arr(D.osint && D.osint.directory);
    if (!dir.length) { mount.appendChild(el("div", "note", "No directory configured.")); return; }
    var grid = el("div", "netgrid");
    dir.forEach(function (g) {
      var col = el("div", "netcol"); var head = el("div", "net-head"); head.appendChild(el("div", "net-title", g.group)); if (has(g.sub)) head.appendChild(el("span", "net-sub", g.sub)); col.appendChild(head);
      arr(g.items).forEach(function (it) {
        var item = el("div", "net-item"); var top = el("div", "net-item-top");
        var name = it.handle && /\./.test(it.handle) ? extLink("https://" + String(it.handle).replace(/^https?:\/\//, ""), "net-name", it.name) : el("span", "net-name", it.name);
        top.appendChild(name); if (has(it.rel)) top.appendChild(el("span", "rel-tag " + it.rel, it.rel)); item.appendChild(top);
        if (has(it.handle)) item.appendChild(el("div", "net-handle", it.handle)); if (has(it.note)) item.appendChild(el("div", "net-note", it.note)); col.appendChild(item);
      });
      grid.appendChild(col);
    });
    mount.appendChild(grid);
  }
  function renderChain() {
    var mount = byId("chainMount"); clear(mount);
    var chain = arr(D.osint && D.osint.signalChain);
    if (!chain.length) { byId("chainBlock").hidden = true; return; }
    byId("chainBlock").hidden = false;
    var box = el("div", "chain");
    chain.forEach(function (s, i) {
      var step = el("div", "chain-step"); var rail = el("div", "chain-rail"); rail.appendChild(el("span", "chain-num", String(i + 1))); step.appendChild(rail);
      var body = el("div", "chain-body"); var top = el("div", "chain-top"); top.appendChild(el("span", "chain-t", s.t || "")); top.appendChild(el("span", "chain-layer", s.layer || "")); body.appendChild(top);
      body.appendChild(el("div", "chain-what", s.what || "")); if (has(s.src)) body.appendChild(el("div", "chain-src", s.src)); step.appendChild(body); box.appendChild(step);
    });
    mount.appendChild(box);
    if (has(D.osint.signalChainNote)) mount.appendChild(el("div", "chain-note", D.osint.signalChainNote));
  }

  /* ---------- Triad Map (optional tab): the COUNTDOWN likelihood heatmaps, embedded ----------
     Each theatre is a self-contained map page (sea · land · air). In preview mode the pages are
     carried inside this file (window.LG_MAPS[id] = base64 of the standalone HTML) and loaded into
     an iframe via srcdoc; in the extension they are packaged files (maps/<id>.html, no inline
     scripts, so the CSP holds). Air theatres accept a coarse public-ADS-B overlay from this page. */
  var LEG_LABEL = { sea: "Sea leg", land: "Land leg (mobile)", air: "Air leg" };
  function decodeMap(b64) { try { var bin = atob(b64); var bytes = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i); return new TextDecoder("utf-8").decode(bytes); } catch (e) { return null; } }
  function mapAvailable(id) { if (PREVIEW) return !!(window.LG_MAPS && window.LG_MAPS[id]); return true; }
  function openMapFrame(theatre, frameHost, status) {
    var id = String(theatre.id || ""); if (!/^[a-z0-9-]+$/.test(id)) return;
    clear(frameHost);
    var f = document.createElement("iframe"); f.className = "map-frame"; f.title = theatre.label || id; f.setAttribute("loading", "lazy");
    f.setAttribute("sandbox", "allow-scripts allow-same-origin allow-popups"); f.setAttribute("referrerpolicy", "no-referrer");
    if (PREVIEW) {
      var html = window.LG_MAPS && window.LG_MAPS[id] ? decodeMap(window.LG_MAPS[id]) : null;
      if (!html) { frameHost.appendChild(el("div", "note", "This theatre's map was not embedded in this preview build (build_preview.py --maps-dir). Open the standalone dist/maps/" + id + ".html instead.")); status.textContent = "not embedded"; return; }
      f.srcdoc = html;
    } else {
      f.src = "maps/" + id + ".html";
    }
    frameHost.appendChild(f); mapFrames[id] = f;
    status.textContent = "loaded · " + (LEG_LABEL[theatre.leg] || theatre.leg || "") + (theatre.edition ? " · " + theatre.edition : "");
    if (theatre.leg === "air" && lastLive) f.addEventListener("load", function () { postLiveToMap(f); });
  }
  function airborneList() {
    var out = []; var flt = lastLive; if (!flt || !flt.ok || !Array.isArray(flt.ac)) return out;
    flt.ac.forEach(function (m) { if (!m || typeof m.lat !== "number" || typeof m.lon !== "number") return; out.push({ cls: String(m.cls || "").replace(AIR_PREFIX, ""), t: S.text(m.t || "", 8), r: S.text(m.r || "", 12), flight: S.text(m.flight || "", 12), lat: Math.round(m.lat * 10) / 10, lon: Math.round(m.lon * 10) / 10, alt: typeof m.alt === "number" ? m.alt : null, airborne: !!m.airborne }); });
    return out.slice(0, 60);
  }
  function postLiveToMap(frame) { try { if (frame && frame.contentWindow) frame.contentWindow.postMessage({ type: "lg-live", ac: airborneList() }, "*"); } catch (e) {} }
  function postLiveToMaps() { Object.keys(mapFrames).forEach(function (id) { var t = arr(D.triadMaps && D.triadMaps.theatres).filter(function (x) { return x.id === id; })[0]; if (t && t.leg === "air") postLiveToMap(mapFrames[id]); }); }
  function renderMaps() {
    var tm = D.triadMaps; var mount = byId("mapsMount"); if (!mount) return; clear(mount);
    if (!tm || !arr(tm.theatres).length) { hideTab("tp-maps"); return; }
    if (has(tm.framingNote)) { var fr = el("div", "pt-frame sw-frame"); fr.appendChild(el("b", null, "Structural priors · no positions")); fr.appendChild(tn(tm.framingNote)); mount.appendChild(fr); }
    if (has(tm.intro)) mount.appendChild(el("p", "posture-read", tm.intro));
    var tiles = el("div", "map-tiles"); var frameHost = el("div", "map-host"); var status = el("div", "map-status", "Select a theatre to load its map.");
    var current = null;
    tm.theatres.forEach(function (t) {
      var tile = el("button", "map-tile leg-" + (t.leg || "sea")); tile.type = "button";
      var top = el("div", "map-tile-top"); top.appendChild(el("span", "leg-chip leg-" + (t.leg || "sea"), LEG_LABEL[t.leg] || t.leg || "")); if (!mapAvailable(t.id)) top.appendChild(el("span", "map-missing", "not embedded")); tile.appendChild(top);
      tile.appendChild(el("div", "map-tile-name", t.label || t.id));
      if (has(t.summary)) tile.appendChild(el("div", "map-tile-sum", t.summary));
      var foot = el("div", "map-tile-foot", (t.edition ? t.edition : "") + (t.headline ? " · " + t.headline : ""));
      tile.appendChild(foot);
      tile.addEventListener("click", function () { tiles.querySelectorAll(".map-tile").forEach(function (x) { x.classList.toggle("on", x === tile); }); current = t; openMapFrame(t, frameHost, status); });
      tiles.appendChild(tile);
    });
    mount.appendChild(tiles);
    var bar = el("div", "map-bar"); bar.appendChild(status);
    var openBtn = el("button", "btn ghost small", "Open full page"); openBtn.type = "button";
    openBtn.addEventListener("click", function () {
      if (!current) return;
      try {
        if (PREVIEW) { var html = window.LG_MAPS && window.LG_MAPS[current.id] ? decodeMap(window.LG_MAPS[current.id]) : null; if (!html) return; var url = URL.createObjectURL(new Blob([html], { type: "text/html" })); window.open(url, "_blank", "noopener"); }
        else window.open(chrome.runtime.getURL("maps/" + current.id + ".html"), "_blank", "noopener");
      } catch (e) {}
    });
    bar.appendChild(openBtn); mount.appendChild(bar); mount.appendChild(frameHost);
    if (has(tm.note)) mount.appendChild(el("div", "note", tm.note));
    // load the first embedded theatre lazily, the first time the tab is shown (a hidden iframe has no size to fit)
    var first = tm.theatres.filter(function (t) { return mapAvailable(t.id); })[0];
    var loaded = false;
    window.__lgOpenFirstMap = function () {
      if (loaded || !first) return; loaded = true;
      var firstTile = null; tiles.querySelectorAll(".map-tile").forEach(function (x, i) { if (tm.theatres[i] === first) firstTile = x; });
      if (firstTile) firstTile.classList.add("on"); current = first; openMapFrame(first, frameHost, status);
    };
    if (!byId("tp-maps").hidden) window.__lgOpenFirstMap();
  }

  /* ---------- Nightwatch (optional tab): the NC3 console, embedded ----------
     Same shape as the Triad Map above: a self-contained page packaged beside this one
     (nightwatch/nightwatch-nc3-console.html, its script externalized so the CSP holds), loaded
     into an iframe the first time the tab is shown — a hidden iframe has no size to fit. */
  var NIGHTWATCH_SRC = "nightwatch/nightwatch-nc3-console.html";
  function renderNightwatch() {
    var mount = byId("nightwatchMount"); if (!mount) return; clear(mount);
    var frameHost = el("div", "map-host"); var status = el("div", "map-status", "Loads when the tab is opened.");
    var bar = el("div", "map-bar"); bar.appendChild(status);
    var openBtn = el("button", "btn ghost small", "Open full page"); openBtn.type = "button";
    openBtn.addEventListener("click", function () {
      try {
        var u = NIGHTWATCH_SRC;
        if (!PREVIEW && window.chrome && chrome.runtime && chrome.runtime.getURL) u = chrome.runtime.getURL(NIGHTWATCH_SRC);
        window.open(u, "_blank", "noopener");
      } catch (e) {}
    });
    bar.appendChild(openBtn); mount.appendChild(bar); mount.appendChild(frameHost);
    var loaded = false;
    window.__lgOpenNightwatch = function () {
      if (loaded) return; loaded = true;
      var f = document.createElement("iframe"); f.className = "map-frame"; f.title = "NIGHTWATCH NC3 Console"; f.setAttribute("loading", "lazy");
      f.setAttribute("sandbox", "allow-scripts allow-same-origin allow-popups"); f.setAttribute("referrerpolicy", "no-referrer");
      f.addEventListener("load", function () { status.textContent = "loaded"; });
      f.src = NIGHTWATCH_SRC;
      frameHost.appendChild(f);
    };
    if (!byId("tp-nightwatch").hidden) window.__lgOpenNightwatch();
  }

  /* ---------- Cold Circuit (optional tab): the cyber-forces watch, embedded ----------
     Same shape as Nightwatch above: a self-contained page packaged beside this one
     (coldcircuit/cold-circuit.html, its scripts externalized so the CSP holds), loaded into an
     iframe the first time the tab is shown — a hidden iframe has no size to fit. */
  var COLDCIRCUIT_SRC = "coldcircuit/cold-circuit.html";
  function renderColdCircuit() {
    var mount = byId("coldCircuitMount"); if (!mount) return; clear(mount);
    var frameHost = el("div", "map-host"); var status = el("div", "map-status", "Loads when the tab is opened.");
    var bar = el("div", "map-bar"); bar.appendChild(status);
    var openBtn = el("button", "btn ghost small", "Open full page"); openBtn.type = "button";
    openBtn.addEventListener("click", function () {
      try {
        var u = COLDCIRCUIT_SRC;
        if (!PREVIEW && window.chrome && chrome.runtime && chrome.runtime.getURL) u = chrome.runtime.getURL(COLDCIRCUIT_SRC);
        window.open(u, "_blank", "noopener");
      } catch (e) {}
    });
    bar.appendChild(openBtn); mount.appendChild(bar); mount.appendChild(frameHost);
    var loaded = false;
    window.__lgOpenColdCircuit = function () {
      if (loaded) return; loaded = true;
      var f = document.createElement("iframe"); f.className = "map-frame"; f.title = "COLD CIRCUIT — Russian cyber forces watch"; f.setAttribute("loading", "lazy");
      f.setAttribute("sandbox", "allow-scripts allow-same-origin allow-popups"); f.setAttribute("referrerpolicy", "no-referrer");
      f.addEventListener("load", function () { status.textContent = "loaded"; });
      f.src = COLDCIRCUIT_SRC;
      frameHost.appendChild(f);
    };
    if (!byId("tp-coldcircuit").hidden) window.__lgOpenColdCircuit();
  }

  /* ---------- Amber Gate (optional tab): the Kaliningrad seam map, embedded ----------
     Same shape again: ambergate/ambergate-seam-map.html, scripts externalized for the CSP,
     loaded into an iframe the first time the tab is shown. */
  var AMBERGATE_SRC = "ambergate/ambergate-seam-map.html";
  function renderAmberGate() {
    var mount = byId("amberGateMount"); if (!mount) return; clear(mount);
    var frameHost = el("div", "map-host"); var status = el("div", "map-status", "Loads when the tab is opened.");
    var bar = el("div", "map-bar"); bar.appendChild(status);
    var openBtn = el("button", "btn ghost small", "Open full page"); openBtn.type = "button";
    openBtn.addEventListener("click", function () {
      try {
        var u = AMBERGATE_SRC;
        if (!PREVIEW && window.chrome && chrome.runtime && chrome.runtime.getURL) u = chrome.runtime.getURL(AMBERGATE_SRC);
        window.open(u, "_blank", "noopener");
      } catch (e) {}
    });
    bar.appendChild(openBtn); mount.appendChild(bar); mount.appendChild(frameHost);
    var loaded = false;
    window.__lgOpenAmberGate = function () {
      if (loaded) return; loaded = true;
      var f = document.createElement("iframe"); f.className = "map-frame"; f.title = "AMBER GATE Seam Map"; f.setAttribute("loading", "lazy");
      f.setAttribute("sandbox", "allow-scripts allow-same-origin allow-popups"); f.setAttribute("referrerpolicy", "no-referrer");
      f.addEventListener("load", function () { status.textContent = "loaded"; });
      f.src = AMBERGATE_SRC;
      frameHost.appendChild(f);
    };
    if (!byId("tp-ambergate").hidden) window.__lgOpenAmberGate();
  }

  /* ---------- Grey Cardinal (optional tab): the covert-action console, embedded ----------
     Same shape again: greycardinal/greycardinal.html, its script externalized for the CSP (the two
     inert application/json data blocks stay in the page), loaded into an iframe the first time the
     tab is shown. */
  var GREYCARDINAL_SRC = "greycardinal/greycardinal.html";
  function renderGreyCardinal() {
    var mount = byId("greyCardinalMount"); if (!mount) return; clear(mount);
    var frameHost = el("div", "map-host"); var status = el("div", "map-status", "Loads when the tab is opened.");
    var bar = el("div", "map-bar"); bar.appendChild(status);
    var openBtn = el("button", "btn ghost small", "Open full page"); openBtn.type = "button";
    openBtn.addEventListener("click", function () {
      try {
        var u = GREYCARDINAL_SRC;
        if (!PREVIEW && window.chrome && chrome.runtime && chrome.runtime.getURL) u = chrome.runtime.getURL(GREYCARDINAL_SRC);
        window.open(u, "_blank", "noopener");
      } catch (e) {}
    });
    bar.appendChild(openBtn); mount.appendChild(bar); mount.appendChild(frameHost);
    var loaded = false;
    window.__lgOpenGreyCardinal = function () {
      if (loaded) return; loaded = true;
      var f = document.createElement("iframe"); f.className = "map-frame"; f.title = "GREY CARDINAL — Russian covert-action console"; f.setAttribute("loading", "lazy");
      f.setAttribute("sandbox", "allow-scripts allow-same-origin allow-popups"); f.setAttribute("referrerpolicy", "no-referrer");
      f.addEventListener("load", function () { status.textContent = "loaded"; });
      f.src = GREYCARDINAL_SRC;
      frameHost.appendChild(f);
    };
    if (!byId("tp-greycardinal").hidden) window.__lgOpenGreyCardinal();
  }

  /* ---------- Feed & Media (collector-fed): items, photos and video with machine-suggested triage ----------
     The collector runs on the user's own machine and reads through the user's own accounts (read-only).
     The worker fetches its JSON over LOOPBACK only; everything here is rendered text-only, images only
     from URLs under the accepted local endpoint. Every triage field is a machine SUGGESTION, labelled. */
  var LEG_ORDER = ["air", "land", "sea", "other"];
  var KIND_LABEL = { sortie: "sortie / flight", launch: "launch / test", exercise: "exercise", deployment: "deployment / move", imagery: "imagery", rhetoric: "rhetoric / signalling", notam: "NOTAM / NAVWARN", adsb: "ADS-B", noise: "noise" };
  function collectorHint(col) {
    var c = D.collector || {};
    var box = el("div", "col-hint");
    var h = el("div", "col-hint-h"); h.appendChild(el("b", null, "Local collector · ")); h.appendChild(tn(PREVIEW ? "Feed and media render only in the installed extension, from the LOOKING GLASS collector running on your own machine." : (col && col.ok ? "connected" : "not connected"))); box.appendChild(h);
    box.appendChild(el("div", "col-hint-p", "The collector (collector/ in the skill) reads through YOUR accounts — Telegram (user session and/or bot), a Discord bot on servers you invite it to, Bluesky, Mastodon, Reddit, YouTube, RSS, public ADS-B and NOTAM / navigational warnings — stores items and media locally, runs a triage agent, and serves JSON on the loopback interface only. Settings → Local collector → endpoint + token → Connect. Everything it carries is unverified OSINT; media triage is a machine suggestion, never a confirmation."));
    if (arr(c.sources).length) {
      var srcs = el("div", "col-sources"); var byKind = {};
      c.sources.forEach(function (s) { var k = s.kind || "other"; (byKind[k] = byKind[k] || []).push(s); });
      Object.keys(byKind).sort().forEach(function (k) { var row = el("div", "col-src-row"); row.appendChild(el("span", "col-src-kind", k)); row.appendChild(el("span", "col-src-list", byKind[k].map(function (s) { return (s.label || s.handle || s.id || "") + (s.enabled === false ? " (off)" : ""); }).join(" · "))); srcs.appendChild(row); });
      box.appendChild(el("div", "mini-h", "Collection plan (from data.js → collector/config.toml)")); box.appendChild(srcs);
    }
    return box;
  }
  function itemCard(it, col) {
    var card = el("div", "feed-item leg-" + (LEG_ORDER.indexOf(it.leg) >= 0 ? it.leg : "other") + (it.triage && it.triage.relevance >= 0.7 ? " hot" : ""));
    var top = el("div", "feed-top");
    var src = it.source || {}; top.appendChild(el("span", "src-tag " + S.text(src.kind || "custom", 16), S.text(src.kind || "?", 16) + " · " + S.text(src.label || src.id || "", 40)));
    if (has(it.leg)) top.appendChild(el("span", "leg-chip leg-" + it.leg, LEG_LABEL[it.leg] || it.leg));
    if (has(it.kind)) top.appendChild(el("span", "kind-chip", KIND_LABEL[it.kind] || S.text(it.kind, 20)));
    top.appendChild(el("span", "feed-when", it.ts ? fmtAgo(Number(it.ts) < 1e12 ? Number(it.ts) * 1000 : Number(it.ts)) + " ago" : ""));
    card.appendChild(top);
    if (has(it.author)) card.appendChild(el("div", "feed-author", S.text(it.author, 80)));
    var body = el("div", "feed-text"); body.appendChild(tn(S.text(it.text || "", 900))); card.appendChild(body);
    var tr = it.triage;
    if (tr && (has(tr.summary_en) || has(tr.grade))) {
      var tb = el("div", "feed-triage");
      tb.appendChild(el("span", "synth-tag", "Machine-suggested triage" + (has(tr.grade) ? " · " + S.text(tr.grade, 12) : "") + (typeof tr.relevance === "number" ? " · relevance " + Math.round(tr.relevance * 100) + "%" : "")));
      if (has(tr.summary_en)) tb.appendChild(tn(S.text(tr.summary_en, 400)));
      if (has(tr.reason)) tb.appendChild(el("div", "feed-reason", S.text(tr.reason, 240)));
      card.appendChild(tb);
    }
    var ents = it.entities || {}; var chips = el("div", "feed-ents");
    ["aircraft", "launchers", "bases", "units", "places"].forEach(function (k) { arr(ents[k]).slice(0, 8).forEach(function (v) { chips.appendChild(el("span", "kw-chip ent-" + k, S.text(v, 40))); }); });
    if (chips.childNodes.length) card.appendChild(chips);
    var foot = el("div", "feed-foot");
    if (arr(it.media).length) foot.appendChild(el("span", "feed-media-n", it.media.length + " media"));
    if (it.dup_of) foot.appendChild(el("span", "feed-dup", "duplicate of " + S.text(it.dup_of, 24)));
    if (has(it.url)) { var lk = extLink(it.url, "sector-link", "open source"); foot.appendChild(lk); }
    card.appendChild(foot);
    return card;
  }
  function renderFeed(col) {
    var mount = byId("feedMount"); if (!mount) return; clear(mount);
    if (!D.collector) { hideTab("tp-feed"); hideTab("tp-gallery"); return; }
    var warn = el("div", "tg-warn"); warn.appendChild(el("b", null, "Unverified · ")); warn.appendChild(tn("Everything in the feed is open-source chatter and imagery pulled by your own collector — leads to corroborate, never facts. Triage labels are machine suggestions. Nothing here is a position, a track or a target.")); mount.appendChild(warn);
    mount.appendChild(collectorHint(col));
    if (PREVIEW || !col || !col.ok) { mount.appendChild(el("div", "lane-empty", PREVIEW ? "Install the extension and connect the collector to see items here." : "Collector not connected or no data yet — open Settings → Local collector, check the endpoint and token, then Refresh.")); return; }
    var items = arr(col.items);
    var sum = col.summary || {};
    var stats = el("div", "sector-stats feed-stats");
    [["Items", items.length], ["Media", arr(col.media).length], ["Sources OK", arr(sum.sources).filter(function (s) { return s && s.ok; }).length + " / " + arr(sum.sources).length], ["Last pull", col.ts ? fmtAgo(col.ts) + " ago" : "—"]].forEach(function (x) { var t = el("div", "sector-tile"); t.appendChild(el("div", "st-num", String(x[1]))); t.appendChild(el("div", "st-lbl", x[0])); stats.appendChild(t); });
    mount.appendChild(stats);
    // filters
    var fb = el("div", "feed-filters");
    var legSel = el("select", "sel"); [["", "All legs"], ["air", "Air"], ["land", "Land (mobile)"], ["sea", "Sea"], ["other", "Other"]].forEach(function (o) { var op = el("option", null, o[1]); op.value = o[0]; legSel.appendChild(op); }); fb.appendChild(legSel);
    var kindSel = el("select", "sel"); var kop = el("option", null, "All kinds"); kop.value = ""; kindSel.appendChild(kop); Object.keys(KIND_LABEL).forEach(function (k) { var op = el("option", null, KIND_LABEL[k]); op.value = k; kindSel.appendChild(op); }); fb.appendChild(kindSel);
    var srcSel = el("select", "sel"); var sop = el("option", null, "All sources"); sop.value = ""; srcSel.appendChild(sop); var seen = {}; items.forEach(function (it) { var k = (it.source && it.source.kind) || "?"; if (!seen[k]) { seen[k] = 1; var op = el("option", null, k); op.value = k; srcSel.appendChild(op); } }); fb.appendChild(srcSel);
    var q = el("input", "filter"); q.type = "search"; q.placeholder = "Filter text / entities…"; fb.appendChild(q);
    var hot = el("label", "chk"); var hc = el("input"); hc.type = "checkbox"; hot.appendChild(hc); hot.appendChild(tn(" relevant only (≥70 %)")); fb.appendChild(hot);
    mount.appendChild(fb);
    var list = el("div", "feed-list"); mount.appendChild(list);
    function apply() {
      clear(list); var n = 0; var qq = q.value.trim().toLowerCase();
      items.forEach(function (it) {
        if (legSel.value && (it.leg || "other") !== legSel.value) return;
        if (kindSel.value && it.kind !== kindSel.value) return;
        if (srcSel.value && ((it.source && it.source.kind) || "?") !== srcSel.value) return;
        if (hc.checked && !(it.triage && it.triage.relevance >= 0.7)) return;
        if (qq) { var hay = (String(it.text || "") + " " + JSON.stringify(it.entities || {}) + " " + ((it.triage && it.triage.summary_en) || "")).toLowerCase(); if (hay.indexOf(qq) === -1) return; }
        if (n++ >= 200) return;
        list.appendChild(itemCard(it, col));
      });
      if (!n) list.appendChild(el("div", "lane-empty", "No items match."));
    }
    [legSel, kindSel, srcSel].forEach(function (x) { x.addEventListener("change", apply); }); q.addEventListener("input", apply); hc.addEventListener("change", apply);
    apply();
    var dot = byId("feedTabDot"); if (dot) dot.hidden = !items.some(function (it) { return it.triage && it.triage.relevance >= 0.85; });
  }
  function renderDigest(col) {
    var mount = byId("digestMount"); var block = byId("digestBlock"); if (!mount) return; clear(mount);
    if (!D.collector) { if (block) block.hidden = true; return; }
    block.hidden = false;
    var d = col && col.ok && col.digest;
    if (!d || !has(d.text)) { mount.appendChild(el("div", "note", "The collector's triage agent writes an I&W-style digest of the last cycle (leads, corroboration status, what is NOT seen). It appears here once the collector has run with an API key configured; without one the feed still works.")); return; }
    var out = el("div", "synth-out"); out.appendChild(el("span", "synth-tag", "Unverified machine digest · " + (d.ts ? fmtAgo(Number(d.ts) < 1e12 ? Number(d.ts) * 1000 : Number(d.ts)) + " ago" : ""))); out.appendChild(tn(S.text(d.text, 6000))); mount.appendChild(out);
  }
  function renderGallery(col) {
    var mount = byId("galleryMount"); if (!mount) return; clear(mount);
    if (!D.collector) { hideTab("tp-gallery"); return; }
    var warn = el("div", "tg-warn"); warn.appendChild(el("b", null, "Unverified imagery · ")); warn.appendChild(tn("Photos and video are what public channels posted, re-encoded by your collector (metadata stripped). 'What the machine sees' is a suggestion for a human analyst to check against the claim, the terrain and the date — recycled and mislabelled footage is the norm in this space.")); mount.appendChild(warn);
    if (PREVIEW || !col || !col.ok) { mount.appendChild(el("div", "lane-empty", PREVIEW ? "Install the extension and connect the collector to browse media here." : "Collector not connected or no media yet.")); return; }
    var endpoint = col.endpoint || DEFAULT_COLLECTOR; var media = arr(col.media);
    if (!media.length) { mount.appendChild(el("div", "lane-empty", "No media collected yet.")); return; }
    var grid = el("div", "gal-grid");
    media.slice(0, 120).forEach(function (m) {
      var card = el("div", "gal-card" + (m.kind === "video" ? " video" : ""));
      var thumb = S.safeLocalUrl(String(m.thumb || "").indexOf("http") === 0 ? m.thumb : endpoint + String(m.thumb || ""), endpoint);
      var box = el("div", "gal-thumb");
      if (thumb) { var img = document.createElement("img"); img.alt = S.text((m.triage && m.triage.what) || "collected media", 120); img.loading = "lazy"; img.decoding = "async"; img.referrerPolicy = "no-referrer"; img.src = thumb; box.appendChild(img); }
      else box.appendChild(el("div", "gal-nothumb", "no thumbnail"));
      if (m.kind === "video") box.appendChild(el("span", "gal-play", "▶ " + (m.duration ? Math.round(m.duration) + "s" : "video")));
      card.appendChild(box);
      var meta = el("div", "gal-meta");
      var src = m.source || {}; meta.appendChild(el("div", "gal-src", S.text(src.kind || "?", 16) + " · " + S.text(src.label || src.id || "", 40) + (m.ts ? " · " + fmtAgo(Number(m.ts) < 1e12 ? Number(m.ts) * 1000 : Number(m.ts)) + " ago" : "")));
      if (m.triage) {
        if (has(m.triage.what)) { var w = el("div", "gal-what"); w.appendChild(el("span", "synth-tag", "Machine sees")); w.appendChild(tn(S.text(m.triage.what, 220))); meta.appendChild(w); }
        var chips = el("div", "feed-ents"); arr(m.triage.aircraft).forEach(function (v) { chips.appendChild(el("span", "kw-chip ent-aircraft", S.text(v, 30))); }); arr(m.triage.launchers).forEach(function (v) { chips.appendChild(el("span", "kw-chip ent-launchers", S.text(v, 30))); }); if (chips.childNodes.length) meta.appendChild(chips);
        if (has(m.triage.claimed_place)) meta.appendChild(kvRow("gal-row", "Claimed place (unverified)", S.text(m.triage.claimed_place, 80)));
        if (has(m.triage.consistency)) meta.appendChild(kvRow("gal-row", "Consistency check", S.text(m.triage.consistency, 160)));
      }
      if (m.dups > 0) meta.appendChild(el("div", "feed-dup", m.dups + " near-duplicate" + (m.dups === 1 ? "" : "s") + " seen (perceptual hash)"));
      var orig = S.safeLocalUrl(endpoint + "/media/file/" + S.text(m.id || "", 40), endpoint);
      if (orig) { var a = document.createElement("a"); a.className = "sector-link"; a.textContent = "open local copy"; a.href = orig; a.target = "_blank"; a.rel = "noopener noreferrer"; meta.appendChild(a); }
      if (has(m.url)) meta.appendChild(extLink(m.url, "sector-link", "source post"));
      card.appendChild(meta); grid.appendChild(card);
    });
    mount.appendChild(grid);
  }

  /* ---------- sources: reliability + academia + security + build record ---------- */
  function renderReliability() {
    var sr = D.sourceReliability; var mount = byId("reliabilityMount"); clear(mount); if (!sr) return;
    if (sr.legend) { var lg = el("div", "adm-legend"); lg.appendChild(el("div", "adm-row", sr.legend.reliability)); lg.appendChild(el("div", "adm-row", sr.legend.credibility)); mount.appendChild(lg); }
    if (has(sr.note)) mount.appendChild(el("div", "note", sr.note));
    var sc = el("div", "src-scroll"); var t = el("table", "src-table");
    var th = el("tr"); ["Source", "Grade", "Role"].forEach(function (h) { th.appendChild(el("th", null, h)); }); t.appendChild(th);
    arr(sr.entries).forEach(function (e) { var tr = el("tr"); tr.appendChild(el("td", "src-name", e.source)); tr.appendChild(el("td", "src-grade", e.grade)); tr.appendChild(el("td", "src-role", e.role)); t.appendChild(tr); });
    sc.appendChild(t); mount.appendChild(sc);
  }
  function renderAcademia() {
    var ac = D.academia; var mount = byId("academiaMount"); clear(mount);
    if (!ac) { byId("academiaBlock").hidden = true; return; }
    byId("academiaBlock").hidden = false;
    mount.appendChild(el("div", "acad-lead", ac.headline || ""));
    if (has(ac.intro)) mount.appendChild(el("p", "posture-read", ac.intro));
    if (has(ac.framingNote)) mount.appendChild(el("div", "acad-framing", ac.framingNote));
    if (arr(ac.stanceLegend).length) { var sl = el("div", "acad-stance-legend"); ac.stanceLegend.forEach(function (s) { var g = el("div", "acad-leg"); g.appendChild(el("span", "acad-stance acad-" + s.key, s.label)); g.appendChild(el("span", "acad-leg-t", s.body)); sl.appendChild(g); }); mount.appendChild(sl); }
    var grid = el("div", "acad-grid");
    arr(ac.countries).forEach(function (co) {
      var col = el("div", "acad-country acad-c-" + (co.stance || "mixed"));
      var head = el("div", "acad-c-head"); var idw = el("div", "acad-c-id"); idw.appendChild(el("span", "acad-flag", co.flag || "")); idw.appendChild(el("span", "acad-c-name", co.name)); head.appendChild(idw); head.appendChild(el("span", "acad-cc", co.cc || "")); col.appendChild(head);
      if (has(co.stanceNote)) col.appendChild(el("div", "acad-c-note", co.stanceNote));
      arr(co.institutions).forEach(function (inst) {
        var it = el("div", "acad-item"); var top = el("div", "acad-item-top");
        var nm = inst.url && inst.url !== "-" ? extLink("https://" + String(inst.url).replace(/^https?:\/\//, ""), "acad-name", inst.name) : el("span", "acad-name", inst.name);
        top.appendChild(nm); if (has(inst.grade)) top.appendChild(el("span", "acad-grade", inst.grade)); it.appendChild(top);
        var meta = el("div", "acad-meta"); if (has(inst.org)) meta.appendChild(el("span", "acad-org", inst.org)); if (inst.url && inst.url !== "-") meta.appendChild(el("span", "acad-url", inst.url)); it.appendChild(meta);
        if (has(inst.focus)) it.appendChild(el("div", "acad-focus", inst.focus)); col.appendChild(it);
      });
      grid.appendChild(col);
    });
    mount.appendChild(grid);
    if (has(ac.gradeNote)) mount.appendChild(el("div", "note", ac.gradeNote));
  }
  function renderSecurity() {
    var mount = byId("securityMount"); clear(mount);
    var panel = el("div", "sec-panel"); var grid = el("div", "sec-grid");
    arr(D.security).forEach(function (s) { var it = el("div", "sec-item"); it.appendChild(el("div", "k", s.k)); var v = el("div", "v"); v.appendChild(el("h5", null, s.h)); v.appendChild(el("p", null, s.p)); it.appendChild(v); grid.appendChild(it); });
    panel.appendChild(grid); mount.appendChild(panel);
  }
  function fingerprint(obj) { // small FNV-1a over the JSON — a build fingerprint, not a security control
    var s = JSON.stringify(obj) || ""; var h = 0x811c9dc5;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0; }
    return ("0000000" + h.toString(16)).slice(-8);
  }
  function renderBuild() {
    var mount = byId("buildMount"); clear(mount); var m = D.meta || {};
    var rec = el("div", "build-rec");
    [["Engine", ENGINE_NAME + " · schema " + (m.version || "?") + (D.subWatch ? " · Sub Watch" : "") + (D.airWatch ? " · Air Watch" : "") + (D.launcherWatch ? " · Launcher Watch" : "") + (D.triadMaps ? " · Triad Map ×" + arr(D.triadMaps.theatres).length : "") + (D.collector ? " · Collector" : "")], ["Subject", (m.country || "") + " — " + (m.subject || "")], ["Compiled", (m.compiled || "") + (m.edition ? " · edition " + m.edition : "")], ["Previous edition", m.previousCompiled || "—"], ["Mode", PREVIEW ? "preview (baseline only)" : "extension (live layers on)"], ["Data fingerprint", fingerprint(D)], ["Sections present", Object.keys(D).filter(function (k) { return D[k] != null; }).join(", ")]]
      .forEach(function (r) { var row = el("div", "build-row"); row.appendChild(el("span", "k", r[0])); row.appendChild(el("span", "v", r[1])); rec.appendChild(row); });
    mount.appendChild(rec);
  }

  /* ---------- utility ---------- */
  function tickClock() { var c = byId("clock"); if (c) c.textContent = new Date().toISOString().slice(11, 19) + "Z"; }

  /* ---------- tabs ---------- */
  function hideTab(panelId) { var t = document.querySelector('.tab[data-tab="' + panelId + '"]'); if (t) t.hidden = true; var p = byId(panelId); if (p) p.hidden = true; }
  function visibleTabs() { return Array.prototype.filter.call(document.querySelectorAll(".tab"), function (t) { return !t.hidden; }); }
  function activateTab(id, fromHash) {
    var tabs = document.querySelectorAll(".tab"); var found = false;
    for (var i = 0; i < tabs.length; i++) { var on = tabs[i].getAttribute("data-tab") === id && !tabs[i].hidden; if (on) found = true; tabs[i].setAttribute("aria-selected", on ? "true" : "false"); tabs[i].tabIndex = on ? 0 : -1; tabs[i].classList.toggle("active", on); }
    if (!found) { id = "tp-bluf"; return activateTab(id, fromHash); }
    var panels = document.querySelectorAll(".tabpanel"); for (var j = 0; j < panels.length; j++) panels[j].hidden = panels[j].id !== id;
    if (id === "tp-maps" && typeof window.__lgOpenFirstMap === "function") window.__lgOpenFirstMap();
    if (id === "tp-nightwatch" && typeof window.__lgOpenNightwatch === "function") window.__lgOpenNightwatch();
    if (id === "tp-coldcircuit" && typeof window.__lgOpenColdCircuit === "function") window.__lgOpenColdCircuit();
    if (id === "tp-ambergate" && typeof window.__lgOpenAmberGate === "function") window.__lgOpenAmberGate();
    if (id === "tp-greycardinal" && typeof window.__lgOpenGreyCardinal === "function") window.__lgOpenGreyCardinal();
    if (!fromHash) { try { history.replaceState(null, "", "#" + id.replace(/^tp-/, "")); } catch (e) {} }
    try { window.scrollTo({ top: 0, behavior: "auto" }); } catch (e) {}
  }
  function wireTabs() {
    var tabs = document.querySelectorAll(".tab");
    tabs.forEach(function (t) {
      t.addEventListener("click", function () { activateTab(t.getAttribute("data-tab")); });
      t.addEventListener("keydown", function (e) {
        var vis = visibleTabs(); var idx = vis.indexOf(t); if (idx === -1) return; var ni = idx;
        if (e.key === "ArrowRight") ni = (idx + 1) % vis.length; else if (e.key === "ArrowLeft") ni = (idx - 1 + vis.length) % vis.length; else if (e.key === "Home") ni = 0; else if (e.key === "End") ni = vis.length - 1; else return;
        e.preventDefault(); vis[ni].focus(); activateTab(vis[ni].getAttribute("data-tab"));
      });
    });
    var fromHash = (location.hash || "").replace(/^#/, ""); activateTab(fromHash ? "tp-" + fromHash : "tp-bluf", true);
    window.addEventListener("hashchange", function () { var h = (location.hash || "").replace(/^#/, ""); if (h) activateTab("tp-" + h, true); });
  }

  /* ---------- live layer (extension mode) ---------- */
  function summarizeLive(flt) {
    var by = {}; arr(D.trackWatch && D.trackWatch.types).forEach(function (ty) { by[ty.key] = { airborne: false, ground: false }; });
    arr(D.airWatch && D.airWatch.live && D.airWatch.live.types).forEach(function (ty) { by[AIR_PREFIX + ty.key] = { airborne: false, ground: false }; });
    if (flt && flt.ok && flt.ac) flt.ac.forEach(function (m) { if (!by[m.cls]) by[m.cls] = { airborne: false, ground: false }; if (m.airborne) by[m.cls].airborne = true; else by[m.cls].ground = true; });
    return by;
  }
  // The worker serves one ADS-B matcher set: Track Watch keys as-is, Air Watch live keys prefixed.
  function mergedMatch() {
    var out = {}; var tm = (D.trackWatch && D.trackWatch.match) || {}; Object.keys(tm).forEach(function (k) { out[k] = tm[k]; });
    var am = (D.airWatch && D.airWatch.live && D.airWatch.live.match) || {}; Object.keys(am).forEach(function (k) { out[AIR_PREFIX + k] = am[k]; });
    return out;
  }
  function mergedTempos() {
    var t = {}; arr(D.trackWatch && D.trackWatch.types).forEach(function (x) { t[x.key] = x.tempo || "frequent"; });
    arr(D.airWatch && D.airWatch.live && D.airWatch.live.types).forEach(function (x) { t[AIR_PREFIX + x.key] = x.tempo || "rare"; });
    return t;
  }
  function seedWorker() {
    try {
      var col = D.collector || {};
      chrome.runtime.sendMessage({ type: "seed", seedVersion: fingerprint({ c: D.osint && D.osint.channels, m: mergedMatch(), s: D.trackWatch && D.trackWatch.sector, a: D.airWatch && D.airWatch.live && D.airWatch.live.sector }), channels: arr(D.osint && D.osint.channels), trackMatch: mergedMatch(), sector: (D.trackWatch && D.trackWatch.sector) || null, airSector: (D.airWatch && D.airWatch.live && D.airWatch.live.sector) || null, tempos: mergedTempos(), collectorDefault: S.localEndpoint(col.endpoint) || DEFAULT_COLLECTOR }, function () { void chrome.runtime.lastError; });
    } catch (e) {}
  }
  function renderLiveEmpty() { renderTrack(null, null, null, null); renderAirLive(null, null, null, null); renderLanes(null); renderScanner(null); renderSubScanner(null); renderAirScanner(null); renderLauncherScanner(null); renderSynthesis(null); renderFeed(null); renderDigest(null); renderGallery(null); }
  function pullLive() {
    if (PREVIEW) { renderLiveEmpty(); return; }
    try {
      chrome.runtime.sendMessage({ type: "getCache" }, function (resp) {
        if (chrome.runtime.lastError || !resp) { renderLiveEmpty(); return; }
        var cache = resp.tg_cache || {};
        renderLanes(cache, resp.tg_health || {}); renderScanner(cache); renderSubScanner(cache); renderAirScanner(cache); renderLauncherScanner(cache); renderSynthesis(cache);
        lastLive = resp.flt_cache || null; var live = summarizeLive(resp.flt_cache);
        renderTrack(live, resp.flt_track, resp.sec_cache, resp.flt_pol);
        renderAirLive(live, resp.flt_track, resp.air_sec_cache, resp.flt_pol);
        postLiveToMaps();
        var col = resp.col_cache || null; if (col && resp.collector && resp.collector.endpoint) col.endpoint = S.localEndpoint(resp.collector.endpoint);
        renderFeed(col); renderDigest(col); renderGallery(col);
        var st = byId("statusText"); if (st) st.textContent = "updated " + fmtAgo(resp.tg_last_run || resp.flt_last_run) + " ago" + (col && col.ok ? " · collector " + fmtAgo(col.ts) : "");
      });
    } catch (e) { renderLiveEmpty(); }
  }
  function wireRefresh() {
    var btn = byId("refreshBtn"), dot = byId("statusDot"), st = byId("statusText");
    btn.addEventListener("click", function () {
      if (PREVIEW) { st.textContent = "preview — no live fetch"; return; }
      dot.className = "dot busy"; st.textContent = "refreshing…"; btn.disabled = true;
      try { chrome.runtime.sendMessage({ type: "refreshNow" }, function () { dot.className = "dot"; btn.disabled = false; pullLive(); }); }
      catch (e) { dot.className = "dot err"; btn.disabled = false; }
    });
    byId("printBtn").addEventListener("click", function () { try { window.print(); } catch (e) {} });
  }
  function wireSettings() {
    var dlg = byId("settings"), body = byId("setBody");
    function build(cfg) {
      window.__lgCfg = cfg || {};
      clear(body);
      body.appendChild(el("p", "note", PREVIEW ? "Settings apply in the installed extension. In preview this is informational." : "Configure the live layer. Channel handles must be public and resolve at t.me/s/<handle>. Everything here stays in this browser's local extension storage."));
      var lab = el("label", null, "Refresh interval (minutes, 15–180)"); lab.htmlFor = "setMins"; body.appendChild(lab);
      var inp = el("input"); inp.type = "number"; inp.id = "setMins"; inp.value = String((cfg && cfg.refreshMinutes) || 30); inp.min = "15"; inp.max = "180"; body.appendChild(inp);
      body.appendChild(el("label", null, "Feed lanes"));
      var known = arr(D.osint && D.osint.channels); var stored = (cfg && cfg.channels) || [];
      var custom = arr(cfg && cfg.customChannels);
      var lanesBox = el("div", "set-lanes");
      function laneRow(c, isCustom) {
        var row = el("div", "set-lane"); var cb = el("input"); cb.type = "checkbox"; cb.setAttribute("data-handle", c.handle); if (isCustom) cb.setAttribute("data-custom", "1");
        var st = stored.filter(function (s) { return s && s.handle === c.handle; })[0];
        cb.checked = st ? st.enabled !== false : c.enabled !== false; row.appendChild(cb);
        var hd = el("div"); hd.appendChild(tn(c.label || ("@" + c.handle))); hd.appendChild(el("div", "hn" + (c.verified ? "" : " unv"), "@" + c.handle + " · " + (c.lane || "custom") + (c.verified ? " · verified " + (c.verifiedOn || "") : " · unverified"))); row.appendChild(hd);
        row.appendChild(el("span", "hn", isCustom ? "custom" : "bundled")); return row;
      }
      known.forEach(function (c) { lanesBox.appendChild(laneRow(c, false)); });
      custom.forEach(function (c) { lanesBox.appendChild(laneRow({ handle: c.handle, label: "@" + c.handle, lane: "custom", verified: false }, true)); });
      body.appendChild(lanesBox);
      var addRow = el("div", "set-row"); var addInp = el("input"); addInp.type = "text"; addInp.id = "setAddHandle"; addInp.placeholder = "add a public handle (t.me/s/<handle>) — unverified until you confirm it"; addRow.appendChild(addInp); body.appendChild(addRow);
      body.appendChild(el("div", "set-help", "Unverified lanes are labelled as such everywhere they render. Unticking a lane stops the worker fetching it on the next cycle."));
      body.appendChild(el("label", null, "Synthesis (optional) — your own Anthropic API key"));
      var keyInp = el("input"); keyInp.type = "password"; keyInp.id = "setKey"; keyInp.placeholder = cfg && cfg.apiKey ? "•••••••• (stored locally — leave blank to keep)" : "sk-ant-… (never leaves this browser except to api.anthropic.com)"; keyInp.autocomplete = "off"; body.appendChild(keyInp);
      var modLab = el("label", null, "Model id or alias"); modLab.htmlFor = "setModel"; body.appendChild(modLab);
      var modInp = el("input"); modInp.type = "text"; modInp.id = "setModel"; modInp.value = (cfg && cfg.model) || DEFAULT_MODEL; body.appendChild(modInp);
      if (D.collector) {
        body.appendChild(el("label", null, "Local collector (optional) — loopback endpoint + shared token"));
        var colCfg = (cfg && cfg.collector) || {};
        var epInp = el("input"); epInp.type = "text"; epInp.id = "setColEndpoint"; epInp.value = colCfg.endpoint || S.localEndpoint(D.collector.endpoint) || DEFAULT_COLLECTOR; epInp.placeholder = DEFAULT_COLLECTOR; body.appendChild(epInp);
        var tokInp = el("input"); tokInp.type = "password"; tokInp.id = "setColToken"; tokInp.placeholder = colCfg.token ? "•••••••• (stored locally — leave blank to keep)" : "token from collector/config.toml"; tokInp.autocomplete = "off"; body.appendChild(tokInp);
        var colRow = el("div", "set-row");
        var colOn = el("label", "chk"); var colCb = el("input"); colCb.type = "checkbox"; colCb.id = "setColEnabled"; colCb.checked = !!colCfg.enabled; colOn.appendChild(colCb); colOn.appendChild(tn(" pull feed, media and digest on each refresh")); colRow.appendChild(colOn);
        var colTest = el("button", "btn ghost small", "Connect & test"); colTest.type = "button"; colTest.id = "setColTest"; colRow.appendChild(colTest);
        var colStatus = el("span", "synth-status", ""); colRow.appendChild(colStatus); body.appendChild(colRow);
        body.appendChild(el("div", "set-help", "Only 127.0.0.1 / localhost endpoints are accepted (the worker enforces it too). Connect asks Chrome for that one loopback origin — an optional host permission you can revoke at chrome://extensions. The collector never posts, never joins anything; it reads through your own accounts and keeps everything on your machine."));
        colTest.addEventListener("click", function () {
          if (PREVIEW) { colStatus.textContent = "Preview — install the extension."; return; }
          var ep = S.localEndpoint(epInp.value); if (!ep) { colStatus.textContent = "Endpoint must be http://127.0.0.1:<port> or http://localhost:<port>."; return; }
          var tok = S.token(tokInp.value) || colCfg.token || "";
          colStatus.textContent = "Requesting permission…";
          var origin = ep.replace(/:\d+$/, "") + "/*";
          var done = function (granted) {
            if (!granted) { colStatus.textContent = "Permission not granted."; return; }
            colStatus.textContent = "Testing…";
            chrome.storage.local.set({ collector: { endpoint: ep, token: tok, enabled: true } }, function () {
              chrome.runtime.sendMessage({ type: "collectorTest" }, function (r) { void chrome.runtime.lastError; colStatus.textContent = r && r.ok ? "OK · " + (r.items || 0) + " items · " + (r.media || 0) + " media · collector " + S.text(r.version || "", 20) : "Failed: " + S.text((r && r.error) || "no response", 120); colCb.checked = true; });
            });
          };
          try { chrome.permissions.request({ origins: [origin] }, done); } catch (e) { done(true); }
        });
      }
      var danger = el("div", "set-danger"); var clr = el("button", "btn ghost small", "Clear cached lanes, tracks, feed and key"); clr.type = "button"; clr.id = "setClear"; danger.appendChild(clr);
      clr.addEventListener("click", function () { if (PREVIEW) return; try { chrome.runtime.sendMessage({ type: "clearCache" }, function () { void chrome.runtime.lastError; chrome.storage.local.remove(["apiKey"], function () { pullLive(); }); }); } catch (e) {} });
      body.appendChild(danger);
    }
    byId("settingsBtn").addEventListener("click", function () {
      if (PREVIEW) { build(null); try { dlg.showModal(); } catch (e) { dlg.setAttribute("open", ""); } return; }
      chrome.storage.local.get(["refreshMinutes", "channels", "customChannels", "apiKey", "model", "collector"], function (cfg) { build(cfg || {}); try { dlg.showModal(); } catch (e) { dlg.setAttribute("open", ""); } });
    });
    function close() { try { dlg.close(); } catch (e) { dlg.removeAttribute("open"); } }
    byId("setClose").addEventListener("click", close); byId("setCancel").addEventListener("click", close);
    byId("setSave").addEventListener("click", function () {
      if (!PREVIEW) {
        var mins = parseInt((byId("setMins") || {}).value, 10); var toSet = {};
        if (mins >= 15 && mins <= 180) toSet.refreshMinutes = mins;
        var known = {}; arr(D.osint && D.osint.channels).forEach(function (c) { known[c.handle] = c; });
        var channels = [], customs = [];
        body.querySelectorAll('input[type=checkbox][data-handle]').forEach(function (cb) {
          var h = S.handle(cb.getAttribute("data-handle")); if (!h) return;
          if (cb.getAttribute("data-custom")) customs.push({ handle: h, enabled: cb.checked });
          channels.push({ handle: h, enabled: cb.checked, verified: !!(known[h] && known[h].verified) });
        });
        var add = S.handle((byId("setAddHandle") || {}).value);
        if (add && !known[add] && !customs.some(function (c) { return c.handle === add; })) { customs.push({ handle: add, enabled: true }); channels.push({ handle: add, enabled: true, verified: false }); }
        toSet.channels = channels.slice(0, 16); toSet.customChannels = customs.slice(0, 8);
        var key = S.apiKey((byId("setKey") || {}).value); if (key) toSet.apiKey = key;
        var model = S.modelId((byId("setModel") || {}).value); if (model) toSet.model = model;
        if (D.collector && byId("setColEndpoint")) {
          var prev = (window.__lgCfg && window.__lgCfg.collector) || {};
          var ep = S.localEndpoint(byId("setColEndpoint").value) || prev.endpoint || DEFAULT_COLLECTOR;
          var tok = S.token((byId("setColToken") || {}).value) || prev.token || "";
          toSet.collector = { endpoint: ep, token: tok, enabled: !!(byId("setColEnabled") && byId("setColEnabled").checked) };
        }
        try { chrome.storage.local.set(toSet, function () { chrome.runtime.sendMessage({ type: "reschedule" }, function () { void chrome.runtime.lastError; pullLive(); }); }); } catch (e) {}
      }
      close();
    });
  }

  /* ---------- init ---------- */
  function init() {
    renderIdentity(); setGauge(); renderProduct(); renderMatrix();
    renderForces(); renderIndicators(); renderDoctrine(); renderEvents();
    renderIw(); renderAch(); renderAnnex(); renderEscalation();
    renderMovement(); renderScanner(null);
    renderAirWatch(); renderAirScanner(null); renderLauncherWatch(); renderLauncherScanner(null);
    renderSubWatch(); renderSubScanner(null);
    renderMaps(); renderNightwatch(); renderColdCircuit(); renderAmberGate(); renderGreyCardinal();
    if (!D.protective) { hideTab("tp-terror"); hideTab("tp-soft"); hideTab("tp-infra"); hideTab("tp-geo"); }
    else { renderTerror(); renderSoft(); renderInfra(); renderGeo(); }
    renderMedia(); renderSocial(); renderDirectory(); renderChain();
    renderReliability(); renderAcademia(); renderSecurity(); renderBuild();
    renderTrack(null, null, null, null); renderAirLive(null, null, null, null); renderLanes(null); renderSynthesis(null);
    renderFeed(null); renderDigest(null); renderGallery(null);
    wireTabs(); wireRefresh(); wireSettings();
    tickClock(); setInterval(tickClock, 1000);
    if (!PREVIEW) { seedWorker(); pullLive(); setInterval(pullLive, 60000); byId("statusText").textContent = "live"; byId("statusDot").className = "dot"; }
    else { byId("statusText").textContent = "preview"; byId("statusDot").className = "dot"; }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
