# LOOKING GLASS — Nuclear Forces & Posture Monitor (Chrome extension)

An **open-source intelligence (OSINT)** dashboard on one country's **nuclear forces and military
posture** — the strategic triad (sea, land, air legs), the nonstrategic and dual-capable forces,
the enablers, the command chain, doctrine and intent — plus a **protective-security layer** and
an optional live layer fed by public channel previews, public military ADS-B and a **local
read-only collector** you run on your own machine through your own accounts. The same engine
re-points at any country by swapping `data.js`; the flagship build is **Russia** (15 SEP 2026).

> **Everything here is public reporting, and nothing here is a position.** Unit, launcher,
> aircraft, boat and warhead locations, alert states and custody are unobservable in every state
> and are **not** shown — not live, not recent, not predicted. The heatmaps are structural priors
> over where a deployed unit *would* be. The protective layer is written for defenders. The
> collector only reads.

## Tabs (25, five groups)

| group · tab | what it holds |
|---|---|
| **Assessment · BLUF** | Posture gauge with an uncertainty range; the BLUF; changes since the last edition; Key Judgments calibrated to **ICD-203** (probability band and confidence stated separately, Admiralty-graded basis, what would change each one). |
| **Capability Matrix** | Every domain × fused level/trend/confidence × per-INT coverage with gaps in red. |
| **Forces** | Order of battle with a second estimate beside each load-bearing figure; branches; systems by domain; a search-verified **command-chain board**; readiness cards; doctrine; timeline. |
| **I&W · ACH** | Indications & Warning with a warning meter over the observable rows and a separate **blind fraction**; ACH ranked by weighted disconfirmation; Key Assumptions; collection gaps. |
| **Intent** | Escalation model: drivers, scenarios with ICD-203 bands, cross-impact. |
| **Watch · Movement** | Movement signatures by visibility tier; live movement-language scanner (native + romanised). |
| **Track Watch** | Allied ISR/tanker pattern-of-life over public **ADS-B** — the mirror indicator. |
| **Air Watch** (v3) | Strike & support aircraft: fleet board (two counts per type, ICAO designators, transponding habit), basing as imagery sees it, observables by tier, air-leg I&W with `unseen` rows, doctrine, timeline, scanner, and a **live board** of the subject's own transponding support types (tankers, airborne command posts, AEW, relay, ISR) in a fixed public sector. Bombers never transpond — absence is uninformative. |
| **Launcher Watch** (v3) | Road-mobile launchers: systems and chassis, garrisons as towns/regions, dispersal doctrine inputs, observables, land-leg I&W with `unseen` rows, doctrine, timeline, scanner. Never a field position. |
| **Sub Watch** | Nuclear submarines: fleet, basing, observables, sea-leg I&W, the undersea-surveillance ledger, doctrine, civil-maritime fusion, timeline, scanner. Never a position. |
| **Triad Map** (v3) | The embedded heatmaps — one per leg/fleet (Russia: Northern Fleet, Pacific Fleet, land, air) — with posture and scenario controls, HDR contours, per-factor tooltips and a triad tab. In the extension, live ADS-B hits from the Air Watch board overlay the air theatre. |
| **Nightwatch** | The embedded NC3 console — Dead Hand relay geometry, satellite shells, the command chain. |
| **Cold Circuit** | The embedded cyber-forces watch — operator, infrastructure and effects geographies kept separate; order of battle, ecosystem, world map, target forecast, tempo, zero-day analysis, campaign record and a cyber I&W board. |
| **Amber Gate** | The embedded Kaliningrad seam map — where assessed defensive coverage thins conditional on eastward commitment; simultaneity, force ledger, sustainment chokepoints, method and confidence. Structural prior only: no position, track or target. |
| **Grey Cardinal** | The embedded covert-action console — Russian unconventional, special-operations and covert-action activity worldwide since January 2022: BLUF and key judgments, order of battle, tradecraft, event-density and exposure world map, campaign record, tempo and attribution ledger, I&W, ACH, target forecast, the Admiralty-graded collection bench and the reference index. Historical public reporting only: no position, track, route or target. |
| **Feed** (v3) | Items from your local collector (Telegram, Discord, Bluesky, Mastodon, Reddit, YouTube, RSS, ADS-B, NOTAM/NAVWARN) with machine triage (relevance, leg, kind, grade, claims), filters, and the **watch digest**. Text-only rendering; everything labelled unverified. |
| **Media** (v3) | Photo/video thumbnails from the collector with what the machine sees, suggested types, the *claimed* place, a consistency check and near-duplicate counts. |
| **Protective · Terror Threat · Soft Targets · Infrastructure · Threat Geography** | The defensive layer in the CISA/NPSA idiom: threat level, actor board, warning indicators, incidents, target-class matrix, sector exposure with data centers spotlighted, regional advisories. |
| **Sources · State Media · Social · Collection · Sources** | Ownership-graded media and platform directories; live channel lanes and the optional synthesis panel; the OSINT directory and signal chain; the Admiralty annex, research base, security model and build record. |

## Modes

| capability | needs a key? | works where |
|---|---|---|
| Full baseline dashboard, every tab, embedded heatmaps | No | Everywhere, offline — the bundled preview HTML |
| Live channel-preview lanes (public `t.me/s/<handle>`, first 16 channels) | No | Installed extension |
| Live Track Watch and Air Watch boards (public military ADS-B, two fixed sectors) | No | Installed extension |
| Live scanner over cached lanes and collector items | No | Installed extension |
| Live ADS-B overlay on the air theatre | No | Installed extension |
| Feed · Media · Digest from the **local collector** | No (collector token) | Installed extension + collector running on 127.0.0.1 (Settings → Local collector → Connect & test; Chrome asks once for the loopback origin) |
| Collector triage / vision / digest agent | Your Anthropic key, in the collector's `config.toml` | Your machine |
| Synthesis panel (Collection tab) | Your Anthropic key, on your click | Installed extension |

## Install

Unzip `<slug>-monitor-extension.zip` → `chrome://extensions` → Developer mode → Load unpacked →
select the `<slug>-monitor/` folder. Open the dashboard from the toolbar icon. For the collector,
see `collector/README.md` and `references/CONNECTORS.md` in the skill.

## Security model (never regress)

- **Least privilege.** Permissions: `storage`, `alarms`. Hosts: `t.me`, `opendata.adsb.fi`,
  `api.anthropic.com`; the loopback collector origin (`http://127.0.0.1:*`, `http://localhost:*`)
  is an **optional** host permission granted only when you click Connect. No tabs, no
  `<all_urls>`, no content scripts.
- **Locked CSP.** `script-src 'self'`; `img/media/connect-src` widened only to the loopback
  origin for collector thumbnails and JSON. No CDN, no inline, no eval. Map theatres are packaged
  pages under the same policy.
- **Hostile input as text only.** Channel HTML, collector items, captions and AI text are parsed
  detached, stripped by `sanitize.js`, length-capped and inserted as text. Thumbnails are
  re-encoded, EXIF-stripped JPEGs served from your own machine.
- **GET-only allowlisted worker.** Cookie-less, no-referrer, re-checked after redirects; the
  collector token travels only as `x-lg-token` to 127.0.0.1 and is never returned to the page.
  No telemetry. Positions coarsened to 0.1°.
- **Local-only storage.** Cache, settings, token and any key in `chrome.storage.local`; this
  hardens the extension, it does not anonymise your network.
- **Reads only.** Nothing posts, joins, follows, scrapes behind another login or asserts a position.
