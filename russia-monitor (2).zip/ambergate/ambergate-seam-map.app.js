/* ============================================================
   AMBER GATE — Kaliningrad seam model
   LOOKING GLASS companion, Ed. 2026.09a
   ============================================================ */
'use strict';

/* ---------- projection ---------- */
const LON0=18.30, LON1=24.40, LAT0=53.55, LAT1=55.80;
const VW=1000, VH=638;
const LATMID=(LAT0+LAT1)/2;
const KMLON=111.32*Math.cos(LATMID*Math.PI/180), KMLAT=111.32;
const px=lon=>(lon-LON0)/(LON1-LON0)*VW;
const py=lat=>(LAT1-lat)/(LAT1-LAT0)*VH;
const dkm=(a,b,c,d)=>{const x=(a-c)*KMLON,y=(b-d)*KMLAT;return Math.sqrt(x*x+y*y);};

/* ---------- grid ---------- */
const DLON=0.026, DLAT=0.015;
const NX=Math.round((LON1-LON0)/DLON), NY=Math.round((LAT1-LAT0)/DLAT);
const clon=i=>LON0+(i+0.5)*DLON, clat=j=>LAT1-(j+0.5)*DLAT;

/* ============================================================
   REFERENCE DATA
   ============================================================ */

/* Garrisons carrying manoeuvre mass. `s` = assessed residual share of a
   notional full garrison, 0–1. All eastern except the two coastal entries. */
const GARRISON=[
 {id:'AG-N01', lon:22.200, lat:54.592, s:0.90, n:'Gusev — 11th AC HQ, 18th Gds MRD, 11th Tk Regt'},
 {id:'AG-N03', lon:21.878, lat:55.081, s:0.60, n:'Sovetsk — 18th Gds MRD elements'},
 {id:'AG-N05', lon:21.790, lat:54.603, s:0.70, n:'Chernyakhovsk — 152nd Gds Msl Bde, air base'},
 {id:'AG-N04', lon:20.510, lat:54.710, s:0.80, n:'Kaliningrad — 7th Sep Gds MRR, 244th Arty Bde'},
 {id:'AG-N08', lon:19.905, lat:54.650, s:0.35, n:'Baltiysk — naval infantry cadre only'},
 {id:'AG-N11', lon:19.988, lat:54.946, s:0.30, n:'Donskoye — coastal missile unit'}
];

/* Air-defence sites. `e` = assessed effectiveness multiplier. */
const SAM=[
 {id:'AG-D01', lon:21.0114, lat:54.6846, e:0.45, r:48, n:'Gvardeysk SAM site (north battery components removed Oct–Nov 2023)'},
 {id:'AG-D02', lon:20.0747, lat:54.7467, e:0.60, r:48, n:'SAM site west of Kaliningrad (SAR returns fell Nov 2023)'},
 {id:'AG-D03', lon:21.216,  lat:54.617,  e:0.80, r:45, n:'Znamensk SAM position'},
 {id:'AG-D05', lon:20.470,  lat:54.690,  e:0.70, r:30, n:'22nd Gds AA Missile Regt — Kaliningrad point defence'},
 {id:'AG-D06', lon:19.900,  lat:54.648,  e:0.65, r:28, n:'Baltiysk base air defence'},
 {id:'AG-D07', lon:20.393,  lat:54.767,  e:0.60, r:26, n:'Chkalovsk airfield defence'}
];

/* Sustainment and internal-mobility single points of failure. */
const CHOKE=[
 {id:'AG-S01', lon:19.902, lat:54.638, c:1.00, k:'sea',  n:'Strait of Baltiysk — the only navigable entrance to the Vistula Lagoon and the Sea Canal'},
 {id:'AG-S02', lon:20.180, lat:54.680, c:0.85, k:'sea',  n:'Kaliningrad Sea Canal — ~40 km dredged channel, Baltiysk to the port'},
 {id:'AG-S03', lon:20.480, lat:54.700, c:0.80, k:'sea',  n:'Kaliningrad seaport — terminus of the Ust-Luga sealift'},
 {id:'AG-S04', lon:20.320, lat:54.995, c:0.85, k:'lng',  n:'FSRU Marshal Vasilevskiy — offshore LNG mooring, single hull'},
 {id:'AG-S05', lon:22.583, lat:54.633, c:0.70, k:'rail', n:'Nesterov / Kybartai — main rail entry from Lithuania'},
 {id:'AG-S06', lon:21.878, lat:55.081, c:0.60, k:'rail', n:'Sovetsk / Pagėgiai — secondary rail entry and Neman crossing'},
 {id:'AG-S08', lon:22.570, lat:54.640, c:0.90, k:'gas',  n:'Gas pipeline border station — Minsk–Vilnius–Kaunas–Kaliningrad'},
 {id:'AG-S07', lon:21.820, lat:54.630, c:0.55, k:'rail', n:'Chernyakhovsk rail junction'},
 {id:'AG-S09', lon:20.150, lat:54.900, c:0.55, k:'gas',  n:'Romanovo underground gas store'}
];

/* Internal crossings — lateral movement inside the oblast. */
const CROSS=[
 {id:'AG-M01', lon:21.060, lat:54.652, c:0.85, n:'Gvardeysk — Pregolya / Deyma junction crossings'},
 {id:'AG-M02', lon:21.110, lat:54.862, c:0.70, n:'Polessk — Deyma crossing, northern lateral'},
 {id:'AG-M03', lon:21.878, lat:55.081, c:0.80, n:'Sovetsk — the only road bridge over the Neman'},
 {id:'AG-M04', lon:20.510, lat:54.705, c:0.65, n:'Kaliningrad — Pregolya crossings in the urban core'},
 {id:'AG-M05', lon:21.216, lat:54.617, c:0.55, n:'Znamensk — Pregolya crossing on the eastern lateral'}
];

/* Generation. `mw` informs the sustainment view, not the surface. */
const ENERGY=[
 {id:'AG-E01', lon:20.420, lat:54.680, mw:900, f:'gas', n:'Kaliningrad CHP-2'},
 {id:'AG-E02', lon:20.550, lat:54.685, mw:456, f:'gas', n:'Pregolskaya CCGT'},
 {id:'AG-E03', lon:21.801, lat:55.095, mw:160, f:'gas', n:'Talakhovskaya TPP (Sovetsk)'},
 {id:'AG-E04', lon:22.195, lat:54.588, mw:160, f:'gas', n:'Mayakovskaya TPP (Gusev)'},
 {id:'AG-E05', lon:20.140, lat:54.680, mw:195, f:'coal',n:'Primorskaya TPP — coal reserve plant'}
];

/* Areas where NATO action is escalation-constrained, and Russian thinness
   therefore is not exploitable. Modelled as a strength, not a weakness. */
const SHADOW=[
 {id:'AG-X01', lon:20.300, lat:54.930, r:20, w:0.80, n:'Reported special-weapons storage site (open-source, unconfirmed)'},
 {id:'AG-D04', lon:20.182, lat:54.857, r:16, w:0.70, n:'Pionersky Voronezh-DM early-warning radar — strategic warning asset'}
];

/* Urban / fortified mass that a thin garrison can still hold. */
const HARD=[
 {lon:20.510, lat:54.710, w:0.80, r:9,  n:'Kaliningrad urban core'},
 {lon:19.900, lat:54.648, w:0.70, r:6,  n:'Baltiysk fortified naval base'},
 {lon:21.790, lat:54.603, w:0.40, r:6,  n:'Chernyakhovsk'},
 {lon:22.200, lat:54.592, w:0.35, r:5,  n:'Gusev'},
 {lon:21.878, lat:55.081, w:0.35, r:5,  n:'Sovetsk'}
];

/* Coastal approach anchors — `q` is assessed approach quality from seaward. */
const COAST=[
 {lon:19.62,lat:54.45,q:0.70,n:'Vistula Spit — Polish half and the 2022 canal open its base'},
 {lon:19.72,lat:54.52,q:0.72,n:'Vistula Spit, Russian section'},
 {lon:19.84,lat:54.60,q:0.75,n:'Spit approach to Baltiysk rear'},
 {lon:19.90,lat:54.67,q:0.85,n:'Baltiysk seaward frontage'},
 {lon:19.94,lat:54.76,q:0.92,n:'Sambian west coast — Primorsk'},
 {lon:19.94,lat:54.87,q:0.92,n:'Sambian west coast — Yantarny'},
 {lon:19.99,lat:54.94,q:0.90,n:'Donskoye — north-west corner'},
 {lon:20.15,lat:54.945,q:0.84,n:'Svetlogorsk'},
 {lon:20.24,lat:54.952,q:0.82,n:'Pionersky'},
 {lon:20.47,lat:54.960,q:0.78,n:'Zelenogradsk'},
 {lon:20.62,lat:55.03,q:0.55,n:'Curonian Spit, southern root'},
 {lon:20.82,lat:55.18,q:0.50,n:'Curonian Spit, centre'},
 {lon:20.97,lat:55.26,q:0.52,n:'Curonian Spit, Morskoye'},
 {lon:19.95,lat:54.46,q:0.58,n:'Vistula Lagoon shore — Mamonovo'},
 {lon:20.17,lat:54.57,q:0.56,n:'Vistula Lagoon shore — Ladushkin'},
 {lon:20.42,lat:54.62,q:0.52,n:'Lagoon head — Ushakovo'}
];

/* NATO-side context nodes. */
const NATO=[
 {lon:19.404,lat:54.156,n:'Elbląg — Multinational Division North East'},
 {lon:21.940,lat:53.808,n:'Orzysz — NATO Battle Group Poland'},
 {lon:24.250,lat:55.020,n:'Rukla — NATO battlegroup, Lithuania'},
 {lon:21.130,lat:55.710,n:'Klaipėda — US/Lithuanian HIMARS live fire, Feb 2026'},
 {lon:22.930,lat:54.100,n:'Suwałki'},
 {lon:18.550,lat:54.520,n:'Gdynia / Gdańsk'}
];

/* The corridor itself. */
const CORRIDOR=[[22.720,54.450],[22.930,54.100],[23.970,54.020]];

/* Zone anchors — Voronoi partition for the tabular twin. */
const ZONES=[
 {id:'Z1', lon:20.10,lat:54.68, n:'Baltiysk narrows & Sea Canal'},
 {id:'Z2', lon:19.99,lat:54.85, n:'Sambian west coast'},
 {id:'Z3', lon:20.40,lat:54.94, n:'Sambian north coast & Zelenogradsk'},
 {id:'Z4', lon:20.52,lat:54.71, n:'Kaliningrad urban core'},
 {id:'Z5', lon:20.10,lat:54.48, n:'Vistula Lagoon shore'},
 {id:'Z6', lon:21.00,lat:55.12, n:'Curonian Spit & Polessk lowland'},
 {id:'Z7', lon:21.05,lat:54.75, n:'Pregolya–Deyma interior'},
 {id:'Z8', lon:21.75,lat:54.62, n:'Chernyakhovsk junction'},
 {id:'Z9', lon:22.00,lat:55.05, n:'Neman line — Sovetsk to Neman'},
 {id:'Z10',lon:22.45,lat:54.58, n:'Eastern salient — Gusev to Nesterov'},
 {id:'Z11',lon:21.00,lat:54.42, n:'Southern border belt'}
];

/* ---------- factors ---------- */
const FACTORS=[
 {id:'F1', k:'vacuum',   w:1.00, on:true, n:'Ground-mass vacuum',
  d:'Residual manoeuvre coverage falling off from each garrison, weighted by assessed residual strength. Every significant garrison sits in the eastern third of the oblast.',
  f:'exp(−d/25 km), garrison-weighted', ref:'AG-N01…N11'},
 {id:'F2', k:'drain',    w:0.85, on:true, n:'Eastward commitment drain',
  d:'The vacuum opened behind the corps when its mass moves toward the corridor. Scales directly with the commitment dial.',
  f:'smoothstep 30→140 km west of the commitment axis', ref:'AG-C01'},
 {id:'F3', k:'littoral', w:0.90, on:true, n:'Littoral accessibility',
  d:'Approach quality from seaward — beach exits, offshore gradient, depth of the road net inland. Highest on the Sambian west coast, lowest in the lagoons.',
  f:'q · exp(−d_coast/9 km)', ref:'AG-L01…L16'},
 {id:'F4', k:'adgap',    w:0.70, on:true, n:'Air-defence engagement seam',
  d:'Residual overlap between published SAM positions, discounted for components assessed removed in 2023. Geometric, not secret: the sites are fixed and their locations are in the public record.',
  f:'1 − Σ e·exp(−(d/r)²)', ref:'AG-D01…D07'},
 {id:'F5', k:'choke',    w:1.10, on:true, n:'Sustainment chokepoint',
  d:'Proximity to a single point of failure in the exclave\'s supply: the strait, the canal, the port, the FSRU, the two rail entries, the pipeline station.',
  f:'max c·exp(−d/7 km)', ref:'AG-S01…S09'},
 {id:'F6', k:'fires',    w:0.45, on:true, n:'NATO fires overmatch',
  d:'Standoff to the nearest NATO land border or open water, banded on published GMLRS / ATACMS / PrSM ranges. Bonus where a cell is covered from both Poland and Lithuania.',
  f:'1 − smoothstep(standoff, 0, 250 km)', ref:'AG-P01…P06'},
 {id:'F7', k:'lateral',  w:0.55, on:true, n:'Internal mobility constraint',
  d:'Dependence on a handful of crossings over the Pregolya–Deyma–Neman system for lateral movement inside the oblast.',
  f:'max c·exp(−d/8 km)', ref:'AG-M01…M05'},
 {id:'F8', k:'hard',     w:-0.80, on:true, n:'Urban & fortified mass',
  d:'Terrain a thin garrison can still hold. Subtracts from assessed thinness.',
  f:'−w·exp(−(d/r)²)', ref:'AG-H01…H05'},
 {id:'F9', k:'shadow',   w:-0.65, on:true, n:'Escalation shadow',
  d:'Ground around a reported special-weapons store and a strategic early-warning radar, where NATO action is constrained by escalation risk. Thinness here is not exploitable.',
  f:'−w·exp(−(d/r)²)', ref:'AG-X01, AG-D04'}
];

const SCENARIOS=[
 {id:'sc1', k:'fleet',  on:false, n:'Baltic Fleet sortied',
  d:'Hulls out of Baltiysk. Base and canal security thins further; the strait matters more, not less.'},
 {id:'sc2', k:'mag',    on:false, n:'Air-defence magazine depletion (D+7)',
  d:'Interceptors expended with no reload route. SAM effectiveness halved across the board.'},
 {id:'sc3', k:'cut',    on:true,  n:'Lithuanian transit severed',
  d:'Rail and pipeline entries closed. Weight shifts entirely onto the sea line and the FSRU. On by default — this is the war condition.'},
 {id:'sc4', k:'recon',  on:false, n:'Garrison reconstituted (out-year)',
  d:'Residual garrison strengths raised toward establishment. Shows which seams close first if regeneration runs to the Lithuanian service\'s 1–2 year limited-action timeline.'}
];

const POSTURE={
 guarded:{commit:20, mag:1.00, label:'Guarded'},
 elevated:{commit:60, mag:1.00, label:'Elevated'},
 high:{commit:80, mag:0.85, label:'High'},
 severe:{commit:95, mag:0.70, label:'Severe'}
};

/* ---------- simultaneity model ---------- */
const TASKS=[
 {id:'T1', n:'Close the Suwałki corridor', cost:6,
  s:'Offensive task from the Gusev–Nesterov salient. The only task that produces a strategic result; also the only one that cannot be done economically.'},
 {id:'T2', n:'Hold the eastern border', cost:3,
  s:'Nesterov–Ozyorsk. ~90 km of frontage facing the Lithuanian border and the corridor\'s northern shoulder.'},
 {id:'T3', n:'Hold the Neman line', cost:3,
  s:'Sovetsk–Neman. A water obstacle in Russia\'s favour, but one road bridge and a rail crossing to lose.'},
 {id:'T4', n:'Cover the Sambian littoral', cost:4,
  s:'~110 km of open coast from Baltiysk round to Zelenogradsk, plus the Curonian Spit. No garrison of consequence west of Kaliningrad.'},
 {id:'T5', n:'Secure Baltiysk & the Sea Canal', cost:2,
  s:'The naval base, the strait and 40 km of dredged channel. Cannot be abandoned without ending seaborne resupply.'},
 {id:'T6', n:'Hold Kaliningrad & the C2 nodes', cost:2,
  s:'Fleet headquarters, corps rear, the port, CHP-2 and Pregolskaya. Urban terrain helps; it still needs bodies.'}
];
const DOCTRINE={
 corridor:{order:['T1','T2','T3','T6','T5','T4'],
   note:'The corridor is the campaign objective; the exclave is expendable ground that fires can partly cover. Matches Russian operational logic and the garrison\'s eastern geography.'},
 fortress:{order:['T5','T6','T4','T2','T3','T1'],
   note:'Hold the exclave, contribute fires to the corridor but not manoeuvre. Preserves the base but forfeits the one result the exclave exists to produce.'},
 balanced:{order:['T2','T5','T6','T1','T3','T4'],
   note:'Cover the irreducible tasks first, then push what is left east. Produces a corridor attempt too weak to close and a coast still uncovered.'}
};

/* ---------- ledger, method content ---------- */
const ORBAT=[
 ['11th Army Corps (HQ)','Gusev','C2','Reported at 71% of authorised strength after 2022; subordinate units repeatedly drawn on for Ukraine','Published ORBAT compilations','AG-N01','warn'],
 ['18th Gds Motor Rifle Division','Gusev / Sovetsk','Manoeuvre','Formed 2021 around the 79th Bde and 7th Regt. Nominally four MR regiments and a tank regiment; no open source places it at establishment in-oblast','Published ORBAT compilations','AG-N02','warn'],
 ['7th Sep Gds Motor Rifle Regt','Kaliningrad','Manoeuvre','Reported ~70% losses in under two weeks in the 2024 Kharkiv fighting and assessed combat-ineffective at the time','Reporting on Kharkiv, 2024','AG-N04','crit'],
 ['120th Naval Infantry Division','Baltiysk (home)','Manoeuvre','Expanded from the 336th Gds Naval Infantry Bde in Dec 2025 — the ninth new Russian manoeuvre division since 2022 — and committed on the Dobropillya axis in Ukraine. Not in the exclave','ISW; unit trackers','AG-N08','gone'],
 ['152nd Gds Missile Brigade','Chernyakhovsk','Fires','Iskander-M. The exclave\'s theatre-strike layer; assessed intact','Published ORBAT; Lithuanian assessment','AG-N05','ok'],
 ['244th Artillery Brigade','Kaliningrad','Fires','Corps artillery; assessed present, manning unseen','Published ORBAT','AG-N06','warn'],
 ['Coastal missile units (Bal / Bastion)','Donskoye and dispersed','Fires','Anti-ship coverage over the south-eastern Baltic; assessed intact','Open reporting','AG-N11','ok'],
 ['44th Air Defence Division / 22nd AA Regt','Kaliningrad and sites','Air defence','S-400 and supporting systems. Components at two sites assessed removed Oct–Nov 2023 amid a sixfold surge in An-124 / Il-76 cargo flights; no confirmed return','Bellingcat SAR and flight analysis','AG-D01/D02','warn'],
 ['Baltic Fleet — surface','Baltiysk','Naval','Corvette-weighted force: Steregushchiy and Buyan-M classes plus Soviet-era units; one Udaloy transferred in 2025. No blue-water escort','UK Defence Forum survey','AG-N10','warn'],
 ['Baltic Fleet — subsurface','Baltiysk','Naval','One 40-year-old Kilo plus a Lada whose permanent assignment is unclear. Assessed the fleet\'s weakest conventional arm','UK Defence Forum survey','AG-N10','crit'],
 ['Naval aviation','Chkalovsk','Air','Su-30SM and Su-24M. Four protective aircraft shelters begun late April 2026 — an admission that parked aircraft ~4 km from the regional capital are at risk','Satellite imagery reporting, 2026','AG-A01','warn'],
 ['Chernyakhovsk air base','Chernyakhovsk','Air','~25 km from the Lithuanian border. No dispersal depth exists anywhere in the oblast','Published basing','AG-A02','warn'],
 ['Voronezh-DM early-warning radar','Pionersky','Strategic','Strategic missile warning. Its status as a national-level asset constrains NATO action across the surrounding coast','Open reporting','AG-D04','info']
];

const KJS=[
 ['KJ-1','Moderate','The manoeuvre ground layer is the hollow one.',
  'Kaliningrad\'s three intact layers — long-range air defence, theatre and coastal fires, and the fleet — are what its reputation rests on. Its <strong>ground forces are not among them</strong>. Roughly 20,000 ground troops were assessed in the exclave at the start of 2022 and a decline on the order of 80% since; the corps was reported at 71% of establishment after 2022; the 7th Separate Regiment was assessed combat-ineffective in 2024; and the exclave\'s principal infantry formation is fighting in Ukraine. The exclave has been a force-generation pool, not a garrison.'],
 ['KJ-2','Moderate','Garrison geography and campaign geography point in opposite directions.',
  'Every manoeuvre garrison of consequence — Gusev, Sovetsk, Chernyakhovsk — sits in the eastern third, 20–40 km from Lithuania and oriented at the corridor. The naval base, the port, the canal, the fleet headquarters, the generating plant and 60% of the population sit in the western third. <strong>Committing the corps east evacuates the west; holding the west forfeits the corridor.</strong> At assessed strength there is no allocation that does both — which is the whole content of the question.'],
 ['KJ-3','Moderate to high','The single most fragile node is the Strait of Baltiysk.',
  'With Lithuanian rail transit capped and more than halved between 2021 and 2024, the exclave\'s bulk lifeline is sealift from Ust-Luga — roughly 2.3 Mt in 2023, on the order of 28–30 vessels working the route in the first half of 2025. <strong>Every hull passes one navigable entrance, then a single ~40 km dredged canal.</strong> The strait is not defended by the layer that is intact; it is defended by the layer that is not.'],
 ['KJ-4','Moderate','The air-defence layer is geometrically penetrable and has no magazine depth.',
  'The sites are few, fixed and published. SAR imagery and flight tracking established that S-400 components left two Kaliningrad positions in Oct–Nov 2023 — north of Gvardeysk and west of the capital — during a sixfold surge in heavy-lift departures, and no confirmed return has been reported. <strong>Whatever remains cannot be reloaded except through the same strait as everything else.</strong> The shelters begun at Chkalovsk in April 2026 concede the same point about aircraft.'],
 ['KJ-5','Low to moderate','Two thin areas are nonetheless strong, because action there is escalation-constrained.',
  'The ground around the reported special-weapons store north of the capital and around the Voronezh-DM strategic warning radar at Pionersky is shielded by escalation risk rather than by troops. <strong>That shadow falls across exactly the stretch of the Sambian north coast the allocation model otherwise flags as weakest.</strong> This is the judgment most likely to be wrong: it assumes declaratory doctrine constrains practice, and it is the one factor here with no observable to test it against.'],
 ['KJ-6','Moderate','The energy island is resilient to losing a plant and not to losing gas.',
  'Installed capacity runs about 2.4 times peak demand across five stations, but roughly 90% of it burns gas, and gas arrives either through the pipeline across Lithuania or through one floating regasification hull at a fixed offshore mooring. The coal reserve plant is the hedge. <strong>In a Baltic war the pipeline closes on day one, which leaves a single unarmoured vessel carrying most of the exclave\'s electricity.</strong>']
];

const ACH=[
 ['H1 — Structural hollowness','<b style="color:var(--amber)">Leading</b>','Consistent reporting on drawdown, the 71% figure, the 2024 losses and the division\'s commitment in Ukraine. Three independent lines converge.','Manning is unseen; every figure is an inference from reported events rather than an observed count.'],
 ['H2 — Reconstitution has closed the gap','Live','Lithuanian assessment describes brigades expanding to divisions and new units forming along NATO\'s borders; the ~80% decline may be a 2023 trough rather than a 2026 state.','New formations near the borders are not the same as new formations <em>in the exclave</em>, which cannot be reinforced overland. No open reporting places restored manoeuvre mass in Kaliningrad.'],
 ['H3 — Thinness is deliberate','Live','A fires-and-sensors bastion under an escalation shadow does not need a garrison; the ground layer was always the expendable one.','Does not explain the eastern garrison geography, which is built for a corridor operation that needs manoeuvre mass.'],
 ['H4 — The dilemma never arises','Contradicted in part','A Baltic campaign might open with Kaliningrad\'s fires while the corps never moves — in which case the west is never evacuated.','Fires alone do not close a 65 km corridor against ground forces. If the corps does not move, the exclave\'s strategic function is not performed and the question resolves the other way.']
];

const IW=[
 'Sealift tonnage on the Ust-Luga–Baltiysk route rising sharply, or new hulls entering the service — the observable that would front-run reconstitution.',
 'New regimental cantonment construction at Gusev or Sovetsk, as against refurbishment.',
 'An-124 / Il-76 movements <em>into</em> Kaliningrad at the tempo seen leaving in late 2023, which would indicate air-defence components returning.',
 'Hardening at Chkalovsk continuing past the four shelters begun in April 2026, or starting at Chernyakhovsk.',
 'Baltic Fleet hulls dispersing out of Baltiysk to Kronstadt, which would read as base survivability being written off.',
 'A second FSRU, additional underground gas storage, or coal stockpiling at Primorskaya — each of which concedes the single-fuel problem.',
 'Conscript intake retained in-oblast rather than rotated out, which is the cheapest way to put bodies on the coast.'
];

const BLIND=[
 'Manning by unit. No open source gives current strength for any formation in the oblast.',
 'Ammunition, fuel and interceptor stocks. Nothing here estimates how long the exclave holds.',
 'SAM magazine depth and whether any reload capacity exists in-theatre.',
 'Naval and air mine inventories on either side — the factor most likely to decide the strait.',
 'Current dispositions of every unit named. Deliberately not modelled; this product refuses positions by design.',
 'Whether the reported special-weapons storage site is active. The escalation-shadow factor rests on it.'
];

const SOURCES=[
 ['Bellingcat — SAR and flight-tracking analysis of Kaliningrad air defence, Nov 2023','B2','Site coordinates, the Oct–Nov 2023 component removal, the cargo-flight surge'],
 ['International Crisis Group — Kaliningrad and the Suwalki Gap','B2','The ~20,000 baseline, the ~80% decline, the transit dependency, the West Berlin analogy'],
 ['Lithuanian national threat assessment, Mar 2026 (via Stars and Stripes)','B2','Brigade-to-division expansion, a new Iskander-M brigade, upgraded Kaliningrad radar, the 1–2 / 6–10 year timelines'],
 ['Institute for the Study of War / unit trackers','B2','The 336th Bde → 120th Naval Infantry Division expansion and its commitment in Ukraine'],
 ['UK Defence Forum — Baltic Fleet survey, 2026','C3','Hull-by-hull fleet condition, the subsurface weakness, the Leningrad MD subordination'],
 ['Centrum Balticum — BSR Policy Briefing on Kaliningrad\'s economy','B2','Generating capacity ratio, gas routes, rail transit caps and decline, Oboronlogistics sealift figures'],
 ['Satellite-imagery reporting on Chkalovsk shelters, 2026','C2','Four shelters begun late April 2026 and their stated purpose'],
 ['Published order-of-battle compilations','C3','Unit subordination and garrison towns. Nominal, not current.'],
 ['Power-plant registries and operator disclosures','B2','Plant capacities and fuels'],
 ['Older base-listing compilations','D4','Not used — internally inconsistent and superseded (e.g. Tochka at a brigade long since re-equipped)']
];

const CALLS=[
 'The codename <b>AMBER GATE</b> and the edition stamp 2026.09a are mine, chosen to sit with the existing LOOKING GLASS companions.',
 'Task costs in the simultaneity board are my own frontage-and-depth estimate, not a Russian planning figure. The shape of the shortfall is the finding; the arithmetic is a scaffold.',
 'Residual garrison strengths (0.30–0.90) are analyst inputs. They encode the reported drawdown and the naval infantry division\'s absence, and they are the single most load-bearing assumption in the surface.',
 'The escalation-shadow factor treats a reported, unconfirmed storage site as an active constraint. If it is wrong, the Sambian north coast moves from mid-table to the top of the zone ranking. Toggle F9 off to see that.',
 'F6 (fires overmatch) is weighted low on purpose. Almost the whole oblast is inside short-range precision fires from NATO soil, so the factor discriminates poorly and would otherwise wash the surface flat.',
 '"Lithuanian transit severed" is on by default because the question posits an active Baltic campaign. In peacetime the rail and pipeline entries carry weight the sea line does not.',
 'Two 2023 SAM coordinates are used as published; everything else is placed at its garrison town centroid, not at a facility.',
 'Grid is 0.026° × 0.015° (~1.67 km cells) over the oblast only. Contours enclose 50 / 80 / 95% of assessed seam mass, not probability.'
];

const ENERGYLIST=[
 '<strong>~1,870 MW installed</strong> across five stations, against a peak demand that the capacity is reported to exceed by about 2.4 times.',
 '<strong>~90% gas-fired.</strong> Kaliningrad CHP-2 (~900 MW), Pregolskaya CCGT (456 MW), Talakhovskaya at Sovetsk (160 MW), Mayakovskaya at Gusev (160 MW).',
 '<strong>Primorskaya (~195 MW) is the only non-gas hedge</strong> — a coal reserve plant, and the reason the grid does not fail outright if gas stops.',
 '<strong>Isolated since February 2025</strong>, when the Baltic states left the BRELL ring for the European network. Kaliningrad ran a five-day full-autonomy test in Feb 2025 and held.',
 '<strong>Gas arrives two ways only:</strong> the Minsk–Vilnius–Kaunas–Kaliningrad pipeline across Lithuania, or the FSRU <em>Marshal Vasilevskiy</em> at a fixed offshore mooring. Underground storage at Romanovo buffers the gap; its wartime fill level is unseen.',
 'The hedge against losing the pipeline is a single unarmoured vessel. The hedge against losing that vessel is coal and the store.'
];

const CHOKELIST=[
 '<strong>Strait of Baltiysk</strong> — the only navigable entrance to the Vistula Lagoon. Every warship, every ferry, every tonne of sealift. <span class="tag t-crit">irreplaceable</span>',
 '<strong>Kaliningrad Sea Canal</strong> — ~40 km of dredged channel from the strait to the port. A canal is blocked by one hull. <span class="tag t-crit">irreplaceable</span>',
 '<strong>Ust-Luga sealift</strong> — the bulk route since 2022, roughly 2.3 Mt in 2023 and ~28–30 vessels working it in H1 2025, across ~900 km of a Baltic in which nine of ten littoral states are NATO. <span class="tag t-warn">contested</span>',
 '<strong>Rail via Lithuania</strong> — capped by agreement since 2022 and more than halved between 2021 and 2024, with successive annual reductions. Closes on day one of a war. <span class="tag t-gone">forfeit in war</span>',
 '<strong>Gas pipeline border station</strong> — one pipeline, on the adversary\'s soil. <span class="tag t-gone">forfeit in war</span>',
 '<strong>FSRU mooring</strong> — fixed, offshore, and inside coastal fires from either direction. <span class="tag t-crit">single hull</span>',
 '<strong>Air</strong> — An-124 and Il-76 into Chkalovsk and Chernyakhovsk. The route that moved S-400 components out in 2023, and the only one that stays open if the strait closes. It cannot move bulk. <span class="tag t-warn">low volume</span>',
 '<strong>Sovetsk road bridge</strong> — internally, the only road crossing of the Neman. Lateral movement between the northern and eastern fronts depends on it. <span class="tag t-warn">no bypass</span>'
];

/* ============================================================
   GEOMETRY HELPERS
   ============================================================ */
const polysOf=f=>(f.t==='P'?[f.c]:f.c);
const linesOf=f=>(f.t==='L'?[f.c]:f.c);

function inRing(x,y,ring){
  let inside=false;
  for(let i=0,j=ring.length-1;i<ring.length;j=i++){
    const xi=ring[i][0],yi=ring[i][1],xj=ring[j][0],yj=ring[j][1];
    if((yi>y)!==(yj>y) && x < (xj-xi)*(y-yi)/((yj-yi)||1e-12)+xi) inside=!inside;
  }
  return inside;
}
function inPoly(x,y,poly){
  if(!inRing(x,y,poly[0])) return false;
  for(let h=1;h<poly.length;h++) if(inRing(x,y,poly[h])) return false;
  return true;
}
function inFeature(x,y,f){
  for(const p of polysOf(f)) if(inPoly(x,y,p)) return true;
  return false;
}
function bboxOf(f){
  let a=1e9,b=1e9,c=-1e9,d=-1e9;
  for(const p of polysOf(f)) for(const pt of p[0]){
    if(pt[0]<a)a=pt[0]; if(pt[1]<b)b=pt[1]; if(pt[0]>c)c=pt[0]; if(pt[1]>d)d=pt[1];
  }
  return [a,b,c,d];
}
const KAL=GEO.kal[0], KALBB=bboxOf(KAL);
const LAKEBB=GEO.lakes.map(bboxOf);

/* ---------- mask ---------- */
const MASK=new Uint8Array(NX*NY);
let NCELL=0;
for(let j=0;j<NY;j++){
  const la=clat(j);
  if(la<KALBB[1]||la>KALBB[3]) continue;
  for(let i=0;i<NX;i++){
    const lo=clon(i);
    if(lo<KALBB[0]||lo>KALBB[2]) continue;
    if(!inFeature(lo,la,KAL)) continue;
    let lake=false;
    for(let k=0;k<GEO.lakes.length;k++){
      const bb=LAKEBB[k];
      if(lo<bb[0]||lo>bb[2]||la<bb[1]||la>bb[3]) continue;
      if(inFeature(lo,la,GEO.lakes[k])){ lake=true; break; }
    }
    if(lake) continue;
    MASK[j*NX+i]=1; NCELL++;
  }
}

/* ---------- static distance fields ---------- */
const D_COAST=new Float32Array(NX*NY), Q_COAST=new Float32Array(NX*NY);
const D_PL=new Float32Array(NX*NY), D_LT=new Float32Array(NX*NY);
const BSEG={PL:(BOUNDARY.PL||[]).flat(), LT:(BOUNDARY.LT||[]).flat(), SEA:(BOUNDARY.SEA||[]).flat()};
for(let j=0;j<NY;j++) for(let i=0;i<NX;i++){
  const idx=j*NX+i; if(!MASK[idx]) continue;
  const lo=clon(i), la=clat(j);
  let best=1e9,q=0;
  for(const c of COAST){ const d=dkm(lo,la,c.lon,c.lat); if(d<best){best=d;q=c.q;} }
  D_COAST[idx]=best; Q_COAST[idx]=q;
  let bp=1e9,bl=1e9;
  for(const p of BSEG.PL){ const d=dkm(lo,la,p[0],p[1]); if(d<bp)bp=d; }
  for(const p of BSEG.LT){ const d=dkm(lo,la,p[0],p[1]); if(d<bl)bl=d; }
  D_PL[idx]=bp; D_LT[idx]=bl;
}
/* zone assignment (Voronoi over anchors) */
const ZONE=new Int8Array(NX*NY).fill(-1);
for(let j=0;j<NY;j++) for(let i=0;i<NX;i++){
  const idx=j*NX+i; if(!MASK[idx]) continue;
  const lo=clon(i), la=clat(j); let best=1e9,z=-1;
  ZONES.forEach((Z,k)=>{ const d=dkm(lo,la,Z.lon,Z.lat); if(d<best){best=d;z=k;} });
  ZONE[idx]=z;
}
/* cell area in km² (constant by construction) */
const CELLKM2=(DLON*KMLON)*(DLAT*KMLAT);

/* ============================================================
   STATE + ENGINE
   ============================================================ */
const S={posture:'elevated', commit:60, resid:9, doctrine:'corridor',
         sc:Object.fromEntries(SCENARIOS.map(s=>[s.k,s.on])),
         fw:Object.fromEntries(FACTORS.map(f=>[f.k,f.on]))};

const smooth=(x,a,b)=>{const t=Math.min(1,Math.max(0,(x-a)/((b-a)||1)));return t*t*(3-2*t);};
const COMMIT_AXIS={lon:22.40, lat:54.58};

let FIELD=new Float32Array(NX*NY);
let PARTS=null;           /* per-cell factor contributions for the tooltip */
let FMIN=0, FMAX=1;

function compute(){
  const commit=S.commit/100;
  const magMul=(S.sc.mag?0.5:1)*POSTURE[S.posture].mag;
  const reconBoost=S.sc.recon?0.35:0;
  const fleetOut=S.sc.fleet?1:0;
  const cut=S.sc.cut?1:0;
  /* residual pool scales the vacuum: fewer BTGe → less coverage everywhere */
  const poolMul=Math.min(1.35, Math.max(0.55, 11/Math.max(4,S.resid)));

  const gar=GARRISON.map(g=>{
    let s=Math.min(1, g.s+reconBoost);
    /* eastward commitment strips the western garrisons first */
    const west=g.lon<21.3;
    if(west) s*= (1-0.55*commit);
    if(g.id==='AG-N08') s*=(1-0.45*fleetOut);
    return {...g, s};
  });
  const chokes=CHOKE.map(c=>{
    let cc=c.c;
    if(cut && (c.k==='rail'||c.k==='gas')) cc*=0.15;     /* route already lost: not a live seam */
    if(cut && (c.k==='sea'||c.k==='lng'))  cc=Math.min(1, cc*1.25); /* all weight shifts here */
    if(fleetOut && c.k==='sea') cc=Math.min(1, cc*1.1);
    return {...c, c:cc};
  });

  const keys=FACTORS.map(f=>f.k);
  PARTS={}; keys.forEach(k=>PARTS[k]=new Float32Array(NX*NY));
  const F=new Float32Array(NX*NY);
  let mn=1e9, mx=-1e9;

  for(let j=0;j<NY;j++){
    const la=clat(j);
    for(let i=0;i<NX;i++){
      const idx=j*NX+i; if(!MASK[idx]) continue;
      const lo=clon(i);

      /* F1 ground-mass vacuum */
      let cov=0;
      for(const g of gar) cov=Math.max(cov, g.s*Math.exp(-dkm(lo,la,g.lon,g.lat)/25));
      const f1=Math.min(1, Math.max(0, 1-cov/poolMul));

      /* F2 eastward commitment drain */
      const f2=commit*smooth(dkm(lo,la,COMMIT_AXIS.lon,COMMIT_AXIS.lat),30,140);

      /* F3 littoral accessibility */
      const f3=Q_COAST[idx]*Math.exp(-D_COAST[idx]/9);

      /* F4 air-defence seam */
      let ad=0;
      for(const s of SAM){ const d=dkm(lo,la,s.lon,s.lat)/s.r; ad+=s.e*magMul*Math.exp(-d*d); }
      const f4=Math.min(1, Math.max(0, 1-Math.min(1,ad)));

      /* F5 sustainment chokepoint */
      let f5=0;
      for(const c of chokes) f5=Math.max(f5, c.c*Math.exp(-dkm(lo,la,c.lon,c.lat)/7));

      /* F6 NATO fires overmatch */
      const standoff=Math.min(D_PL[idx],D_LT[idx],D_COAST[idx]);
      let f6=1-smooth(standoff,0,250);
      if(D_PL[idx]<150 && D_LT[idx]<150) f6=Math.min(1,f6*1.25);

      /* F7 internal mobility */
      let f7=0;
      for(const c of CROSS) f7=Math.max(f7, c.c*Math.exp(-dkm(lo,la,c.lon,c.lat)/8));

      /* F8 urban & fortified mass (negative) */
      let f8=0;
      for(const h of HARD){ const d=dkm(lo,la,h.lon,h.lat)/h.r; f8=Math.max(f8,h.w*Math.exp(-d*d)); }

      /* F9 escalation shadow (negative) */
      let f9=0;
      for(const x of SHADOW){ const d=dkm(lo,la,x.lon,x.lat)/x.r; f9=Math.max(f9,x.w*Math.exp(-d*d)); }

      const raw={vacuum:f1,drain:f2,littoral:f3,adgap:f4,choke:f5,fires:f6,lateral:f7,hard:f8,shadow:f9};
      let v=0;
      for(const f of FACTORS){ if(!S.fw[f.k]) continue; const c=f.w*raw[f.k]; PARTS[f.k][idx]=c; v+=c; }
      F[idx]=v; if(v<mn)mn=v; if(v>mx)mx=v;
    }
  }
  FIELD=F;
  /* percentile stretch: the composite has a high floor (fires and the vacuum
     are elevated almost everywhere), so a raw min–max normalisation washes the
     discriminating factors out. Anchor on p8 / p99.5 instead. */
  const v=[];
  for(let idx=0;idx<NX*NY;idx++) if(MASK[idx]) v.push(F[idx]);
  v.sort((a,b)=>a-b);
  FMIN=v[Math.floor(v.length*0.08)];
  FMAX=v[Math.floor(v.length*0.995)];
  if(!(FMAX>FMIN)){ FMIN=mn; FMAX=mn+1; }
}

/* normalised value 0–1, gamma-shaped for contrast on the dark ground */
const nv=idx=>{
  const t=(FIELD[idx]-FMIN)/(FMAX-FMIN);
  return Math.pow(Math.min(1,Math.max(0,t)),1.35);
};

/* ---------- colour ---------- */
const STOPS=[[0,16,26,46],[0.24,44,47,99],[0.44,92,54,112],[0.62,143,63,98],
             [0.79,192,90,62],[0.91,224,147,44],[1,247,223,160]];
function ramp(t){
  t=Math.min(1,Math.max(0,t));
  for(let k=0;k<STOPS.length-1;k++){
    const a=STOPS[k],b=STOPS[k+1];
    if(t>=a[0]&&t<=b[0]){
      const u=(t-a[0])/((b[0]-a[0])||1);
      return [a[1]+(b[1]-a[1])*u, a[2]+(b[2]-a[2])*u, a[3]+(b[3]-a[3])*u];
    }
  }
  return [247,223,160];
}

/* ============================================================
   RENDER — heat canvas
   ============================================================ */
const cv=document.getElementById('heat'), cx=cv.getContext('2d');
const off=document.createElement('canvas'); off.width=NX; off.height=NY;
const ocx=off.getContext('2d');

function drawHeat(){
  const img=ocx.createImageData(NX,NY), d=img.data;
  for(let idx=0;idx<NX*NY;idx++){
    const o=idx*4;
    if(!MASK[idx]){ d[o+3]=0; continue; }
    const t=nv(idx), c=ramp(t);
    d[o]=c[0]; d[o+1]=c[1]; d[o+2]=c[2];
    d[o+3]=Math.round(255*(0.22+0.72*t));
  }
  ocx.putImageData(img,0,0);
  const r=cv.getBoundingClientRect();
  const dpr=Math.min(2,window.devicePixelRatio||1);
  cv.width=Math.max(1,Math.round(r.width*dpr)); cv.height=Math.max(1,Math.round(r.height*dpr));
  cx.clearRect(0,0,cv.width,cv.height);
  cx.imageSmoothingEnabled=true; cx.imageSmoothingQuality='high';
  cx.drawImage(off,0,0,cv.width,cv.height);
}

/* ============================================================
   RENDER — vector overlay
   ============================================================ */
const svg=document.getElementById('vec'), svgBase=document.getElementById('base');
const NS='http://www.w3.org/2000/svg';
const el=(t,a={})=>{const e=document.createElementNS(NS,t);for(const k in a)e.setAttribute(k,a[k]);return e;};
const ringPath=r=>r.map((p,i)=>(i?'L':'M')+px(p[0]).toFixed(1)+' '+py(p[1]).toFixed(1)).join('')+'Z';
const linePath=r=>r.map((p,i)=>(i?'L':'M')+px(p[0]).toFixed(1)+' '+py(p[1]).toFixed(1)).join('');

function polyPath(f){
  let s='';
  for(const poly of polysOf(f)) for(const ring of poly) s+=ringPath(ring);
  return s;
}

/* marching squares on the normalised field */
const MS=[[],[['L','B']],[['B','R']],[['L','R']],[['T','R']],[['L','T'],['B','R']],[['T','B']],
          [['L','T']],[['L','T']],[['T','B']],[['L','B'],['T','R']],[['T','R']],[['L','R']],
          [['B','R']],[['L','B']],[]];
function contour(level){
  const at=(i,j)=>(i<0||j<0||i>=NX||j>=NY||!MASK[j*NX+i])?-9:nv(j*NX+i);
  let path='';
  const ip=(p,q,vp,vq)=>{const t=(level-vp)/((vq-vp)||1e-9);
    return [p[0]+(q[0]-p[0])*t, p[1]+(q[1]-p[1])*t];};
  const toXY=g=>[px(LON0+(g[0]+0.5)*DLON).toFixed(1), py(LAT1-(g[1]+0.5)*DLAT).toFixed(1)];
  for(let j=0;j<NY-1;j++) for(let i=0;i<NX-1;i++){
    const a=at(i,j),b=at(i+1,j),c=at(i+1,j+1),d=at(i,j+1);
    let k=0; if(a>=level)k|=8; if(b>=level)k|=4; if(c>=level)k|=2; if(d>=level)k|=1;
    if(k===0||k===15) continue;
    const P={T:ip([i,j],[i+1,j],a,b), R:ip([i+1,j],[i+1,j+1],b,c),
             B:ip([i,j+1],[i+1,j+1],d,c), L:ip([i,j],[i,j+1],a,d)};
    for(const [s,e] of MS[k]){
      const A=toXY(P[s]), B=toXY(P[e]);
      path+=`M${A[0]} ${A[1]}L${B[0]} ${B[1]}`;
    }
  }
  return path;
}
function hdrLevels(){
  const vals=[];
  for(let idx=0;idx<NX*NY;idx++) if(MASK[idx]) vals.push(nv(idx));
  vals.sort((a,b)=>b-a);
  const tot=vals.reduce((s,v)=>s+v,0);
  const out=[]; let cum=0, want=[0.5,0.8,0.95], wi=0;
  for(const v of vals){ cum+=v;
    while(wi<want.length && cum/tot>=want[wi]){ out.push(v); wi++; }
    if(wi>=want.length) break;
  }
  while(out.length<3) out.push(vals[vals.length-1]||0);
  return out;
}

const MARK={
  c2:      p=>`M${p[0]-4} ${p[1]-4}h8v8h-8Z`,
  ground:  p=>`M${p[0]} ${p[1]-4.4}a4.4 4.4 0 1 0 0.01 0Z`,
  air:     p=>`M${p[0]} ${p[1]-5}L${p[0]+4.6} ${p[1]+3.4}L${p[0]-4.6} ${p[1]+3.4}Z`,
  ad:      p=>`M${p[0]} ${p[1]-5.2}L${p[0]+5.2} ${p[1]}L${p[0]} ${p[1]+5.2}L${p[0]-5.2} ${p[1]}Z`,
  choke:   p=>`M${p[0]-4.6} ${p[1]}h9.2M${p[0]} ${p[1]-4.6}v9.2`,
  energy:  p=>`M${p[0]-3.6} ${p[1]-3.6}h7.2v7.2h-7.2Z`,
  nato:    p=>`M${p[0]} ${p[1]-4}a4 4 0 1 0 0.01 0Z`
};

/* base layer: everything the heat surface should sit on top of */
function drawBase(){
  svgBase.textContent='';
  const g=el('g');
  g.appendChild(el('path',{d:polyPath(GEO.land[0]),fill:'#161f2b',stroke:'none'}));
  GEO.lakes.forEach(l=>g.appendChild(el('path',{d:polyPath(l),fill:'#0c1420',stroke:'#223044','stroke-width':0.5})));
  GEO.riv.forEach(r=>{ for(const ln of linesOf(r))
    g.appendChild(el('path',{d:linePath(ln),fill:'none',stroke:'#22405c','stroke-width':1})); });
  GEO.nb.forEach(n=>g.appendChild(el('path',{d:polyPath(n),fill:'none',stroke:'#2b3746','stroke-width':1})));
  /* faint ground inside the oblast so masked-out cells still read as land */
  g.appendChild(el('path',{d:polyPath(KAL),fill:'#1b2030',stroke:'none'}));
  svgBase.appendChild(g);
}

function drawVectors(){
  svg.textContent='';
  const g=el('g');
  g.appendChild(el('path',{d:polyPath(KAL),fill:'none',stroke:'#c1685a','stroke-width':1.5,opacity:0.95}));

  /* borders, emphasised */
  (BOUNDARY.PL||[]).forEach(s=>g.appendChild(el('path',{d:linePath(s),fill:'none',stroke:'#4a82c0','stroke-width':2.2,opacity:0.75})));
  (BOUNDARY.LT||[]).forEach(s=>g.appendChild(el('path',{d:linePath(s),fill:'none',stroke:'#4a82c0','stroke-width':2.2,opacity:0.75})));

  /* --- contours --- */
  const lv=hdrLevels();
  const cst=[['#f7dfa0',1.6,0.95],['#e0932c',1.2,0.7],['#8f3f62',1.0,0.5]];
  lv.forEach((v,k)=>g.appendChild(el('path',{d:contour(v),fill:'none',stroke:cst[k][0],
     'stroke-width':cst[k][1],opacity:cst[k][2],'stroke-linecap':'round'})));

  /* --- Kaliningrad Sea Canal: the exclave's seaborne spine --- */
  const CANAL=[[19.905,54.645],[20.05,54.652],[20.20,54.662],[20.35,54.682],[20.48,54.700]];
  g.appendChild(el('path',{d:linePath(CANAL),fill:'none',stroke:'#e2604a','stroke-width':2.4,
    'stroke-linecap':'round',opacity:0.55}));
  g.appendChild(el('path',{d:linePath(CANAL),fill:'none',stroke:'#f5b9a8','stroke-width':0.9,
    'stroke-dasharray':'2 3','stroke-linecap':'round',opacity:0.9}));

  /* --- Suwałki corridor --- */
  g.appendChild(el('path',{d:linePath(CORRIDOR),fill:'none',stroke:'#4a82c0','stroke-width':1.6,
    'stroke-dasharray':'7 5',opacity:0.8}));
  const cm=[px(23.2),py(54.10)];
  g.appendChild(txt(cm[0],cm[1]+16,'SUWAŁKI CORRIDOR — 65 km',{fill:'#5b93d4',size:9.5,ls:'.14em',anchor:'middle'}));

  /* --- markers --- */
  const mk=(kind,lon,lat,stroke,title,fill)=>{
    const p=[px(lon),py(lat)];
    const e=el('path',{d:MARK[kind](p),fill:fill||'none',stroke:stroke,'stroke-width':1.5,
      'vector-effect':'non-scaling-stroke'});
    const t=document.createElementNS(NS,'title'); t.textContent=title; e.appendChild(t);
    g.appendChild(e);
  };
  GARRISON.forEach(x=>mk('ground',x.lon,x.lat,'#e8d7b0',`${x.id} · ${x.n}`,'#1a1208'));
  [['AG-A01',20.393,54.767,'Chkalovsk — Su-30SM / Su-24M, shelters begun Apr 2026'],
   ['AG-A02',21.790,54.603,'Chernyakhovsk air base — ~25 km from Lithuania'],
   ['AG-A03',19.988,54.946,'Donskoye air base']].forEach(a=>mk('air',a[1],a[2],'#9fc4e8',`${a[0]} · ${a[3]}`,'#0c1622'));
  SAM.forEach(s=>mk('ad',s.lon,s.lat,'#7fb8a0',`${s.id} · ${s.n}`,'#0b1a14'));
  CHOKE.forEach(c=>mk('choke',c.lon,c.lat,'#e2604a',`${c.id} · ${c.n}`));
  ENERGY.forEach(e=>mk('energy',e.lon,e.lat,'#c9a24a',`${e.id} · ${e.n} — ${e.mw} MW ${e.f}`,'#1c1608'));
  NATO.forEach(n=>mk('nato',n.lon,n.lat,'#4a82c0',n.n));

  /* escalation shadow rings */
  SHADOW.forEach(x=>{
    const rx=(x.r/KMLON)/(LON1-LON0)*VW, ry=(x.r/KMLAT)/(LAT1-LAT0)*VH;
    const e=el('ellipse',{cx:px(x.lon),cy:py(x.lat),rx,ry,fill:'none',stroke:'#6f7f95',
      'stroke-width':1,'stroke-dasharray':'3 4',opacity:S.fw.shadow?0.75:0.18});
    const t=document.createElementNS(NS,'title'); t.textContent=`${x.id} · ${x.n}`; e.appendChild(t);
    g.appendChild(e);
  });

  /* --- labels --- */
  const LB=[
   [20.51,54.71,'Kaliningrad','e',-4],[19.90,54.648,'Baltiysk','w',13],[22.20,54.592,'Gusev','e',-6],
   [21.878,55.081,'Sovetsk','e',0],[21.79,54.603,'Chernyakhovsk','e',14],[19.94,54.87,'Yantarny','w',0],
   [20.47,54.96,'Zelenogradsk','e',0],[21.06,54.652,'Gvardeysk','e',-5],[22.583,54.633,'Nesterov','e',-6],
   [20.72,55.21,'Curonian Spit','w',0],[19.72,54.52,'Vistula Spit','w',0],[20.24,54.952,'Pionersky','w',-9],
   [21.13,55.71,'Klaipėda','e',0],[19.40,54.156,'Elbląg','w',0],[24.25,55.02,'Rukla','w',0],
   [21.94,53.808,'Orzysz','e',0],[20.22,54.618,'Sea Canal','e',0]
  ];
  LB.forEach(([lo,la,nm,side,dy])=>{
    const x=px(lo), y=py(la);
    g.appendChild(txt(side==='e'?x+7:x-7, y+3.2+(dy||0), nm,
      {fill:'#b6c2d1',size:9.5,anchor:side==='e'?'start':'end',ls:'.03em'}));
  });
  /* country labels */
  [[19.6,53.85,'POLAND'],[23.6,55.45,'LITHUANIA'],[24.15,54.05,'BELARUS'],[19.6,55.45,'BALTIC SEA']]
   .forEach(([lo,la,nm])=>g.appendChild(txt(px(lo),py(la),nm,
     {fill:'#46566a',size:9,ls:'.22em',anchor:'start'})));
  g.appendChild(txt(px(21.2),py(54.30),'KALININGRAD OBLAST',
     {fill:'#b0584a',size:10,ls:'.2em',anchor:'middle',op:0.9}));

  svg.appendChild(g);
}
function txt(x,y,s,o={}){
  const t=el('text',{x,y,fill:o.fill||'#b6c2d1','font-size':o.size||10,
    'font-family':'ui-monospace,SFMono-Regular,Menlo,Consolas,monospace',
    'letter-spacing':o.ls||'0','text-anchor':o.anchor||'start',opacity:o.op??1,
    'paint-order':'stroke','stroke':'#080b10','stroke-width':2.6,'stroke-linejoin':'round'});
  t.textContent=s; return t;
}

/* ============================================================
   TOOLTIP
   ============================================================ */
const box=document.getElementById('mapbox'), tip=document.getElementById('tip');
box.addEventListener('pointermove',e=>{
  const r=box.getBoundingClientRect();
  const fx=(e.clientX-r.left)/r.width, fy=(e.clientY-r.top)/r.height;
  const lon=LON0+fx*(LON1-LON0), lat=LAT1-fy*(LAT1-LAT0);
  const i=Math.floor((lon-LON0)/DLON), j=Math.floor((LAT1-lat)/DLAT);
  const idx=j*NX+i;
  if(i<0||j<0||i>=NX||j>=NY||!MASK[idx]){ tip.classList.remove('on'); return; }
  const active=FACTORS.filter(f=>S.fw[f.k]).map(f=>({f,v:PARTS[f.k][idx]}))
                      .sort((a,b)=>Math.abs(b.v)-Math.abs(a.v)).slice(0,5);
  const z=ZONES[ZONE[idx]];
  let h=`<h5>${z?z.n:'—'}</h5>
    <div class="frow"><span>Seam index</span><b>${(nv(idx)*100).toFixed(0)}</b></div>
    <div style="height:1px;background:var(--line);margin:6px 0"></div>`;
  for(const a of active){
    const mag=Math.min(1,Math.abs(a.v)/1.1);
    const col=a.v<0?'#4fa87a':'#e0932c';
    h+=`<div class="frow"><span>${a.f.id} ${a.f.n}</span><b style="color:${col}">${a.v>=0?'+':''}${a.v.toFixed(2)}</b></div>
        <div class="fbar"><i style="width:${(mag*100).toFixed(0)}%;background:${col}"></i></div>`;
  }
  h+=`<div style="color:var(--faint);font-size:10px;margin-top:4px;font-family:var(--mono)">
      ${lat.toFixed(3)}N ${lon.toFixed(3)}E · ~${CELLKM2.toFixed(1)} km² cell</div>`;
  tip.innerHTML=h; tip.classList.add('on');
  const w=tip.offsetWidth||200, hh=tip.offsetHeight||160;
  let tx=e.clientX-r.left+14, ty=e.clientY-r.top+14;
  if(tx+w>r.width-6) tx=e.clientX-r.left-w-14;
  if(ty+hh>r.height-6) ty=Math.max(6,e.clientY-r.top-hh-14);
  tip.style.left=tx+'px'; tip.style.top=ty+'px';
});
box.addEventListener('pointerleave',()=>tip.classList.remove('on'));

/* ============================================================
   ZONE TABLE
   ============================================================ */
function drawZones(){
  const mass=new Float64Array(ZONES.length), area=new Float64Array(ZONES.length);
  const cnt=new Float64Array(ZONES.length);
  const drv=ZONES.map(()=>({})), glob={}; let gcnt=0;
  for(let idx=0;idx<NX*NY;idx++){
    if(!MASK[idx]) continue;
    const z=ZONE[idx]; if(z<0) continue;
    const v=nv(idx); mass[z]+=v; area[z]+=CELLKM2; cnt[z]++; gcnt++;
    for(const f of FACTORS){ if(!S.fw[f.k]) continue;
      drv[z][f.k]=(drv[z][f.k]||0)+PARTS[f.k][idx];
      glob[f.k]=(glob[f.k]||0)+PARTS[f.k][idx]; }
  }
  /* the peak driver is the factor most ELEVATED here against the oblast-wide
     mean — otherwise the heaviest-weighted factor wins every row and says nothing */
  const topDriver=k=>{
    let best=null,bv=-1e9;
    for(const f of FACTORS){ if(!S.fw[f.k]) continue;
      const d=(drv[k][f.k]||0)/(cnt[k]||1) - (glob[f.k]||0)/(gcnt||1);
      if(d>bv){ bv=d; best=f.k; } }
    return best?[best,bv]:null;
  };
  const tot=mass.reduce((a,b)=>a+b,0)||1;
  const rows=ZONES.map((Z,k)=>({Z,share:mass[k]/tot,area:area[k],top:topDriver(k)}))
    .sort((a,b)=>b.share-a.share);
  const tb=document.querySelector('#zonetbl tbody'); tb.textContent='';
  rows.forEach((r,i)=>{
    const tr=document.createElement('tr');
    const f=r.top?FACTORS.find(x=>x.k===r.top[0]):null;
    const col=i===0?'#f7dfa0':i===1?'#e0932c':i===2?'#c05a3e':'#5c3670';
    tr.innerHTML=`<td class="k">${r.Z.n}</td>
      <td><span class="tnum mono" style="color:${col}">${(r.share*100).toFixed(1)}%</span>
          <div class="bar"><i style="width:${(r.share/rows[0].share*100).toFixed(0)}%;background:${col}"></i></div></td>
      <td class="tnum mono">${Math.round(r.area).toLocaleString()} km²</td>
      <td>${f?f.id+' '+f.n:'—'}</td>
      <td class="ref">${r.Z.id}</td>`;
    tb.appendChild(tr);
  });

  /* live ranking beside the BLUF — seam mass per 1,000 km², so small zones
     are not punished for being small */
  const dens=rows.map(r=>({...r, d:r.share/(r.area/1000)})).sort((a,b)=>b.d-a.d);
  const top=dens[0].d;
  const ol=document.getElementById('rank'); ol.textContent='';
  dens.slice(0,5).forEach((r,i)=>{
    const f=r.top?FACTORS.find(x=>x.k===r.top[0]):null;
    const col=i===0?'#f7dfa0':i===1?'#e0932c':i===2?'#c05a3e':'#7a5a8c';
    const li=document.createElement('li');
    li.innerHTML=`<b>${r.Z.n}</b><span style="color:${col}">${(r.d/top*100).toFixed(0)}</span>
      <u>driver: ${f?f.id+' '+f.n.toLowerCase():'—'} · ${(r.share*100).toFixed(1)}% of total mass</u>`;
    ol.appendChild(li);
  });
  document.getElementById('rank-foot').innerHTML =
    `Indexed on seam mass per 1,000&nbsp;km², top zone = 100. Recomputes with every control.
     Current condition: <b style="color:var(--dim)">${POSTURE[S.posture].label}</b>,
     ${S.commit}% committed east, ${S.resid} BTGe in the oblast.`;
}

/* ============================================================
   SIMULTANEITY
   ============================================================ */
function drawSim(){
  const pool=S.resid, order=DOCTRINE[S.doctrine].order;
  let left=pool; const alloc={};
  for(const id of order){
    const t=TASKS.find(x=>x.id===id);
    const give=Math.min(t.cost,Math.max(0,left));
    alloc[id]=give; left-=give;
  }
  const short=TASKS.reduce((s,t)=>s+(t.cost-alloc[t.id]),0);
  const reqTot=TASKS.reduce((s,t)=>s+t.cost,0);

  const list=document.getElementById('tasklist'); list.textContent='';
  order.map(id=>TASKS.find(t=>t.id===id)).forEach((t,rank)=>{
    const a=alloc[t.id], gap=t.cost-a, pc=a/t.cost;
    const d=document.createElement('div'); d.className='task';
    const tagCls=pc>=1?'t-ok':pc>0?'t-warn':'t-crit';
    const tagTxt=pc>=1?'covered':pc>0?'thin':'uncovered';
    d.innerHTML=`<div class="nm"><span class="ref" style="margin-right:7px">P${rank+1}</span>${t.n}
        <span class="tag ${tagCls}" style="margin-left:7px">${tagTxt}</span></div>
      <div class="num">${a.toFixed(0)} / ${t.cost} BTGe</div>
      <div class="sub">${t.s}</div>
      <div class="allocbar"><i style="width:${(pc*100).toFixed(0)}%"></i>
        <u style="left:${(pc*100).toFixed(0)}%;width:${((gap/t.cost)*100).toFixed(0)}%"></u></div>`;
    list.appendChild(d);
  });

  const uncovered=order.map(id=>TASKS.find(t=>t.id===id)).filter(t=>alloc[t.id]<t.cost);
  const first=uncovered[0];
  document.getElementById('sim-verdict').innerHTML =
    `<b>${pool} of ${reqTot} BTGe available — a shortfall of ${short}.</b> Under
     <b>${S.doctrine==='corridor'?'corridor-first':S.doctrine==='fortress'?'fortress-first':'balanced'}</b>
     priority the board runs dry at <b>${first?first.n.toLowerCase():'—'}</b>, and
     ${uncovered.length} of 6 tasks finish short. ` +
    (S.doctrine==='corridor'
      ? 'Every task the corps drops is behind it: the coast, the canal and the base it sails from.'
      : S.doctrine==='fortress'
      ? 'The exclave holds and the corridor stays open — which means the campaign the exclave exists to enable does not happen.'
      : 'Nothing is covered well enough to matter. This is the allocation that loses twice.');
  document.getElementById('doc-note').textContent=DOCTRINE[S.doctrine].note;
}

/* ============================================================
   SUSTAINMENT DIAGRAM
   ============================================================ */
function drawFlow(){
  const W=960,H=430, s=[];
  const NODE=(x,y,w,h,title,sub,col)=>{
    s.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#0f141c" stroke="${col}" stroke-width="1.2"/>`);
    s.push(`<text x="${x+11}" y="${y+20}" fill="#dbe3ed" font-size="12.5" font-family="ui-sans-serif,system-ui">${title}</text>`);
    if(sub) s.push(`<text x="${x+11}" y="${y+37}" fill="#8c9baf" font-size="10.5" font-family="ui-monospace,Menlo,monospace">${sub}</text>`);
  };
  const ARROW=(x1,y1,x2,y2,col,lab,dash)=>{
    const mx=(x1+x2)/2;
    s.push(`<path d="M${x1} ${y1}L${x2-9} ${y2}" fill="none" stroke="${col}" stroke-width="1.6" ${dash?'stroke-dasharray="5 4"':''} opacity="0.85"/>`);
    s.push(`<path d="M${x2-9} ${y2-4}l8 4-8 4Z" fill="${col}"/>`);
    if(lab) s.push(`<text x="${mx}" y="${y1-9}" fill="#6d7d91" font-size="9" text-anchor="middle" font-family="ui-monospace,Menlo,monospace" letter-spacing=".04em">${lab}</text>`);
  };
  const HEAD=(x,y,t)=>s.push(`<text x="${x}" y="${y}" fill="#5d6b7e" font-size="9.5" letter-spacing=".16em" font-family="ui-monospace,Menlo,monospace">${t}</text>`);

  HEAD(14,20,'ORIGIN'); HEAD(400,20,'CHOKEPOINT'); HEAD(712,20,'DELIVERED TO');

  const C={crit:'#e2604a',warn:'#e3a63f',gone:'#4a5666',ok:'#4fa87a',info:'#5b93d4'};
  const rows=[
   {y:40, o:['Ust-Luga sealift','~2.3 Mt/yr · 28–30 hulls'], c:['Strait of Baltiysk','400 m · no alternative'], d:['Baltiysk base & Kaliningrad port','ammunition · fuel · SAM reloads'], col:C.crit, lab:'~900 km of NATO sea'},
   {y:118,o:['Lithuanian rail','capped 2022 · halved by 2024'], c:['Kybartai / Pagėgiai','on adversary soil'], d:['Chernyakhovsk junction','bulk freight'], col:C.gone, lab:'closes on day one', dash:true},
   {y:196,o:['Pipeline gas','Minsk–Vilnius–Kaunas'], c:['Border station','one pipeline'], d:['Gas-fired power stations','~90% of all generation'], col:C.gone, lab:'closes on day one', dash:true},
   {y:274,o:['LNG by sea','chartered cargoes'], c:['FSRU Marshal Vasilevskiy','one hull · fixed mooring'], d:['Gas grid & Romanovo store','the wartime fallback'], col:C.crit, lab:'the hedge, and a point'},
   {y:352,o:['Air bridge','An-124 / Il-76'], c:['Chkalovsk · Chernyakhovsk','both inside short-range fires'], d:['High-value cargo only','no bulk capacity'], col:C.warn, lab:'took S-400 out, 2023'}
  ];
  for(const r of rows){
    NODE(14,r.y,270,52,r.o[0],r.o[1],r.col);
    NODE(400,r.y,268,52,r.c[0],r.c[1],r.col);
    NODE(712,r.y,234,52,r.d[0],r.d[1],r.col);
    ARROW(284,r.y+26,400,r.y+26,r.col,r.lab,r.dash);
    ARROW(668,r.y+26,712,r.y+26,r.col,'',r.dash);
  }
  document.getElementById('flowbox').innerHTML=
    `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Kaliningrad sustainment routes and their chokepoints">${s.join('')}</svg>`;
}

/* ============================================================
   STATIC CONTENT
   ============================================================ */
function fill(){
  document.getElementById('bluf').innerHTML =
   `Kaliningrad's thin ground is not on the border it faces &mdash; it is <strong>behind</strong> it.
    Conditional on the 11th Army Corps being committed eastward to close the Suwa&#322;ki corridor while the
    exclave's own naval infantry division fights in Ukraine, assessed defensive coverage collapses fastest along the
    <strong>maritime sustainment spine</strong> &mdash; the Strait of Baltiysk and the 40&nbsp;km Sea Canal, through which
    effectively all seaborne resupply passes &mdash; and across the <strong>Sambian littoral</strong> west of the capital,
    where the corps has no garrison of consequence and never did. The intact layers (air defence, Iskander, coastal
    anti-ship fires, the fleet) all sit <em>behind</em> those seams and all depend on them for resupply.
    The single most consequential counter-finding is that the weakest coastal stretch of all sits under an escalation
    shadow that has nothing to do with troops.`;

  /* factor + scenario controls */
  const fc=document.getElementById('factors');
  FACTORS.forEach(f=>{
    const l=document.createElement('label'); l.className='chk';
    l.innerHTML=`<input type="checkbox" id="fk-${f.k}" ${f.on?'checked':''}>
      <span>${f.id} &nbsp;${f.n}<i>${f.f} &nbsp;·&nbsp; wt ${f.w>0?'+':''}${f.w.toFixed(2)}</i></span>`;
    l.title=f.d; fc.appendChild(l);
    l.querySelector('input').addEventListener('change',e=>{S.fw[f.k]=e.target.checked; redraw();});
  });
  const sc=document.getElementById('scenarios');
  SCENARIOS.forEach(x=>{
    const l=document.createElement('label'); l.className='chk';
    l.innerHTML=`<input type="checkbox" id="sk-${x.k}" ${x.on?'checked':''}><span>${x.n}<i>${x.d}</i></span>`;
    sc.appendChild(l);
    l.querySelector('input').addEventListener('change',e=>{S.sc[x.k]=e.target.checked; redraw();});
  });

  /* legend ramp */
  const stops=STOPS.map(s=>`rgb(${s[1]|0},${s[2]|0},${s[3]|0}) ${(s[0]*100).toFixed(0)}%`).join(',');
  document.getElementById('ramp').style.background=`linear-gradient(90deg,${stops})`;

  /* orbat */
  const ob=document.querySelector('#orbat tbody');
  ORBAT.forEach(r=>{
    const tr=document.createElement('tr');
    tr.innerHTML=`<td class="k">${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td>
      <td>${r[3]} <span class="tag t-${r[6]}">${r[6]==='gone'?'not in theatre':r[6]==='ok'?'intact':r[6]==='crit'?'attrited':r[6]==='info'?'constraint':'degraded'}</span></td>
      <td>${r[4]}</td><td class="ref">${r[5]}</td>`;
    ob.appendChild(tr);
  });

  /* key judgments */
  const kj=document.getElementById('kjs');
  KJS.forEach(k=>{
    const d=document.createElement('div'); d.className='kj';
    d.innerHTML=`<div class="kj-h"><b>${k[0]}</b><em>Confidence: ${k[1]}</em></div>
      <div style="color:var(--ink);font-size:13.5px;font-weight:600;line-height:1.45">${k[2]}</div>
      <p>${k[3]}</p>`;
    kj.appendChild(d);
  });

  const ach=document.querySelector('#ach tbody');
  ACH.forEach(r=>{const tr=document.createElement('tr');
    tr.innerHTML=`<td class="k">${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td>`;ach.appendChild(tr);});

  const put=(id,arr)=>{const u=document.getElementById(id);
    arr.forEach(x=>{const li=document.createElement('li');li.innerHTML=x;u.appendChild(li);});};
  put('iw',IW); put('blind',BLIND); put('calls',CALLS);
  put('energy-list',ENERGYLIST); put('choke-list',CHOKELIST);

  const ft=document.querySelector('#factbl tbody');
  FACTORS.forEach(f=>{const tr=document.createElement('tr');
    tr.innerHTML=`<td class="k">${f.id} ${f.n}</td>
      <td class="tnum mono" style="color:${f.w<0?'var(--ok)':'var(--amber)'}">${f.w>0?'+':''}${f.w.toFixed(2)}</td>
      <td>${f.d}</td><td class="mono" style="font-size:11px">${f.f}</td><td class="ref">${f.ref}</td>`;
    ft.appendChild(tr);});

  const st=document.querySelector('#srctbl tbody');
  SOURCES.forEach(r=>{const tr=document.createElement('tr');
    tr.innerHTML=`<td class="k">${r[0]}</td><td><span class="srcgrade">${r[1]}</span></td><td>${r[2]}</td>`;
    st.appendChild(tr);});

  drawFlow();
}

/* ============================================================
   CONTROLS + BOOT
   ============================================================ */
function pills(id,key,after){
  document.querySelectorAll(`#${id} .pill`).forEach(b=>{
    b.addEventListener('click',()=>{
      document.querySelectorAll(`#${id} .pill`).forEach(o=>o.setAttribute('aria-pressed','false'));
      b.setAttribute('aria-pressed','true'); S[key]=b.dataset.v; after&&after();
    });
  });
}
pills('posture','posture',()=>{
  const c=POSTURE[S.posture].commit;
  S.commit=c; document.getElementById('commit').value=c;
  document.getElementById('commit-v').textContent=c+'%';
  redraw();
});
pills('doctrine','doctrine',drawSim);

const bind=(id,key,fmt,after)=>{
  const inp=document.getElementById(id), out=document.getElementById(id+'-v');
  inp.addEventListener('input',()=>{ S[key]=+inp.value; out.textContent=fmt(+inp.value); after(); });
};
bind('commit','commit',v=>v+'%',()=>redraw());
bind('resid','resid',v=>v+' BTGe',()=>{
  document.getElementById('sim-pool').value=S.resid;
  document.getElementById('sim-pool-v').textContent=S.resid+' BTGe';
  redraw(); drawSim();
});
bind('sim-pool','resid',v=>v+' BTGe',()=>{
  document.getElementById('resid').value=S.resid;
  document.getElementById('resid-v').textContent=S.resid+' BTGe';
  drawSim(); redraw();
});

/* tabs */
document.querySelectorAll('[role=tab]').forEach(t=>{
  t.addEventListener('click',()=>{
    document.querySelectorAll('[role=tab]').forEach(o=>{
      o.setAttribute('aria-selected','false');
      document.getElementById(o.getAttribute('aria-controls')).hidden=true;
    });
    t.setAttribute('aria-selected','true');
    document.getElementById(t.getAttribute('aria-controls')).hidden=false;
    if(t.id==='t-map') requestAnimationFrame(drawHeat);
  });
});

function redraw(){ compute(); drawHeat(); drawVectors(); drawZones(); }

fill(); drawBase(); redraw(); drawSim();
let rt; addEventListener('resize',()=>{clearTimeout(rt); rt=setTimeout(drawHeat,140);});

