/* ================= COLD CIRCUIT — app ================= */
const $ = (s,r=document)=>r.querySelector(s);
const $$ = (s,r=document)=>Array.from(r.querySelectorAll(s));
const esc = s => String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const refs = ids => (ids||[]).map(i=>`<span class="ref" data-s="${i}">${i}</span>`).join('');

/* ---------- header ---------- */
$('#mEd').textContent = META.edition; $('#mAs').textContent = META.asOf;
$('#mPo').textContent = META.posture.level; $('#mRa').textContent = META.posture.range;
$('#mMv').textContent = META.posture.mover; $('#fEd').textContent = META.edition; $('#fCo').textContent = META.compiled;

/* ---------- tabs ---------- */
const TABS = [
  {g:"Assessment", items:[["bluf","BLUF"],["orbat","Order of battle"],["eco","Ecosystem"]]},
  {g:"Geography",  items:[["map","World map"],["fore","Target forecast"],["tempo","Tempo"]]},
  {g:"Technical",  items:[["zd","Zero-day"],["time","Campaign record"]]},
  {g:"Watch",      items:[["iw","I&W"],["feed","Feed"],["src","Sources"]]}
];
const rail = $('#rail');
TABS.forEach(grp=>{
  const d = document.createElement('div'); d.className='grp';
  d.innerHTML = `<span class="grp-l">${grp.g}</span>` + grp.items.map(([id,l])=>
    `<button class="tab" role="tab" id="tab-${id}" data-t="${id}" aria-controls="t-${id}" aria-selected="false">${l}</button>`).join('');
  rail.appendChild(d);
});
function show(id){
  $$('.tab').forEach(b=>b.setAttribute('aria-selected', String(b.dataset.t===id)));
  $$('main > section').forEach(s=>{ s.hidden = (s.id !== 't-'+id); });
  if(location.hash.slice(1)!==id) history.replaceState(null,'','#'+id);
  window.scrollTo({top:0, behavior:'instant'});
  if(id==='map') drawMap();
}
rail.addEventListener('click', e=>{ const b=e.target.closest('.tab'); if(b) show(b.dataset.t); });
rail.addEventListener('keydown', e=>{
  if(e.key!=='ArrowRight' && e.key!=='ArrowLeft') return;
  const tabs=$$('.tab'); const i=tabs.indexOf(document.activeElement); if(i<0) return;
  const n=tabs[(i + (e.key==='ArrowRight'?1:tabs.length-1)) % tabs.length]; n.focus(); show(n.dataset.t); e.preventDefault();
});

/* ---------- BLUF ---------- */
const nObs = IW.filter(x=>x.st==='observed').length, nUn = IW.filter(x=>x.st==='unseen').length;
$('#blufTiles').innerHTML = [
  ['Units in the order of battle','9','am','across GRU, SVR, FSB and Belarus'],
  ['NATO states with confirmed physical or OT effect','4','ro','Poland · Norway · Denmark · Sweden'],
  ['Zero-days in the wild, 2025','90','','48% enterprise; none attributed to Russian state espionage'],
  ['Russia-nexus gray-zone incidents in Europe','~15/mo','cy','up from ~10 before April 2026'],
  ['Indicators observed of '+IW.length, String(nObs),'','and '+nUn+' that cannot be seen at all'],
  ['Sources cited', String(SRC.length),'am','joint advisories, sanctions, courts, telemetry, leaks']
].map(([l,v,c,d])=>`<div class="tile"><div class="l">${l}</div><div class="v ${c}">${v}</div><div class="d">${d}</div></div>`).join('');

const POS = {guarded:25, elevated:45, HIGH:70, high:70, severe:88};
$('#pLevel').textContent = META.posture.level;
$('#pRange').textContent = META.posture.range + ' · ' + META.posture.mover;
$('#pNote').textContent = META.posture.note;
$('#pBar').style.cssText = 'width:70%;background:linear-gradient(90deg,var(--t2),var(--t5))';

$('#kjWrap').innerHTML = KJ.map(k=>`
  <div class="kjcard ${k.cls}">
    <div class="id">${k.id} · ${k.prob} · ${k.conf} confidence · grade ${k.grade}</div>
    <div class="j">${k.j}</div>
    <div class="meta">${refs(k.src)}</div>
    <p class="note" style="margin:0 0 10px">${k.basis}</p>
    <div class="w"><b>What would change this</b>${k.w}</div>
  </div>`).join('');

$('#whatChanged').innerHTML = `
<ul style="margin:0;padding-left:18px;color:var(--ink2);font-size:13px;line-height:1.75">
<li><b>10 Sep 2026</b> — NATO allies disclosed that a UK–Norway–US operation tracked GUGI submersibles testing a means of disabling the Svalbard fibre links at up to 2,700 m. The seabed threat moved from anchor-dragging to purpose-built.${refs(['CC-47'])}</li>
<li><b>29 Aug 2026</b> — Gray-zone tempo in Europe reported at roughly fifteen incidents a month, up from about ten before April.${refs(['CC-46'])}</li>
<li><b>24–26 Aug 2026</b> — Norway absorbed the largest DDoS its digitalisation agency has recorded, one day after an NOK 85bn Ukraine pledge. The cleanest trigger–response pair in the current record.${refs(['CC-40'])}</li>
<li><b>Jul 2026</b> — the heaviest attribution month yet: router-hygiene and Zimbra advisories, the Dutch camera disclosure, and a North Atlantic Council condemnation, all inside three weeks.${refs(['CC-02','CC-03','CC-17','CC-34'])}</li>
<li><b>17 Sep 2026</b> — the EU announced a collective counter-hybrid response mechanism after NATO intercepted an armed drone over Lithuania — governed, as reported, by the same unanimity rule that has stalled sanctions.${refs(['CC-46'])}</li>
</ul>`;

/* ---------- ORBAT ---------- */
$('#orbatWrap').innerHTML = ORBAT.map(s=>`
  <details ${s.svc==='GRU'?'open':''}>
    <summary><span style="color:var(${s.col})">${s.svc}</span> — ${esc(s.full)} · ${esc(s.hq)}</summary>
    <div class="dc">
      ${s.units.map(u=>`
        <div style="padding:12px 0;border-bottom:1px solid var(--line)">
          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:baseline">
            <span class="mono" style="font-size:14px;font-weight:700;color:var(${s.col});letter-spacing:.06em">${esc(u.u)}</span>
            <span class="note" style="margin:0">${esc(u.alt)}</span>
          </div>
          <div class="mono" style="font-size:11px;color:var(--ink3);margin-top:5px;letter-spacing:.03em">${esc(u.names)}</div>
          <div class="note" style="margin-top:6px"><b style="color:var(--ink2)">Site</b> · ${esc(u.site)}</div>
          <p style="margin:8px 0 6px">${esc(u.mission)}</p>
          <p class="note" style="margin:0">${esc(u.recent)}${refs(u.src)}</p>
        </div>`).join('')}
    </div>
  </details>`).join('');

/* ---------- Tiers ---------- */
$('#tierWrap').innerHTML = TIERS.map(t=>`
  <div class="panel" style="border-left:3px solid var(${t.col});margin-bottom:10px">
    <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:baseline;margin-bottom:6px">
      <span class="mono" style="font-size:10px;letter-spacing:.16em;color:var(--ink4);text-transform:uppercase">${t.t}</span>
      <span style="font-size:15px;font-weight:650;color:var(${t.col})">${esc(t.n)}</span>
      <span class="pill p-un">control: ${esc(t.ctl)}</span>
      <span class="pill p-un">deniability: ${esc(t.den)}</span>
      <span class="pill p-un">tempo: ${esc(t.tempo)}</span>
    </div>
    <div class="mono" style="font-size:11px;color:var(--ink3);margin-bottom:8px">${esc(t.ex)}</div>
    <p style="margin:0">${esc(t.d)}${refs(t.src)}</p>
  </div>`).join('');

/* ================= MAP ================= */
const EE = (()=>{ const A1=1.340264,A2=-0.081106,A3=0.000893,A4=0.003796,M=Math.sqrt(3)/2;
  return (lon,lat)=>{ const p=lat*Math.PI/180,l=lon*Math.PI/180;
    const th=Math.asin(Math.max(-1,Math.min(1,M*Math.sin(p))));
    const t2=th*th,t6=t2*t2*t2;
    const den=M*(A1+3*A2*t2+7*A3*t6+9*A4*t6*t2);
    return [l*Math.cos(th)/den, th*(A1+A2*t2+t6*(A3+A4*t2))]; };
})();
const VB_W=1160, VB_H=520, PAD=8, LAT_MIN=-58, LAT_MAX=84;
const _x0=EE(-180,0)[0], _x1=EE(180,0)[0], _y0=EE(0,LAT_MIN)[1], _y1=EE(0,LAT_MAX)[1];
const SC = Math.min((VB_W-2*PAD)/(_x1-_x0), (VB_H-2*PAD)/(_y1-_y0));
const OX = PAD + ((VB_W-2*PAD)-(_x1-_x0)*SC)/2, OY = PAD + ((VB_H-2*PAD)-(_y1-_y0)*SC)/2;
function prj(lon,lat){ const [x,y]=EE(lon,lat); return [OX+(x-_x0)*SC, OY+(_y1-y)*SC]; }
function pathOf(rings){
  let d='';
  for(const r of rings){
    // split the ring wherever it crosses the antimeridian, so a polygon that
    // wraps (Russia, Fiji, the Aleutians) does not draw a bar across the map
    const runs=[]; let cur=[], prevLon=null;
    for(const [lon,lat] of r){
      if(prevLon!==null && Math.abs(lon-prevLon)>180){ if(cur.length>1) runs.push(cur); cur=[]; }
      cur.push([lon, Math.max(LAT_MIN-2, Math.min(LAT_MAX+2, lat))]);
      prevLon=lon;
    }
    if(cur.length>1) runs.push(cur);
    if(runs.length>1 && r.length>2){
      const first=runs[0], last=runs[runs.length-1];
      if(Math.abs(first[0][0]-last[last.length-1][0])<=180){ runs[0]=last.concat(first); runs.pop(); }
    }
    for(const run of runs){
      if(run.length<2) continue;
      let seg='';
      run.forEach(([lon,lat],i)=>{ const [X,Y]=prj(lon,lat); seg += (i?'L':'M')+X.toFixed(1)+' '+Y.toFixed(1); });
      d += seg + 'Z';
    }
  }
  return d;
}
const T_RAMP = ['#161E28','#281C1A','#472A27','#6A3633','#92413D','#C04C48','#EC5B57'];
const T_BINS = [10,20,32,46,62,80];   // upper edge of each band
function threatFill(v){
  if(v==null) return '#161E28';
  for(let i=0;i<T_BINS.length;i++) if(v<T_BINS[i]) return T_RAMP[i+1];
  return T_RAMP[6];
}
const ROLE = {
  hq:{c:'#C07C00',s:'HQ / service'}, unit:{c:'#E8A838',s:'Operational unit'},
  pipe:{c:'#9B61EA',s:'Training & recruitment'}, cont:{c:'#00AA58',s:'Contractor / institute'},
  ew:{c:'#D84497',s:'Electronic warfare'}, fwd:{c:'#009EBC',s:'Forward / occupied'},
  ally:{c:'#E64343',s:'Allied service'},
  host:{c:'#E8A838',s:'Hosting / bulletproof'}, cam:{c:'#E64343',s:'Compromised camera estate'},
  edge:{c:'#009EBC',s:'Edge-device beachhead'}, relay:{c:'#9B61EA',s:'Relay estate'},
  aitm:{c:'#D84497',s:'ISP-level AiTM'}, cloud:{c:'#00AA58',s:'Cloud C2 abuse'}
};
const HYB = {
  cable:{c:'#009EBC',s:'Subsea cable / seabed'}, gnss:{c:'#D84497',s:'GNSS jamming'},
  sab:{c:'#E64343',s:'Arson / sabotage'}, drone:{c:'#9B61EA',s:'Drone incursion'},
  ot:{c:'#F66D67',s:'OT / physical cyber effect'}, ddos:{c:'#C07C00',s:'Major DDoS'}
};
let LAYER='ops', SHOWHYB=false, SHOWLAB=true, mapDrawn=false;
const tip = $('#tip'), maparea = $('#maparea');
function showTip(e, html){
  tip.innerHTML = html;
  const r = maparea.getBoundingClientRect();
  let x = e.clientX - r.left + 14, y = e.clientY - r.top + 12;
  tip.style.opacity = '1';
  const tw = tip.offsetWidth, th = tip.offsetHeight;
  if(x + tw > r.width - 6) x = e.clientX - r.left - tw - 12;
  if(y + th > r.height - 6) y = Math.max(4, e.clientY - r.top - th - 10);
  tip.style.left = x+'px'; tip.style.top = y+'px';
}
function hideTip(){ tip.style.opacity='0'; }

function drawMap(){
  const svg = $('#map');
  svg.setAttribute('viewBox', `0 0 ${VB_W} ${VB_H}`);
  let s = `<rect x="0" y="0" width="${VB_W}" height="${VB_H}" fill="#060A0E"/><g id="lands">`;
  for(const f of WORLD){
    if(f.n==='Antarctica'||f.n==='Fr. S. Antarctic Lands') continue;
    const d = pathOf(f.g); if(!d) continue;
    let fill='#151D27', stroke='#232F3C', sw=0.5, extra='';
    if(LAYER==='eff'){
      if(SPECIAL[f.n]==='origin'){ fill='#2A2008'; stroke='#C07C00'; sw=0.9; }
      else if(SPECIAL[f.n]==='cobel'){ fill='#241A0C'; stroke='#8A6420'; sw=0.8; }
      else { const v = VICTIMS[f.n]; fill = threatFill(v?v.v:null); if(v) { stroke='#2C3A48'; } }
    } else {
      if(SPECIAL[f.n]==='origin'){ fill='#221A08'; stroke='#7A5410'; sw=0.8; }
      else if(SPECIAL[f.n]==='cobel'){ fill='#1E1709'; stroke='#5C441A'; sw=0.7; }
    }
    const V = VICTIMS[f.n];
    const payload = esc(JSON.stringify({n:f.n, v:V?V.v:null, a:V?V.a:0,i:V?V.i:0,h:V?V.h:0,o:V?V.o:0,e:V?V.e:0, t:V?V.n:'', sp:SPECIAL[f.n]||''}));
    s += `<path d="${d}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}" stroke-linejoin="round" class="cty" data-c="${payload}"${extra}/>`;
  }
  s += `</g><g id="pts">`;

  const set = LAYER==='ops' ? OPERATORS : LAYER==='infra' ? INFRA : [];
  for(const p of set){
    const [X,Y]=prj(p.lon,p.lat); const role=ROLE[p.r]||{c:'#E8A838',s:p.r};
    const r = 3 + p.w*0.42;
    const payload = esc(JSON.stringify({k:'pt', n:p.n, s:p.s, d:p.d, g:p.g, src:p.src, role:role.s}));
    s += `<circle cx="${X.toFixed(1)}" cy="${Y.toFixed(1)}" r="${(r+3.5).toFixed(1)}" fill="${role.c}" opacity="0.13" class="pt" data-c="${payload}"/>`;
    s += `<circle cx="${X.toFixed(1)}" cy="${Y.toFixed(1)}" r="${r.toFixed(1)}" fill="${role.c}" stroke="#060A0E" stroke-width="1.4" class="pt" data-c="${payload}"/>`;
  }
  if(SHOWHYB){
    for(const p of HYBRID){
      const [X,Y]=prj(p.lon,p.lat); const h=HYB[p.t]||{c:'#E8A838',s:p.t};
      const payload = esc(JSON.stringify({k:'hy', n:p.n, s:p.d, d:p.x, g:'', src:p.src, role:h.s}));
      s += `<rect x="${(X-3.6).toFixed(1)}" y="${(Y-3.6).toFixed(1)}" width="7.2" height="7.2" transform="rotate(45 ${X.toFixed(1)} ${Y.toFixed(1)})" fill="${h.c}" stroke="#060A0E" stroke-width="1.2" class="pt" data-c="${payload}"/>`;
    }
  }
  s += `</g><g id="labs" pointer-events="none">`;
  if(SHOWLAB && LAYER!=='eff'){
    const placed=[]; let n=0;
    for(const p of set.filter(p=>p.lab).sort((a,b)=>b.w-a.w)){
      if(n>=11) break;
      const [X,Y]=prj(p.lon,p.lat);
      let dy=null;
      for(const cand of [-11,13,-22,24,-33]){ if(!placed.some(q=>Math.abs(q[0]-X)<110 && Math.abs(q[1]-(Y+cand))<12)){ dy=cand; break; } }
      if(dy===null) continue; placed.push([X,Y+dy]); n++;
      const t = p.lab || (p.n.length>28 ? p.n.slice(0,27)+'…' : p.n);
      s += `<text x="${X.toFixed(1)}" y="${(Y+dy).toFixed(1)}" text-anchor="middle" font-family="ui-monospace,Menlo,monospace" font-size="8.5" fill="#C3D1E0" stroke="#060A0E" stroke-width="2.8" paint-order="stroke" letter-spacing="0.3">${esc(t)}</text>`;
    }
  }
  s += `</g>`;
  svg.innerHTML = s;
  mapDrawn = true;
  legend();
  $('#mapCount').innerHTML = LAYER==='eff'
    ? `<b>${Object.keys(VICTIMS).length}</b> scored countries`
    : `<b>${set.length}</b> sites${SHOWHYB?` · <b>${HYBRID.length}</b> hybrid events`:''}`;
  detail();
}
$('#map').addEventListener('mousemove', e=>{
  const t = e.target.closest('[data-c]'); if(!t){ hideTip(); return; }
  const o = JSON.parse(t.dataset.c);
  if(o.k==='pt'||o.k==='hy'){
    showTip(e, `<div class="h">${esc(o.role)}</div><div style="font-weight:600;margin-bottom:2px">${esc(o.n)}</div>
      <div class="b">${esc(o.s)}${o.d?'<br>'+esc(o.d):''}</div>
      <div class="g">${o.g?'grade '+esc(o.g)+' · ':''}${esc(o.src)}</div>`);
  } else {
    if(o.sp==='origin'){ showTip(e, `<div class="h">Origin</div><div class="b">Russian Federation — the state whose services, contractors and tolerated criminal market this board describes.</div>`); return; }
    if(o.sp==='cobel'){ showTip(e, `<div class="h">Co-belligerent</div><div class="b">Belarus — host to UNC1151/Ghostwriter and a staging geography rather than a victim geography.</div>`); return; }
    if(o.v==null){ showTip(e, `<div class="h">No score</div><div style="font-weight:600">${esc(o.n)}</div><div class="b">Not in the scored set: no publicly attributed Russia-nexus targeting found in the 2021–2026 record reviewed here. Absence of reporting is not absence of targeting.</div>`); return; }
    showTip(e, `<div class="h">Effects intensity ${o.v}/100</div><div style="font-weight:600;margin-bottom:3px">${esc(o.n)}</div>
      <div class="b">${o.t?esc(o.t)+'<br><br>':''}<span class="mono" style="font-size:10.5px;color:var(--ink3)">advisory ${o.a}/25 · incidents ${o.i}/30 · hybrid ${o.h}/20 · OT effect ${o.o}/15 · political ${o.e}/10</span></div>`);
  }
});
$('#map').addEventListener('mouseleave', hideTip);
function legend(){
  const el=$('#mapLegend'); let h='';
  if(LAYER==='eff'){
    h += `<div class="lgi"><span>Effects intensity</span><span class="ramp">${T_RAMP.slice(1).map(c=>`<i style="background:${c}"></i>`).join('')}</span><span>&lt;10 · 20 · 32 · 46 · 62 · 80+</span></div>`;
    h += `<div class="lgi"><span class="sw" style="background:#2A2008;border:1px solid #C07C00"></span>Origin</div>`;
    h += `<div class="lgi"><span class="sw" style="background:#241A0C;border:1px solid #8A6420"></span>Co-belligerent</div>`;
    h += `<div class="lgi"><span class="sw" style="background:#161E28"></span>Not scored</div>`;
  } else {
    const set = LAYER==='ops'?OPERATORS:INFRA;
    const seen=new Set(); set.forEach(p=>seen.add(p.r));
    h += Array.from(seen).map(r=>`<div class="lgi"><span class="sw" style="background:${ROLE[r].c}"></span>${ROLE[r].s}</div>`).join('');
  }
  if(SHOWHYB){
    const seen=new Set(); HYBRID.forEach(p=>seen.add(p.t));
    h += `<div class="lgi" style="opacity:.55">|</div>` + Array.from(seen).map(t=>`<div class="lgi"><span class="sw" style="background:${HYB[t].c};transform:rotate(45deg)"></span>${HYB[t].s}</div>`).join('');
  }
  el.innerHTML = h;
}
function siteTable(){
  if(LAYER==='eff'){
    const rows = Object.entries(VICTIMS).sort((a,b)=>b[1].v-a[1].v);
    return `<h2>Scored countries</h2><p class="note">Every component is shown so the total can be rebuilt or rejected. Sorted by composite intensity.</p>
    <div class="tw" style="margin-top:12px"><table><thead><tr><th>Country</th><th>Score</th><th>Advisory<br>/25</th><th>Incidents<br>/30</th><th>Hybrid<br>/20</th><th>OT effect<br>/15</th><th>Political<br>/10</th><th>Note</th></tr></thead><tbody>`
      + rows.map(([k,v])=>`<tr><td><b>${esc(k)}</b></td>
        <td><span class="pill" style="color:${threatFill(v.v)};border-color:${threatFill(v.v)};background:transparent">${v.v}</span></td>
        <td class="num">${v.a}</td><td class="num">${v.i}</td><td class="num">${v.h}</td><td class="num">${v.o}</td><td class="num">${v.e}</td>
        <td>${esc(v.n||'—')}</td></tr>`).join('') + `</tbody></table></div>`;
  }
  const set = LAYER==='ops'?OPERATORS:INFRA;
  return `<h2>${LAYER==='ops'?'Sites':'Infrastructure nodes'}</h2>
  <p class="note">The tabular twin of the map — every plotted point with its role, confidence grade and source.</p>
  <div class="tw" style="margin-top:12px"><table><thead><tr><th>Node</th><th>Role</th><th>Where</th><th>Grade</th><th>What it is</th><th>Src</th></tr></thead><tbody>`
  + set.map(p=>`<tr><td><b>${esc(p.n)}</b></td>
      <td><span class="pill" style="color:${ROLE[p.r].c};border-color:${ROLE[p.r].c};background:transparent">${esc(ROLE[p.r].s)}</span></td>
      <td>${esc(p.s)}</td><td class="mono">${esc(p.g)}</td><td>${esc(p.d)}</td><td>${refs([p.src])}</td></tr>`).join('')
  + `</tbody></table></div>`;
}
function detail(){
  const el = $('#mapDetail');
  if(LAYER==='ops'){
    el.innerHTML = `<h2>Where the people are</h2>
    <p>Almost the entire Russian offensive cyber establishment sits inside one city. Two GRU unit addresses entered the public record through a 2018 US indictment and have never been contradicted: Unit 26165 on Komsomolsky Prospekt and Unit 74455 in a Khimki building its own officers call the Tower${refs(['CC-57'])}. The SVR works from Yasenevo, the FSB from Lubyanka, and the training pipeline that feeds all of them from a university four kilometres from Red Square${refs(['CC-28'])}.</p>
    <p>The analytic value of this concentration is limited but real. It tells you the time zone, which sets the tempo. It tells you the recruitment pipeline is an institution with a published intake rather than a talent market, so capacity does not decay under sanctions. And it tells you that the only geography sanctions can reach — the contractor and hosting layer — is the outer ring, not the core.</p>
    <div class="grid g2" style="margin-top:14px">
      <div class="panel"><h4 style="margin-top:0">The one exception worth knowing</h4><p class="note" style="margin:0">Kaliningrad. The EU sanctioned the 142nd Separate Electronic Warfare Battalion there in December 2025 for GNSS interference across member states${refs(['CC-26'])} — the only formal link between a named Russian unit outside Moscow and a persistent effect on NATO territory. It is also the only Russian cyber-adjacent capability whose geography genuinely constrains its reach.</p></div>
      <div class="panel"><h4 style="margin-top:0">What this map cannot show</h4><p class="note" style="margin:0">Unit 29155's and Centre 16's placements are approximate and graded accordingly. No open source places FSB Centre 16 to a building. Rostov-on-Don and Sevastopol are inferred from campaign geography, not from a named facility, and are graded C3. Treat every C3 point as a hypothesis.</p></div>
    </div>`;
  } else if(LAYER==='infra'){
    el.innerHTML = `<h2>Where the packets come from</h2>
    <p>This is the layer that breaks the intuitive picture. Very little Russian operational traffic originates in Russia. It comes from a hosting network registered in Moldova and operated from the Netherlands${refs(['CC-30'])}, from consumer routers in a hundred and twenty countries${refs(['CC-22'])}, from end-of-life Cisco equipment inside the victim's own sector${refs(['CC-02'])}, and increasingly from ordinary cloud-storage APIs where the beacon is indistinguishable from any other HTTPS session${refs(['CC-21'])}.</p>
    <p>The defensive consequence is blunt: <b>source geography proves nothing, and geo-blocking Russia buys you almost nothing.</b> A router implant in a residential block puts the operator inside your country, inside your time zone and inside your ISP's address space. Build detection on behaviour — configuration exports, new tunnels, packet-capture utilities appearing on edge devices, consent grants to unfamiliar applications — not on where the connection appears to start.</p>
    <div class="grid g3" style="margin-top:14px">
      <div class="panel"><h4 style="margin-top:0">The camera belt</h4><p class="note" style="margin:0">Unit 26165 has run a large-scale campaign against internet-exposed RTSP cameras since March 2022, weighted 81% Ukraine, 9.9% Romania, 4.0% Poland${refs(['CC-01'])}. In July 2026 Dutch intelligence disclosed compromised cameras on military logistics routes in the Netherlands, with image-recognition software applied to the feeds${refs(['CC-17'])}. This is cyber collection producing physical targeting data — the clearest single illustration of the fusion thesis.</p></div>
      <div class="panel"><h4 style="margin-top:0">The hosting shell game</h4><p class="note" style="margin:0">Stark Industries was founded two weeks before the invasion, sanctioned by the EU in May 2025, and reopened under a Dutch entity within weeks — the owners having had roughly twelve days of effective notice${refs(['CC-30'])}. Aeza, Zservers and Media Land followed the same arc. Sanctions here move the paperwork; the packets keep flowing.</p></div>
      <div class="panel"><h4 style="margin-top:0">The position inside Russia</h4><p class="note" style="margin:0">FSB Centre 16 has demonstrated adversary-in-the-middle at the ISP layer on Russian domestic transit, installing rogue root certificates against embassies in Moscow${refs(['CC-08'])}. Practical rule for anyone who travels: a device that has used Russian domestic internet should be treated as compromised and rebuilt, not cleaned.</p></div>
    </div>`;
  } else {
    el.innerHTML = `<h2>Where the consequences land</h2>
    <p>Ukraine absorbs the destructive effort and always has. What changed between 2024 and 2026 is that four NATO states — Poland, Norway, Denmark and Sweden — recorded physical or operational-technology effect on their own territory${refs(['CC-14','CC-35','CC-36','CC-37'])}, and none of it required an exploit. Default credentials, exposed human-machine interfaces and internet-reachable controllers were enough.</p>
    <p>Microsoft's 2025 reporting put the ten countries most affected by Russian activity all inside NATO, a 25% year-on-year rise${refs(['CC-09'])}. The shape of the map follows two variables more than any other: how much a country has given Ukraine, and how exposed its logistics geography is. Poland scores highest among NATO members on both counts and is, correspondingly, the most attacked.</p>
    <div class="grid g2" style="margin-top:14px">
      <div class="panel"><h4 style="margin-top:0">The Hungary anomaly</h4><p class="note" style="margin:0">Hungary appears in advisories as a camera-belt geography, yet CSIS records no Russian physical attacks on Hungarian territory, and the same is true of Serbia${refs(['CC-24'])}. Political alignment is visible in the incident data. It is the clearest available evidence that this campaign is centrally directed and politically calibrated rather than opportunistic.</p></div>
      <div class="panel"><h4 style="margin-top:0">Reporting bias, stated</h4><p class="note" style="margin:0">This score measures <b>disclosed</b> targeting. Countries with strong services and a policy of naming Russia publicly score higher than equally targeted countries that stay silent. Read a low score in a capable, candid state as signal; read a low score elsewhere as an open question, not as safety.</p></div>
    </div>`;
  }
  el.insertAdjacentHTML('beforeend', siteTable());
  $$('#mapDetail .ref').forEach(bindRef);
}
$$('.mapctl .seg button[data-layer]').forEach(b=>b.addEventListener('click',()=>{
  LAYER=b.dataset.layer; $$('.mapctl .seg button[data-layer]').forEach(x=>x.setAttribute('aria-pressed',String(x===b))); drawMap();
}));
$('#hybToggle').addEventListener('change',e=>{ SHOWHYB=e.target.checked; drawMap(); });
$('#labToggle').addEventListener('change',e=>{ SHOWLAB=e.target.checked; drawMap(); });

/* ---------- FORECAST ---------- */
let TIERF='all';
function tierMatch(t){ if(TIERF==='all') return true; return t.toLowerCase().includes(TIERF.toLowerCase()); }
function renderFore(){
  const set = SECTORS.filter(s=>tierMatch(s.tier)).slice().sort((a,b)=>b.pn-a.pn);
  $('#foreBars').innerHTML = set.map(s=>`
    <div class="bar" title="${esc(s.p)} — ${s.pn}%">
      <div class="n">${esc(s.s)}</div>
      <div class="t"><i style="width:${s.pn}%;background:${threatFill(s.pn)}"></i></div>
      <div class="v">${s.pn}%</div>
    </div>`).join('');
  $('#foreDetail').innerHTML = set.map(s=>`
    <div class="panel" style="margin-bottom:10px;border-left:3px solid ${threatFill(s.pn)}">
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:baseline;margin-bottom:6px">
        <span style="font-size:15px;font-weight:650;color:var(--ink)">${esc(s.s)}</span>
        <span class="pill ${s.pn>=90?'p-crit':s.pn>=78?'p-high':s.pn>=60?'p-med':'p-low'}">${esc(s.p)} · ${s.pn}%</span>
        <span class="pill p-un">${esc(s.tier)}</span>
        <span class="mono" style="font-size:10.5px;color:var(--ink3)">${esc(s.a)}</span>
      </div>
      <div class="note" style="margin-bottom:6px"><b style="color:var(--ink2)">Most likely route in</b> · ${esc(s.vec)}</div>
      <p style="margin:0 0 8px">${esc(s.why)}${refs(s.src)}</p>
      <div class="note" style="border-top:1px dashed var(--line2);padding-top:8px;margin:0"><b style="color:var(--ink2)">First thing you would see</b> · ${esc(s.obs)}</div>
    </div>`).join('');
  $$('#foreDetail .ref').forEach(bindRef);
}
$$('#t-fore .seg button[data-tier]').forEach(b=>b.addEventListener('click',()=>{
  TIERF=b.dataset.tier; $$('#t-fore .seg button[data-tier]').forEach(x=>x.setAttribute('aria-pressed',String(x===b))); renderFore();
}));
renderFore();

/* ---------- TEMPO ---------- */
const DAYS=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
let TZ=3;
const A_RAMP=['#161E28','#231D14','#332610','#4A340F','#66470E','#83590A','#A06B05','#BD7D02','#D48E00'];
function ampl(v){ return A_RAMP[Math.max(0,Math.min(8,Math.round(v*8)))]; }
function renderClock(){
  const off = TZ-3;
  let h = '<tr><th class="rl"></th>' + Array.from({length:24},(_,i)=>`<th>${String(i).padStart(2,'0')}</th>`).join('') + '</tr>';
  for(let d=0; d<7; d++){
    h += `<tr><td class="rl">${DAYS[d]}</td>`;
    for(let dh=0; dh<24; dh++){
      const mh = ((dh - off) % 24 + 24) % 24;
      const v = TEMPO.dayMul[d]*TEMPO.hourMsk[mh];
      h += `<td><div class="cell" style="background:${ampl(v)}" title="${DAYS[d]} ${String(dh).padStart(2,'0')}:00 — relative intensity ${(v*100).toFixed(0)}% (${String(mh).padStart(2,'0')}:00 Moscow)"></div></td>`;
    }
    h += '</tr>';
  }
  $('#clockTbl').innerHTML = h;
  $('#tzLabel').textContent = ({3:'Moscow · UTC+3',0:'UTC',1:'Central Europe · UTC+1','-5':'US Eastern · UTC−5','-8':'US Pacific · UTC−8'})[String(TZ)];
}
$$('#t-tempo .seg button[data-tz]').forEach(b=>b.addEventListener('click',()=>{
  TZ=parseInt(b.dataset.tz,10); $$('#t-tempo .seg button[data-tz]').forEach(x=>x.setAttribute('aria-pressed',String(x===b))); renderClock();
}));
renderClock();

(function destChart(){
  const W=520,H=190,L=34,B=26,T=10,R=8;
  const iw=W-L-R, ih=H-T-B, bw=iw/24;
  let s=`<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;display:block" role="img" aria-label="Modelled destructive-execution timing by hour of victim local time">`;
  [0,0.25,0.5,0.75,1].forEach(g=>{ const y=T+ih-g*ih;
    s+=`<line x1="${L}" y1="${y.toFixed(1)}" x2="${W-R}" y2="${y.toFixed(1)}" stroke="#1D2733" stroke-width="1"/>`;
    s+=`<text x="${L-6}" y="${(y+3.5).toFixed(1)}" text-anchor="end" font-family="ui-monospace,Menlo,monospace" font-size="8.5" fill="#63748A">${Math.round(g*100)}</text>`; });
  TEMPO.destructive.forEach((v,i)=>{
    const bh=v*ih, x=L+i*bw+1.2, y=T+ih-bh;
    s+=`<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${(bw-2.4).toFixed(1)}" height="${bh.toFixed(1)}" rx="2" fill="${i<6||i>=18?'#DE4E4B':'#47211E'}"><title>${String(i).padStart(2,'0')}:00 victim local — relative likelihood ${(v*100).toFixed(0)}%</title></rect>`;
  });
  [0,6,12,18,23].forEach(i=>{ s+=`<text x="${(L+i*bw+bw/2).toFixed(1)}" y="${H-9}" text-anchor="middle" font-family="ui-monospace,Menlo,monospace" font-size="8.5" fill="#63748A">${String(i).padStart(2,'0')}</text>`; });
  s+=`<text x="${L}" y="${H-1}" font-family="ui-monospace,Menlo,monospace" font-size="8" fill="#465667" letter-spacing="0.1em">HOUR · VICTIM LOCAL TIME</text>`;
  s+=`</svg>`;
  $('#destChart').innerHTML = s;
})();

$('#anchorWrap').innerHTML = TEMPO.anchors.map(a=>`
  <div class="panel"><h4 style="margin-top:0">${esc(a.t)}${refs([a.s])}</h4><p class="note" style="margin:0">${esc(a.d)}</p></div>`).join('');

$('#seasonStrip').innerHTML = TEMPO.season.map((m,i)=>
  `<div class="m" data-i="${i}" style="background:${ampl(m.v*0.95)};cursor:pointer" title="${esc(m.n)}">${m.m}</div>`).join('');
function seasonNote(i){ const m=TEMPO.season[i];
  $('#seasonNote').innerHTML = `<div class="mono" style="font-size:10px;letter-spacing:.14em;color:var(--amber);text-transform:uppercase">${m.m} · index ${(m.v*100).toFixed(0)}</div><p class="note" style="margin:6px 0 0">${esc(m.n)}</p>`; }
seasonNote(11);
$('#seasonStrip').addEventListener('click', e=>{ const t=e.target.closest('[data-i]'); if(t) seasonNote(+t.dataset.i); });

$('#trigTbl').innerHTML = `<thead><tr><th>Stimulus</th><th>Response</th><th>Observed lag</th><th>Src</th></tr></thead><tbody>` +
  TEMPO.triggers.map(t=>`<tr><td><b>${esc(t.e)}</b></td><td>${esc(t.r)}</td><td class="num mono">${esc(t.lag)}</td><td>${refs([t.src])}</td></tr>`).join('') + '</tbody>';

/* ---------- ZERO-DAY ---------- */
$('#zdTiles').innerHTML = [
  ['Zero-days in the wild, 2025', ZD_STATS.total2025, '', 'Google Threat Intelligence Group'],
  ['Hit enterprise technology', ZD_STATS.enterprise+' ('+ZD_STATS.entPct+'%)','am','an all-time high'],
  ['In security &amp; networking products', ZD_STATS.secnet,'ro','the edge is the exploit market'],
  ['Attributed to PRC-nexus groups', '≥'+ZD_STATS.prc,'cy','double the 2024 count'],
  ['Attributed to Russian state espionage', ZD_STATS.ru_state,'am','none in the 2025 set'],
  ['Russia-nexus, financially motivated tier', '3+','ro','RomCom, UNC2165, FIN11/CL0P']
].map(([l,v,c,d])=>`<div class="tile"><div class="l">${l}</div><div class="v ${c}">${v}</div><div class="d">${d}</div></div>`).join('');
$('#zdNote').innerHTML = esc(ZD_STATS.note) + refs(['CC-10']);

$('#zdForecast').innerHTML = ZD_FORECAST.map(f=>`
  <div class="panel" style="margin-bottom:10px;border-left:3px solid ${threatFill(f.p)}">
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:baseline;margin-bottom:5px">
      <span class="mono" style="font-size:11px;color:var(--ink4);letter-spacing:.12em">#${f.r}</span>
      <span style="font-size:15px;font-weight:650;color:var(--ink)">${esc(f.cls)}</span>
      <span class="pill ${f.p>=80?'p-crit':f.p>=65?'p-high':f.p>=40?'p-med':'p-un'}">priority ${f.p}</span>
    </div>
    <div class="mono" style="font-size:11px;color:var(--ink3);margin-bottom:7px">${esc(f.ex)}</div>
    <p style="margin:0 0 8px">${esc(f.why)}${refs(f.src)}</p>
    <div class="note" style="border-top:1px dashed var(--line2);padding-top:8px;margin:0"><b style="color:var(--ink2)">Do this</b> · ${esc(f.def)}</div>
  </div>`).join('');

let ZF='all';
function renderZd(){
  const set = ZD_LEDGER.filter(r=> ZF==='all' || r.z.startsWith('0-day'));
  $('#zdTbl').innerHTML = `<thead><tr><th>Year</th><th>Vulnerability / capability</th><th>Actor</th><th>Class</th><th>Type</th><th>Note</th><th>Src</th></tr></thead><tbody>` +
    set.map(r=>`<tr><td class="num mono">${esc(r.y)}</td><td><b>${esc(r.cve)}</b></td><td>${esc(r.act)}</td><td>${esc(r.cls)}</td>
      <td><span class="pill ${r.z.startsWith('0-day')?'p-crit':r.z==='—'?'p-un':'p-med'}">${esc(r.z)}</span></td><td>${esc(r.note)}</td><td>${refs([r.src])}</td></tr>`).join('') + '</tbody>';
  $$('#zdTbl .ref').forEach(bindRef);
}
$$('#t-zd .seg button[data-zf]').forEach(b=>b.addEventListener('click',()=>{
  ZF=b.dataset.zf; $$('#t-zd .seg button[data-zf]').forEach(x=>x.setAttribute('aria-pressed',String(x===b))); renderZd();
}));
renderZd();

/* ---------- TIMELINE ---------- */
let TF='all';
function renderTl(){
  const set = TIMELINE.filter(r=> TF==='all' || r.k===TF);
  $('#tlWrap').innerHTML = set.map(r=>`
    <div class="tlr ${r.k}"><div class="in">
      <div class="d">${esc(r.d)}</div>
      <div class="t">${esc(r.t)}</div>
      <div class="x">${esc(r.x)}${refs([r.src])}</div>
    </div></div>`).join('');
  $$('#tlWrap .ref').forEach(bindRef);
}
$$('#t-time .seg button[data-tf]').forEach(b=>b.addEventListener('click',()=>{
  TF=b.dataset.tf; $$('#t-time .seg button[data-tf]').forEach(x=>x.setAttribute('aria-pressed',String(x===b))); renderTl();
}));
renderTl();

/* ---------- I&W ---------- */
const ST = {observed:['p-crit','Observed'], 'not observed':['p-med','Not observed'], unseen:['p-un','Unseen']};
$('#iwWrap').innerHTML = ['observed','not observed','unseen'].map(st=>`
  <div>
    <h4 style="margin-top:0">${ST[st][1]} <span class="pill ${ST[st][0]}">${IW.filter(x=>x.st===st).length}</span></h4>
    ${IW.filter(x=>x.st===st).map(x=>`
      <div class="panel" style="margin-bottom:8px;padding:12px">
        <div style="font-size:13px;color:var(--ink);font-weight:550;line-height:1.45">${esc(x.i)}</div>
        <div class="note" style="margin:5px 0 0;font-size:12px">${esc(x.w)}${refs([x.src])}</div>
      </div>`).join('')}
  </div>`).join('');
const bp = Math.round(nUn/IW.length*100);
$('#blindPct').textContent = bp + '% (' + nUn + ' of ' + IW.length + ')';
$('#blindBar').style.cssText = `width:${bp}%;background:linear-gradient(90deg,#2A3745,#63748A)`;

/* ---------- FEED ---------- */
const okR = FEED_RSS.filter(f=>f.st==='ok').length;
$('#feedTiles').innerHTML = [
  ['RSS lanes verified live', String(okR)+' of '+FEED_RSS.length,'am','HTTP 200, XML returned, 17 Sep 2026'],
  ['Telegram lanes verified', String(FEED_TG.length),'cy','public t.me/s preview resolves'],
  ['Lanes blocked to automated clients', String(FEED_RSS.filter(f=>f.st==='blocked').length+FEED_SOCIAL.length),'ro','need browser context or credentials'],
  ['Outbound calls made by this page','0','','self-contained by design']
].map(([l,v,c,d])=>`<div class="tile"><div class="l">${l}</div><div class="v ${c}">${v}</div><div class="d">${d}</div></div>`).join('');
const stPill = s => s==='ok'?'<span class="pill p-ok">live</span>' : s==='blocked'?'<span class="pill p-high">blocked</span>' : '<span class="pill p-un">no feed</span>';
$('#feedRss').innerHTML = FEED_RSS.map(f=>`
  <div class="lane"><div class="n">${esc(f.n)}<span>${esc(f.u)}</span><span style="color:var(--ink3);font-family:var(--sans);font-size:12px">${esc(f.k)}</span></div><div>${stPill(f.st)}</div></div>`).join('');
$('#feedTg').innerHTML = FEED_TG.map(f=>`
  <div class="lane"><div class="n">${esc(f.n)}<span>t.me/s/${esc(f.h)}</span><span style="color:var(--ink3);font-family:var(--sans);font-size:12px">${esc(f.k)}</span></div><div>${stPill(f.st)}</div></div>`).join('');
$('#feedSoc').innerHTML = FEED_SOCIAL.map(f=>`
  <div class="lane"><div class="n">${esc(f.n)}<span>${esc(f.u)}</span><span style="color:var(--ink3);font-family:var(--sans);font-size:12px">${esc(f.k)}</span></div><div>${stPill(f.st)}</div></div>`).join('');

/* ---------- SOURCES ---------- */
const gcount = {};
SRC.forEach(s=>{ gcount[s[1]] = (gcount[s[1]]||0)+1; });
const A = Object.entries(gcount).filter(([k])=>k[0]==='A').reduce((a,[,v])=>a+v,0);
const B = Object.entries(gcount).filter(([k])=>k[0]==='B').reduce((a,[,v])=>a+v,0);
const C = Object.entries(gcount).filter(([k])=>k[0]==='C').reduce((a,[,v])=>a+v,0);
$('#gradeTiles').innerHTML = [
  ['Total sources', String(SRC.length),'am',''],
  ['Grade A — official', String(A),'','advisories, sanctions, courts, NATO'],
  ['Grade B — reliable', String(B),'cy','vendor telemetry, investigations, think tanks'],
  ['Grade C — single-source', String(C),'ro','held at lower confidence throughout']
].map(([l,v,c,d])=>`<div class="tile"><div class="l">${l}</div><div class="v ${c}">${v}</div><div class="d">${d}</div></div>`).join('');
$('#srcWrap').innerHTML = SRC.map(([id,g,m,u])=>`
  <div class="src"><div class="id">${id}</div><div class="m">${m}<span class="u">${esc(u)}</span></div><div class="g">${g}</div></div>`).join('');

/* ---------- ref tooltips ---------- */
function bindRef(el){
  const s = SRCMAP[el.dataset.s]; if(!s) return;
  const plain = s[2].replace(/<[^>]+>/g,'');
  el.setAttribute('title', s[0] + ' · grade ' + s[1] + ' — ' + plain);
  el.setAttribute('role','link'); el.setAttribute('tabindex','0');
  el.addEventListener('click', ()=>{ show('src'); setTimeout(()=>{
    const row = $$('#srcWrap .src').find(r=>r.querySelector('.id').textContent===s[0]);
    if(row){ row.scrollIntoView({block:'center'}); row.style.background='rgba(232,168,56,.07)'; setTimeout(()=>row.style.background='',1600); }
  },40); });
  el.addEventListener('keydown', e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); el.click(); } });
}
$$('.ref').forEach(bindRef);

/* ---------- boot ---------- */
const start = (location.hash||'').slice(1);
show(TABS.flatMap(g=>g.items.map(i=>i[0])).includes(start) ? start : 'bluf');
window.addEventListener('resize', ()=>{ if(!$('#t-map').hidden) drawMap(); }, {passive:true});

