
(function(){
"use strict";
var WORLD = JSON.parse(document.getElementById("lg-world").textContent);
var D = JSON.parse(document.getElementById("lg-data").textContent);
var INC=D.inc, SITES=D.sites, LEDGER=D.ledger, BENCH=D.sources, REFS=D.refs;
var REFMAP={}; REFS.forEach(function(r){REFMAP[r.i]=r;});

/* ═══ constants ═══════════════════════════════════════════ */
var DOMAINS=["Sabotage & lethal action","Air & electromagnetic","Undersea & maritime","Espionage & networks","Information operations","Expeditionary & PMC"];
var SLOT=["--s1","--s2","--s3","--s4","--s5","--s6"];
var DCOL={}; DOMAINS.forEach(function(d,i){DCOL[d]="var("+SLOT[i]+")";});
var GRADES=["A","B","C","D"], GW={A:1,B:.85,C:.65,D:.4};
var ACTORLAB={"GRU-29155":"GRU Unit 29155","GRU-other":"GRU (other)","SVR":"SVR","FSB":"FSB","Wagner":"Wagner Group",
 "AfricaCorps":"Africa Corps","Navy-GUGI":"Navy / GUGI","ShadowFleet":"Shadow fleet","InfoOps":"Influence apparatus",
 "Proxy":"Recruited proxy","MoD/RuAF":"MoD / Armed Forces","Rosgvardia":"Rosgvardia","Unattributed":"Unattributed"};
var SFLAB={legal:"Court & legal",govt:"Government",research:"Research body",press:"Investigative press",technical:"Technical feed"};
var CALIAS={"United States":"United States of America","Central African Republic":"Central African Rep.","Equatorial Guinea":"Eq. Guinea"};
var QMAX=18;
function css(v){return getComputedStyle(document.documentElement).getPropertyValue(v).trim();}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}
function qi(d){var y=+d.slice(0,4),m=+(d.slice(5,7)||1); return y<2022?-1:(y-2022)*4+Math.floor((m-1)/3);}
function qlab(i){return i<0?"≤2021":(2022+Math.floor(i/4))+" Q"+((i%4)+1);}
function refHTML(id){ if(!id) return ""; return '<span class="ref" data-ref="'+id+'">GC-'+id+'</span>'; }

/* ═══ analytic content ════════════════════════════════════ */
var BLUF = "Russia runs a single extraterritorial covert-action programme across six operational domains and seventy-five countries, and it has changed shape twice since 2022. The expulsion of more than four hundred declared officers from Europe in spring 2022 pushed execution onto disposable, locally-recruited proxies paid in cryptocurrency and tasked over Telegram. The 2023 formation of the GRU's Department for Special Tasks then put European sabotage and the African expeditionary mission under one commander. Physical effects have since crossed from property damage into lethal-risk yields — C-4 under a Polish freight line, PETN and RDX on drones at Leipzig — while the influence layer has reoriented from persuading readers to contaminating machine retrieval. The campaign is not, on this evidence, preparation for war: its target set is overwhelmingly the logistics of Ukrainian aid, and its tradecraft is cheap, attributable and frequently caught. The more consequential trend is on the other side of the glass. Attribution capacity is contracting — two UN panels vetoed away, two US attribution bodies closed — faster than activity is falling, and the coming fall in grade-A records will look like a decline in activity when it is a decline in observation.";

var TILES=[
 {n:"Posture",v:"ELEVATED–HIGH",s:"Sustained, industrialised, still sub-Article-5"},
 {n:"Peak quarter",v:"2025 Q4",s:"Rail charges, parcel plots, Baltic cable series"},
 {n:"Leading hypothesis",v:"COERCIVE SIGNALLING",s:"H2 — fewest inconsistencies; H3 close second"},
 {n:"Blind fraction",v:"SUBSTANTIAL",s:"Six I&W rows are structurally unobservable"}
];

var KJ=[
{id:"KJ-1",t:"The extraterritorial campaign is now <em>very likely</em> run as one integrated programme under the GRU's Department for Special Tasks rather than as separate service efforts.",b:"Very likely",c:"Moderate",g:"B2",
 basis:"The 2023 stand-up of the Department for Special Tasks under Andrei Averyanov and Ivan Kasianenko; the same officer subsequently holding Africa Corps oversight; and the migration of Unit 29155's signature tradecraft — disposable proxies, crypto payment, Telegram tasking — into theatres as far apart as Poland and Mali.",
 chg:"Evidence of separate FSB- or SVR-run sabotage chains operating without GRU deconfliction, or a public reorganisation splitting the European and African mandates.",refs:[]},
{id:"KJ-2",t:"Execution has <em>almost certainly</em> shifted from professional officers to disposable, locally-recruited proxies.",b:"Almost certainly",c:"High",g:"A1",
 basis:"Thirty-two people charged in Poland alone — Polish, Russian, Ukrainian, Belarusian and Colombian nationals; the Vilnius IKEA arson tasked to a teenager for €10,000; PET's September 2026 statement describing recruitment through social media, gaming platforms and Telegram paid in cryptocurrency; the UK Leyton warehouse convictions under the National Security Act 2023.",
 chg:"A return to officer-executed operations, which would signal either proxy-pipeline failure or a decision to accept attribution.",refs:[]},
{id:"KJ-3",t:"Physical sabotage in Europe crossed from property damage into lethal-risk yields during 2024–26, and this is <em>likely</em> deliberate rather than accidental escalation.",b:"Likely",c:"Moderate",g:"B2",
 basis:"The DHL Leipzig and Birmingham incendiaries, assessed by Polish prosecutors as a rehearsal for devices aboard North America-bound cargo aircraft; a C-4 charge detonated under a Polish freight line in November 2025; 800g of PETN and a separate 50g RDX device on drones at Leipzig in August 2026; and the plot against Rheinmetall's chief executive.",
 chg:"Evidence that device yields were deliberately sub-lethal, or a documented tasking instruction limiting casualties.",refs:[]},
{id:"KJ-4",t:"The September–November 2025 drone wave over NATO states is <em>unlikely</em> to be attributable to Russia on the currently available public evidence, whatever the political framing.",b:"Unlikely (as attributable)",c:"Moderate",g:"C3",
 basis:"Roughly thirty sightings across six countries, almost no airframes recovered, no telemetry or control evidence published, and not one formal national attribution — against a record in which every other domain has produced named vessels, named handlers and convictions.",
 chg:"Recovery and forensic exploitation of an airframe, or a formal national attribution with published evidence.",refs:[]},
{id:"KJ-5",t:"Attribution capacity is <em>very likely</em> contracting faster than activity is falling.",b:"Very likely",c:"High",g:"A2",
 basis:"The closure of the State Department's Global Engagement Center and its successor R/FIMI in 2024–25; Russian vetoes ending the UN Panels of Experts for Mali in 2023 and North Korea in 2024; and the concentration of the newest records in confidence grade C while total records rise.",
 chg:"A new standing attribution mechanism, or a sustained rise in grade-A records through 2027.",refs:[]},
{id:"KJ-6",t:"Baltic undersea damage is <em>more likely than not</em> the product of a deniable commercial-shipping model rather than of GUGI's special-mission fleet.",b:"More likely than not",c:"Moderate",g:"B3",
 basis:"Every dated cable break attributable to a named vessel involves a shadow-fleet or third-flag merchant dragging an anchor; GUGI's Yantar has been repeatedly observed surveying UK, Irish and Norwegian waters without a single attributed break; and several prosecutions have collapsed on the difficulty of separating deliberate drag from genuine accident.",
 chg:"A break attributed to a submersible or diver emplacement, or a prosecution establishing tasking from a Russian service to a merchant master.",refs:[]},
{id:"KJ-7",t:"The African expeditionary project <em>very likely</em> passed its high-water mark during 2026.",b:"Very likely",c:"Moderate",g:"B2",
 basis:"The loss of Kidal, Tessalit and Aguelhok under an Algerian-mediated withdrawal; the killing of Mali's defence minister, Africa Corps's principal counterpart; and a recruitment target cut from 40,000 to 20,000 and never met — offset only by new access in Togo, Equatorial Guinea and Madagascar, which buys influence rather than control.",
 chg:"A durable reversal in northern Mali, or a functioning naval facility at Port Sudan.",refs:[]},
{id:"KJ-8",t:"The information-operations layer has <em>almost certainly</em> reoriented from persuading people to contaminating machines.",b:"Almost certainly",c:"High",g:"A2",
 basis:"Portal Kombat's migration to roughly 10,000 articles a day across 101 sites in more than fifty languages with negligible human readership; NewsGuard's finding that leading chatbots repeated Pravda-laundered claims a third of the time; and the operators' own stated intent to change what AI systems say.",
 chg:"A measurable fall in model contamination rates, or a redeployment of resources back to human-facing channels.",refs:[]},
{id:"KJ-9",t:"Loss of the declared diplomatic platform in 2022 <em>likely</em> caused the shift to proxies rather than merely coinciding with it.",b:"Likely",c:"Moderate",g:"B2",
 basis:"More than four hundred officers expelled across Europe in spring 2022; SUPO's assessment that Russian human-intelligence capacity in Finland was substantially degraded and activity pushed toward cyber and proxy methods; and the near-absence of proxy-sabotage prosecutions before 2023 against their dominance afterwards.",
 chg:"Evidence that the proxy model was already resourced and planned before February 2022.",refs:[]}
];

var IW=[
{s:"ACTIVE",t:"National prosecutions naming a Russian handler",w:"Poland charged a Russian national in December 2025 with directing a sabotage network from Moscow Oblast; Lithuania charged fifteen over the 2024 arson campaign.",k:"act"},
{s:"ACTIVE",t:"Explosive charges against rail infrastructure",w:"C-4 under the Warsaw–Lublin–Hrubieszów freight line, November 2025 — the first confirmed military explosive against European rail in this campaign.",k:"act"},
{s:"ACTIVE",t:"Explosive devices in air-cargo and airport environments",w:"PETN and RDX drone devices at Leipzig/Halle, August 2026, following the 2024 DHL incendiary series.",k:"act"},
{s:"ACTIVE",t:"Cable or pipeline damage with a shadow-fleet vessel in track",w:"Continuous since October 2023; most recent attributable events January 2026 in the Gulf of Finland and the Šventoji–Liepāja corridor.",k:"act"},
{s:"ACTIVE",t:"GUGI hull loitering inside a NATO exclusive economic zone",w:"Yantar north of Scotland, November 2025, including directed-energy harassment of RAF aircrew.",k:"act"},
{s:"ACTIVE",t:"GNSS interference beyond the Kaliningrad and Kola source areas",w:"Persistent across the Baltic, Black Sea and eastern Mediterranean; Lloyd's List rates these among the most intense spoofing environments worldwide.",k:"act"},
{s:"ACTIVE",t:"AI-generated content targeting a national election",w:"Voice-cloned audio impersonating fifty-plus organisations in Armenia, June 2026; deepfake video ahead of the US midterms, September 2026.",k:"act"},
{s:"ACTIVE",t:"Lethal plots against defence executives, defectors and dissidents",w:"A $40,000 murder-for-hire indictment unsealed in Brooklyn, September 2026; the Papperger plot in 2024; Kuzminov killed in Spain in 2023.",k:"act"},
{s:"ACTIVE",t:"Compatriot-network expulsion or closure by a host state",w:"Berlin's Russian House ordered closed September 2026 — the largest in the Europe-wide rollback that began in Ljubljana in 2022.",k:"act"},
{s:"LATENT",t:"Africa Corps territorial consolidation",w:"Reversed in 2026: Kidal, Tessalit and Aguelhok lost, Anéfis contested. New access in Togo, Equatorial Guinea and Madagascar is influence, not control.",k:"lat"},
{s:"LATENT",t:"Drone incursions over nuclear-sharing and fifth-generation air bases",w:"Volkel, Kleine Brogel, Skrydstrup and Ørland during the 2025 wave; no recurrence at that scale in 2026 and still no attribution.",k:"lat"},
{s:"DORMANT",t:"Officer-executed operations on NATO soil",w:"Not observed since the 2022 expulsions. A return would signal proxy-pipeline failure or a decision to accept attribution.",k:"dor"},
{s:"UNSEEN",t:"Tasking traffic between handler and proxy",w:"Recruitment is visible only after a prosecution discloses it. Every network in this dataset was observed at the point of arrest, never at the point of tasking — so the register is a record of failures, not of operations.",k:"uns"},
{s:"UNSEEN",t:"Operations that succeeded without attribution",w:"An arson recorded as an electrical fault, a cable break logged as a fishing accident and a fire ruled accidental all leave no trace here. The dataset counts what was noticed.",k:"uns"},
{s:"UNSEEN",t:"Seabed device emplacement",w:"No public sensing regime detects a payload placed on a cable or pipeline. Survey activity is observable; emplacement is not.",k:"uns"},
{s:"UNSEEN",t:"Aborted and stood-down operations",w:"Attempts and successes are recorded; cancellations are not. Tempo may therefore measure tolerance for risk rather than intent.",k:"uns"},
{s:"UNSEEN",t:"The North American caseload",w:"Outside one September 2026 indictment the record is nearly empty, against a European record that is saturated. That asymmetry far more likely reflects disclosure practice than targeting.",k:"uns"},
{s:"UNSEEN",t:"Moscow's own effectiveness assessment",w:"Nothing in the open record shows whether the Russian state judges this campaign to be working. Every judgement about intent here is inferred from effects.",k:"uns"}
];

var ACH={
 h:["H1<br>Shaping for war","H2<br>Coercive signalling","H3<br>Institutional momentum","H4<br>Observation artefact"],
 rows:[
 {e:"Tempo tracks Ukraine-aid decision points rather than NATO force-generation milestones",v:["N","CC","N","I"]},
 {e:"Target set is overwhelmingly Ukraine-logistics-linked, not NATO command, mobilisation or nuclear infrastructure",v:["II","CC","C","N"]},
 {e:"Tradecraft is cheap and disposable, not pre-positioned, compartmented or sleeper-based",v:["II","C","CC","N"]},
 {e:"Escalation continued after several of the aid decisions it supposedly targeted were taken anyway",v:["C","I","CC","N"]},
 {e:"Detection improved sharply after 2023 — new UK National Security Act powers, the EU hybrid sanctions regime, dedicated national units",v:["N","N","N","CC"]},
 {e:"Grade-A records rose through 2024–25 then flattened in 2026 while total records kept rising",v:["N","N","C","CC"]},
 {e:"The Russian MoD publicly named 21 European defence firms as legitimate targets, April 2026",v:["C","CC","C","II"]},
 {e:"Physical effects crossed into lethal-risk yields — C-4, PETN, RDX",v:["CC","C","C","II"]},
 {e:"Proxies are routinely caught and convicted; the network is not protected or reconstituted covertly",v:["II","C","CC","C"]},
 {e:"The same commander holds both the European sabotage mandate and the African expeditionary mission",v:["C","N","CC","N"]}
 ]
};
var ACHCONC=[
 {h:"Leading — H2, coercive signalling",t:"Carries the fewest inconsistencies and explains the two hardest facts: a target set built almost entirely around Ukrainian aid logistics, and a public Russian MoD declaration naming European defence firms. Coercion requires the adversary to know it is being coerced, which is why attributable tradecraft is a feature rather than a failure."},
 {h:"Strong second — H3, institutional momentum",t:"Best explains the tradecraft economics: a directorate stood up in 2023 with a mandate to produce effects will produce cheap, frequent, attributable effects, and will keep producing them after the stated provocation passes. H2 and H3 are not exclusive; the likeliest reading is a coercive mandate executed by an organisation with its own reasons to keep the tempo up."},
 {h:"Weakest — H1, shaping for war",t:"Fails on three diagnostics. Preparation would concentrate on NATO command, mobilisation and reinforcement infrastructure rather than aid logistics; it would protect its networks rather than burn them at the rate observed; and it would favour pre-positioning over single-use recruits. The lethal-yield trend is the only evidence that genuinely supports it."},
 {h:"Partially true — H4, observation artefact",t:"Not a rival explanation so much as a correction to the others. A real share of the post-2023 rise is improved detection, and the flattening of grade-A records against rising totals in 2026 is the signature of that effect running in reverse. Any reading of the tempo curve that ignores H4 overstates the change in Russian behaviour."}
];

var FORECAST=[
 {t:"Air-cargo and logistics nodes serving Ukraine",b:"Highly likely",p:92,w:"Two device generations already demonstrated, an intact proxy pipeline, and a target set that is both soft and directly tied to the coercive objective."},
 {t:"Defence-industrial sites across Germany, Poland, Czechia, Bulgaria and Italy",b:"Highly likely",p:88,w:"Five separate incidents in the eight weeks to mid-September 2026, and a Russian MoD statement naming 21 such firms as legitimate targets."},
 {t:"Rail corridors east of the Oder",b:"Likely",p:76,w:"The only corridor carrying materiel at scale; three distinct attack methods already used — cable cuts, radio-stop spoofing and buried charges."},
 {t:"Moldovan, Georgian and Armenian political systems",b:"Likely",p:74,w:"The influence apparatus is intact, sanctioned but not degraded, and these are the three systems where its returns have historically been highest."},
 {t:"Baltic and North Sea cables and interconnectors",b:"Roughly even chance",p:55,w:"Method still works and prosecutions keep failing, but Baltic Sentry and the new UK boarding powers have raised the cost of the shipping model."},
 {t:"Individual defence executives, defectors and dissidents",b:"Roughly even chance",p:50,w:"Demonstrated intent in three jurisdictions, but a low observed success rate and heavy protective response after each disclosure."},
 {t:"Nuclear-sharing and fifth-generation air bases (reconnaissance, not attack)",b:"Roughly even chance",p:46,w:"The 2025 wave established the pattern without attribution; recurrence is likelier than escalation to effects."},
 {t:"North American soil",b:"Unlikely but rising",p:28,w:"The 2024 parcel series was assessed as a rehearsal for North America-bound cargo, and the September 2026 indictment shows recruitment already running there."},
 {t:"West African port and basing access",b:"Likely",p:70,w:"Togo, Guinea and Equatorial Guinea are all live, and the Atlantic corridor matters more to Moscow now that northern Mali is contested and Syria is gone."}
];

var TRADECRAFT = ''+
'<div class="sect"><h2>Tradecraft and doctrine</h2><span class="n">What the Russian side actually calls this</span></div>'+
'<p>Three Russian terms of art describe what this console maps. None of them is the phrase most Western coverage reaches for.</p>'+
'<h3><span class="ru">спецмероприятия</span> — <em>spetsmeropriyatiya</em>, special measures</h3>'+
'<p>The GRU’s own umbrella for covert action abroad: sabotage, targeted killing, coup support and clandestine paramilitary work. This is the Unit 29155 portfolio and, since 2023, the Department for Special Tasks portfolio. It is an <strong>operational</strong> category, distinct from the special-operations vocabulary used for the SSO, and it is the correct frame for most of the Sabotage and Assassination records here.</p>'+
'<h3><span class="ru">активные мероприятия</span> — <em>aktivnye meropriyatiya</em>, active measures</h3>'+
'<p>The older Cheka-to-KGB tradition of political warfare short of conflict: disinformation, forgery, front organisations, agents of influence. Inherited by the SVR and FSB and visible here in the compatriot networks, the covert media estate and the election operations. Oleg Kalugin called it “the heart and soul of Soviet intelligence”, and the continuity from Operation Trust to Portal Kombat is real rather than rhetorical.</p>'+
'<h3><span class="ru">маскировка</span> — <em>maskirovka</em>, deception</h3>'+
'<p>Formalised in Soviet doctrine from a 1924 directive and codified in the 1944 military encyclopaedia. Operationally it is what makes the whole proxy model work: the point of a Colombian national setting fire to a Warsaw depot is not the fire, it is the twelve months of legal process needed to say who ordered it. Crimea in 2014 was the last large-scale success; the Donbas showed its limits once uniformed regulars started being captured.</p>'+
'<h3>The phrase that is not doctrine</h3>'+
'<p>The <strong>“Gerasimov Doctrine”</strong> appears nowhere in this build, deliberately. It was coined by Mark Galeotti in a 2013–14 blog post, publicly retracted by him in <em>Foreign Policy</em> in 2018, and describes a document that does not exist. Gerasimov’s February 2013 article in <em>Military-Industrial Courier</em> was an analysis of what Russia believed the West was doing to <strong>it</strong> through colour revolutions. Michael Kofman argues the term has no referent in Russian military thought at all; Charles Bartles reads the article as commentary on modern warfare generally; Roger McDermott treats the myth itself as one of the more dangerous distortions in NATO threat perception. Cite it only as Western shorthand for a cluster of observed behaviours, never as a recovered planning document.</p>'+
'<div class="sect"><h2>The recruitment funnel</h2><span class="n">How a proxy operation is actually assembled</span></div>'+
'<p>Every prosecuted network in this dataset follows close to the same five steps, and the uniformity is itself diagnostic — it indicates a written procedure rather than improvisation.</p>'+
'<ul>'+
'<li><strong>Solicitation at scale.</strong> Open Telegram channels, gaming platforms and job-style adverts targeting migrants, students, minor criminals and the financially precarious in the target country. PET described exactly this model to the Danish public in September 2026.</li>'+
'<li><strong>A trivial first task.</strong> Photograph a building, place a sticker, leave a package. It is cheap, it is deniable, and it establishes the payment relationship and the compromise.</li>'+
'<li><strong>Crypto payment against proof of completion.</strong> Sums are small — €10,000 for the Vilnius IKEA arson, $25,000 offered for a killing, $40,000 in the Brooklyn plot. The economics only work because the recruit is disposable.</li>'+
'<li><strong>Escalation to effects.</strong> Arson, then incendiary devices, then explosives. The same handler will run several recruits against the same target class.</li>'+
'<li><strong>No exfiltration.</strong> Nothing in the record shows a serious effort to extract a burned proxy. The recruit is the deniability layer, and the arrest is priced in.</li>'+
'</ul>'+
'<div class="sect"><h2>Four layers of deniability</h2><span class="n">Why attribution keeps failing in court</span></div>'+
'<p>The structure is legible once the cases are stacked: <strong>officers</strong> who never enter the target country, <strong>proxies</strong> who do and are caught, <strong>commercial cover</strong> — the front media, the PMC contracting shells, the news agencies — and <strong>deniable shipping</strong>, where a third-flag merchant drags an anchor and no prosecutor can prove the drag was ordered. Each layer defeats a different evidentiary standard. The Baltic cable prosecutions have collapsed at layer four; the European arson prosecutions succeed at layer two and stop there.</p>';

var METHOD = ''+
'<div class="sect"><h2>Build and method</h2><span class="n">GREY CARDINAL · Ed 2026.09f · compiled 17 SEP 2026</span></div>'+
'<p>A geocoded, confidence-graded register of Russian unconventional activity from January 2022 to 17 September 2026, drawn from court records, formal government attributions, national intelligence-service reporting, institutional research, investigative journalism and technical monitoring feeds, rendered as a kernel-density surface so the shape of the campaign is visible rather than asserted.</p>'+
'<h3>Confidence grading</h3>'+
'<p>Every record carries a grade, and the grade is about <strong>evidence</strong>, not about how plausible a claim feels.</p>'+
'<ul>'+
'<li><strong class="gA" style="border:0;padding:0">A</strong> — judicially proven or formally government-attributed with published evidence: a conviction, an unsealed indictment, a designation naming the actor, a service’s own published finding.</li>'+
'<li><strong class="gB" style="border:0;padding:0">B</strong> — government-attributed without published evidence, or strong investigative journalism that identifies the officers.</li>'+
'<li><strong class="gC" style="border:0;padding:0">C</strong> — credible suspicion under investigation; the pattern fits, an inquiry is open, no attribution has been made.</li>'+
'<li><strong class="gD" style="border:0;padding:0">D</strong> — alleged or actively contested, including cases where investigators found <em>no</em> evidence of sabotage but which still circulate in incident tallies.</li>'+
'</ul>'+
'<p>Grade D records are kept rather than dropped. A dataset that quietly discards its contested cases flatters itself; keeping them visible is what lets a reader see how much of the picture rests on suspicion.</p>'+
'<h3>Judgment calls, stated</h3>'+
'<ul>'+
'<li><strong>The name and edition.</strong> GREY CARDINAL after <span class="ru">серый кардинал</span>, the Russian term for the hidden hand behind a throne; edition 2026.09f follows COLD CIRCUIT’s 2026.09e in the LOOKING GLASS companion series. Both are the compiler’s choices.</li>'+
'<li><strong>Equal Earth projection.</strong> Equal-area, so density is comparable between the Sahel and the Baltic. Mercator would inflate Russia roughly threefold and make the map argue for a conclusion the data does not support.</li>'+
'<li><strong>Eight operational domains folded to six.</strong> Assassination merged into Sabotage and lethal action; cyber-physical records distributed by their effect. The LOOKING GLASS categorical palette validates at six slots and fails at eight, and a seventh invented hue would be unreadable where marks overlap.</li>'+
'<li><strong>Nord Stream is graded D and not attributed to Russia.</strong> The German investigation centres on a Ukrainian dive team and has produced arrest warrants and a contested extradition. It is the most-cited incident in this space and the evidence does not support the common framing.</li>'+
'<li><strong>The 2025 drone wave is graded C throughout.</strong> It is the largest single cluster in the dataset by event count and carries no formal attribution from any government.</li>'+
'<li><strong>Posture is separated from activity.</strong> Garrisons, bases and campaign infrastructure sit in their own layer and never enter the density surface — otherwise Moscow and the Kola Peninsula would dominate a map of things that happened elsewhere.</li>'+
'<li><strong>Information operations are plotted at the target, not the operator.</strong> Anchoring Doppelgänger or Portal Kombat at their Moscow offices would produce one enormous and analytically useless hotspot; the operators appear in the posture layer instead.</li>'+
'<li><strong>The 2022 expulsion wave is included as espionage-network records.</strong> It is a Western response rather than a Russian action, but it maps the declared-officer footprint at the moment the campaign turned to proxies — which is why Bulgaria, Slovakia and Slovenia stand out.</li>'+
'<li><strong>Counts are not intensity.</strong> One record is the Marywilska 44 fire that destroyed a thousand businesses; another is a drone sighting that closed an airport for an hour. Density measures reported activity, not consequence.</li>'+
'<li><strong>Coordinates are site-level where a site is named, city-level otherwise and area-centroid for national or maritime records.</strong> Precision is stated per record. Undersea break points are approximate; published positions are rarely precise enough to pin.</li>'+
'</ul>'+
'<h3>The social-media and milblogger layer — what it is here</h3>'+
'<p>The Russian-language Telegram ecosystem cannot be scraped live from a published page, and this build does not pretend otherwise. It contributes in two ways instead.</p>'+
'<p>First, a <strong>graded collection bench</strong>: twenty channels with operator identification where it exists, institutional affiliation, an Admiralty grade and, where documented, a fabrication record. Live subscriber counts were read from Telegram’s own unauthenticated <span class="mono">t.me/s/&lt;handle&gt;</span> preview surface on 17 September 2026. That endpoint is the most useful free technique in this space — it returns real metadata without an account, and a wrong handle returns Telegram’s generic placeholder rather than an error, which is how unverified handles in the bench were separated from confirmed ones.</p>'+
'<p>Second, <strong>provenance tagging</strong>: every record carries the source family that produced it — court and legal record, government attribution, institutional research, investigative press or technical feed. Filter the map by collection channel and you can watch which parts of the picture would disappear if a channel went dark.</p>'+
'<p><strong>Two circulating attributions did not survive verification and are flagged rather than repeated.</strong> The widely-shared identification of the Fighterbomber channel’s operator could not be corroborated in any primary source. And the December 2025 report that Andrei Averyanov had been killed in a strike on a shadow-fleet tanker was retracted — he subsequently led Africa Corps delegations to Equatorial Guinea and Madagascar. Both are useful reminders of how quickly the OSINT commons propagates a confident error.</p>'+
'<h3>Known gaps</h3>'+
'<ul>'+
'<li><strong>North America is structurally under-represented</strong> and that is a disclosure artefact, not a finding about targeting.</li>'+
'<li><strong>Grade C dominates the newest material</strong> because investigations run slower than publication; several 2026 records will move up or down as prosecutions conclude.</li>'+
'<li><strong>Ukraine’s own theatre is out of scope.</strong> Spetsnaz and SSO employment inside Ukraine is conventional wartime special operations, included only where it bears on the extraterritorial campaign.</li>'+
'<li><strong>Six I&amp;W rows are unobservable in principle.</strong> They are listed on the warning board rather than silently omitted.</li>'+
'</ul>'+
'<h3>Refreshing this build</h3>'+
'<p>Every record resolves to a numbered reference below. The standing feeds that generate new records are the European service annual reports, VIGINUM’s case reports, the EEAS FIMI series, DOJ and OFAC releases, ACLED’s event coding, and the technical layer — GPSJAM, ADS-B and AIS aggregators, Copernicus SAR and the TeleGeography cable map. Re-running those feeds updates the build incrementally; nothing here needs to be rebuilt from zero.</p>';

/* ═══ state ═══════════════════════════════════════════════ */
var S={dom:{},grade:{},actor:"",sf:"",q0:-1,q1:QMAX,heat:true,chor:false,pts:true,sites:false};
DOMAINS.forEach(function(d){S.dom[d]=true;}); GRADES.forEach(function(g){S.grade[g]=true;});
function filtered(){return INC.filter(function(r){
  if(!S.dom[r.dom]||!S.grade[r.g]) return false;
  if(S.actor&&r.a!==S.actor) return false;
  if(S.sf&&r.sf!==S.sf) return false;
  var q=qi(r.d); return q>=S.q0&&q<=S.q1;});}

/* ═══ Equal Earth projection ══════════════════════════════ */
var EE={A1:1.340264,A2:-0.081106,A3:0.000893,A4:0.003796,M:Math.sqrt(3)/2};
function ee(lon,lat){
  var p=lat*Math.PI/180, l=lon*Math.PI/180;
  var st=EE.M*Math.sin(p); if(st>1)st=1; if(st<-1)st=-1;
  var th=Math.asin(st), t2=th*th, t6=t2*t2*t2;
  var den=EE.M*(EE.A1+3*EE.A2*t2+t6*(7*EE.A3+9*EE.A4*t2));
  return [l*Math.cos(th)/den, th*(EE.A1+EE.A2*t2+t6*(EE.A3+EE.A4*t2))];
}
var X0=ee(-180,0)[0], X1=ee(180,0)[0], YT=ee(0,84)[1], YB=ee(0,-58)[1];
var cv=document.getElementById("map"), ctx=cv.getContext("2d");
var W=0,H=0,DPR=1,SC=1,OY=0,MH=0;
var view={k:1,x:0,y:0};
function baseProj(lon,lat){var q=ee(lon,lat); return [(q[0]-X0)*SC, OY+(YT-q[1])*SC];}
function proj(lon,lat){var b=baseProj(lon,lat); return [b[0]*view.k+view.x, b[1]*view.k+view.y];}
function clampView(){
  view.k=Math.max(1,Math.min(16,view.k));
  view.x=Math.min(0,Math.max(W-W*view.k,view.x));
  var dh=MH*view.k;
  if(dh>=H) view.y=Math.min(-OY*view.k, Math.max(H-(OY+MH)*view.k, view.y));
  else view.y=(H-dh)/2-OY*view.k;
}
function resize(){
  DPR=Math.min(2,window.devicePixelRatio||1);
  var r=cv.getBoundingClientRect();
  W=Math.max(300,Math.round(r.width)); H=Math.max(240,Math.round(r.height));
  cv.width=Math.round(W*DPR); cv.height=Math.round(H*DPR); ctx.setTransform(DPR,0,0,DPR,0,0);
  SC=W/(X1-X0); MH=(YT-YB)*SC; OY=(H-MH)/2;
  clampView(); draw();
}

/* ═══ heat surface ════════════════════════════════════════ */
var hc=document.createElement("canvas"), hctx=hc.getContext("2d");
function hx(h){h=h.replace("#","");return [parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)];}
function ramp(){return ["--r1","--r2","--r3","--r4","--r5","--r6","--r7","--r8"].map(function(v){return hx(css(v));});}
function drawHeat(rows){
  var CELL=4, gw=Math.ceil(W/CELL), gh=Math.ceil(H/CELL), grid=new Float32Array(gw*gh);
  var R=Math.max(5,Math.round((25+view.k*3)/CELL)), R2=R*R, inv=1/(2*(R/2)*(R/2)), any=false;
  for(var i=0;i<rows.length;i++){
    var p=proj(rows[i].lon,rows[i].lat), gx=p[0]/CELL, gy=p[1]/CELL;
    if(gx<-R-2||gy<-R-2||gx>gw+R+2||gy>gh+R+2) continue;
    any=true; var wt=GW[rows[i].g]||.6;
    var x0=Math.max(0,Math.floor(gx-R)),x1=Math.min(gw-1,Math.ceil(gx+R));
    var y0=Math.max(0,Math.floor(gy-R)),y1=Math.min(gh-1,Math.ceil(gy+R));
    for(var y=y0;y<=y1;y++){var dy=y-gy;
      for(var x=x0;x<=x1;x++){var dx=x-gx,d2=dx*dx+dy*dy; if(d2>R2) continue;
        grid[y*gw+x]+=wt*Math.exp(-d2*inv);}}
  }
  if(!any) return;
  var max=0; for(var n=0;n<grid.length;n++) if(grid[n]>max) max=grid[n];
  if(max<=0) return;
  var RP=ramp(); hc.width=gw; hc.height=gh;
  var img=hctx.createImageData(gw,gh), dta=img.data;
  for(var m=0;m<grid.length;m++){
    var v=grid[m]/max; if(v<=0.012) continue;
    v=Math.pow(v,0.6);
    var t=v*(RP.length-1), lo=Math.floor(t), hi=Math.min(RP.length-1,lo+1), f=t-lo, c0=RP[lo], c1=RP[hi], o=m*4;
    dta[o]=c0[0]+(c1[0]-c0[0])*f; dta[o+1]=c0[1]+(c1[1]-c0[1])*f; dta[o+2]=c0[2]+(c1[2]-c0[2])*f;
    dta[o+3]=Math.min(238,255*Math.pow(v,0.7));
  }
  hctx.putImageData(img,0,0);
  ctx.save(); ctx.imageSmoothingEnabled=true; ctx.imageSmoothingQuality="high";
  ctx.globalAlpha=.93; ctx.drawImage(hc,0,0,gw,gh,0,0,gw*CELL,gh*CELL); ctx.restore();
}

/* ═══ choropleth ══════════════════════════════════════════ */
function exposure(rows){
  var m={}, un=0;
  rows.forEach(function(r){
    var parts=r.c.indexOf("Multiple")===0||r.c==="International waters" ? [] : r.c.split(" / ");
    if(!parts.length){un++; return;}
    parts.forEach(function(p){ p=p.trim(); p=CALIAS[p]||p; m[p]=(m[p]||0)+(GW[r.g]||.6)/parts.length; });
  });
  return {m:m,un:un};
}
function featPath(f){
  ctx.beginPath();
  for(var g=0;g<f.p.length;g++){var rings=f.p[g];
    for(var h=0;h<rings.length;h++){var ring=rings[h];
      for(var k=0;k<ring.length;k++){var pt=proj(ring[k][0],ring[k][1]); if(k===0)ctx.moveTo(pt[0],pt[1]); else ctx.lineTo(pt[0],pt[1]);}
      ctx.closePath();}}
}

/* ═══ draw ════════════════════════════════════════════════ */
var lastRows=[], lastPts=[], expo={m:{},un:0};
function draw(){
  var rows=lastRows;
  ctx.clearRect(0,0,W,H); ctx.fillStyle="#080A0D"; ctx.fillRect(0,0,W,H);
  ctx.save(); ctx.strokeStyle=css("--rule"); ctx.lineWidth=1; ctx.globalAlpha=.6; ctx.beginPath();
  for(var lo=-180;lo<=180;lo+=30){ for(var t=0;t<=40;t++){var la=84-(84+58)*t/40,p=proj(lo,la); if(t===0)ctx.moveTo(p[0],p[1]); else ctx.lineTo(p[0],p[1]);} }
  for(var la2=-40;la2<=80;la2+=20){ for(var t2=0;t2<=48;t2++){var lo2=-180+360*t2/48,p2=proj(lo2,la2); if(t2===0)ctx.moveTo(p2[0],p2[1]); else ctx.lineTo(p2[0],p2[1]);} }
  ctx.stroke(); ctx.restore();

  var RP=ramp(), max=0;
  if(S.chor){ for(var k0 in expo.m) if(expo.m[k0]>max) max=expo.m[k0]; }
  ctx.save(); ctx.lineWidth=Math.min(1.1,.5+view.k*.05); ctx.strokeStyle="#2A313B";
  for(var i=0;i<WORLD.length;i++){
    var f=WORLD[i], fill="#161A20";
    if(S.chor && max>0){
      var v=(expo.m[f.n]||0)/max;
      if(v>0){ var t3=Math.pow(v,.5)*(RP.length-1), l3=Math.floor(t3), h3=Math.min(RP.length-1,l3+1), fr=t3-l3;
        var c0=RP[l3],c1=RP[h3];
        fill="rgb("+Math.round(c0[0]+(c1[0]-c0[0])*fr)+","+Math.round(c0[1]+(c1[1]-c0[1])*fr)+","+Math.round(c0[2]+(c1[2]-c0[2])*fr)+")"; }
    }
    featPath(f); ctx.fillStyle=fill; ctx.fill("evenodd"); ctx.stroke();
  }
  ctx.restore();

  if(S.heat && !S.chor) drawHeat(rows);

  lastPts=[];
  if(S.sites){
    ctx.save();
    for(var s=0;s<SITES.length;s++){
      var sp=proj(SITES[s].lon,SITES[s].lat);
      if(sp[0]<-14||sp[1]<-14||sp[0]>W+14||sp[1]>H+14) continue;
      var rr=4.3; ctx.beginPath();
      ctx.moveTo(sp[0],sp[1]-rr); ctx.lineTo(sp[0]+rr,sp[1]); ctx.lineTo(sp[0],sp[1]+rr); ctx.lineTo(sp[0]-rr,sp[1]); ctx.closePath();
      ctx.strokeStyle="#0A0C0F"; ctx.lineWidth=1.8; ctx.stroke();
      ctx.fillStyle=css("--s2"); ctx.fill();
      lastPts.push({x:sp[0],y:sp[1],r:8,site:SITES[s]});
    }
    ctx.restore();
  }
  if(S.pts){
    var sel=DOMAINS.filter(function(d){return S.dom[d];});
    var byDom=sel.length>0&&sel.length<=3;
    var RAD={A:4.1,B:3.6,C:3.1,D:2.7};
    ctx.save();
    for(var j=0;j<rows.length;j++){
      var p3=proj(rows[j].lon,rows[j].lat);
      if(p3[0]<-12||p3[1]<-12||p3[0]>W+12||p3[1]>H+12) continue;
      var rad=RAD[rows[j].g]||3;
      ctx.beginPath(); ctx.arc(p3[0],p3[1],rad,0,6.2832);
      ctx.strokeStyle="#0A0C0F"; ctx.lineWidth=1.8; ctx.stroke();
      ctx.fillStyle=byDom?css(SLOT[DOMAINS.indexOf(rows[j].dom)]):"#E6E9EE";
      ctx.globalAlpha=rows[j].g==="D"?.5:(rows[j].g==="C"?.75:1);
      ctx.fill(); ctx.globalAlpha=1;
      lastPts.push({x:p3[0],y:p3[1],r:Math.max(7,rad+4),rec:rows[j]});
    }
    ctx.restore();
  }
  document.getElementById("mapfoot").textContent="Equal Earth · "+rows.length+" events"+(S.chor?" · "+expo.un+" multi-country / maritime unassigned":"")+" · ×"+view.k.toFixed(1);
}

/* ═══ map interaction ═════════════════════════════════════ */
var tip=document.getElementById("tip");
function hit(mx,my){var best=null,bd=1e9;
  for(var i=lastPts.length-1;i>=0;i--){var p=lastPts[i],dx=mx-p.x,dy=my-p.y,d=dx*dx+dy*dy;
    if(d<=p.r*p.r&&d<bd){bd=d;best=p;}} return best;}
cv.addEventListener("mousemove",function(e){
  var r=cv.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;
  if(dragging){tip.classList.remove("on");return;}
  var h=hit(mx,my);
  if(!h){tip.classList.remove("on");cv.style.cursor="grab";return;}
  cv.style.cursor="pointer";
  if(h.rec) tip.innerHTML='<div class="th">'+esc(h.rec.s)+'</div><div class="tm">'+esc(h.rec.d)+' · '+esc(h.rec.c)+' · grade '+h.rec.g+'</div><div class="tb">'+esc(h.rec.w.slice(0,150))+(h.rec.w.length>150?"…":"")+'</div>';
  else tip.innerHTML='<div class="th">'+esc(h.site.n)+'</div><div class="tm">'+esc(h.site.cls)+' · '+esc(h.site.s)+'</div><div class="tb">'+esc(h.site.w.slice(0,150))+(h.site.w.length>150?"…":"")+'</div>';
  tip.classList.add("on");
  var tw=tip.offsetWidth||260,th=tip.offsetHeight||70;
  tip.style.left=Math.max(6,Math.min(W-tw-6,mx+14))+"px";
  tip.style.top=Math.max(6,Math.min(H-th-6,my-th-10))+"px";
});
cv.addEventListener("mouseleave",function(){tip.classList.remove("on");});
cv.addEventListener("click",function(e){var r=cv.getBoundingClientRect();var h=hit(e.clientX-r.left,e.clientY-r.top); if(h) showDetail(h.rec||null,h.site||null);});
var dragging=false,dsx=0,dsy=0,dvx=0,dvy=0;
cv.addEventListener("pointerdown",function(e){dragging=true;cv.classList.add("drag");cv.setPointerCapture(e.pointerId);dsx=e.clientX;dsy=e.clientY;dvx=view.x;dvy=view.y;});
cv.addEventListener("pointermove",function(e){if(!dragging)return;view.x=dvx+(e.clientX-dsx);view.y=dvy+(e.clientY-dsy);clampView();draw();});
cv.addEventListener("pointerup",function(){dragging=false;cv.classList.remove("drag");});
cv.addEventListener("pointercancel",function(){dragging=false;cv.classList.remove("drag");});
cv.addEventListener("wheel",function(e){e.preventDefault();var r=cv.getBoundingClientRect();zoomAt(e.clientX-r.left,e.clientY-r.top,e.deltaY<0?1.18:1/1.18);},{passive:false});
function zoomAt(mx,my,f){var k0=view.k;view.k=Math.max(1,Math.min(16,view.k*f));var s=view.k/k0;view.x=mx-(mx-view.x)*s;view.y=my-(my-view.y)*s;clampView();draw();}
document.getElementById("z-in").onclick=function(){zoomAt(W/2,H/2,1.5);};
document.getElementById("z-out").onclick=function(){zoomAt(W/2,H/2,1/1.5);};
document.getElementById("z-fit").onclick=function(){view={k:1,x:0,y:0};clampView();draw();};

function showDetail(rec,site){
  var el=document.getElementById("detail");
  if(rec) el.innerHTML='<div class="dtop"><h3>'+esc(rec.s)+'</h3><span class="pill g'+rec.g+'">Grade '+rec.g+'</span></div>'+
    '<div class="dmeta"><span class="pill"><i style="background:'+DCOL[rec.dom]+'"></i>'+esc(rec.dom)+'</span>'+
    '<span class="pill">'+esc(rec.d)+'</span><span class="pill">'+esc(rec.c)+'</span>'+
    '<span class="pill">'+esc(ACTORLAB[rec.a]||rec.a)+'</span><span class="pill">'+esc(rec.k)+'</span>'+
    '<span class="pill">target: '+esc(rec.t)+'</span><span class="pill">'+esc(SFLAB[rec.sf]||rec.sf)+'</span>'+
    '<span class="pill mono">'+rec.lat.toFixed(3)+', '+rec.lon.toFixed(3)+' · '+esc(rec.pr)+'</span></div>'+
    '<p>'+esc(rec.w)+'</p><p style="margin-top:9px">Reference '+refHTML(rec.ref)+'</p>';
  else if(site) el.innerHTML='<div class="dtop"><h3>'+esc(site.n)+'</h3><span class="pill">Posture</span></div>'+
    '<div class="dmeta"><span class="pill"><i style="background:var(--s2)"></i>'+esc(site.cls)+'</span>'+
    '<span class="pill">'+esc(site.org)+'</span>'+(site.u&&site.u!=="—"&&site.u!=="unknown"?'<span class="pill mono">'+esc(site.u)+'</span>':'')+
    '<span class="pill">'+esc(site.s)+'</span>'+(site.str&&site.str!=="—"?'<span class="pill">'+esc(site.str)+'</span>':'')+
    '<span class="pill mono">'+site.lat.toFixed(3)+', '+site.lon.toFixed(3)+'</span></div>'+
    '<p>'+esc(site.w)+'</p><p style="margin-top:9px">Reference '+refHTML(site.ref)+'</p>';
}
function defaultDetail(){
  var rows=lastRows, a=rows.filter(function(r){return r.g==="A";}).length;
  document.getElementById("detail").innerHTML='<div class="dtop"><h3>'+rows.length+' events in view</h3><span class="pill">'+(rows.length?Math.round(a/rows.length*100):0)+'% grade A</span></div>'+
  '<p>Click any mark for the full record, its grade and its reference. Drag to pan, scroll to zoom. The density surface is kernel-weighted by confidence grade; the exposure layer is a per-country composite of the same weights, and multi-country or maritime records are left unassigned rather than smeared across a region.</p>';
}

/* ═══ charts ══════════════════════════════════════════════ */
var SV="http://www.w3.org/2000/svg";
function svg(w,h){var s=document.createElementNS(SV,"svg");s.setAttribute("viewBox","0 0 "+w+" "+h);s.setAttribute("width","100%");s.setAttribute("role","img");return s;}
function el(t,a){var e=document.createElementNS(SV,t);for(var k in a)e.setAttribute(k,a[k]);return e;}
function txt(x,y,s,c,an){var t=el("text",{x:x,y:y,"class":c||"cx-lab"});if(an)t.setAttribute("text-anchor",an);t.textContent=s;return t;}
function tally(rows,key,lab,lim){var m={};rows.forEach(function(r){m[r[key]]=(m[r[key]]||0)+1;});
  var a=Object.keys(m).map(function(k){return [lab?(lab[k]||k):k,m[k],k];}); a.sort(function(x,y){return y[1]-x[1];});
  return lim?a.slice(0,lim):a;}
function barChart(id,data,color){
  var host=document.getElementById(id); host.innerHTML="";
  if(!data.length){host.innerHTML='<p class="note">No records match the current filters.</p>';return;}
  var rowH=21,W2=470,PL=150,PR=42,H2=data.length*rowH+8;
  var max=Math.max.apply(null,data.map(function(d){return d[1];}));
  var s=svg(W2,H2), iw=W2-PL-PR;
  data.forEach(function(d,i){
    var y=i*rowH+4,w=Math.max(2,(d[1]/max)*iw);
    var nm=d[0].length>23?d[0].slice(0,22)+"…":d[0];
    s.appendChild(txt(PL-11,y+11.5,nm,"cx-name","end"));
    var rc=el("rect",{x:PL,y:y+2.5,width:w,height:rowH-8,rx:2,fill:color||"var(--s1)"});
    var ti=el("title");ti.textContent=d[0]+": "+d[1];rc.appendChild(ti);
    s.appendChild(rc); s.appendChild(txt(PL+w+6,y+11.5,d[1],"cx-val"));
  });
  s.appendChild(el("line",{x1:PL,x2:PL,y1:2,y2:H2-4,"class":"base-l"}));
  host.appendChild(s);
}
function timeChart(rows){
  var host=document.getElementById("ch-time"); host.innerHTML="";
  var W2=1000,H2=220,PL=34,PR=8,PT=10,PB=30;
  var b={}; for(var q=-1;q<=QMAX;q++) b[q]={};
  rows.forEach(function(r){var q=qi(r.d); if(q>QMAX)return; b[q][r.dom]=(b[q][r.dom]||0)+1;});
  var keys=[]; for(var q2=-1;q2<=QMAX;q2++) keys.push(q2);
  var max=0; keys.forEach(function(k){var t=0;DOMAINS.forEach(function(d){t+=b[k][d]||0;});if(t>max)max=t;});
  max=Math.max(4,max); var step=Math.ceil(max/4), s=svg(W2,H2), iw=W2-PL-PR, ih=H2-PT-PB, bw=iw/keys.length;
  for(var v=0;v<=max;v+=step){var y=PT+ih-(v/max)*ih;
    s.appendChild(el("line",{x1:PL,x2:W2-PR,y1:y,y2:y,"class":v===0?"base-l":"grid-l"}));
    s.appendChild(txt(PL-6,y+3.5,v,"cx-val","end"));}
  keys.forEach(function(k,i){
    var x=PL+i*bw+2.5,acc=0;
    DOMAINS.forEach(function(d,di){var n=b[k][d]||0; if(!n)return;
      var hgt=(n/max)*ih, y=PT+ih-((acc+n)/max)*ih;
      var rc=el("rect",{x:x,y:y,width:Math.max(2,bw-5),height:Math.max(1,hgt-1.6),fill:"var("+SLOT[di]+")",rx:1});
      var ti=el("title");ti.textContent=qlab(k)+" · "+d+": "+n;rc.appendChild(ti);
      s.appendChild(rc); acc+=n;});
    var lab=k<0?"≤2021":(k%4===0?String(2022+Math.floor(k/4)):(k%4===2?"Q3":null));
    if(lab) s.appendChild(txt(x+(bw-5)/2,H2-11,lab,"cx-lab","middle"));
  });
  host.appendChild(s);
  var lg=document.getElementById("leg-time"); lg.innerHTML="";
  DOMAINS.forEach(function(d,i){var sp=document.createElement("span");sp.innerHTML='<i style="background:var('+SLOT[i]+')"></i>'+esc(d);lg.appendChild(sp);});
}
function calChart(rows){
  var host=document.getElementById("ch-cal"); host.innerHTML="";
  var MN=["J","F","M","A","M","J","J","A","S","O","N","D"], yrs=[2022,2023,2024,2025,2026];
  var g={}, max=0;
  rows.forEach(function(r){ if(r.d.length<7) return; var y=+r.d.slice(0,4), m=+r.d.slice(5,7);
    if(yrs.indexOf(y)<0) return; var k=y+"-"+m; g[k]=(g[k]||0)+1; if(g[k]>max)max=g[k];});
  var RP=ramp(), html='<div class="calgrid"><div></div>';
  MN.forEach(function(m){html+='<div class="ch">'+m+'</div>';});
  yrs.forEach(function(y){
    html+='<div class="rh">'+y+'</div>';
    for(var m=1;m<=12;m++){
      var n=g[y+"-"+m]||0, bg="var(--r1)";
      if(n>0&&max>0){var t=Math.pow(n/max,.6)*(RP.length-1),l=Math.floor(t),h=Math.min(RP.length-1,l+1),f=t-l,c0=RP[l],c1=RP[h];
        bg="rgb("+Math.round(c0[0]+(c1[0]-c0[0])*f)+","+Math.round(c0[1]+(c1[1]-c0[1])*f)+","+Math.round(c0[2]+(c1[2]-c0[2])*f)+")";}
      html+='<div class="cell" style="background:'+bg+'" title="'+y+"-"+String(m).padStart(2,"0")+': '+n+' events">'+(n||"")+'</div>';
    }
  });
  html+='</div><p class="note" style="margin-top:9px">Peak month '+max+' events. Cells are counts, not rates — 2026 stops at September.</p>';
  host.innerHTML=html;
}
function gradeChart(rows){
  var host=document.getElementById("ch-grade"); host.innerHTML="";
  var yrs=[2022,2023,2024,2025,2026], GC={A:"--gA",B:"--gB",C:"--gC",D:"--gD"};
  var W2=520,H2=200,PL=34,PR=10,PT=10,PB=28, s=svg(W2,H2), iw=W2-PL-PR, ih=H2-PT-PB, bw=iw/yrs.length;
  [0,25,50,75,100].forEach(function(v){var y=PT+ih-(v/100)*ih;
    s.appendChild(el("line",{x1:PL,x2:W2-PR,y1:y,y2:y,"class":v===0?"base-l":"grid-l"}));
    s.appendChild(txt(PL-6,y+3.5,v+"%","cx-val","end"));});
  yrs.forEach(function(y,i){
    var sub=rows.filter(function(r){return +r.d.slice(0,4)===y;}), tot=sub.length||1, acc=0, x=PL+i*bw+6;
    GRADES.forEach(function(gg){
      var n=sub.filter(function(r){return r.g===gg;}).length; if(!n) return;
      var frac=n/tot, hgt=frac*ih, yy=PT+ih-((acc+frac)*ih);
      var rc=el("rect",{x:x,y:yy,width:bw-12,height:Math.max(1,hgt-1.4),fill:"var("+GC[gg]+")",rx:1});
      var ti=el("title");ti.textContent=y+" grade "+gg+": "+n+" of "+sub.length;rc.appendChild(ti);
      s.appendChild(rc); acc+=frac;});
    s.appendChild(txt(x+(bw-12)/2,H2-10,y,"cx-lab","middle"));
    s.appendChild(txt(x+(bw-12)/2,PT-1,"n="+sub.length,"cx-lab","middle"));
  });
  host.appendChild(s);
  var lg=document.getElementById("leg-grade"); lg.innerHTML="";
  GRADES.forEach(function(gg){var sp=document.createElement("span");sp.innerHTML='<i style="background:var('+GC[gg]+')"></i>Grade '+gg;lg.appendChild(sp);});
}

/* ═══ render ══════════════════════════════════════════════ */
function render(){
  lastRows=filtered(); expo=exposure(lastRows);
  draw(); defaultDetail();
  timeChart(lastRows); calChart(lastRows); gradeChart(lastRows);
  barChart("ch-cty",tally(lastRows,"c",null,12));
  barChart("ch-act",tally(lastRows,"a",ACTORLAB,12),"var(--s4)");
  barChart("ch-tgt",tally(lastRows,"t",null,10),"var(--s5)");
  barChart("ch-sf",tally(lastRows,"sf",SFLAB),"var(--s2)");
  renderTable();
}

/* ═══ controls ════════════════════════════════════════════ */
(function(){
  var cd=document.getElementById("c-dom");
  DOMAINS.forEach(function(d,i){
    var n=INC.filter(function(r){return r.dom===d;}).length;
    var b=document.createElement("button"); b.className="chip"; b.type="button"; b.setAttribute("aria-pressed","true");
    b.innerHTML='<i style="background:var('+SLOT[i]+')"></i>'+esc(d)+' <em>'+n+'</em>';
    b.onclick=function(){S.dom[d]=!S.dom[d];b.setAttribute("aria-pressed",String(S.dom[d]));render();};
    cd.appendChild(b);});
  var cg=document.getElementById("c-grade");
  GRADES.forEach(function(g){
    var n=INC.filter(function(r){return r.g===g;}).length;
    var b=document.createElement("button"); b.className="chip"; b.type="button"; b.setAttribute("aria-pressed","true");
    b.innerHTML='<i style="background:var(--g'+g+')"></i>'+g+' <em>'+n+'</em>';
    b.onclick=function(){S.grade[g]=!S.grade[g];b.setAttribute("aria-pressed",String(S.grade[g]));render();};
    cg.appendChild(b);});
  var fa=document.getElementById("f-actor");
  tally(INC,"a",ACTORLAB).forEach(function(t){var o=document.createElement("option");o.value=t[2];o.textContent=t[0]+" ("+t[1]+")";fa.appendChild(o);});
  fa.onchange=function(){S.actor=fa.value;render();};
  var fs=document.getElementById("f-sf");
  tally(INC,"sf",SFLAB).forEach(function(t){var o=document.createElement("option");o.value=t[2];o.textContent=t[0]+" ("+t[1]+")";fs.appendChild(o);});
  fs.onchange=function(){S.sf=fs.value;render();};
})();
var sF=document.getElementById("s-from"), sT=document.getElementById("s-to");
sF.min=-1;sF.max=QMAX;sF.step=1;sF.value=-1; sT.min=-1;sT.max=QMAX;sT.step=1;sT.value=QMAX;
function syncRange(e){var a=+sF.value,b=+sT.value;
  if(a>b){ if(e&&e.target===sF){b=a;sT.value=b;} else {a=b;sF.value=a;} }
  S.q0=a;S.q1=b;
  document.getElementById("r-from").textContent=qlab(a);
  document.getElementById("r-to").textContent=qlab(b); render();}
sF.addEventListener("input",syncRange); sT.addEventListener("input",syncRange);
function layerNote(){
  document.getElementById("ramphead").textContent=S.chor?"Country exposure":"Activity density";
  document.getElementById("rampnote").textContent=S.chor
    ? "Per-country composite of filtered events weighted by confidence grade, square-root scaled. Multi-country and maritime records are left unassigned rather than smeared across a region — the count is in the map footer."
    : "Kernel density of the filtered events, weighted by confidence grade. Select three domains or fewer and the event marks take their domain colour; above three they stay neutral, because more than three hues cannot be told apart reliably when marks overlap.";
}
document.getElementById("b-heat").onclick=function(){S.heat=true;S.chor=false;this.classList.add("on");document.getElementById("b-chor").classList.remove("on");layerNote();draw();};
document.getElementById("b-chor").onclick=function(){S.chor=true;S.heat=false;this.classList.add("on");document.getElementById("b-heat").classList.remove("on");layerNote();draw();};
document.getElementById("b-pts").onclick=function(){S.pts=!S.pts;this.classList.toggle("on",S.pts);draw();};
document.getElementById("b-sites").onclick=function(){S.sites=!S.sites;this.classList.toggle("on",S.sites);draw();};
document.getElementById("b-reset").onclick=function(){
  DOMAINS.forEach(function(d){S.dom[d]=true;}); GRADES.forEach(function(g){S.grade[g]=true;});
  S.actor="";S.sf="";S.q0=-1;S.q1=QMAX;
  document.getElementById("f-actor").value="";document.getElementById("f-sf").value="";
  sF.value=-1;sT.value=QMAX;
  document.getElementById("r-from").textContent=qlab(-1);document.getElementById("r-to").textContent=qlab(QMAX);
  var cs=document.querySelectorAll("#c-dom .chip, #c-grade .chip");
  for(var i=0;i<cs.length;i++) cs[i].setAttribute("aria-pressed","true");
  render();};

/* ═══ campaign record table ═══════════════════════════════ */
var sortK="d", sortDir=-1;
function renderTable(){
  var q=(document.getElementById("q").value||"").toLowerCase().trim();
  var rows=lastRows.filter(function(r){ if(!q) return true;
    return (r.s+" "+r.c+" "+r.w+" "+(ACTORLAB[r.a]||r.a)+" "+r.k+" "+r.dom).toLowerCase().indexOf(q)>=0;});
  rows=rows.slice().sort(function(a,b){var x=a[sortK],y=b[sortK]; if(x===y) return a.d<b.d?1:-1; return (x<y?-1:1)*sortDir;});
  document.getElementById("tcount").textContent=rows.length+" of "+INC.length+" records";
  var h="";
  for(var i=0;i<rows.length;i++){var r=rows[i];
    h+='<tr><td class="d">'+esc(r.d)+'</td><td>'+esc(r.c)+'</td><td class="s">'+esc(r.s)+'</td>'+
      '<td><span class="pill"><i style="background:'+DCOL[r.dom]+'"></i>'+esc(r.dom)+'</span></td>'+
      '<td>'+esc(ACTORLAB[r.a]||r.a)+'</td><td>'+esc(r.k)+'</td>'+
      '<td><span class="pill g'+r.g+'">'+r.g+'</span></td>'+
      '<td style="min-width:310px">'+esc(r.w)+'</td><td>'+refHTML(r.ref)+'</td></tr>';}
  document.getElementById("tbody").innerHTML=h;
}
document.getElementById("q").addEventListener("input",renderTable);
(function(){var ths=document.querySelectorAll("#tbl thead th[data-k]");
  for(var i=0;i<ths.length;i++)(function(th){th.onclick=function(){var k=th.getAttribute("data-k");
    if(sortK===k)sortDir*=-1;else{sortK=k;sortDir=1;} renderTable();};})(ths[i]);})();

/* ═══ static renders ══════════════════════════════════════ */
document.getElementById("blufText").textContent=BLUF;
document.getElementById("blufTiles").innerHTML=TILES.map(function(t){
  return '<div class="card"><div class="sub" style="margin:0 0 6px">'+esc(t.n)+'</div><div class="mono" style="font-size:17px;font-weight:600;color:var(--accent);letter-spacing:.02em">'+esc(t.v)+'</div><div class="note" style="margin-top:5px">'+esc(t.s)+'</div></div>';}).join("");
document.getElementById("kjn").textContent=KJ.length+" judgments · ICD-203 bands · Admiralty grades";
document.getElementById("kjlist").innerHTML=KJ.map(function(k){
  return '<div class="kj"><div class="kjid">'+k.id+'</div><div class="kjtext">'+k.t+'</div>'+
   '<div class="kjmeta"><span class="pill">Likelihood: '+esc(k.b)+'</span><span class="pill">Confidence: '+esc(k.c)+'</span><span class="pill">Admiralty '+esc(k.g)+'</span></div>'+
   '<dl><dt>Basis</dt><dd>'+k.basis+'</dd><dt>Would change it</dt><dd>'+k.chg+'</dd></dl></div>';}).join("");
document.getElementById("tradecraft").innerHTML=TRADECRAFT;
document.getElementById("method").innerHTML=METHOD;
document.getElementById("iwn").textContent=IW.length+" indicators · "+IW.filter(function(i){return i.k==="uns";}).length+" unseen";
document.getElementById("iwboard").innerHTML='<div class="iwrow head"><div>Status</div><div>Indicator</div><div>Most recent observation</div></div>'+
 IW.map(function(i){return '<div class="iwrow'+(i.k==="uns"?" unseen":"")+'"><div><span class="iwst st-'+i.k+'">'+i.s+'</span></div>'+
 '<div><div class="iwtext">'+esc(i.t)+'</div></div><div class="iwwhy">'+esc(i.w)+'</div></div>';}).join("");
(function(){
  var CLS={CC:"cc",C:"c1",N:"nn",I:"i1",II:"ii"};
  var h='<thead><tr><th>Diagnostic evidence</th>'+ACH.h.map(function(x){return '<th class="hh">'+x+'</th>';}).join("")+'</tr></thead><tbody>';
  ACH.rows.forEach(function(r){ h+='<tr><td class="ev">'+esc(r.e)+'</td>'+r.v.map(function(v){return '<td class="c '+CLS[v]+'">'+v+'</td>';}).join("")+'</tr>';});
  h+='</tbody>'; document.getElementById("achtbl").innerHTML=h;
  document.getElementById("achconc").innerHTML=ACHCONC.map(function(c){
    return '<div class="card"><h3>'+esc(c.h)+'</h3><p class="note" style="margin-top:7px;font-size:12.8px">'+esc(c.t)+'</p></div>';}).join("");
})();
document.getElementById("fcboard").innerHTML=FORECAST.map(function(f){
  return '<div class="fc"><div><div style="color:var(--ink);font-size:13.6px">'+esc(f.t)+'</div><div class="note" style="margin-top:3px">'+esc(f.w)+'</div></div>'+
  '<div><div class="fcbar"><i style="width:'+f.p+'%"></i></div><div class="fclab">'+esc(f.b)+'</div></div></div>';}).join("");
(function(){
  var order=["Covert action","Cyber","Spetsnaz","SSO","Naval SOF","Seabed warfare","Expeditionary","Influence","Psyops","HQ","Rosgvardia","Garrison","EW"];
  var by={}; SITES.forEach(function(s){(by[s.cls]=by[s.cls]||[]).push(s);});
  var keys=Object.keys(by).sort(function(a,b){var ia=order.indexOf(a),ib=order.indexOf(b);return (ia<0?99:ia)-(ib<0?99:ib);});
  var out=keys.map(function(k){
    return '<div class="sect"><h2>'+esc(k)+'</h2><span class="n">'+by[k].length+'</span></div><div class="deck">'+
     by[k].map(function(s){return '<article class="entry"><h4>'+esc(s.n)+'</h4><div class="meta">'+esc(s.org)+
      (s.u&&s.u!=="—"&&s.u!=="unknown"?" · "+esc(s.u):"")+'<br>'+esc(s.s)+(s.str&&s.str!=="—"?" · "+esc(s.str):"")+
      '</div><p>'+esc(s.w)+'</p><p style="margin:0">'+refHTML(s.ref)+'</p></article>';}).join("")+'</div>';}).join("");
  document.getElementById("oob").innerHTML=out;
})();
document.getElementById("ledger").innerHTML=LEDGER.map(function(l){
  return '<div class="lrow"><div class="ld">'+esc(l.d)+'</div><div class="lb">'+esc(l.by)+'</div><p>'+esc(l.w)+' '+refHTML(l.ref)+'</p></div>';}).join("");
function renderBench(){
  var q=(document.getElementById("qs").value||"").toLowerCase().trim();
  var rows=BENCH.filter(function(s){ if(!q) return true;
    return (s.n+" "+s.cat+" "+(s.who||"")+" "+(s.use||"")+" "+(s.h||"")+" "+(s.risk||"")+" "+(s.aff||"")).toLowerCase().indexOf(q)>=0;});
  document.getElementById("scount").textContent=rows.length+" of "+BENCH.length+" sources";
  var by={},order=[]; rows.forEach(function(s){if(!by[s.cat]){by[s.cat]=[];order.push(s.cat);}by[s.cat].push(s);});
  document.getElementById("bench").innerHTML=order.map(function(c){
    return '<div class="sect"><h2>'+esc(c)+'</h2><span class="n">'+by[c].length+'</span></div><div class="deck">'+
     by[c].map(function(s){return '<article class="entry"><h4>'+esc(s.n)+'</h4><div class="meta">'+esc(s.h||"")+
      (s.sub&&s.sub!=="—"?" · "+esc(s.sub)+" subscribers":"")+'</div>'+
      (s.who?'<p><strong style="color:var(--ink)">Operator.</strong> '+esc(s.who)+'</p>':'')+
      (s.aff?'<p><strong style="color:var(--ink)">Affiliation.</strong> '+esc(s.aff)+'</p>':'')+
      '<p>'+esc(s.use)+'</p>'+(s.g&&s.g!=="—"?'<p style="margin:0"><span class="adm">'+esc(s.g)+'</span></p>':'')+
      (s.risk?'<div class="risk">'+esc(s.risk)+'</div>':'')+'</article>';}).join("")+'</div>';}).join("");
}
document.getElementById("qs").addEventListener("input",renderBench);
document.getElementById("benchn").textContent=BENCH.length+" sources · Admiralty graded";
renderBench();
function renderRefs(){
  var q=(document.getElementById("qr").value||"").toLowerCase().trim();
  var rows=REFS.filter(function(r){ if(!q) return true; return (r.p+" "+r.u).toLowerCase().indexOf(q)>=0;});
  document.getElementById("rcount").textContent=rows.length+" of "+REFS.length+" references";
  document.getElementById("reflist").innerHTML='<div class="refrow head"><div>ID</div><div>Publisher</div><div>Reference</div><div>Cites</div></div>'+
   rows.map(function(r){return '<div class="refrow" id="ref-'+r.i+'"><div class="rid">GC-'+r.i+'</div><div>'+esc(r.p)+'</div>'+
    '<div><a href="'+esc(r.u)+'" target="_blank" rel="noopener">'+esc(r.u.length>96?r.u.slice(0,95)+"…":r.u)+'</a></div><div class="rn">'+r.n+'</div></div>';}).join("");
}
document.getElementById("qr").addEventListener("input",renderRefs);
document.getElementById("refn").textContent=REFS.length+" unique references";
renderRefs();
document.getElementById("foot").innerHTML='GREY CARDINAL · LOOKING GLASS companion console · Edition 2026.09f · compiled 17 September 2026 from public reporting. '+
 INC.length+' events, '+SITES.length+' sited units, '+BENCH.length+' graded sources, '+REFS.length+' references. '+
 'Historical published activity only — no positions, no tracks, no targets. Assessments are the compiler’s own; this is an open-source analytic product and not an intelligence report.';

/* ═══ navigation ══════════════════════════════════════════ */
var VIEWS={
 assess:[["bluf","BLUF & key judgments"],["oob","Order of battle"],["trade","Tradecraft"]],
 geo:[["map","World map"],["record","Campaign record"],["tempo","Tempo & ledger"]],
 warn:[["iw","Indicators & warning"],["ach","Competing hypotheses"],["fc","Target forecast"]],
 coll:[["bench","Collection bench"],["src","Method & references"]]
};
var ALL=[]; for(var s0 in VIEWS) VIEWS[s0].forEach(function(v){ALL.push(v[0]);});
function showView(id){
  ALL.forEach(function(v){var n=document.getElementById("v-"+v); if(n) n.hidden=(v!==id);});
  var vb=document.querySelectorAll("#views .vbtn");
  for(var i=0;i<vb.length;i++) vb[i].classList.toggle("on",vb[i].getAttribute("data-v")===id);
  if(id==="map") requestAnimationFrame(resize);
}
function showSeg(seg,viewId){
  var sb=document.querySelectorAll(".segbtn");
  for(var i=0;i<sb.length;i++) sb[i].classList.toggle("on",sb[i].getAttribute("data-seg")===seg);
  var host=document.getElementById("views"); host.innerHTML="";
  VIEWS[seg].forEach(function(v){
    var b=document.createElement("button"); b.className="vbtn"; b.type="button"; b.setAttribute("data-v",v[0]); b.textContent=v[1];
    b.onclick=function(){showView(v[0]);}; host.appendChild(b);});
  showView(viewId||VIEWS[seg][0][0]);
}
(function(){var sb=document.querySelectorAll(".segbtn");
  for(var i=0;i<sb.length;i++)(function(b){b.onclick=function(){showSeg(b.getAttribute("data-seg"));window.scrollTo(0,0);};})(sb[i]);})();
document.addEventListener("click",function(e){
  var t=e.target;
  if(t && t.classList && t.classList.contains("ref")){
    var id=t.getAttribute("data-ref");
    document.getElementById("qr").value="";
    renderRefs(); showSeg("coll","src");
    setTimeout(function(){
      var row=document.getElementById("ref-"+id);
      if(row){ row.scrollIntoView({block:"center"}); row.classList.add("flash");
        setTimeout(function(){row.classList.remove("flash");},2200);}
    },40);
  }
});

/* ═══ boot ════════════════════════════════════════════════ */
document.getElementById("m-inc").textContent=INC.length;
document.getElementById("m-cty").textContent=(function(){var s={};INC.forEach(function(r){s[r.c]=1;});return Object.keys(s).length;})();
document.getElementById("m-site").textContent=SITES.length;
document.getElementById("m-ref").textContent=REFS.length;
document.getElementById("m-a").textContent=Math.round(INC.filter(function(r){return r.g==="A";}).length/INC.length*100)+"%";
document.getElementById("r-from").textContent=qlab(-1);
document.getElementById("r-to").textContent=qlab(QMAX);
layerNote();
showSeg("assess");
window.addEventListener("resize",function(){clearTimeout(window.__rt);window.__rt=setTimeout(resize,120);});
resize(); render();
})();
